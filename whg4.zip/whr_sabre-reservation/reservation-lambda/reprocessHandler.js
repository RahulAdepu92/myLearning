'use strict';
var aws = require('aws-sdk');
const tableDefs = require('./tableDefs');
const parseString = require('xml2js');
// const jpath = require('jspath');

const parser = new parseString.Parser({
  explicitArray: true
});
const s3 = new aws.S3({
  region: 'us-west-2'
});
const sns = new aws.SNS({
  region: 'us-west-2'
});

// Validation Flag
var valid_flag = true;
// Enviorment Variables

const redBucket = process.env.redBucket
const blueBucket = process.env.blueBucket
const errorBucket = process.env.errorBucket
const SNSTopicArn = process.env.SNSTopicArn

// Array Falttening Function
function flatten(ary) {
  var ret = [];
  for (var i = 0; i < ary.length; i++) {
    if (Array.isArray(ary[i])) {
      ret = ret.concat(flatten(ary[i]));
    } else {
      ret.push(ary[i]);
    }
  }
  return ret;
}

// XML to JSON Parser
async function createJSON(xml_buff) {

  try {
    
    let data = await parser.parseStringPromise(xml_buff);

    return data;

  } catch(e) {
    valid_flag = false;
    console.log(`ERROR while parsing the XML. Details - ${String(e)}`);
  }

}

// Function to combine all table data
async function createUberObj(xml_buff,s3outputPath) {
  try {
    let json_ = await createJSON(xml_buff);


    let uberObj = tableDefs.map(table => {

      return {
        tableName: table.tableName,
        records: flatten(table.transform(json_,s3outputPath))
      }

    })

    return uberObj;

  } catch (e) {
    console.log(e)
  }

}

// Generate Timestamp
function create_ts(){

  return (new Date().toISOString())
  
}

function generateESLogs(prc_arn,taskName,sts,srcName,targetName,uniqueID,uniqueID1,errDesc,srcTS,prcStartTS){
  var logs_json_ = { 
    "source_system" : "Sabre CR", "domain" : "Reservation", "subdomain" : "", "process_name" : "Reservation Reprocessing Notification", "process_arn" : `${prc_arn}`, 
      "task_name" : `${taskName}`, "rule_id" : "", "rule_name" : "", "status" : `${sts}`, "source_name" : `${srcName}`, "target_name" : `${targetName}`,             
      "unique_id" : `${uniqueID}`, "unique_value_1" : `${uniqueID1}`,  "error_desc" : `${errDesc}`, "design_pattern" : "REALTIME","source_system_timestamp" : `${srcTS}`,"business_date" : "", "original_file_name" : "","process_start_datetime" : `${prcStartTS}`, 
      "process_end_datetime" : `${create_ts()}`,"batch_id" : "","source_record_count" : "1","target_success_count" : "1","target_failed_count" : "0"};

  console.log(JSON.stringify(logs_json_));
}

// Main (Index) Function
module.exports.index = async (event,context) => {

    var date = new Date();
    var year = String(date.getUTCFullYear());
    var month = ('0' + String(date.getUTCMonth() + 1)).slice(-2)
    var day = ('0' + String(date.getUTCDate())).slice(-2)

    console.log(`EVENT: ${JSON.stringify(event)}`);

    let record = event.Records[0];
    let srcTS = record['eventTime']
    let key = decodeURIComponent(record.s3.object.key);
    let key_split = key.split('/')
    let seqNum = key_split[key_split.length - 1]
    var s3_path = `s3://${blueBucket}/sabre/reservation/intermediate/${year}/${month}/${day}/${seqNum}.json`

    valid_flag =  true;
    
    let s3_get_paras = {
        Bucket: redBucket,
        Key: key,
    }

    let resp = await s3.getObject(s3_get_paras).promise();
    let payload = resp.Body

    try {
        let output = await createUberObj(payload,s3_path);
        if(valid_flag === true){
            var jso1 = {};

            for (let x of output) {
            jso1[`${x.tableName}`] = x.records
            };
            // console.log(JSON.stringify(jso1))

            var echo_token_val = jso1['stg_rsv_HotelReservation'][0]['id']

            var blue_prc_start_ts =  create_ts();

            var s3_paras = {
            Key: `sabre/reservation/intermediate/${year}/${month}/${day}/${seqNum}.json`,
            Bucket: blueBucket,
            Body: JSON.stringify(jso1),
            ServerSideEncryption: "AES256"
            };

            await s3.putObject(s3_paras).promise();
            console.log(`${seqNum} successfully processed`);

            generateESLogs(context.invokedFunctionArn,'Red S3 Terminal to Blue S3 Terminal','SUCCESS',`s3://${redBucket}/${key}`,`s3://${blueBucket}/${s3_paras['Key']}`, seqNum, echo_token_val,'', srcTS, blue_prc_start_ts);

        }else{
          console.log(`${seqNum} is Malformed XML`);

          var error_prc_start_ts =  create_ts();
          
          var s3_error_paras = {
              Key: `sabre/reservation/errors/${year}/${month}/${day}/${seqNum}`,
              Bucket: errorBucket,
              Body: payload,
              ServerSideEncryption: "AES256"
          }

          await s3.putObject(s3_error_paras).promise();
          console.log(`Putting Malformed XML at S3 path: s3://${errorBucket}/${s3_error_paras['Key']}`);

          generateESLogs(context.invokedFunctionArn,'Red S3 Terminal to Blue S3 Terminal','ERROR',`s3://${redBucket}/${key}`,`s3://${errorBucket}/${s3_error_paras['Key']}`, seqNum, '','Malformed/Bad XML', srcTS, error_prc_start_ts);
        }
        
    } catch (e) {
        console.log(`ERROR: ${String(e)}`);

        var s3_error_paras = {
          Key: `sabre/reservation/errors/${year}/${month}/${day}/${seqNum}`,
          Bucket: errorBucket,
          Body: payload,
          ServerSideEncryption: "AES256"
      }
  
        await s3.putObject(s3_error_paras).promise();
  
        generateESLogs(context.invokedFunctionArn,'Reservation Reprocessing Lambda Process Failed','ERROR',`s3://${redBucket}/${key}`,`s3://${errorBucket}/${s3_error_paras['Key']}`, seqNum, '',`${String(e)}`, srcTS, error_prc_start_ts);

        const sns_paras = {
        TopicArn: SNSTopicArn,
        Subject: 'Reservation XML to JSON Transform Lambda Failed',
        Message: `ERROR Details: ${String(e)}`
        };
        await sns.publish(sns_paras).promise();

    };
};