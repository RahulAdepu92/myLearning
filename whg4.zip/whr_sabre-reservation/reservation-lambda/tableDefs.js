// const { transform } = require("lodash");
const jpath = require('jspath');

function extract(path, o) {
    let r = jpath.apply(path, o)
    if (typeof r === "undefined") {
        return ''
    } else {
        return r
    }
}

let tableDefs = [{
        tableName: "stg_rsv_Membership",
        transform: function(json,s3outputPath) {
            let ecoToken = extract('.OTA_HotelResNotifRQ.$.EchoToken[0]', json)
            let roomStays = extract('..HotelReservations.HotelReservation.RoomStays', json)
            let uniqueidid = extract('..HotelReservations.HotelReservation.UniqueID.$.ID[0]', json)
            let resstatus = extract('.OTA_HotelResNotifRQ.$.ResStatus[0]', json)
			let basicpropertyinfohotelcode = extract('.OTA_HotelResNotifRQ.HotelReservations.HotelReservation.RoomStays.RoomStay.BasicPropertyInfo.$.HotelCode[0]', json)

            var member_cnt = 0
            let records = roomStays.map(roomStay => {
                return extract('.RoomStay', roomStay).map((members, roomStayIndex) => {
                    return extract('.Memberships', members).map((member) => {
                        return extract('.Membership', member).map((attrs, attrsIndex) => {
                            return {
                                id: ecoToken,
                                roomstayseqno: String(roomStayIndex + 1),
                                memebershipseqno: String(member_cnt = member_cnt + 1),
                                programcode: extract('.$.ProgramCode[0]', attrs),
                                accountid: extract('.$.AccountID[0]', attrs),
                                bonuscode: extract('.$.BonusCode[0]', attrs),
                                pointsearned: extract('.$.PointsEarned[0]', attrs),
                                inserted_ts: '',
                                uniqueidid: uniqueidid,
                                basicpropertyinfohotelcode: basicpropertyinfohotelcode,
                                resstatus: resstatus,
                                src_file_nm: s3outputPath

                            };

                        });
                    });
                });
            });

            return records;
        }
    },
    {
        tableName: "stg_rsv_ResGuestRPH",
        transform: function(json,s3outputPath) {
            let ecoToken = extract('.OTA_HotelResNotifRQ.$.EchoToken[0]', json)
            let roomStays = extract('..HotelReservations.HotelReservation.RoomStays', json)
            let uniqueidid = extract('..HotelReservations.HotelReservation.UniqueID.$.ID[0]', json)
            let resstatus = extract('.OTA_HotelResNotifRQ.$.ResStatus[0]', json)
			let basicpropertyinfohotelcode = extract('.OTA_HotelResNotifRQ.HotelReservations.HotelReservation.RoomStays.RoomStay.BasicPropertyInfo.$.HotelCode[0]', json)

            var resGuestRPH_cnt = 0;
            let records = roomStays.map(roomStay => {
                return extract('.RoomStay', roomStay).map((resGuestRPHs, roomStayIndex) => {
                    return extract('.ResGuestRPHs', resGuestRPHs).map(resGuestRPH => {
                        return extract('.ResGuestRPH', resGuestRPH).map((attrs, attrsIndex) => {
                            return {
                                id: ecoToken,
                                roomstayseqno: String(roomStayIndex + 1),
                                resguestrphseqno: String(resGuestRPH_cnt = resGuestRPH_cnt + 1),
                                rph: extract('.$.RPH[0]', attrs),
                                inserted_ts: '',
                                uniqueidid: uniqueidid,
                                basicpropertyinfohotelcode: basicpropertyinfohotelcode,
                                resstatus: resstatus,
                                src_file_nm: s3outputPath
                            }
                        });
                    });
                });
            });
            return records;
        }
    },
    {
        tableName: "stg_rsv_ProfileInfo",
        transform: function(json,s3outputPath,seqNum) {
            let ecoToken = extract('.OTA_HotelResNotifRQ.$.EchoToken[0]', json)
            let resGuests = extract('..HotelReservations.HotelReservation.ResGuests', json)
            let uniqueidid = extract('..HotelReservations.HotelReservation.UniqueID.$.ID[0]', json)
            let resstatus = extract('.OTA_HotelResNotifRQ.$.ResStatus[0]', json)
			let basicpropertyinfohotelcode = extract('.OTA_HotelResNotifRQ.HotelReservations.HotelReservation.RoomStays.RoomStay.BasicPropertyInfo.$.HotelCode[0]', json)

            var profile_cnt = 0;
            let records = resGuests.map(resGuests => {
                return extract('.ResGuest', resGuests).map(resGuest => {
                    let resGuestRPH = extract('.$.ResGuestRPH[0]', resGuest)
                    let primaryIndicator = extract('.$.PrimaryIndicator[0]', resGuest)

                    return extract('.Profiles', resGuest).map(profiles => {
                        return extract('.ProfileInfo', profiles).map((profileInfo, profileinfoIndex) => {
                            return extract('.Profile', profileInfo).map(profile => {

                                let profileType = extract('.$.ProfileType[0]', profile)

                                let companyInfoTag = extract('.CompanyInfo', profile)

                                if (companyInfoTag.length === 0) {

                                    return extract('.Customer', profile).map(customer => {
                                        let birthdate = extract('.$.Birthdate[0]', customer)
                                        let lockoutType = extract('.$.LockoutType[0]', customer)
                                        let email_val = extract('.Email[0]', customer)
                                        let nametype = extract('.PersonName.NameType[0]', customer)
                                        let nameprefix = extract('.PersonName.NamePrefix[0]', customer)
                                        let givename = extract('.PersonName.GivenName[0]', customer)
                                        let middlename = extract('.PersonName.MiddleName[0]', customer)
                                        let surname = extract('.PersonName.Surname[0]', customer)
                                        let namesuffix = extract('.PersonName.NameSuffix[0]', customer)

                                        return {
                                            id: ecoToken,
                                            profileseqno: String(profile_cnt = profile_cnt + 1),
                                            resguestrph: resGuestRPH,
                                            primaryindicator: primaryIndicator,
                                            profiletype: profileType,
                                            birthdate: birthdate,
                                            lockouttype: lockoutType,
                                            nametype: nametype,
                                            nameprefix: nameprefix,
                                            givenname: givename,
                                            companyname: '',
                                            middlename: middlename,
                                            surname: surname,
                                            namesuffix: namesuffix,
                                            email: email_val,
                                            inserted_ts: '',
                                            uniqueidid: uniqueidid,
                                            basicpropertyinfohotelcode: basicpropertyinfohotelcode,
                                            resstatus: resstatus,
                                            src_file_nm: s3outputPath
                                        }

                                    })
                                } else {

                                    return extract('.CompanyInfo', profile).map(companyinfo => {
                                        let companyname = extract('.CompanyName', companyinfo)

                                        if (companyname.length > 1) {
                                            profile_cnt = profile_cnt + 1

                                            var company_list = [];
                                            for (let companyindex in companyname) {
                                                //    console.log(typeof(resGuests[companyindex]))
                                                if (typeof(companyname[companyindex]) === "object") {
                                                    let compval = extract('._[0]', companyname[companyindex])
                                                    company_list.push(compval)
                                                } else if (typeof(companyname[companyindex]) === "string") {
                                                    let compval = companyname[companyindex]
                                                    company_list.push(compval)
                                                }
                                            }

                                            var company_list_distinct = [...new Set(company_list)];

                                            return company_list_distinct.map(compname => {
                                                let companynamevalue = compname
                                                let email = extract('.Email[0]', companyinfo)
                                                let givenName = extract('.ContactPerson.PersonName[0].GivenName[0]', companyinfo)
                                                let surName = extract('.ContactPerson.PersonName[0].Surname[0]', companyinfo)
                                                return {
                                                    id: ecoToken,
                                                    profileseqno: String(profile_cnt),
                                                    resguestrph: resGuestRPH,
                                                    primaryindicator: primaryIndicator,
                                                    profiletype: profileType,
                                                    birthdate: '',
                                                    lockouttype: '',
                                                    nametype: '',
                                                    nameprefix: '',
                                                    givenname: givenName,
                                                    companyname: companynamevalue,
                                                    middlename: '',
                                                    surname: surName,
                                                    namesuffix: '',
                                                    email: email,
                                                    inserted_ts: '',
                                                    uniqueidid: uniqueidid,
                                                    basicpropertyinfohotelcode: basicpropertyinfohotelcode,
                                                    resstatus: resstatus,
                                                    src_file_nm: s3outputPath
                                                }
                                            });

                                        } else {
                                            let companynamevalue = extract('.CompanyName[0]', companyinfo)
                                            let email = extract('.Email[0]', companyinfo)
                                            let givenName = extract('.ContactPerson.PersonName[0].GivenName[0]', companyinfo)
                                            let surName = extract('.ContactPerson.PersonName[0].Surname[0]', companyinfo)
                                            return {
                                                id: ecoToken,
                                                profileseqno: String(profile_cnt = profile_cnt + 1),
                                                resguestrph: resGuestRPH,
                                                primaryindicator: primaryIndicator,
                                                profiletype: profileType,
                                                birthdate: '',
                                                lockouttype: '',
                                                nametype: '',
                                                nameprefix: '',
                                                givenname: givenName,
                                                companyname: companynamevalue,
                                                middlename: '',
                                                surname: surName,
                                                namesuffix: '',
                                                email: email,
                                                inserted_ts: '',
                                                uniqueidid: uniqueidid,
                                                basicpropertyinfohotelcode: basicpropertyinfohotelcode,
                                                resstatus: resstatus,
                                                src_file_nm: s3outputPath
                                            }
                                        }
                                    })
                                }
                            });
                        });
                    });
                })

            });
            return records;
        }
    },
    {
        tableName: "stg_rsv_Addr",
        transform: function(json,s3outputPath) {
            let ecoToken = extract('.OTA_HotelResNotifRQ.$.EchoToken[0]', json)
            let resGuests = extract('..HotelReservations.HotelReservation.ResGuests', json)
            let uniqueidid = extract('..HotelReservations.HotelReservation.UniqueID.$.ID[0]', json)
            let resstatus = extract('.OTA_HotelResNotifRQ.$.ResStatus[0]', json)
			let basicpropertyinfohotelcode = extract('.OTA_HotelResNotifRQ.HotelReservations.HotelReservation.RoomStays.RoomStay.BasicPropertyInfo.$.HotelCode[0]', json)

            // var profile_addr_cnt = 0;
            let records = resGuests.map(resGuests => {
                var profile_addr_cnt = 0;
                return extract('.ResGuest', resGuests).map(resGuest => {
                    return extract('.Profiles', resGuest).map(profiles => {
                        return extract('.ProfileInfo', profiles).map((profileInfo, profileInfoIndex) => {
                            return extract('.Profile', profileInfo).map(profile => {

                                let companyInfoTag = extract('.CompanyInfo', profile)

                                if (companyInfoTag.length === 0) {
                                    return extract('.Customer', profile).map(customer => {
                                        if (extract('.Address', customer).length === 0) {
                                            profile_addr_cnt = profile_addr_cnt + 1
                                            return []
                                        } else {
                                            if (extract('.Address', customer).length > 1) {
                                                profile_addr_cnt = profile_addr_cnt + 1

                                                return extract('.Address', customer).map((address, addressIndex) => {
                                                    let addressType = extract('.$.Type[0]', address)
                                                    let addressRemark = extract('.$.Remark[0]', address)
                                                    let companyName = extract('.CompanyName[0]', address)
                                                    let addressLine1 = extract('.AddressLine[0]', address)
                                                    let addressLine2 = extract('.AddressLine[1]', address)
                                                    let addressLine3 = extract('.AddressLine[2]', address)
                                                    let city = extract('.CityName[0]', address)
                                                    let statecode = extract('.StateProv.$.StateCode[0]', address)
                                                    let postalcode = extract('.PostalCode[0]', address)
                                                    let countrycode = extract('.CountryName.$.Code[0]', address)

                                                    return {
                                                        id: ecoToken,
                                                        profileseqno: String(profile_addr_cnt),
                                                        addressseqno: String(addressIndex + 1),
                                                        addresstype: addressType,
                                                        rmrk: addressRemark,
                                                        companyname: companyName,
                                                        addressline1: addressLine1,
                                                        addressline2: addressLine2,
                                                        addressline3: addressLine3,
                                                        cityname: city,
                                                        statecode: statecode,
                                                        postalcode: postalcode,
                                                        countrycode: countrycode,
                                                        inserted_ts: '',
                                                        uniqueidid: uniqueidid,
                                                        basicpropertyinfohotelcode: basicpropertyinfohotelcode,
                                                        resstatus: resstatus,
                                                        src_file_nm: s3outputPath
                                                    }
                                                })
                                            } else {
                                                return extract('.Address', customer).map((address, addressIndex) => {
                                                    let addressType = extract('.$.Type[0]', address)
                                                    let addressRemark = extract('.$.Remark[0]', address)
                                                    let companyName = extract('.CompanyName[0]', address)
                                                    let addressLine1 = extract('.AddressLine[0]', address)
                                                    let addressLine2 = extract('.AddressLine[1]', address)
                                                    let addressLine3 = extract('.AddressLine[2]', address)
                                                    let city = extract('.CityName[0]', address)
                                                    let statecode = extract('.StateProv.$.StateCode[0]', address)
                                                    let postalcode = extract('.PostalCode[0]', address)
                                                    let countrycode = extract('.CountryName.$.Code[0]', address)

                                                    return {
                                                        id: ecoToken,
                                                        profileseqno: String(profile_addr_cnt = profile_addr_cnt + 1),
                                                        addressseqno: String(addressIndex + 1),
                                                        addresstype: addressType,
                                                        rmrk: addressRemark,
                                                        companyname: companyName,
                                                        addressline1: addressLine1,
                                                        addressline2: addressLine2,
                                                        addressline3: addressLine3,
                                                        cityname: city,
                                                        statecode: statecode,
                                                        postalcode: postalcode,
                                                        countrycode: countrycode,
                                                        inserted_ts: '',
                                                        uniqueidid: uniqueidid,
                                                        basicpropertyinfohotelcode: basicpropertyinfohotelcode,
                                                        resstatus: resstatus,
                                                        src_file_nm: s3outputPath
                                                    }
                                                })
                                            }
                                        }

                                    })
                                } else {
                                    return extract('.CompanyInfo', profile).map(companyInfo => {
                                        let companyname = extract('.CompanyName', companyInfo)

                                        var company_list = [];
                                        for (let companyindex in companyname) {
                                            //    console.log(typeof(resGuests[companyindex]))
                                            if (typeof(companyname[companyindex]) === "object") {
                                                let compval = extract('._[0]', companyname[companyindex])
                                                company_list.push(compval)
                                            } else if (typeof(companyname[companyindex]) === "string") {
                                                let compval = companyname[companyindex]
                                                company_list.push(compval)
                                            }
                                        }

                                        var company_list_distinct = [...new Set(company_list)];

                                        if (extract('.AddressInfo', companyInfo).length === 0) {
                                            profile_addr_cnt = profile_addr_cnt + 1
                                            return []
                                        } else {
                                            // let companynameval = extract('.CompanyName[0]',companyInfo)
                                            if (extract('.AddressInfo', companyInfo).length > 1) {
                                                profile_addr_cnt = profile_addr_cnt + 1
                                                let addr_cnt = 0
                                                return extract('.AddressInfo', companyInfo).map((addressInfo, addressInfoIndex) => {

                                                    if (companyname.length > 1) {
                                                        return company_list_distinct.map(compname => {

                                                            let addressInfoType = extract('.$.Type[0]', addressInfo)
                                                            let addressInfoLine1 = extract('.AddressLine[0]', addressInfo)
                                                            let addressInfoLine2 = extract('.AddressLine[1]', addressInfo)
                                                            let addressInfoLine3 = extract('.AddressLine[2]', addressInfo)
                                                            let cityInfo = extract('.CityName[0]', addressInfo)
                                                            let statecodeInfo = extract('.StateProv.$.StateCode[0]', addressInfo)
                                                            let postalcodeInfo = extract('.PostalCode[0]', addressInfo)
                                                            let countrycodeInfo = extract('.CountryName.$.Code[0]', addressInfo)

                                                            return {
                                                                id: ecoToken,
                                                                profileseqno: String(profile_addr_cnt),
                                                                addressseqno: String(addr_cnt = addr_cnt + 1),
                                                                addresstype: addressInfoType,
                                                                rmrk: '',
                                                                companyname: compname,
                                                                addressline1: addressInfoLine1,
                                                                addressline2: addressInfoLine2,
                                                                addressline3: addressInfoLine3,
                                                                cityname: cityInfo,
                                                                statecode: statecodeInfo,
                                                                postalcode: postalcodeInfo,
                                                                countrycode: countrycodeInfo,
                                                                inserted_ts: '',
                                                                uniqueidid: uniqueidid,
                                                                basicpropertyinfohotelcode: basicpropertyinfohotelcode,
                                                                resstatus: resstatus,
                                                                src_file_nm: s3outputPath
                                                            }

                                                        })
                                                    } else {
                                                        let addressInfoType = extract('.$.Type[0]', addressInfo)
                                                        let addressInfoLine1 = extract('.AddressLine[0]', addressInfo)
                                                        let addressInfoLine2 = extract('.AddressLine[1]', addressInfo)
                                                        let addressInfoLine3 = extract('.AddressLine[2]', addressInfo)
                                                        let cityInfo = extract('.CityName[0]', addressInfo)
                                                        let statecodeInfo = extract('.StateProv.$.StateCode[0]', addressInfo)
                                                        let postalcodeInfo = extract('.PostalCode[0]', addressInfo)
                                                        let countrycodeInfo = extract('.CountryName.$.Code[0]', addressInfo)

                                                        return {
                                                            id: ecoToken,
                                                            profileseqno: String(profile_addr_cnt),
                                                            addressseqno: String(addr_cnt = addr_cnt + 1),
                                                            addresstype: addressInfoType,
                                                            rmrk: '',
                                                            companyname: extract('.CompanyName[0]', companyInfo),
                                                            addressline1: addressInfoLine1,
                                                            addressline2: addressInfoLine2,
                                                            addressline3: addressInfoLine3,
                                                            cityname: cityInfo,
                                                            statecode: statecodeInfo,
                                                            postalcode: postalcodeInfo,
                                                            countrycode: countrycodeInfo,
                                                            inserted_ts: '',
                                                            uniqueidid: uniqueidid,
                                                            basicpropertyinfohotelcode: basicpropertyinfohotelcode,
                                                            resstatus: resstatus,
                                                            src_file_nm: s3outputPath
                                                        }
                                                    }

                                                })
                                            } else {
                                                return extract('.AddressInfo', companyInfo).map((addressInfo, addressInfoIndex) => {
                                                    let addr_cnt = 0
                                                    if (companyname.length > 1) {
                                                        profile_addr_cnt = profile_addr_cnt + 1
                                                        return company_list_distinct.map(compname => {
                                                            let addressInfoType = extract('.$.Type[0]', addressInfo)
                                                            let addressInfoLine1 = extract('.AddressLine[0]', addressInfo)
                                                            let addressInfoLine2 = extract('.AddressLine[1]', addressInfo)
                                                            let addressInfoLine3 = extract('.AddressLine[2]', addressInfo)
                                                            let cityInfo = extract('.CityName[0]', addressInfo)
                                                            let statecodeInfo = extract('.StateProv.$.StateCode[0]', addressInfo)
                                                            let postalcodeInfo = extract('.PostalCode[0]', addressInfo)
                                                            let countrycodeInfo = extract('.CountryName.$.Code[0]', addressInfo)

                                                            return {
                                                                id: ecoToken,
                                                                profileseqno: String(profile_addr_cnt),
                                                                addressseqno: String(addr_cnt = addr_cnt + 1),
                                                                addresstype: addressInfoType,
                                                                rmrk: '',
                                                                companyname: compname,
                                                                addressline1: addressInfoLine1,
                                                                addressline2: addressInfoLine2,
                                                                addressline3: addressInfoLine3,
                                                                cityname: cityInfo,
                                                                statecode: statecodeInfo,
                                                                postalcode: postalcodeInfo,
                                                                countrycode: countrycodeInfo,
                                                                inserted_ts: '',
                                                                uniqueidid: uniqueidid,
                                                                basicpropertyinfohotelcode: basicpropertyinfohotelcode,
                                                                resstatus: resstatus,
                                                                src_file_nm: s3outputPath
                                                            }
                                                        })
                                                    } else {
                                                        let addressInfoType = extract('.$.Type[0]', addressInfo)
                                                        let addressInfoLine1 = extract('.AddressLine[0]', addressInfo)
                                                        let addressInfoLine2 = extract('.AddressLine[1]', addressInfo)
                                                        let addressInfoLine3 = extract('.AddressLine[2]', addressInfo)
                                                        let cityInfo = extract('.CityName[0]', addressInfo)
                                                        let statecodeInfo = extract('.StateProv.$.StateCode[0]', addressInfo)
                                                        let postalcodeInfo = extract('.PostalCode[0]', addressInfo)
                                                        let countrycodeInfo = extract('.CountryName.$.Code[0]', addressInfo)

                                                        return {
                                                            id: ecoToken,
                                                            profileseqno: String(profile_addr_cnt = profile_addr_cnt + 1),
                                                            addressseqno: String(addr_cnt = addr_cnt + 1),
                                                            addresstype: addressInfoType,
                                                            rmrk: '',
                                                            companyname: extract('.CompanyName[0]', companyInfo),
                                                            addressline1: addressInfoLine1,
                                                            addressline2: addressInfoLine2,
                                                            addressline3: addressInfoLine3,
                                                            cityname: cityInfo,
                                                            statecode: statecodeInfo,
                                                            postalcode: postalcodeInfo,
                                                            countrycode: countrycodeInfo,
                                                            inserted_ts: '',
                                                            uniqueidid: uniqueidid,
                                                            basicpropertyinfohotelcode: basicpropertyinfohotelcode,
                                                            resstatus: resstatus,
                                                            src_file_nm: s3outputPath
                                                        }
                                                    }

                                                })
                                            }


                                        }
                                    })
                                }
                            });
                        });
                    });
                })

            });
            return records;
        }

    },
    {
        tableName: "stg_rsv_Rate",
        transform: function(json,s3outputPath) {
            let ecoToken = extract('.OTA_HotelResNotifRQ.$.EchoToken[0]', json)
            let roomStay = extract('..HotelReservations.HotelReservation.RoomStays.RoomStay', json)
            let uniqueidid = extract('..HotelReservations.HotelReservation.UniqueID.$.ID[0]', json)
            let resstatus = extract('.OTA_HotelResNotifRQ.$.ResStatus[0]', json)
			let basicpropertyinfohotelcode = extract('.OTA_HotelResNotifRQ.HotelReservations.HotelReservation.RoomStays.RoomStay.BasicPropertyInfo.$.HotelCode[0]', json)
            let brandcode = extract('..HotelReservations.HotelReservation.RoomStays.RoomStay.BasicPropertyInfo.$.BrandCode[0]', json)
            var rate_cnt = 0;
            var RoomStayCnt = 0;

            let records = []

            for (let roomStayIndex in roomStay) {
                let roomRate = extract('.RoomRates.RoomRate', roomStay[roomStayIndex])

                for (let roomRateIndex in roomRate) {
                    let Rate = extract('.Rates.Rate', roomRate[roomRateIndex])


                    for (let rateIndex in Rate) {

                        let RatePlan = extract('.RatePlans.RatePlan', roomStay[roomStayIndex])

                        let rateplancategory = extract('.$.RatePlanCategory[0]', roomRate[roomRateIndex])
                        let roomtypecode = extract('.$.RoomTypeCode[0]', roomRate[roomRateIndex])
                        let invblockcode = extract('.$.InvBlockCode[0]', roomRate[roomRateIndex])
                        let numberofunits = extract('.$.NumberOfUnits[0]', roomRate[roomRateIndex])
                        let roomraterateplancode = extract('.$.RatePlanCode[0]', roomRate[roomRateIndex])

                        let iscommissionable = extract('.$.IsCommissionable[0]', RatePlan[roomRateIndex])
                        let commisionPercent = extract('.Commission.$.Percent[0]', RatePlan[roomRateIndex])
                        let taxinclusive = extract('.RatePlanInclusions.$.TaxInclusive[0]', RatePlan[roomRateIndex])
                        let rateplancode = extract('.$.RatePlanCode[0]', RatePlan[roomRateIndex])
                        let rateplandescription = String(extract('.RatePlanDescription.Text[0]', RatePlan[roomRateIndex]))
                        let additionaldetailtype = extract('.AdditionalDetails.AdditionalDetail.$.Type[0]', RatePlan[roomRateIndex])
                        let rateplantypecode = extract('.$.RatePlanType[0]', RatePlan[roomRateIndex])

                        let ratetimeunit = extract('.$.RateTimeUnit[0]', Rate[rateIndex])
                        let effectivedate = extract('.$.EffectiveDate[0]', Rate[rateIndex])
                        let expiredate = extract('.$.ExpireDate[0]', Rate[rateIndex])
                        let unitmultiplier = extract('.$.UnitMultiplier[0]', Rate[rateIndex])
                        let baseamountbeforetax = extract('.Base.$.AmountBeforeTax[0]', Rate[rateIndex])
                        let baseamountaftertax = extract('.Base.$.AmountAfterTax[0]', Rate[rateIndex])
                        let currencycode = extract('.Base.$.CurrencyCode[0]', Rate[rateIndex])
                        let taxesamount = extract('.Base.Taxes.$.Amount[0]', Rate[rateIndex])
                        let taxescurrencycode = extract('.Base.Taxes.$.CurrencyCode[0]', Rate[rateIndex])
                        let roomratetaxamount = extract('.Base.Taxes.$.Amount[0]', Rate[rateIndex])
                        let roomratetaxcurrencycode = extract('.Base.Taxes.$.CurrencyCode[0]', Rate[rateIndex])

                        let awardrateind = extract('.TPA_Extensions.AwardRate.$.RateQualification[0]', Rate[rateIndex])

                        records.push({
                            id: ecoToken,
                            roomstayseqno: String(roomStayIndex + 1).replace('0', ''),
                            rateseqno: String(rate_cnt = rate_cnt + 1),
                            ratetimeunit: ratetimeunit,
                            effectivedate: effectivedate,
                            expiredate: expiredate,
                            unitmultiplier: unitmultiplier,
                            base_beforetax_amt: baseamountbeforetax,
                            base_amountaftertax: baseamountaftertax,
                            base_currencycode: currencycode,
                            taxes_amount: taxesamount,
                            taxes_currency_code: taxescurrencycode,
                            rateplancategory: rateplancategory,
                            iscommissionable: iscommissionable,
                            pct: commisionPercent,
                            taxinclusive: taxinclusive,
                            cd: rateplancode,
                            rateplandescriptiontext: rateplandescription,
                            additionaldetailtype: additionaldetailtype,
                            roomtypecode: roomtypecode,
                            invblockcode: invblockcode,
                            numberofunits: numberofunits,
                            rateplancode: roomraterateplancode,
                            roomratebasetaxamount: roomratetaxamount,
                            roomratebasetaxcurrencycode: roomratetaxcurrencycode,
                            rate_plan_type_code: rateplantypecode,
                            award_rate_ind: awardrateind,
                            inserted_ts: '',
                            uniqueidid: uniqueidid,
                            basicpropertyinfohotelcode: basicpropertyinfohotelcode,
                            brandcode: brandcode,
                            resstatus: resstatus,
                            src_file_nm: s3outputPath
                        })
                    }

                }
            }

            return records;
        }
    },
    {
        tableName: "stg_rsv_Telephone",
        transform: function(json,s3outputPath) {
            let ecoToken = extract('.OTA_HotelResNotifRQ.$.EchoToken[0]', json)
            let resGuest = extract('..HotelReservations.HotelReservation.ResGuests.ResGuest', json)
            let uniqueidid = extract('..HotelReservations.HotelReservation.UniqueID.$.ID[0]', json)
            let resstatus = extract('.OTA_HotelResNotifRQ.$.ResStatus[0]', json)
			let basicpropertyinfohotelcode = extract('.OTA_HotelResNotifRQ.HotelReservations.HotelReservation.RoomStays.RoomStay.BasicPropertyInfo.$.HotelCode[0]', json)

            var profile_tel_cnt = 0;
            // var tele_cnt = 0;
            let records = resGuest.map(resguest => {
                return extract('.Profiles.ProfileInfo', resguest).map((profileinfo, profileInfoIndex) => {
                    let companyInfo = extract('.Profile.CompanyInfo', profileinfo)

                    if (companyInfo.length === 0) {
                        if (extract('.Profile.Customer.Telephone', profileinfo).length === 0) {
                            profile_tel_cnt = profile_tel_cnt + 1
                            return [];
                        } else {
                            if (extract('.Profile.Customer.Telephone', profileinfo).length > 1) {
                                profile_tel_cnt = profile_tel_cnt + 1
                                return extract('.Profile.Customer.Telephone', profileinfo).map((telephone, telephoneIndex) => {
                                    return {
                                        id: ecoToken,
                                        profileseqno: String(profile_tel_cnt),
                                        telephoneseqno: String(telephoneIndex + 1),
                                        phonetechtype: extract('.$.PhoneTechType[0]', telephone),
                                        phonenumber: extract('.$.PhoneNumber[0]', telephone),
                                        formattedind: extract('.$.FormattedInd[0]', telephone),
                                        defaultind: extract('.$.DefaultInd[0]', telephone),
                                        inserted_ts: '',
                                        uniqueidid: uniqueidid,
                                        basicpropertyinfohotelcode: basicpropertyinfohotelcode,
                                        resstatus: resstatus,
                                        src_file_nm: s3outputPath
                                    }
                                })
                            } else {
                                return extract('.Profile.Customer.Telephone', profileinfo).map((telephone, telephoneIndex) => {
                                    return {
                                        id: ecoToken,
                                        profileseqno: String(profile_tel_cnt = profile_tel_cnt + 1),
                                        telephoneseqno: String(telephoneIndex + 1),
                                        phonetechtype: extract('.$.PhoneTechType[0]', telephone),
                                        phonenumber: extract('.$.PhoneNumber[0]', telephone),
                                        formattedind: extract('.$.FormattedInd[0]', telephone),
                                        defaultind: extract('.$.DefaultInd[0]', telephone),
                                        inserted_ts: '',
                                        uniqueidid: uniqueidid,
                                        basicpropertyinfohotelcode: basicpropertyinfohotelcode,
                                        resstatus: resstatus,
                                        src_file_nm: s3outputPath
                                    }
                                })
                            }
                        }
                    } else {
                        let telephoneinfo = extract('.Profile.CompanyInfo.TelephoneInfo', profileinfo)
                        if (telephoneinfo.length === 0) {
                            if (extract('.Profile.CompanyInfo.ContactPerson.Telephone', profileinfo).length === 0) {
                                profile_tel_cnt = profile_tel_cnt + 1;
                                return [];
                            } else {
                                if (extract('.Profile.CompanyInfo.ContactPerson.Telephone', profileinfo).length > 1) {
                                    profile_tel_cnt = profile_tel_cnt + 1
                                    return extract('.Profile.CompanyInfo.ContactPerson.Telephone', profileinfo).map((tele, teleIndex) => {
                                        return {
                                            id: ecoToken,
                                            profileseqno: String(profile_tel_cnt),
                                            telephoneseqno: String(teleIndex + 1),
                                            phonetechtype: extract('.$.PhoneTechType[0]', tele),
                                            phonenumber: extract('.$.PhoneNumber[0]', tele),
                                            formattedind: extract('.$.FormattedInd[0]', tele),
                                            defaultind: extract('.$.DefaultInd[0]', tele),
                                            inserted_ts: '',
                                            uniqueidid: uniqueidid,
                                            basicpropertyinfohotelcode: basicpropertyinfohotelcode,
                                            resstatus: resstatus,
                                            src_file_nm: s3outputPath
                                        }
                                    })
                                } else {
                                    return extract('.Profile.CompanyInfo.ContactPerson.Telephone', profileinfo).map((tele, teleIndex) => {
                                        return {
                                            id: ecoToken,
                                            profileseqno: String(profile_tel_cnt = profile_tel_cnt + 1),
                                            telephoneseqno: String(teleIndex + 1),
                                            phonetechtype: extract('.$.PhoneTechType[0]', tele),
                                            phonenumber: extract('.$.PhoneNumber[0]', tele),
                                            formattedind: extract('.$.FormattedInd[0]', tele),
                                            defaultind: extract('.$.DefaultInd[0]', tele),
                                            inserted_ts: '',
                                            uniqueidid: uniqueidid,
                                            basicpropertyinfohotelcode: basicpropertyinfohotelcode,
                                            resstatus: resstatus,
                                            src_file_nm: s3outputPath
                                        }
                                    })
                                }

                            }
                        } else {
                            if (extract('.Profile.CompanyInfo.TelephoneInfo', profileinfo).length > 1) {
                                profile_tel_cnt = profile_tel_cnt + 1
                                return extract('.Profile.CompanyInfo.TelephoneInfo', profileinfo).map((teleinfo, teleinfoIndex) => {
                                    return {
                                        id: ecoToken,
                                        profileseqno: String(profile_tel_cnt),
                                        telephoneseqno: String(teleinfoIndex + 1),
                                        phonetechtype: extract('.$.PhoneTechType[0]', teleinfo),
                                        phonenumber: extract('.$.PhoneNumber[0]', teleinfo),
                                        formattedind: extract('.$.FormattedInd[0]', teleinfo),
                                        defaultind: extract('.$.DefaultInd[0]', teleinfo),
                                        inserted_ts: '',
                                        uniqueidid: uniqueidid,
                                        basicpropertyinfohotelcode: basicpropertyinfohotelcode,
                                        resstatus: resstatus,
                                        src_file_nm: s3outputPath
                                    }
                                })
                            } else {
                                return extract('.Profile.CompanyInfo.TelephoneInfo', profileinfo).map((teleinfo, teleinfoIndex) => {
                                    return {
                                        id: ecoToken,
                                        profileseqno: String(profile_tel_cnt = profile_tel_cnt + 1),
                                        telephoneseqno: String(teleinfoIndex + 1),
                                        phonetechtype: extract('.$.PhoneTechType[0]', teleinfo),
                                        phonenumber: extract('.$.PhoneNumber[0]', teleinfo),
                                        formattedind: extract('.$.FormattedInd[0]', teleinfo),
                                        defaultind: extract('.$.DefaultInd[0]', teleinfo),
                                        inserted_ts: '',
                                        uniqueidid: uniqueidid,
                                        basicpropertyinfohotelcode: basicpropertyinfohotelcode,
                                        resstatus: resstatus,
                                        src_file_nm: s3outputPath
                                    }
                                })
                            }
                        }

                    }
                })
            })
            return records;
        }
    },
    {
        tableName: "stg_rsv_PaymentAccepted",
        transform: function(json,s3outputPath) {
            let ecoToken = extract('.OTA_HotelResNotifRQ.$.EchoToken[0]', json)
            let roomStay = extract('..HotelReservations.HotelReservation.RoomStays.RoomStay', json)
            let uniqueidid = extract('..HotelReservations.HotelReservation.UniqueID.$.ID[0]', json)
            let resstatus = extract('.OTA_HotelResNotifRQ.$.ResStatus[0]', json)
			let basicpropertyinfohotelcode = extract('.OTA_HotelResNotifRQ.HotelReservations.HotelReservation.RoomStays.RoomStay.BasicPropertyInfo.$.HotelCode[0]', json)

            var final_records = [];
            var RoomStayCnt = 0;

            for (let roomStay_record in roomStay) {

                var roomStayIndex = String(RoomStayCnt + 1)

                let gurantee = extract('.Guarantee', roomStay[roomStay_record])
                let depositpayments = extract('.DepositPayments', roomStay[roomStay_record])

                var gunt_cnt = 0;

                for (let gurantee_record in gurantee) {

                    let guaranteeaccepted = extract('.GuaranteesAccepted.GuaranteeAccepted', gurantee[gurantee_record])

                    if (guaranteeaccepted.length === 0) {
                        var nm = extract('.GuaranteeDescription.$.Name[0]', gurantee[gurantee_record])
                        var output = {
                            id: ecoToken,
                            roomstayseqno: roomStayIndex,
                            paymentacceptedseqno: String(gunt_cnt = gunt_cnt + 1),
                            guaranteecode: extract('.$.GuaranteeCode[0]', gurantee[gurantee_record]),
                            guaranteetype: extract('.$.GuaranteeType[0]', gurantee[gurantee_record]),
                            cardtype: '',
                            cardcode: '',
                            nm: nm,
                            guaranteetext: extract('.GuaranteeDescription.Text[0]', gurantee[gurantee_record]),
                            paymenttransactiontypecode: '',
                            directbillid: '',
                            voucherseriescode: '',
                            loyalty_redemption_qty: '',
                            loyalty_certificate_num: '',
                            inserted_ts: '',
                            uniqueidid: uniqueidid,
                            basicpropertyinfohotelcode: basicpropertyinfohotelcode,
                            resstatus: resstatus,
                            src_file_nm: s3outputPath
                        }
                        final_records.push(output)
                    } else {

                        for (let guranteeAccepted_record in guaranteeaccepted) {

                            var nm = extract('.PaymentCard.CardHolderName[0]', guaranteeaccepted[guranteeAccepted_record])

                            var output = {
                                id: ecoToken,
                                roomstayseqno: roomStayIndex,
                                paymentacceptedseqno: String(gunt_cnt = gunt_cnt + 1),
                                guaranteecode: extract('.$.GuaranteeCode[0]', gurantee[gurantee_record]),
                                guaranteetype: extract('.$.GuaranteeType[0]', gurantee[gurantee_record]),
                                cardtype: extract('.PaymentCard.$.CardType[0]', guaranteeaccepted[guranteeAccepted_record]),
                                cardcode: extract('.PaymentCard.$.CardCode[0]', guaranteeaccepted[guranteeAccepted_record]),
                                nm: nm,
                                guaranteetext: extract('.GuaranteeDescription.Text[0]', gurantee[gurantee_record]),
                                paymenttransactiontypecode: '',
                                directbillid: '',
                                voucherseriescode: '',
                                loyalty_redemption_qty: extract('.LoyaltyRedemption.$.RedemptionQuantity[0]', guaranteeaccepted[guranteeAccepted_record]),
                                loyalty_certificate_num: extract('.LoyaltyRedemption.LoyaltyCertificate.$.CertificateNumber[0]', guaranteeaccepted[guranteeAccepted_record]),
                                inserted_ts: '',
                                uniqueidid: uniqueidid,
                                basicpropertyinfohotelcode: basicpropertyinfohotelcode,
                                resstatus: resstatus,
                                src_file_nm: s3outputPath
                            }
                            final_records.push(output)
                        }
                    }

                }

                let gPayment = extract('.GuaranteePayment', depositpayments)
                for (let gpayment_record in gPayment) {
                    let APayment = extract('.AcceptedPayments.AcceptedPayment', gPayment[gpayment_record])
                    for (let acceptedPayment_record in APayment) {

                        var output = {
                            id: ecoToken,
                            roomstayseqno: roomStayIndex,
                            paymentacceptedseqno: String(gunt_cnt = gunt_cnt + 1),
                            guaranteecode: '',
                            guaranteetype: '',
                            cardtype: extract('.PaymentCard.$.CardType[0]', APayment[acceptedPayment_record]),
                            cardcode: extract('.PaymentCard.$.CardCode[0]', APayment[acceptedPayment_record]),
                            nm: extract('.PaymentCard.CardHolderName[0]', APayment[acceptedPayment_record]),
                            guaranteetext: '',
                            paymenttransactiontypecode: extract('.$.PaymentTransactionTypeCode[0]', APayment[acceptedPayment_record]),
                            directbillid: extract('.DirectBill.$.DirectBillID[0]', APayment[acceptedPayment_record]),
                            voucherseriescode: extract('.Voucher.$.SeriesCode[0]', APayment[acceptedPayment_record]),
                            loyalty_redemption_qty: '',
                            loyalty_certificate_num: '',
                            inserted_ts: '',
                            uniqueidid: uniqueidid,
                            basicpropertyinfohotelcode: basicpropertyinfohotelcode,
                            resstatus: resstatus,
                            src_file_nm: s3outputPath
                        }
                        final_records.push(output)
                    }
                }
            }
            return final_records;
        }
    },
    {
        tableName: "stg_rsv_GuestCount",
        transform: function(json,s3outputPath) {
            let ecoToken = extract('.OTA_HotelResNotifRQ.$.EchoToken[0]', json)
            let roomStay = extract('..HotelReservations.HotelReservation.RoomStays.RoomStay', json)
            let uniqueidid = extract('..HotelReservations.HotelReservation.UniqueID.$.ID[0]', json)
            let resstatus = extract('.OTA_HotelResNotifRQ.$.ResStatus[0]', json)
			let basicpropertyinfohotelcode = extract('.OTA_HotelResNotifRQ.HotelReservations.HotelReservation.RoomStays.RoomStay.BasicPropertyInfo.$.HotelCode[0]', json)

            var guest_count_cnt = 0;
            let records = roomStay.map((roomstay, roomstayIndex) => {
                return extract('.GuestCounts.GuestCount', roomstay).map((guestcount, guestcountIndex) => {
                    let agequalifyingcode = extract('.$.AgeQualifyingCode[0]', guestcount)
                    let guestcnt = extract('.$.Count[0]', guestcount)

                    return {
                        id: ecoToken,
                        roomstayseqno: String(roomstayIndex + 1),
                        guestcountseqno: String(guest_count_cnt = guest_count_cnt + 1),
                        agequalifyingcode: agequalifyingcode,
                        cnt: guestcnt,
                        inserted_ts: '',
                        uniqueidid: uniqueidid,
                        basicpropertyinfohotelcode: basicpropertyinfohotelcode,
                        resstatus: resstatus,
                        src_file_nm: s3outputPath
                    }
                })
            })
            return records;
        }
    },
    {
        tableName: "stg_rsv_Comments",
        transform: function(json,s3outputPath) {
            let ecoToken = extract('.OTA_HotelResNotifRQ.$.EchoToken[0]', json)
            let roomStay = extract('..HotelReservations.HotelReservation.RoomStays.RoomStay', json)
            let uniqueidid = extract('..HotelReservations.HotelReservation.UniqueID.$.ID[0]', json)
            let resstatus = extract('.OTA_HotelResNotifRQ.$.ResStatus[0]', json)
			let basicpropertyinfohotelcode = extract('.OTA_HotelResNotifRQ.HotelReservations.HotelReservation.RoomStays.RoomStay.BasicPropertyInfo.$.HotelCode[0]', json)

            var comment_cnt = 0;
            let records = roomStay.map((roomstay, roomstayIndex) => {
                return extract('.Comments.Comment', roomstay).map((comment, commentIndex) => {
                    return {
                        id: ecoToken,
                        roomstayseqno: String(roomstayIndex + 1),
                        commentsseqno: String(comment_cnt = comment_cnt + 1),
                        guestviewable: extract('.$.GuestViewable[0]', comment),
                        txt: extract('.Text[0]', comment),
                        inserted_ts: '',
                        uniqueidid: uniqueidid,
                        basicpropertyinfohotelcode: basicpropertyinfohotelcode,
                        resstatus: resstatus,
                        src_file_nm: s3outputPath
                    }
                })
            })
            return records;
        }
    },
    {
        tableName: "stg_rsv_CustLoyalty",
        transform: function(json,s3outputPath) {
            let ecoToken = extract('.OTA_HotelResNotifRQ.$.EchoToken[0]', json)
            let resGuest = extract('..HotelReservations.HotelReservation.ResGuests.ResGuest', json)
            let uniqueidid = extract('..HotelReservations.HotelReservation.UniqueID.$.ID[0]', json)
            let resstatus = extract('.OTA_HotelResNotifRQ.$.ResStatus[0]', json)
			let basicpropertyinfohotelcode = extract('.OTA_HotelResNotifRQ.HotelReservations.HotelReservation.RoomStays.RoomStay.BasicPropertyInfo.$.HotelCode[0]', json)

            var profile_cust_loyalty_cnt = 0;
            let records = resGuest.map(resguest => {
                return extract('.Profiles.ProfileInfo', resguest).map((profileinfo, profileinfoIndex) => {
                    if (extract('.Profile.Customer.CustLoyalty', profileinfo).length === 0) {
                        profile_cust_loyalty_cnt = profile_cust_loyalty_cnt + 1
                        return [];
                    } else {
                        if (extract('.Profile.Customer.CustLoyalty', profileinfo).length > 1) {
                            profile_cust_loyalty_cnt = profile_cust_loyalty_cnt + 1
                            return extract('.Profile.Customer.CustLoyalty', profileinfo).map((custloyalty, custloyaltyIndex) => {
                                let programid = extract('.$.ProgramID[0]', custloyalty)
                                let membershipid = extract('.$.MembershipID[0]', custloyalty)
                                let loyaltylevel = extract('.$.LoyalLevel[0]', custloyalty)
                                let effectivedate = extract('.$.EffectiveDate[0]', custloyalty)
                                let expiredate = extract('.$.ExpireDate[0]', custloyalty)
                                let signupdate = extract('.$.SignupDate[0]', custloyalty)

                                return {
                                    id: ecoToken,
                                    profileseqno: String(profile_cust_loyalty_cnt),
                                    custloyaltyseqno: String(custloyaltyIndex + 1),
                                    programid: programid,
                                    membershipid: membershipid,
                                    loyallevel: loyaltylevel,
                                    effectivedate: effectivedate,
                                    expiredate: expiredate,
                                    signupdate: signupdate,
                                    inserted_ts: '',
                                    uniqueidid: uniqueidid,
                                    basicpropertyinfohotelcode: basicpropertyinfohotelcode,
                                    resstatus: resstatus,
                                    src_file_nm: s3outputPath
                                }
                            })
                        } else {
                            return extract('.Profile.Customer.CustLoyalty', profileinfo).map((custloyalty, custloyaltyIndex) => {
                                let programid = extract('.$.ProgramID[0]', custloyalty)
                                let membershipid = extract('.$.MembershipID[0]', custloyalty)
                                let loyaltylevel = extract('.$.LoyalLevel[0]', custloyalty)
                                let effectivedate = extract('.$.EffectiveDate[0]', custloyalty)
                                let expiredate = extract('.$.ExpireDate[0]', custloyalty)
                                let signupdate = extract('.$.SignupDate[0]', custloyalty)

                                return {
                                    id: ecoToken,
                                    profileseqno: String(profile_cust_loyalty_cnt = profile_cust_loyalty_cnt + 1),
                                    custloyaltyseqno: String(custloyaltyIndex + 1),
                                    programid: programid,
                                    membershipid: membershipid,
                                    loyallevel: loyaltylevel,
                                    effectivedate: effectivedate,
                                    expiredate: expiredate,
                                    signupdate: signupdate,
                                    inserted_ts: '',
                                    uniqueidid: uniqueidid,
                                    basicpropertyinfohotelcode: basicpropertyinfohotelcode,
                                    resstatus: resstatus,
                                    src_file_nm: s3outputPath
                                }
                            })
                        }
                    }
                })
            })
            return records;
        }
    },
    {
        tableName: "stg_rsv_Guaranteepayment",
        transform: function(json,s3outputPath) {
            let ecoToken = extract('.OTA_HotelResNotifRQ.$.EchoToken[0]', json)
            let roomStay = extract('..HotelReservations.HotelReservation.RoomStays.RoomStay', json)
            let uniqueidid = extract('..HotelReservations.HotelReservation.UniqueID.$.ID[0]', json)
            let resstatus = extract('.OTA_HotelResNotifRQ.$.ResStatus[0]', json)
			let basicpropertyinfohotelcode = extract('.OTA_HotelResNotifRQ.HotelReservations.HotelReservation.RoomStays.RoomStay.BasicPropertyInfo.$.HotelCode[0]', json)

            let records = roomStay.map((roomstay, roomstayIndex) => {
                let gurantee = extract('.Guarantee', roomstay)
                let depositpayments = extract('.DepositPayments', roomstay)

                if (gurantee.length === 0 && depositpayments.length === 0) {
                    return []
                } else {
                    if (depositpayments.length === 0) {
                        return [];
                    } else {
                        if (gurantee.length === 0) {
                            return extract('.GuaranteePayment', depositpayments).map((gpayment, gpaymentIndex) => {
                                let noofnights = extract('.AmountPercent.$.NumberOfNights[0]', gpayment)
                                let curcode = extract('.AmountPercent.$.CurrencyCode[0]', gpayment)
                                let pct = extract('.AmountPercent.$.Percent[0]', gpayment)
                                let amt = extract('.AmountPercent.$.Amount[0]', gpayment)

                                return extract('.Deadline', gpayment).map(deadline => {

                                    return {
                                        id: ecoToken,
                                        roomstayseqno: String(roomstayIndex + 1),
                                        guaranteepaymentseqno: String(gpaymentIndex + 1),
                                        numberofnights: noofnights,
                                        currencycode: curcode,
                                        pct: pct,
                                        amt: amt,
                                        absol_dead_ln: extract('.$.AbsoluteDeadline[0]', deadline),
                                        offset_tm_unit_txt: extract('.$.OffsetTimeUnit[0]', deadline),
                                        offset_unit_mult_txt: extract('.$.OffsetUnitMultiplier[0]', deadline),
                                        offset_drop_tm_txt: extract('.$.OffsetDropTime[0]', deadline),
                                        guar_nm: '',
                                        guar_dscr_txt: '',
                                        inserted_ts: '',
                                        uniqueidid: uniqueidid,
                                        basicpropertyinfohotelcode: basicpropertyinfohotelcode,
                                        resstatus: resstatus,
                                        src_file_nm: s3outputPath
                                    }
                                });
                            });
                        } else {
                            return gurantee.map(gurante => {
                                var gurante_nm = extract('.GuaranteeDescription.$.Name[0]', gurante);
                                var gurante_txt = extract('.GuaranteeDescription.Text[0]', gurante);

                                return extract('.GuaranteePayment', depositpayments).map((gpayment, gpaymentIndex) => {
                                    let noofnights = extract('.AmountPercent.$.NumberOfNights[0]', gpayment)
                                    let curcode = extract('.AmountPercent.$.CurrencyCode[0]', gpayment)
                                    let pct = extract('.AmountPercent.$.Percent[0]', gpayment)
                                    let amt = extract('.AmountPercent.$.Amount[0]', gpayment)

                                    return extract('.Deadline', gpayment).map(deadline => {

                                        return {
                                            id: ecoToken,
                                            roomstayseqno: String(roomstayIndex + 1),
                                            guaranteepaymentseqno: String(gpaymentIndex + 1),
                                            numberofnights: noofnights,
                                            currencycode: curcode,
                                            pct: pct,
                                            amt: amt,
                                            absol_dead_ln: extract('.$.AbsoluteDeadline[0]', deadline),
                                            offset_tm_unit_txt: extract('.$.OffsetTimeUnit[0]', deadline),
                                            offset_unit_mult_txt: extract('.$.OffsetUnitMultiplier[0]', deadline),
                                            offset_drop_tm_txt: extract('.$.OffsetDropTime[0]', deadline),
                                            guar_nm: gurante_nm,
                                            guar_dscr_txt: gurante_txt,
                                            inserted_ts: '',
                                            uniqueidid: uniqueidid,
                                            basicpropertyinfohotelcode: basicpropertyinfohotelcode,
                                            resstatus: resstatus,
                                            src_file_nm: s3outputPath
                                        }
                                    });
                                });
                            })
                        }
                    }
                }
            });
            return records;
        }
    },
    {
        tableName: "stg_rsv_HotelReservationId",
        transform: function(json,s3outputPath) {
            let ecoToken = extract('.OTA_HotelResNotifRQ.$.EchoToken[0]', json)
            let hotelresid = extract('..HotelReservations.HotelReservation.ResGlobalInfo.HotelReservationIDs.HotelReservationID', json)
            let uniqueidid = extract('..HotelReservations.HotelReservation.UniqueID.$.ID[0]', json)
            let resstatus = extract('.OTA_HotelResNotifRQ.$.ResStatus[0]', json)
			let basicpropertyinfohotelcode = extract('.OTA_HotelResNotifRQ.HotelReservations.HotelReservation.RoomStays.RoomStay.BasicPropertyInfo.$.HotelCode[0]', json)
            let brandcode = extract('..HotelReservations.HotelReservation.RoomStays.RoomStay.BasicPropertyInfo.$.BrandCode[0]', json)
            let records = hotelresid.map((hotelresid, hotelresidIndex) => {
                return {
                    id: ecoToken,
                    hotelreservationidseqno: String(hotelresidIndex + 1),
                    resid_type: extract('.$.ResID_Type[0]', hotelresid),
                    resid_value: extract('.$.ResID_Value[0]', hotelresid),
                    resid_source: extract('.$.ResID_Source[0]', hotelresid),
                    forguest: extract('.$.ForGuest[0]', hotelresid),
                    inserted_ts: '',
                    uniqueidid: uniqueidid,
                    basicpropertyinfohotelcode: basicpropertyinfohotelcode,
                    resstatus: resstatus,
                    brandcode: brandcode,
                    src_file_nm: s3outputPath
                }
            });
            return records;
        }
    },
    {
        tableName: "stg_rsv_Roomstay",
        transform: function(json,s3outputPath) {
            let ecoToken = extract('.OTA_HotelResNotifRQ.$.EchoToken[0]', json)
            let roomStay = extract('..HotelReservations.HotelReservation.RoomStays.RoomStay', json)
            let uniqueidid = extract('..HotelReservations.HotelReservation.UniqueID.$.ID[0]', json)
            let resstatus = extract('.OTA_HotelResNotifRQ.$.ResStatus[0]', json)
            
			

            let records = roomStay.map((roomstay, roomstayIndex) => {
                return {
                    id: ecoToken,
                    roomstayseqno: String(roomstayIndex + 1),
                    guestcountisperroom: extract('.GuestCounts.$.IsPerRoom[0]', roomstay),
                    promotioncode: extract('.$.PromotionCode[0]', roomstay),
                    marketcode: extract('.$.MarketCode[0]', roomstay),
                    sourceofbusiness: extract('.$.SourceOfBusiness[0]', roomstay),
                    timespan_start: extract('.TimeSpan.$.Start[0]', roomstay),
                    timespan_end: extract('.TimeSpan.$.End[0]', roomstay),
                    totalcurrencycode: extract('.Total.$.CurrencyCode[0]', roomstay),
                    totalamountbeforetax: extract('.Total.$.AmountBeforeTax[0]', roomstay),
                    totalamountaftertax: extract('.Total.$.AmountAfterTax[0]', roomstay),
                    totaltaxesamount: extract('.Total.Taxes.$.Amount[0]', roomstay),
                    totaltaxescurrencycode: extract('.Total.Taxes.$.CurrencyCode[0]', roomstay),
                    priceviewable: extract('.BookingRules.BookingRule.$.PriceViewable[0]', roomstay),
                    basicpropertyinfobrandcode: extract('.BasicPropertyInfo.$.BrandCode[0]', roomstay),
                    basicpropertyinfohotelcode: extract('.BasicPropertyInfo.$.HotelCode[0]', roomstay),
                    basicpropertyinfochaincode: extract('.BasicPropertyInfo.$.ChainCode[0]', roomstay),
                    check_in_date: extract('..HotelReservations.HotelReservation.ResGuests.ResGuest[0].TPA_Extensions[0].CheckIn[0]', json),
                    check_out_date: extract('..HotelReservations.HotelReservation.ResGuests.ResGuest[0].TPA_Extensions[0].CheckOut[0]', json),
                    inserted_ts: '',
                    uniqueidid: uniqueidid,
                    resstatus: resstatus,
                    src_file_nm: s3outputPath

                }
            });
            return records;
        }
    },
    {
        tableName: "stg_rsv_HotelReservation",
        transform: function(json,s3outputPath) {
            let ecoToken = extract('.OTA_HotelResNotifRQ.$.EchoToken[0]', json)
            let resstatus = extract('.OTA_HotelResNotifRQ.$.ResStatus[0]', json)
            let createdatetime = extract('..HotelReservations.HotelReservation.$.CreateDateTime[0]', json)
            let creatorid = extract('..HotelReservations.HotelReservation.$.CreatorID[0]', json)
            let lastmodifydatetime = extract('..HotelReservations.HotelReservation.$.LastModifyDateTime[0]', json)
            let lastmodifierid = extract('..HotelReservations.HotelReservation.$.LastModifierID[0]', json)
            let uniqueidtype = extract('..HotelReservations.HotelReservation.UniqueID.$.Type[0]', json)
            let uniqueidid = extract('..HotelReservations.HotelReservation.UniqueID.$.ID[0]', json)
            let reservationstatus = extract('..HotelReservations.HotelReservation.$.ResStatus[0]', json)
            let usdexchangerates = extract('..HotelReservations.HotelReservation.TPA_Extensions.ExchangeRates.$.USD[0]', json)
            let eurexchangerates = extract('..HotelReservations.HotelReservation.TPA_Extensions.ExchangeRates.$.EUR[0]', json)
            let transmissiontimestamp = extract('.OTA_HotelResNotifRQ.$.TimeStamp[0]', json)
            let cancelpenaltypolicycode = extract('...HotelReservations.HotelReservation.ResGlobalInfo.CancelPenalties.CancelPenalty.$.PolicyCode[0]', json)
            let srcbuscrocode = extract('..HotelReservations.HotelReservation.TPA_Extensions.SourceOfBusiness.$.CroCode[0]', json)
            let enrollmentid = extract('..HotelReservations.HotelReservation.ResGuests.ResGuest[0].TPA_Extensions[0].Enrollment.$.EnrollmentIndicator[0]', json)
            let lastmodchanneltype = extract('..HotelReservations.HotelReservation.TPA_Extensions.LastModifyingChannel.$.Type[0]', json)
            let lastmodchannelcompanycode = extract('..HotelReservations.HotelReservation.TPA_Extensions.LastModifyingChannel.CompanyName.$.Code[0]', json)
            let lastmodchannelcompanyname = extract('..HotelReservations.HotelReservation.TPA_Extensions.LastModifyingChannel.CompanyName._[0]', json)
            let confrmdate = extract('..HotelReservations.HotelReservation.TPA_Extensions.ConfirmDate.$.ConfirmDateTime[0]', json)

            let coupn_cd = extract('..HotelReservations.HotelReservation.TPA_Extensions.CouponOffers.CouponOffer.$.CouponCode[0]', json)
            let offr_cd = extract('..HotelReservations.HotelReservation.TPA_Extensions.CouponOffers.CouponOffer.$.OfferCode[0]', json)
            let scndry_sts = extract('..HotelReservations.HotelReservation.TPA_Extensions.OnPropertyStatus[0]', json)

            let rsrv_lylty_src_nm = extract('..HotelReservations.HotelReservation.TPA_Extensions.LoyaltySources.LoyaltySource.$.Name[0]', json)
            let rsrv_lylty_src_cd = extract('..HotelReservations.HotelReservation.TPA_Extensions.LoyaltySources.LoyaltySource.$.Code[0]', json)

			let basicpropertyinfohotelcode = extract('.OTA_HotelResNotifRQ.HotelReservations.HotelReservation.RoomStays.RoomStay.BasicPropertyInfo.$.HotelCode[0]', json)
            let brandcode = extract('..HotelReservations.HotelReservation.RoomStays.RoomStay.BasicPropertyInfo.$.BrandCode[0]', json)
            let comment = extract('..HotelReservations.HotelReservation.ResGlobalInfo.Comments.Comment', json)

            var cancelreasoncode = '';
            var cancelreason = '';
            var cancelcomment = '';

            if (comment.length === 0) {
                cancelreasoncode = '';
                cancelreason = '';
                cancelcomment = '';
            } else {
                comment.forEach(comment => {
                    if (extract('.$.Name[0]', comment) === 'CancelReasonCode') {
                        cancelreasoncode = extract('.Text[0]', comment);
                    } else if (extract('.$.Name[0]', comment) === 'CancelReason') {
                        cancelreason = extract('.Text[0]', comment);
                    } else if (extract('.$.Name[0]', comment) === 'CancelComment') {
                        cancelcomment = extract('.Text[0]', comment);
                    }
                });
            }

            let requestortype = extract('.OTA_HotelResNotifRQ.POS.Source[0].RequestorID.$.Type[0]', json)
            let requestorid = extract('.OTA_HotelResNotifRQ.POS.Source[0].RequestorID.$.ID[0]', json)
            let primarychanneltype = extract('.OTA_HotelResNotifRQ.POS.Source[0].BookingChannel.$.Type[0]', json)
            let primarychannelid = extract('.OTA_HotelResNotifRQ.POS.Source[0].BookingChannel.$.Primary[0]', json)
            let primarychannelcompanycode = extract('.OTA_HotelResNotifRQ.POS.Source[0].BookingChannel.CompanyName.$.Code[0]', json)
            let primarychannelcompanyname = extract('.OTA_HotelResNotifRQ.POS.Source[0].BookingChannel.CompanyName._[0]', json)

            let source_arr_len = extract('.OTA_HotelResNotifRQ.POS.Source', json).length

            if (source_arr_len >= 1 && source_arr_len < 3) {
                let secchannelcompanycode = extract('.OTA_HotelResNotifRQ.POS.Source[1].BookingChannel.CompanyName.$.Code[0]', json)
                if (secchannelcompanycode === 'VDN') {
                    let secchannelcompanyname = extract('.OTA_HotelResNotifRQ.POS.Source[1].BookingChannel.CompanyName._[0]', json)
                    var records = [{
                        id: ecoToken,
                        coupn_cd: coupn_cd,
                        offr_cd: offr_cd,
                        scndry_sts: scndry_sts,
                        resstatus: resstatus,
                        rsrv_lylty_src_nm : rsrv_lylty_src_nm,
                        rsrv_lylty_src_cd : rsrv_lylty_src_cd,
                        requestortype: requestortype,
                        requestortypeid: requestorid,
                        primarychanneltype: primarychanneltype,
                        primarychannelind: primarychannelid,
                        primarychannelcompanycode: primarychannelcompanycode,
                        primarychannelcompanyname: primarychannelcompanyname,
                        secondarychanneltype: '',
                        secondarychannelind: '',
                        secondarychannelcompanycode: '',
                        secondarychannelcompanyname: '',
                        createdatetime: createdatetime,
                        creatorid: creatorid,
                        lastmodifydatetime: lastmodifydatetime,
                        lastmodifierid: lastmodifierid,
                        uniqueidtype: uniqueidtype,
                        uniqueidid: uniqueidid,
                        reservationstatus: reservationstatus,
                        usd_exchange_rate: usdexchangerates,
                        eur_exchange_rate: eurexchangerates,
                        transmission_timestamp: transmissiontimestamp,
                        cancelpenaltypolicycode: cancelpenaltypolicycode,
                        cancelcommenttxt: cancelcomment,
                        cancelreasontxt: cancelreason,
                        cancelreasoncdtxt: cancelreasoncode,
                        sourceofbusinesscrocode: srcbuscrocode,
                        enrolment_ind: enrollmentid,
                        vdn_comp_cd: secchannelcompanyname,
                        lastmodifyingchanneltype: lastmodchanneltype,
                        lastmodifyingchannelcompanycode: lastmodchannelcompanycode,
                        lastmodifyingchannelcompanyname: lastmodchannelcompanyname,
                        confirmdatetime: confrmdate,
                        inserted_ts: '',
                        basicpropertyinfohotelcode: basicpropertyinfohotelcode,
                        brandcode: brandcode,
                        src_file_nm: s3outputPath
                    }]
                } else {
                    let secchanneltype = extract('.OTA_HotelResNotifRQ.POS.Source[1].BookingChannel.$.Type[0]', json)
                    let secchannelid = extract('.OTA_HotelResNotifRQ.POS.Source[1].BookingChannel.$.Primary[0]', json)
                    let secchannelcompanycode = extract('.OTA_HotelResNotifRQ.POS.Source[1].BookingChannel.CompanyName.$.Code[0]', json)
                    let secchannelcompanyname = extract('.OTA_HotelResNotifRQ.POS.Source[1].BookingChannel.CompanyName._[0]', json)

                    var records = [{
                        id: ecoToken,
                        coupn_cd: coupn_cd,
                        offr_cd: offr_cd,
                        scndry_sts: scndry_sts,
                        resstatus: resstatus,
                        rsrv_lylty_src_nm : rsrv_lylty_src_nm,
                        rsrv_lylty_src_cd : rsrv_lylty_src_cd,
                        requestortype: requestortype,
                        requestortypeid: requestorid,
                        primarychanneltype: primarychanneltype,
                        primarychannelind: primarychannelid,
                        primarychannelcompanycode: primarychannelcompanycode,
                        primarychannelcompanyname: primarychannelcompanyname,
                        secondarychanneltype: secchanneltype,
                        secondarychannelind: secchannelid,
                        secondarychannelcompanycode: secchannelcompanycode,
                        secondarychannelcompanyname: secchannelcompanyname,
                        createdatetime: createdatetime,
                        creatorid: creatorid,
                        lastmodifydatetime: lastmodifydatetime,
                        lastmodifierid: lastmodifierid,
                        uniqueidtype: uniqueidtype,
                        uniqueidid: uniqueidid,
                        reservationstatus: reservationstatus,
                        usd_exchange_rate: usdexchangerates,
                        eur_exchange_rate: eurexchangerates,
                        transmission_timestamp: transmissiontimestamp,
                        cancelpenaltypolicycode: cancelpenaltypolicycode,
                        cancelcommenttxt: cancelcomment,
                        cancelreasontxt: cancelreason,
                        cancelreasoncdtxt: cancelreasoncode,
                        sourceofbusinesscrocode: srcbuscrocode,
                        enrolment_ind: enrollmentid,
                        vdn_comp_cd: '',
                        lastmodifyingchanneltype: lastmodchanneltype,
                        lastmodifyingchannelcompanycode: lastmodchannelcompanycode,
                        lastmodifyingchannelcompanyname: lastmodchannelcompanyname,
                        confirmdatetime: confrmdate,
                        inserted_ts: '',
                        basicpropertyinfohotelcode: basicpropertyinfohotelcode,
                        brandcode: brandcode,
                        src_file_nm: s3outputPath
                    }]
                }

            } else if (source_arr_len > 2) {
                let secchanneltype = extract('.OTA_HotelResNotifRQ.POS.Source[1].BookingChannel.$.Type[0]', json)
                let secchannelid = extract('.OTA_HotelResNotifRQ.POS.Source[1].BookingChannel.$.Primary[0]', json)
                let secchannelcompanycode = extract('.OTA_HotelResNotifRQ.POS.Source[1].BookingChannel.CompanyName.$.Code[0]', json)
                let secchannelcompanyname = extract('.OTA_HotelResNotifRQ.POS.Source[1].BookingChannel.CompanyName._[0]', json)

                let thirdcompanycode = extract('.OTA_HotelResNotifRQ.POS.Source[2].BookingChannel.CompanyName._[0]', json)

                var records = [{
                    id: ecoToken,
                    coupn_cd: coupn_cd,
                    offr_cd: offr_cd,
                    scndry_sts: scndry_sts,
                    resstatus: resstatus,
                    rsrv_lylty_src_nm : rsrv_lylty_src_nm,
                    rsrv_lylty_src_cd : rsrv_lylty_src_cd,
                    requestortype: requestortype,
                    requestortypeid: requestorid,
                    primarychanneltype: primarychanneltype,
                    primarychannelind: primarychannelid,
                    primarychannelcompanycode: primarychannelcompanycode,
                    primarychannelcompanyname: primarychannelcompanyname,
                    secondarychanneltype: secchanneltype,
                    secondarychannelind: secchannelid,
                    secondarychannelcompanycode: secchannelcompanycode,
                    secondarychannelcompanyname: secchannelcompanyname,
                    createdatetime: createdatetime,
                    creatorid: creatorid,
                    lastmodifydatetime: lastmodifydatetime,
                    lastmodifierid: lastmodifierid,
                    uniqueidtype: uniqueidtype,
                    uniqueidid: uniqueidid,
                    reservationstatus: reservationstatus,
                    usd_exchange_rate: usdexchangerates,
                    eur_exchange_rate: eurexchangerates,
                    transmission_timestamp: transmissiontimestamp,
                    cancelpenaltypolicycode: cancelpenaltypolicycode,
                    cancelcommenttxt: cancelcomment,
                    cancelreasontxt: cancelreason,
                    cancelreasoncdtxt: cancelreasoncode,
                    sourceofbusinesscrocode: srcbuscrocode,
                    enrolment_ind: enrollmentid,
                    vdn_comp_cd: thirdcompanycode,
                    lastmodifyingchanneltype: lastmodchanneltype,
                    lastmodifyingchannelcompanycode: lastmodchannelcompanycode,
                    lastmodifyingchannelcompanyname: lastmodchannelcompanyname,
                    confirmdatetime: confrmdate,
                    inserted_ts: '',
                    basicpropertyinfohotelcode: basicpropertyinfohotelcode,
                    brandcode: brandcode,
                    src_file_nm: s3outputPath
                }]

            }
            return records;

        }
    },
    {
        tableName: "stg_rsv_TaxBreakdown",
        transform: function(json,s3outputPath) {
            let ecoToken = extract('.OTA_HotelResNotifRQ.$.EchoToken[0]', json)
            let roomStay = extract('..HotelReservations.HotelReservation.RoomStays.RoomStay', json)
			let uniqueidid = extract('..HotelReservations.HotelReservation.UniqueID.$.ID[0]', json)
            let resstatus = extract('.OTA_HotelResNotifRQ.$.ResStatus[0]', json)
			let basicpropertyinfohotelcode = extract('.OTA_HotelResNotifRQ.HotelReservations.HotelReservation.RoomStays.RoomStay.BasicPropertyInfo.$.HotelCode[0]', json)

            let records = roomStay.map((roomstay, roomstayIndex) => {
                return extract('.Total.Taxes.Tax', roomstay).map((tax, taxIndex) => {
                    return {
                        id: ecoToken,
                        roomstayseqno: String(roomstayIndex + 1),
                        taxseqno: String(taxIndex + 1),
                        cd: extract('.$.Code[0]', tax),
                        amt: extract('.$.Amount[0]', tax),
                        effectivedate: extract('.$.EffectiveDate[0]', tax),
                        expiredate: extract('.$.ExpireDate[0]', tax),
                        chargefrequency: extract('.$.ChargeFrequency[0]', tax),
                        taxdescription_name: extract('.TaxDescription.$.Name[0]', tax),
                        taxdescription_text: extract('.TaxDescription.Text[0]', tax),
                        inserted_ts: '',
						uniqueidid: uniqueidid,
                        basicpropertyinfohotelcode: basicpropertyinfohotelcode,
                        resstatus: resstatus,
                        src_file_nm: s3outputPath
                    }
                });
            });
            return records;
        }
    },
    {
        tableName: "stg_rsv_UniqueId",
        transform: function(json,s3outputPath) {
            let ecoToken = extract('.OTA_HotelResNotifRQ.$.EchoToken[0]', json)
            let resGuest = extract('..HotelReservations.HotelReservation.ResGuests.ResGuest', json)
            let resstatus = extract('.OTA_HotelResNotifRQ.$.ResStatus[0]', json)
            let uniqueidid_conf = extract('..HotelReservations.HotelReservation.UniqueID.$.ID[0]', json)
            let brandcode = extract('..HotelReservations.HotelReservation.RoomStays.RoomStay.BasicPropertyInfo.$.BrandCode[0]', json)
			let basicpropertyinfohotelcode = extract('.OTA_HotelResNotifRQ.HotelReservations.HotelReservation.RoomStays.RoomStay.BasicPropertyInfo.$.HotelCode[0]', json)

            var cnt = 0
            let records = resGuest.map(resguest => {
                return extract('.Profiles.ProfileInfo', resguest).map(profileinfo => {
                    return extract('.UniqueID', profileinfo).map((uniqueid, uniqueidIndex) => {
                        return {
                            id: ecoToken,
                            uniqueidseqno: String(cnt = cnt + 1),
                            uniqueidtype: extract('.$.Type[0]', uniqueid),
                            uniqueidid: extract('.$.ID[0]', uniqueid),
                            uniqueid_context: extract('.$.ID_Context[0]', uniqueid),
                            companynamecode: extract('.CompanyName.$.Code[0]', uniqueid),
                            codecontext: extract('.CompanyName.$.CodeContext[0]', uniqueid),
                            div: extract('.CompanyName.$.Division[0]', uniqueid),
                            inserted_ts: '',
                            basicpropertyinfohotelcode: basicpropertyinfohotelcode,
                            resstatus: resstatus,
                            uniqueidid_conf: uniqueidid_conf,
                            brandcode: brandcode,
                            src_file_nm: s3outputPath

                        }
                    });
                });
            });
            return records;
        }
    },
    {
        tableName: "stg_rsv_CancelPenaltyPolicy",
        transform: function(json,s3outputPath) {
            let ecoToken = extract('.OTA_HotelResNotifRQ.$.EchoToken[0]', json)
            let cancelPenalty = extract('..HotelReservations.HotelReservation.ResGlobalInfo.CancelPenalties.CancelPenalty', json)
            let uniqueidid = extract('..HotelReservations.HotelReservation.UniqueID.$.ID[0]', json)
            let resstatus = extract('.OTA_HotelResNotifRQ.$.ResStatus[0]', json)
			let basicpropertyinfohotelcode = extract('.OTA_HotelResNotifRQ.HotelReservations.HotelReservation.RoomStays.RoomStay.BasicPropertyInfo.$.HotelCode[0]', json)

            let records = cancelPenalty.map(cancelpenalty => {
                return {
                    id: ecoToken,
                    cancel_penalty_policy_code: extract('.$.PolicyCode[0]', cancelpenalty),
                    cancel_offset_time_unit: extract('.Deadline.$.OffsetTimeUnit[0]', cancelpenalty),
                    cancel_offset_unit_multiplier: extract('.Deadline.$.OffsetUnitMultiplier[0]', cancelpenalty),
                    cancel_offset_drop_time: extract('.Deadline.$.OffsetDropTime[0]', cancelpenalty),
                    cancel_absolute_deadline: extract('.Deadline.$.AbsoluteDeadline[0]', cancelpenalty),
                    cancel_tax_inclusive: extract('.AmountPercent.$.TaxInclusive[0]', cancelpenalty),
                    cancel_numbr_of_nights: extract('.AmountPercent.$.NmbrOfNights[0]', cancelpenalty),
                    cancel_percent: extract('.AmountPercent.$.Percent[0]', cancelpenalty),
                    cancel_penalty_amount: extract('.AmountPercent.$.Amount[0]', cancelpenalty),
                    cancel_currency_code: extract('.AmountPercent.$.CurrencyCode[0]', cancelpenalty),
                    cancel_penalty_desc_text: extract('.PenaltyDescription.Text[0]', cancelpenalty),
                    inserted_ts: '',
                    uniqueidid: uniqueidid,
                    basicpropertyinfohotelcode: basicpropertyinfohotelcode,
                    resstatus: resstatus,
                    src_file_nm: s3outputPath
                }
            });
            return records;
        }
    }
]

module.exports = tableDefs