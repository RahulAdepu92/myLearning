import sys
from datetime import datetime
from datetime import timedelta
import pytz
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.dynamicframe import DynamicFrame
from pyspark.sql import SQLContext
import boto3
import logging
from pyspark.sql import functions as f
from pyspark.sql.functions import  col, when, lit, input_file_name, substring_index,year, month, dayofmonth
from pyspark.sql.types import TimestampType, DoubleType, StructType, StructField, StringType, IntegerType, LongType, FloatType, DecimalType

################################### Setting up Spark environment and enabling Glue to interact with Spark Platform ##################################
sc=SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
sqlContext = SQLContext(sc)

################################### Enabling access to the arguments ##################################
job = Job(glueContext)
args = getResolvedOptions(sys.argv, ['JOB_NAME','blue_bucket','error_bucket','SNS','rsdb','redshiftconnection','tablename','schemaname','audittable','ScriptBucketName','configfile','gold_bucket','rules_tablename','dq_intermediate_tablename'])
job.init(args['JOB_NAME'], args)

################################### Setting up logger for event logging ##################################
logging.basicConfig()
logger = logging.getLogger()
logger.setLevel(logging.INFO)

################################### Assigning job arguments to variables  ##################################

rsdb = args['rsdb']
redshiftconnection = args['redshiftconnection']
blue_bucket = args['blue_bucket']
gold_bucket = args['gold_bucket']
file_path_gen = 's3://{}/sabre/reservation/processing/'.format(blue_bucket)
error_bucket = args['error_bucket']
job_name = args['JOB_NAME']
tablename = args['tablename']
schemaname = args['schemaname']
audittable = args['audittable']
sns_notify = args['SNS']
MARKER_FILE = "sabre/reservation/reservation-glue-workflow-marker-triggers/" +args["JOB_NAME"]
PARQUET_FILE_PATH = "s3://{}/reservation/{}".format(gold_bucket,'UniqueID')
job_run = True
s3_lku_site = 's3://{}/sabre/reservation/lkup-site/'.format(blue_bucket)
rules_tablename = args['rules_tablename']
dq_intermediate_tablename = args['dq_intermediate_tablename']

################################### Create low level reosurce service client for S3 ans SNS  ##################################

s3Client = boto3.client('s3',region_name='us-west-2')
s3resource = boto3.resource('s3',region_name='us-west-2')
glueClient = boto3.client('reservation-glue', region_name='us-west-2')


try:
    sns_client = boto3.client('sns',region_name = 'us-west-2')
    logger.info("Enabled SNS Notification")
except Exception as e:
    logger.error(str(e))
    logger.info(" Unable to enable SNS, failed with error: {}".format(str(e)))
    logger.info("Continuing with load without SNS notification")
    
    
def notifymsg(sub, msg):
    #sns_client.publish(TopicArn = sns_notify, Message = msg , Subject= sub) 
    logger.info("**************** [INFO] SNS Notification Sent: {} *************************".format(job_name))

################## Create Timestamp ############################

def create_timestamp_est():
    
    now = datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')
    
    # est = pytz.timezone('US/Eastern')
    # now_est = now.astimezone(est).strftime('%Y-%m-%d %H:%M:%S.%f')
    
    return now


######## Check if this is rerun based on the marker file, if so the job execution is skipped ###################################
try:
    response = s3Client.head_object(Bucket=blue_bucket, Key=MARKER_FILE)
    print(response)
    print("*******************[INFO] JOB ALREADY EXECUTED ********************")
    job_run = False
except Exception as HeadObjectException:
    ##############################################################################################
    # No Marker file present, then this is first time execution
    # Will read the file based on get_input_s3_path response
    ##############################################################################################
    print(HeadObjectException)

if job_run:
    
    ################################### Retriving connection information from Glue connections for Redshift  ##################################
    try:
       logger.info("Getting Redshift Connection Information")    
       rs_connection_dest = glueContext.extract_jdbc_conf(redshiftconnection)
       rs_url_dest = rs_connection_dest["url"]
       rs_user_dest = rs_connection_dest["user"]
       rs_pwd_dest = rs_connection_dest["password"]
       rs_url_db_dest = rs_url_dest+'/'+rsdb
    except Exception as e:
       logger.error(str(e))
       f_msg=" Unable to connect to Redshift while processing the reservation-glue job {0} , failed with error: {1}  ".format(job_name,str(e))
       f_sub = "Reservation UniqueID Glue job "+job_name+" failed" 
       notifymsg(f_sub, f_msg)
       logger.info(" Exiting with error: {}".format(str(e)))
       exit(1)  
       
    ############################## Reading Data from Processing Folder #################################################
    try:
        logger.info(" Reading UniqueID Data from JSON ")
        res_s3_read_dyf = glueContext.create_dynamic_frame.from_options(connection_type="s3", 
                    connection_options={"paths": [file_path_gen],'recurse':True, 'groupFiles': 'inPartition'},
                    format="json",
                    format_options={"jsonPath": "$.stg_rsv_UniqueId[*]"})
        
        res_df = res_s3_read_dyf.toDF()
        res_df_count = res_df.count()
        print('Total Cound DF: {}'.format(res_df_count))
        #res_df.printSchema()
        # res_df.show(10, False)  

        logger.info(" Reading lkup-site Data from JSON ")
        res_s3_read_lkup_site_dyf = glueContext.create_dynamic_frame.from_options(connection_type="s3", 
                    connection_options={"paths": [s3_lku_site],'recurse':True, 'groupFiles': 'inPartition'},
                    format="json")
                    
        res_df_lkup_site = res_s3_read_lkup_site_dyf.toDF()
        res_df_lkup_site_count = res_df_lkup_site.count()
        print('Total lkup-site Count DF: {}'.format(res_df_lkup_site_count))
        res_df_lkup_site.printSchema()        
        
        res_df_lkup_site.show(10,False)      
        
        new_column_name_list = list(map(lambda x:'lkup_'+x,res_df_lkup_site.columns))
        res_df_lkup_site_lkup = res_df_lkup_site.toDF(*new_column_name_list)
 
    except Exception as e:
        logger.error("************ {} [ERROR] Exception while reading the file from S3 *************".format(str(datetime.now())))
        logger.error("*********** [ERROR] Failing with error:  {} **************".format(str(e)))
        f_msg="  Error while reading UniqueID data from S3 for the job {0} , failed with error: {1}  ".format(job_name,str(e))
        f_sub = "Reservation UniqueID Glue job "+job_name+" failed" 
        notifymsg(f_sub, f_msg)
        exit(1)
    
    if res_df_count == 0:
        logger.info('No Data to process for UniqueID for {} run'.format(str(datetime.now())))
        f_msg = "No Data to Process for UniqueID Glue Job - {} for run {}".format(job_name,str(datetime.now()))
        f_sub = "No Data to Process for UniqueID Glue Job - {}".format(job_name)
        notifymsg(f_sub, f_msg)
        # exit(0)
    else:
        logger.info(" Reading from dwstg.rsv_data_valrules")
        ################## Data read from redshift to df for rsv_data_valrules#################################
        try:
            data_valrules_df = glueContext.create_dynamic_frame.from_options(
                                            connection_type = "redshift", 
                                            connection_options = {
                                                            "url": rs_url_db_dest,
                                                            "database": rsdb, 
                                                            "user": rs_user_dest, 
                                                            "password": rs_pwd_dest, 
                                                            "dbtable" : schemaname+'.'+rules_tablename ,  
                                                            "redshiftTmpDir" : "s3://"+blue_bucket+'/sabre/reservation/dataread/rsv_data_valrules/{}/{}/'.format(job_name,str(datetime.now()).replace(" ","_"))
                                                        }                                                
                                                )
            res_df_data_valrules = data_valrules_df.toDF()
            res_df_data_valrules_count = res_df_data_valrules.count()
            print('Total lkup-site Count DF: {}'.format(res_df_data_valrules_count))
            res_df_data_valrules.printSchema()
            res_df_data_valrules.show(10,False)
            logger.info(" Data Read from rsv_data_valrules to df complete")
        
            new_column_name_list = list(map(lambda x:'val_'+x,res_df_data_valrules.columns))
            res_df_data_valrules_val = res_df_data_valrules.toDF(*new_column_name_list)
            
        except Exception as e:
            logger.error(str(e))
            logger.info("  [ERROR] Error while loading to df from rsv_data_valrules table, failed with : {} ".format(str(e)))
            f_msg="  Error while loading to df from rsv_data_valrules table for the job {}, failed with error: {} ".format(job_name,str(e))
            f_sub = "Reservation Room Stay Glue job "+job_name+" failed" 
            notifymsg(f_sub, f_msg)
            exit(1)
        

        ################## Data Transformation Step #################################
        try:
            logger.info('Mapping Field Name with Redshift Column')
            
            ################## Filling in blank values with Null values #################################
            for x in res_df.columns:
                res_df = res_df.withColumn(x, when(col(x) != '', col(x)).otherwise(None)) 
                
            df_final = res_df.withColumn('inserted_ts',lit(create_timestamp_est()).cast(TimestampType()))
            
            # df_final.printSchema()
            # df_final.show(10, False)
            
            df_final_new = df_final.drop("resstatus","basicpropertyinfohotelcode","uniqueidid_conf")
            df_final_new.printSchema()
            df_final_new.show(10, False)
            dyf_final = DynamicFrame.fromDF(df_final_new, glueContext,'dyf_final')
            
        except Exception as e:
            logger.error("************ {} [ERROR] Exception while doing Data Transformtion on UniqueID Data *************".format(str(datetime.now())))
            logger.error("*********** [ERROR] Failing with error:  {} **************".format(str(e)))
            f_msg="  Error while doing Data Transformtion on UniqueID Data for Glue Job {0} , failed with error: {1}  ".format(job_name,str(e))
            f_sub = "Reservation UniqueID Glue job "+job_name+" failed" 
            notifymsg(f_sub, f_msg)
            exit(1)
        ################## Data Quality Checks #################################
        try:
            logger.info('Start of DQ checks')
            ################## Rule 51 Data Check Invalid Corp ID values. #################################
            df_DQ_check = df_final.withColumn('Qid',
                                   when((df_final.uniqueidtype == '4') & (df_final.uniqueid_context == 'crs') & (((f.col('uniqueidid').cast(StringType()))[0:5]).cast(StringType()) == '5136N'), '51').otherwise('NOACTION')
                                   ).withColumn('src_col_value',
                                   when((df_final.uniqueidtype == '4') & (df_final.uniqueid_context == 'crs') & (((f.col('uniqueidid').cast(StringType()))[0:5]).cast(StringType()) == '5136N'), f.col('uniqueidid'))
                                  .otherwise('NOACTION'))
            print(" data checks completed")
            df_DQ_check.show()
            print(" filter data")
            df_DQ_error = df_DQ_check.filter(df_DQ_check.Qid != 'NOACTION')
            print(" join dataframes")
            ################## Join Dq Val rules table to df_DQ_error data frame based on Qid value #################################
            df_DQ_valrules_join = df_DQ_error.join(res_df_data_valrules_val,(df_DQ_error.Qid == res_df_data_valrules_val.val_id),how='inner')
            
            print(" join with lku_site")  

            ################## Join Lkup_site table to df_DQ_valrules_join data frame based on basicpropertyinfohotelcode = lkup_crs_site_id and considering only matched values #################################
            df_DQ_valrules_lkup_site_join_1 = df_DQ_valrules_join.join(res_df_lkup_site_lkup,(df_DQ_valrules_join.basicpropertyinfohotelcode == res_df_lkup_site_lkup.lkup_crs_site_id),how='inner')
            ################## Join Lkup_site table to df_DQ_valrules_join data frame based on basicpropertyinfohotelcode = lkup_site_id & brandcode = lkup_brand_id  and considering only matched values #################################                      
            df_DQ_valrules_lkup_site_join_2 = df_DQ_valrules_join.join(res_df_lkup_site_lkup,((((df_DQ_valrules_join.basicpropertyinfohotelcode == res_df_lkup_site_lkup.lkup_site_id) 
                                                                                    & (df_DQ_valrules_join.brandcode == res_df_lkup_site_lkup.lkup_brand_id)) & df_DQ_valrules_join.brandcode.isNotNull() )
                                                                                    ),how='inner' )
            df_DQ_valrules_lkup_site_union = df_DQ_valrules_lkup_site_join_1.union(df_DQ_valrules_lkup_site_join_2)
            df_DQ_valrules_lkup_site_union = df_DQ_valrules_lkup_site_union.distinct()
            ################## Join Lkup_site table to df_DQ_valrules_join data frame based on basicpropertyinfohotelcode = lkup_site_id & brandcode is null  and considering only matched values #################################      
            df_DQ_valrules_lkup_site_join_3 = df_DQ_valrules_join.join(res_df_lkup_site_lkup,((df_DQ_valrules_join.basicpropertyinfohotelcode == res_df_lkup_site_lkup.lkup_site_id) &  df_DQ_valrules_join.brandcode.isNull()),how = 'inner')

            df_DQ_valrules_lkup_site_union_2 = df_DQ_valrules_lkup_site_union.union(df_DQ_valrules_lkup_site_join_3)
            df_DQ_valrules_lkup_site_union_2 = df_DQ_valrules_lkup_site_union_2.distinct()
            ################## Join Lkup_site table to df_DQ_valrules_join data frame excluding above joined values #################################      
            df_DQ_error_exclude  = df_DQ_valrules_join.join(df_DQ_valrules_lkup_site_union_2, (df_DQ_valrules_join.basicpropertyinfohotelcode == df_DQ_valrules_lkup_site_union_2.basicpropertyinfohotelcode),how='leftanti').select(df_DQ_valrules_join['*'])
            df_DQ_valrules_lkup_site_join_4 = df_DQ_error_exclude.join(res_df_lkup_site_lkup,(df_DQ_error_exclude.basicpropertyinfohotelcode == res_df_lkup_site_lkup.lkup_crs_site_id),how='left')
            df_DQ_valrules_lkup_site_join = df_DQ_valrules_lkup_site_union_2.union(df_DQ_valrules_lkup_site_join_4)
			
			
            df_DQ_valrules_lkup_site_join = df_DQ_valrules_lkup_site_join.distinct()
        
            print(" assigning values")
            df_DQ_valrules_lkup_site_join.show()
            df_DQ_valrules_lkup_site_join.createOrReplaceTempView("DQ_final_ins_view") 
            
            df_DQ_final_ins = spark.sql("""select distinct id, uniqueidid_conf as conf_num, case when basicpropertyinfohotelcode = lkup_crs_site_id  then basicpropertyinfohotelcode
                                                  when basicpropertyinfohotelcode = lkup_site_id then lkup_crs_site_id  else basicpropertyinfohotelcode end as synxis_site_id
                                            ,case when basicpropertyinfohotelcode =  lkup_crs_site_id then lkup_site_id 
                                                  when basicpropertyinfohotelcode = lkup_site_id then basicpropertyinfohotelcode else lkup_site_id end as wyn_site_id
                                            ,case when resstatus='Commit' then 'N' when resstatus='Modify' then 'O' when resstatus='Cancel' then 'X' else null end as log_type, val_src_colname as src_column_name
                                            ,src_col_value as src_column_value,  val_data_quality_validation_rule as error_message, inserted_ts as insert_ts, inserted_ts as updated_ts,
											Replace(case when brandcode IS NULL then lkup_brand_id else brandcode end ,'WY' , 'WD') as brand_id,  val_id as dataval_id, val_quarantine_flag as pros_flag from DQ_final_ins_view """)

            df_DQ_final_ins.printSchema()
            df_DQ_final_ins.show(10, False)
            
            dyf_DQ_final = DynamicFrame.fromDF(df_DQ_final_ins, glueContext,'dyf_DQ_final')
 
            df_final_new = df_final.drop("resstatus","basicpropertyinfohotelcode","brandcode","uniqueidid_conf")
            df_final_new.printSchema()
            df_final_new.show(10, False)
            dyf_final = DynamicFrame.fromDF(df_final_new, glueContext,'dyf_final')
            
        except Exception as e:
            logger.error("************ {} [ERROR] Exception while doing Data Transformtion on Hotel Reservation Data *************".format(str(datetime.now())))
            logger.error("*********** [ERROR] Failing with error:  {} **************".format(str(e)))
            f_msg="  Error while doing Data Transformtion on Hotel Reservation Data for Glue Job {0} , failed with error: {1}  ".format(job_name,str(e))
            f_sub = "Reservation Hotel Reservation Glue job "+job_name+" failed" 
            notifymsg(f_sub, f_msg)
            exit(1)  
            

        #################### Dataload to Redshift ########################
        try:
            redshift_load = glueContext.write_dynamic_frame.from_jdbc_conf(
                                        frame = dyf_final, 
                                        catalog_connection = redshiftconnection, 
                                        connection_options = {
                                                            "url": rs_url_db_dest,
                                                            "database": rsdb, 
                                                            "user": rs_user_dest, 
                                                            "password": rs_pwd_dest, 
                                                            "dbtable" : schemaname+'.'+tablename ,
                                                            "extracopyoptions":"MAXERROR 100000"},  
                                        redshift_tmp_dir = "s3://"+blue_bucket+'/sabre/reservation/dataload/{}/{}/'.format(job_name,str(datetime.now()).replace(" ","_"))
                                            )
            logger.info(" Data Load Process for UniqueID to redshift complete")
        except Exception as e:
            logger.error(str(e))
            logger.info("  [ERROR] Error while loading to Redshift Staging table, failed with : {} ".format(str(e)))
            f_msg="  Error while loading to Staging table for the job {}, failed with error: {} ".format(job_name,str(e))
            f_sub = "Reservation UniqueID Glue job "+job_name+" failed" 
            notifymsg(f_sub, f_msg)
            exit(1)
        
        if dyf_DQ_final.count() != 0:
            logger.info(" Starting Data load to DQ Error table")
            try:
                dyf_DQ_final = DropNullFields.apply(frame = dyf_DQ_final, transformation_ctx = "dyf_DQ_final")
                redshift_load = glueContext.write_dynamic_frame.from_jdbc_conf(
                                        frame = dyf_DQ_final, 
                                        catalog_connection = redshiftconnection, 
                                        connection_options = {
                                                            "url": rs_url_db_dest,
                                                            "database": rsdb, 
                                                            "user": rs_user_dest, 
                                                            "password": rs_pwd_dest, 
                                                            "dbtable" : schemaname+'.'+dq_intermediate_tablename ,
                                                            "extracopyoptions":"MAXERROR 100000"},  
                                        redshift_tmp_dir = "s3://"+blue_bucket+'/sabre/reservation/dqerrorload/{}/{}/'.format(job_name,str(datetime.now()).replace(" ","_"))
                                            )
                logger.info(" Data Load Process for Hotel Reservation to redshift complete")
            except Exception as e:
                logger.error(str(e))
                logger.info("  [ERROR] Error while loading to DQ Error table, failed with : {} ".format(str(e)))
                f_msg="  Error while loading to DQ Error table for the job {}, failed with error: {} ".format(job_name,str(e))
                f_sub = "Reservation Hotel Reservation Glue job "+job_name+" failed" 
                notifymsg(f_sub, f_msg)
                exit(1) 
        ############### Creating Parquet Files and saving it to Gold S3 ##############
        df_parquet = df_final.withColumn('year',year(col("inserted_ts"))).withColumn('month',month(col("inserted_ts"))).withColumn('day',dayofmonth(col("inserted_ts"))).repartition(1)
        
        dyf_parquet = DynamicFrame.fromDF(df_parquet, glueContext,'dyf_parquet')
        # dyf_parquet.show(10)
        # dyf_parquet.printSchema()
        
        try:
            mb_write_to_s3 = glueContext.write_dynamic_frame.from_options(
                    frame = dyf_parquet, 
                    connection_type = "s3", 
                    connection_options = {"path": PARQUET_FILE_PATH,"partitionKeys": ['year','month','day']}, 
                    format = "parquet"
                    )
        except Exception as e:
            logger.error(str(e))
            logger.info("  [ERROR] Error while writing parquet files to S3, failed with : {} ".format(str(e)))
            f_msg="  Error while writing parquet files to S3 for the job {}, failed with error: {} ".format(job_name,str(e))
            f_sub = "Reservation Address Glue job "+job_name+" failed" 
            notifymsg(f_sub, f_msg)
            exit(1)
        
        ####################### Creating a Marker File ###########################
        try:
            response = s3Client.put_object(Bucket=blue_bucket, Body="Completed", Key=MARKER_FILE)
            print(response)
        except Exception as error:
            logger.error("************ {} [ERROR] Exception while writing the marker file to S3 for UniqueID Glue Job************".format(str(datetime.now())))
            logger.error("*********** [ERROR] Failing with error: {} **************".format(str(error)))
            f_msg="  Error while writing the marker file to S3 for UniqueID Glue Job {}, failed with Error: {}".format(job_name,str(e))
            f_sub = "Error writing Marker File for Glue Job - {}".format(job_name) 
            notifymsg(f_sub, f_msg)
            exit(1)

logger.info(" ************** {} End of Load process for UniqueID *********************** ".format(str(datetime.now())))
job.commit()