import sys
from datetime import datetime
from datetime import timedelta
import pytz
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.dynamicframe import DynamicFrame
from pyspark.sql import SQLContext
import boto3
import logging
from pyspark.sql.functions import  col, when, lit, input_file_name, substring_index,year, month, dayofmonth
from pyspark.sql.types import TimestampType, DoubleType, StructType, StructField, StringType, IntegerType, LongType, FloatType, DecimalType

################################### Setting up Spark environment and enabling Glue to interact with Spark Platform ##################################
sc=SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
sqlContext = SQLContext(sc)

################################### Enabling access to the arguments ##################################
job = Job(glueContext)
args = getResolvedOptions(sys.argv, ['JOB_NAME','blue_bucket','error_bucket','SNS','rsdb','redshiftconnection','tablename','schemaname','audittable','ScriptBucketName','configfile','gold_bucket'])
job.init(args['JOB_NAME'], args)

################################### Setting up logger for event logging ##################################
logging.basicConfig()
logger = logging.getLogger()
logger.setLevel(logging.INFO)

################################### Assigning job arguments to variables  ##################################

rsdb = args['rsdb']
redshiftconnection = args['redshiftconnection']
blue_bucket = args['blue_bucket']
gold_bucket = args['gold_bucket']
file_path_gen = 's3://{}/sabre/reservation/processing/'.format(blue_bucket)
error_bucket = args['error_bucket']
job_name = args['JOB_NAME']
tablename = args['tablename']
schemaname = args['schemaname']
audittable = args['audittable']
sns_notify = args['SNS']
MARKER_FILE = "sabre/reservation/reservation-glue-workflow-marker-triggers/" +args["JOB_NAME"]
PARQUET_FILE_PATH = "s3://{}/reservation/{}".format(gold_bucket,'ResGuest')
job_run = True

################################### Create low level reosurce service client for S3 ans SNS  ##################################

s3Client = boto3.client('s3',region_name='us-west-2')
s3resource = boto3.resource('s3',region_name='us-west-2')
glueClient = boto3.client('reservation-glue', region_name='us-west-2')


try:
    sns_client = boto3.client('sns',region_name = 'us-west-2')
    logger.info("Enabled SNS Notification")
except Exception as e:
    logger.error(str(e))
    logger.info(" Unable to enable SNS, failed with error: {}".format(str(e)))
    logger.info("Continuing with load without SNS notification")
    
    
def notifymsg(sub, msg):
    sns_client.publish(TopicArn = sns_notify, Message = msg , Subject= sub) 
    logger.info("**************** [INFO] SNS Notification Sent: {} *************************".format(job_name))

################## Create Timestamp ############################

def create_timestamp_est():
    
    now = datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')
    
    # est = pytz.timezone('US/Eastern')
    # now_est = now.astimezone(est).strftime('%Y-%m-%d %H:%M:%S.%f')
    
    return now


######## Check if this is rerun based on the marker file, if so the job execution is skipped ###################################
try:
    response = s3Client.head_object(Bucket=blue_bucket, Key=MARKER_FILE)
    print(response)
    print("*******************[INFO] JOB ALREADY EXECUTED ********************")
    job_run = False
except Exception as HeadObjectException:
    ##############################################################################################
    # No Marker file present, then this is first time execution
    # Will read the file based on get_input_s3_path response
    ##############################################################################################
    print(HeadObjectException)

if job_run:
    
    ################################### Retriving connection information from Glue connections for Redshift  ##################################
    try:
       logger.info("Getting Redshift Connection Information")    
       rs_connection_dest = glueContext.extract_jdbc_conf(redshiftconnection)
       rs_url_dest = rs_connection_dest["url"]
       rs_user_dest = rs_connection_dest["user"]
       rs_pwd_dest = rs_connection_dest["password"]
       rs_url_db_dest = rs_url_dest+'/'+rsdb
    except Exception as e:
       logger.error(str(e))
       f_msg=" Unable to connect to Redshift while processing the reservation-glue job {0} , failed with error: {1}  ".format(job_name,str(e))
       f_sub = "Reservation Rest Guest Glue job "+job_name+" failed" 
       notifymsg(f_sub, f_msg)
       logger.info(" Exiting with error: {}".format(str(e)))
       exit(1)  
       
    ############################## Reading Data from Processing Folder #################################################
    try:
        logger.info(" Reading Rest Guest Data from JSON ")
        res_s3_read_dyf = glueContext.create_dynamic_frame.from_options(connection_type="s3", 
                    connection_options={"paths": [file_path_gen],'recurse':True, 'groupFiles': 'inPartition'},
                    format="json",
                    format_options={"jsonPath": "$.stg_rsv_ResGuestRPH[*]"})
        
        res_df = res_s3_read_dyf.toDF()
        res_df_count = res_df.count()
        print('Total Cound DF: {}'.format(res_df_count))
        res_df.printSchema()
        # res_df.show(10, False)   
    except Exception as e:
        logger.error("************ {} [ERROR] Exception while reading the file from S3 *************".format(str(datetime.now())))
        logger.error("*********** [ERROR] Failing with error:  {} **************".format(str(e)))
        f_msg="  Error while reading Rest Guest data from S3 for the job {0} , failed with error: {1}  ".format(job_name,str(e))
        f_sub = "Reservation Rest Guest Glue job "+job_name+" failed" 
        notifymsg(f_sub, f_msg)
        exit(1)
    
    if res_df_count == 0:
        logger.info('No Data to process for Rest Guest for {} run'.format(str(datetime.now())))
        f_msg = "No Data to Process for Rest Guest Glue Job - {} for run {}".format(job_name,str(datetime.now()))
        f_sub = "No Data to Process for Rest Guest Glue Job - {}".format(job_name)
        notifymsg(f_sub, f_msg)
        # exit(0)
    else:
        ################## Data Transformation Step #################################
        try:
            logger.info('Mapping Field Name with Redshift Column')
            
            ################## Filling in blank values with Null values #################################
            for x in res_df.columns:
                res_df = res_df.withColumn(x, when(col(x) != '', col(x)).otherwise(None)) 
                
            df_final = res_df.withColumn('inserted_ts',lit(create_timestamp_est()).cast(TimestampType()))
            
            # df_final.printSchema()
            # df_final.show(10, False)
            
            df_final_new = df_final.drop("uniqueidid","resstatus","basicpropertyinfohotelcode")
            df_final_new.printSchema()
            df_final_new.show(10, False)
            dyf_final = DynamicFrame.fromDF(df_final_new, glueContext,'dyf_final')
            
        except Exception as e:
            logger.error("************ {} [ERROR] Exception while doing Data Transformtion on Rest Guest Data *************".format(str(datetime.now())))
            logger.error("*********** [ERROR] Failing with error:  {} **************".format(str(e)))
            f_msg="  Error while doing Data Transformtion on Rest Guest Data for Glue Job {0} , failed with error: {1}  ".format(job_name,str(e))
            f_sub = "Reservation Rest Guest Glue job "+job_name+" failed" 
            notifymsg(f_sub, f_msg)
            exit(1)
            
        #################### Dataload to Redshift ########################
        try:
            redshift_load = glueContext.write_dynamic_frame.from_jdbc_conf(
                                        frame = dyf_final, 
                                        catalog_connection = redshiftconnection, 
                                        connection_options = {
                                                            "url": rs_url_db_dest,
                                                            "database": rsdb, 
                                                            "user": rs_user_dest, 
                                                            "password": rs_pwd_dest, 
                                                            "dbtable" : schemaname+'.'+tablename ,
                                                            "extracopyoptions":"MAXERROR 100000"},  
                                        redshift_tmp_dir = "s3://"+blue_bucket+'/sabre/reservation/dataload/{}/{}/'.format(job_name,str(datetime.now()).replace(" ","_"))
                                            )
            logger.info(" Data Load Process for Rest Guest to redshift complete")
        except Exception as e:
            logger.error(str(e))
            logger.info("  [ERROR] Error while loading to Redshift Staging table, failed with : {} ".format(str(e)))
            f_msg="  Error while loading to Staging table for the job {}, failed with error: {} ".format(job_name,str(e))
            f_sub = "Reservation Rest Guest Glue job "+job_name+" failed" 
            notifymsg(f_sub, f_msg)
            exit(1)
        
        ############### Creating Parquet Files and saving it to Gold S3 ##############
        df_parquet = df_final.withColumn('year',year(col("inserted_ts"))).withColumn('month',month(col("inserted_ts"))).withColumn('day',dayofmonth(col("inserted_ts"))).repartition(1)
        
        dyf_parquet = DynamicFrame.fromDF(df_parquet, glueContext,'dyf_parquet')
        # dyf_parquet.show(10)
        # dyf_parquet.printSchema()
        
        try:
            mb_write_to_s3 = glueContext.write_dynamic_frame.from_options(
                    frame = dyf_parquet, 
                    connection_type = "s3", 
                    connection_options = {"path": PARQUET_FILE_PATH,"partitionKeys": ['year','month','day']}, 
                    format = "parquet"
                    )
        except Exception as e:
            logger.error(str(e))
            logger.info("  [ERROR] Error while writing parquet files to S3, failed with : {} ".format(str(e)))
            f_msg="  Error while writing parquet files to S3 for the job {}, failed with error: {} ".format(job_name,str(e))
            f_sub = "Reservation Address Glue job "+job_name+" failed" 
            notifymsg(f_sub, f_msg)
            exit(1)
        
        ####################### Creating a Marker File ###########################
        try:
            response = s3Client.put_object(Bucket=blue_bucket, Body="Completed", Key=MARKER_FILE)
            print(response)
        except Exception as error:
            logger.error("************ {} [ERROR] Exception while writing the marker file to S3 for Rest Guest Glue Job************".format(str(datetime.now())))
            logger.error("*********** [ERROR] Failing with error: {} **************".format(str(error)))
            f_msg="  Error while writing the marker file to S3 for Rest Guest Glue Job {}, failed with Error: {}".format(job_name,str(e))
            f_sub = "Error writing Marker File for Glue Job - {}".format(job_name) 
            notifymsg(f_sub, f_msg)
            exit(1)

logger.info(" ************** {} End of Load process for Rest Guest *********************** ".format(str(datetime.now())))
job.commit()