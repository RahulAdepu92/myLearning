import sys
from datetime import date, datetime
from datetime import timedelta
import pytz
import json
import time
import pandas
from pytz import timezone
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.dynamicframe import DynamicFrame
from pyspark.sql import SQLContext
import boto3
import logging
from requests.utils import requote_uri
from pyspark.sql.functions import  col, when, lit, input_file_name, substring_index
from pyspark.sql.types import TimestampType, DoubleType, StructType, StructField, StringType, IntegerType, LongType, FloatType, DecimalType

################################### Setting up Spark environment and enabling Glue to interact with Spark Platform ##################################
sc=SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
sqlContext = SQLContext(sc)

################################### Enabling access to the arguments ##################################
job = Job(glueContext)
args = getResolvedOptions(sys.argv, ['JOB_NAME','blue_bucket','error_bucket','SNS','rsdb','redshiftconnection','schemaname','audittable','ScriptBucketName','configfile','glueerrortable','gold_bucket','ESLogGroup','dq_tablename','dq_intermediate_tablename','DQESLogGroup'])
job.init(args['JOB_NAME'], args)

################################### Setting up logger for event logging ##################################
logging.basicConfig()
logger = logging.getLogger()
logger.setLevel(logging.INFO)

################################### Assigning job arguments to variables  ##################################

rsdb = args['rsdb']
redshiftconnection = args['redshiftconnection']
blue_bucket = args['blue_bucket']
gold_bucket = args['gold_bucket']
file_path_gen = 's3://{}/sabre/reservation/processing/'.format(blue_bucket)
error_bucket = args['error_bucket']
job_name = args['JOB_NAME']
schemaname = args['schemaname']
audittable = args['audittable']
glueerrortable = args['glueerrortable']
sns_notify = args['SNS']
# MARKER_FILE = "sabre/reservation/reservation-glue-workflow-marker-triggers/" +args["JOB_NAME"]
ECO_TOKEN_PATH = "s3://{}/sabre/reservation/echotoken/".format(blue_bucket)
REDSHIFT_PATH = "s3://{}/sabre/reservation/redshift/".format(blue_bucket)
es_log_group_nm = args['ESLogGroup']
dq_tablename = args['dq_tablename']
dq_intermediate_tablename = args['dq_intermediate_tablename']
dq_es_log_group_nm = args['DQESLogGroup']

SuccessTokens=[]
MissingTokens=[]
currentimestamp = str(datetime.now()).replace(" ","_")
################################### Create low level reosurce service client for S3 ans SNS  ##################################

s3Client = boto3.client('s3',region_name='us-west-2')
s3resource = boto3.resource('s3',region_name='us-west-2')
glueClient = boto3.client('reservation-glue', region_name='us-west-2')


try:
    sns_client = boto3.client('sns',region_name = 'us-west-2')
    logger.info("Enabled SNS Notification")
except Exception as e:
    logger.error(str(e))
    logger.info(" Unable to enable SNS, failed with error: {}".format(str(e)))
    logger.info("Continuing with load without SNS notification")


    
def notifymsg(sub, msg):
    sns_client.publish(TopicArn = sns_notify, Message = msg , Subject= sub) 
    logger.info("**************** [INFO] SNS Notification Sent: {} *************************".format(job_name))


def create_timestamp_est():
    
    now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    return now

def create_ts_es():
    
    now = datetime.now().strftime('%Y-%m-%dT%H:%M:%S.%fZ')
    return now

def create_trigger_file_ts():
    now = datetime.now()
    
    est = pytz.timezone('US/Eastern')
    now_est = now.astimezone(est).strftime('%Y-%m-%d %H:%M:%S.%f')
    return now_est
    
log_process_start_datetime = create_ts_es()
################################### Retriving connection information from Glue connections for Redshift  ##################################
try:
    logger.info("Getting Redshift Connection Information")    
    rs_connection_dest = glueContext.extract_jdbc_conf(redshiftconnection)
    rs_url_dest = rs_connection_dest["url"]
    rs_user_dest = rs_connection_dest["user"]
    rs_pwd_dest = rs_connection_dest["password"]
    rs_url_db_dest = rs_url_dest+'/'+rsdb
except Exception as e:
    logger.error(str(e))
    f_msg=" Unable to connect to Redshift while processing the reservation-glue job {0} , failed with error: {1}  ".format(job_name,str(e))
    f_sub = "Reservation Audit Glue job "+job_name+" failed" 
    notifymsg(f_sub, f_msg)
    logger.info(" Exiting with error: {}".format(str(e)))
    exit(1)  

log_group = es_log_group_nm
log_stream_n = 'GlueLogs'
dq_log_stream_n = 'DQGlueLogs'
ts = datetime.now()
ts_est = timezone('US/Eastern').localize(ts)
ts_est_str = ts_est.strftime('%Y-%m-%d-%H-%M-%S')
log_stream =  '{}-{}'.format(log_stream_n,ts_est_str)
dq_log_stream = '{}-{}'.format(dq_log_stream_n,ts_est_str)
dq_log_group = dq_es_log_group_nm

#########################################Create ESLogGroup stream################################### 
try:
    logs = boto3.client('logs', region_name = 'us-west-2')
    logs.create_log_stream(logGroupName=log_group, logStreamName=log_stream)
    logger.info("Connected to Log Stream")
    # print('LogStream  {} created successfully!'.format(logStreamName))
except Exception as e:
    logger.error(str(e))
    # print('LogStream  {} already exist.'.format(logStreamName))

#########################################Create DQESLogGroup stream################################### 

try:
    logs = boto3.client('logs', region_name = 'us-west-2')
    logs.create_log_stream(logGroupName=dq_log_group, logStreamName=dq_log_stream)
    logger.info("Connected to Log Stream")
    # print('DQLogStream  {} created successfully!'.format(logStreamName))
except Exception as e:
    logger.error(str(e))
    # print('DQLogStream  {} already exist.'.format(logStreamName))
         

def generateESLogs(job_name,status,error_desc,log_process_src_datetime,log_process_start_datetime,source_count,AuditTokens_success_count,AuditTokens_error_count):
    logs_json_ = json.dumps({"source_system":"Sabre CR","domain":"Reservation","subdomain":"","process_name":"Reservation Notification","process_arn":"{}".format(job_name), 
      "task_name":"Audit for RS Batch Load","rule_id":"","rule_name":"","status":"{}".format(status),"source_name":"","target_name":"RS Staging Audit Table","unique_id":"", 
      "unique_value_1":"","unique_value_2":"","unique_value_3":"","error_desc":"{}".format(error_desc),"design_pattern":"BATCH","source_system_timestamp":"{}".format(log_process_src_datetime),"business_date":"", 
      "original_file_name":"","process_start_datetime":"{}".format(log_process_start_datetime),"process_end_datetime":"{}".format(create_ts_es()),"batch_id":"",
      "source_record_count":"{}".format(source_count),"target_success_count":"{}".format(AuditTokens_success_count),"target_failed_count":"{}".format(AuditTokens_error_count)})
    
    return logs_json_
    
def generateDQESLogs(job_name,rule_id,rule_name,log_process_start_datetime,source_count,dq_count):
    
    DQ_logs_json_ = json.dumps({"source_system":"Sabre PMS","domain":"Reservation","subdomain":"","process_name":"Reservation Audit Job","process_arn":"{}".format(job_name),
       "task_name":"DQ Check","rule_id":"{}".format(rule_id),"rule_name":"{}".format(rule_name),"source_name":"","design_pattern":"Batch","source_system_timestamp":"{}".format(log_process_start_datetime),"original_file_name":"",
       "process_start_datetime":"{}".format(log_process_start_datetime),"process_end_datetime":"{}".format(create_ts_es()),"batch_id":"","source_record_count":source_count,
       "dq_error_count":dq_count,"unique_id":""})
     
    return DQ_logs_json_
    
   
def streaminfo(msg):
        timestamp = int(round(time.time() * 1000))
        response = logs.describe_log_streams(
            logGroupName=log_group,
            logStreamNamePrefix=log_stream
        )
        event_log = {
            'logGroupName':log_group,
            'logStreamName':log_stream,
            'logEvents':[
                {
                    'timestamp': timestamp,
                    'message': msg
                }
            ]
        }
        
        if 'uploadSequenceToken' in response['logStreams'][0]:
            event_log.update({'sequenceToken': response['logStreams'][0]['uploadSequenceToken']})

        response = logs.put_log_events(**event_log)
        
def dqstreaminfo(msg):
        timestamp = int(round(time.time() * 1000))
        response = logs.describe_log_streams(
            logGroupName=dq_log_group,
            logStreamNamePrefix=dq_log_stream
        )
        event_log = {
            'logGroupName':dq_log_group,
            'logStreamName':dq_log_stream,
            'logEvents':[
                {
                    'timestamp': timestamp,
                    'message': msg
                }
            ]
        }
        
        if 'uploadSequenceToken' in response['logStreams'][0]:
            event_log.update({'sequenceToken': response['logStreams'][0]['uploadSequenceToken']})

        response = logs.put_log_events(**event_log)
    
    
#########################################################################################
#  Identify the echotokens that are not available in the Redshift tables
#########################################################################################
def EchotokenValidation(tablename,starttime):
    print(tablename)
    print(starttime)
    try:
        #rstable_sql = "select distinct id as id from dw_stg_glue.stg_rsv_addr where inserted_ts > '2019-12-09 09:25:04'"
        rstable_sql = "select distinct id as id from {} where inserted_ts > \'{}\'".format(schemaname+'.'+tablename,starttime)
        print(rstable_sql)
        SuccessTokens_df = spark.read.format("com.databricks.spark.redshift").option("url", rs_url_db_dest+'?user='+rs_user_dest+'&password='+rs_pwd_dest)\
                            .option("query", rstable_sql)\
                            .option("forward_spark_s3_credentials", "true")\
                            .option("tempdir", REDSHIFT_PATH+"Audit/"+str(datetime.now()).replace(" ","_")+"/")\
                            .load()
        #SuccessTokens_df.show()
        #rstable_dyf = glueContext.create_dynamic_frame.from_options(
	    #                         connection_type = "redshift", 
        #                         connection_options = {
		#                                                "url": url_db_dest,
		#                                                "database": DATABASE, 
		#                                                "user": user_dest, 
		#                                                "password": pwd_dest, 
		#                                                "dbtable" : schema_name +"."+ tablename,
		#                                                "redshiftTmpDir" :  redshift_temp_dir+"Audit/"+str(datetime.now()).replace(" ","_")+"/"
	    #                                              }
        #                                       )
        #spark.dropTempTable('rstable')
        #rstable_df=rstable_dyf.toDF()
        #rstable_df.show()
        #rstable_dyf.toDF().createOrReplaceTempView("rstable")
        SuccessTokens_df.createOrReplaceTempView("rstable")
        
        
        #SuccessTokens_sql = ' select et._EchoToken as id  from echoToken_temp et inner join rstable rst on et._EchoToken = rst.id and rst.inserted_ts > {0} '.format("'"+starttime+"'")
        #SuccessTokens_df = spark.sql(SuccessTokens_sql)
        SuccessTokens_df.repartition(1).write.csv('s3://{}/sabre/reservation/'.format(blue_bucket) +  'Audit/'+tablename+'/SuccessTokens/'+currentimestamp+"/",header = 'true')
        #SuccessTokens_df.repartition(1).write.csv(WRITE_S3_PATH + TODAY +  '/Audit/'+tablename+'/SuccessTokens/'+currentimestamp+"/",header = 'true')
        bucket_location = s3Client.get_bucket_location(Bucket=blue_bucket)
        success_url = requote_uri("https://{1}.s3.amazonaws.com/{2}".format( bucket_location['LocationConstraint'],blue_bucket,'sabre/reservation/'+'Audit/'+tablename+'/SuccessTokens/'+currentimestamp+"/"))
        # success_url = requote_uri("https://{1}.s3.amazonaws.com/{2}".format( bucket_location['LocationConstraint'],SOURCE_BUCKET,'reservation-glue-workflow-triggers/'+TODAY +'/Audit/'+tablename+'/SuccessTokens/'+currentimestamp+"/"))
        SuccessTokens.append(str(success_url))
        
        MissingTokens_sql = ' select distinct(et._EchoToken) as id from echoToken_temp et where not exists (select distinct(rst.id) as id from rstable rst where et._EchoToken = rst.id ) '
        MissingTokens_df = spark.sql(MissingTokens_sql)
        # MissingTokens_df.repartition(1).write.csv(WRITE_S3_PATH + TODAY +  '/Audit/'+tablename+'/MissingTokens/'+currentimestamp+"/",header = 'true')
        # missing_url = requote_uri("https://s3.{0}.amazonaws.com/{1}/{2}".format(bucket_location['LocationConstraint'], SOURCE_BUCKET, 'reservation-glue-workflow-triggers/'+TODAY +'/Audit/'+tablename+'/MissingTokens/'+currentimestamp+"/"))
        MissingTokens_df.repartition(1).write.csv('s3://{}/sabre/reservation/'.format(blue_bucket) +  'Audit/'+tablename+'/MissingTokens/'+currentimestamp+"/",header = 'true')
        missing_url = requote_uri("https://s3.{0}.amazonaws.com/{1}/{2}".format(bucket_location['LocationConstraint'], blue_bucket, 'sabre/reservation/'+'Audit/'+tablename+'/MissingTokens/'+currentimestamp+"/"))
        MissingTokens.append(str(missing_url))
        

    except Exception as e:
       logger.error(str(e))
       logger.error("**************** [ERROR] Error reading echotoken, failed with error: {} ***********".format(str(e)))
       f_msg = "**************** [ERROR] Error reading echotoken, failed with error: {} ***********".format(str(e))
       f_sub = "Reservation Audit Job - {} Failed".format(job_name)
       
       # Generating logs for ES
       streaminfo(generateESLogs(job_name,'ERROR',str(e),log_process_start_datetime,log_process_start_datetime,0,0,0))
       notifymsg(f_sub,f_msg)
       exit(1) 

############################### read_s3_dataset ######################3
# Read the echotokens from s3, written by firstjob
##########################################################################
 
try:
    echotoken_df=glueContext.read \
                            .format("csv") \
                            .option("inferSchema", "false") \
                            .option("header", "true") \
                            .load(ECO_TOKEN_PATH)
    #print(echotoken_df.show())
    source_count=echotoken_df.count()
    echotoken_df.createTempView("echoToken_temp")

except Exception as e:
    logger.error(str(e))
    logger.error("**************** [ERROR] Error reading echotoken, failed with error: {} ***********".format(str(e)))
    f_msg = "**************** [ERROR] Error reading echotoken, failed with error: {} ***********".format(str(e))
    f_sub = "Reservation Audit Job - {} Failed".format(job_name)
    
    # Generating logs for ES
    streaminfo(generateESLogs(job_name,'ERROR',str(e),log_process_start_datetime,log_process_start_datetime,0,0,0))
    notifymsg(f_sub,f_msg)
    exit(1)     

########################### Read STL_LOAD_ERRORS ###################################

logger.info("{}: Getting Data from Load Error Table for Audit".format(str(datetime.now())))

try:
    RSerror_df = glueContext.create_dynamic_frame.from_options(
	connection_type = "redshift", 
	connection_options = {
		"url": rs_url_db_dest,
        "database": rsdb, 
        "user": rs_user_dest, 
        "password": rs_pwd_dest, 
        "dbtable" : schemaname + ".{}".format(glueerrortable),
		"redshiftTmpDir" :  REDSHIFT_PATH+"stl_load_errors/"+str(datetime.now()).replace(" ","_")+"/"
	    }
    )


    RSerror_df.toDF().createTempView("RSerror")
except Exception as e:
    logger.error(str(e))
    logger.error("**************** [ERROR] Error reading STL_LOAD_ERRORS Table, failed with error: {} ***********".format(str(e)))
    f_msg = "**************** [ERROR] Error reading STL_LOAD_ERRORS Table, failed with error: {} ***********".format(str(e))
    f_sub = "Reservation Audit Job - {} Failed".format(job_name)
    
    # Generating logs for ES
    streaminfo(generateESLogs(job_name,'ERROR',str(e),log_process_start_datetime,log_process_start_datetime,source_count,0,source_count))
    notifymsg(f_sub,f_msg)
    exit(1)  

########################### Read rsv_dq_error_intermediate table data  ###################################

logger.info("{}: Getting Data from DQ Load Error Table".format(str(datetime.now())))

try:
    DQ_intermediate_dyf = glueContext.create_dynamic_frame.from_options(
	connection_type = "redshift", 
	connection_options = {
		"url": rs_url_db_dest,
        "database": rsdb, 
        "user": rs_user_dest, 
        "password": rs_pwd_dest, 
        "dbtable" : schemaname + ".{}".format(dq_intermediate_tablename),
		"redshiftTmpDir" :  REDSHIFT_PATH+"rsv_dq_error_intermediate/"+str(datetime.now()).replace(" ","_")+"/"
	    }
    )

    DQ_intermediate_dyf.toDF().createTempView("RSDQerror")
except Exception as e:
    logger.error(str(e))
    logger.error("**************** [ERROR] Error reading rsv_dq_error_intermediate Table, failed with error: {} ***********".format(str(e)))
    f_msg = "**************** [ERROR] Error reading rsv_dq_error_intermediate Table, failed with error: {} ***********".format(str(e))
    f_sub = "Reservation Audit Job - {} Failed".format(job_name)
    
    # Generating logs for ES
    streaminfo(generateESLogs(job_name,'ERROR',str(e),log_process_start_datetime,log_process_start_datetime,source_count,0,source_count))
    notifymsg(f_sub,f_msg)
    exit(1)    

########################### Read rsv_data_errors_counts for ES logs  ###################################
logger.info("{}: Reading DQ Data from DQ Load Error Table for Audit".format(str(datetime.now())))
try:
    Errorcount_sql = 'select dataval_id,error_message,count(1) as dq_count from RSDQerror group by dataval_id,error_message'
    print("okay1")
    Errorcount_df = spark.sql(Errorcount_sql)
    print("okay2")
    #dataval_id_c = Errorcount_df["dataval_id"]
    #dataval_id_c = Errorcount_df.rdd.map(new-res-stream-lambda x: x.dataval_id).collect()
    #error_message_c = Errorcount_df["error_message"]
    #error_message_c = Errorcount_df.rdd.map(new-res-stream-lambda x: x.error_message).collect()
    #dq_count_c = Errorcount_df["dq_count"]
    #dq_count_c = Errorcount_df.rdd.map(new-res-stream-lambda x: x.dq_count).collect()
    
    pandDF = Errorcount_df.select(Errorcount_df.dataval_id,Errorcount_df.error_message,Errorcount_df.dq_count).toPandas()
    print(pandDF)
    print("okay3")
    dataval_id_c = list(pandDF['dataval_id'])
    print(dataval_id_c)
    error_message_c = list(pandDF['error_message'])
    print(error_message_c)
    dq_count_c = list(pandDF['dq_count'])
    print(dq_count_c)
    print("okay4")
    rule_id_received = len(dataval_id_c)
    i=0
    while i < rule_id_received:
    
    # Generating logs for ES
     dqstreaminfo(generateDQESLogs(job_name,dataval_id_c[i],error_message_c[i],log_process_start_datetime,source_count,dq_count_c[i]))
     i = i+1
    print("okay5")
except Exception as e:
    logger.error(str(e))
    logger.error("**************** [ERROR] Error reading rsv_dq_error_intermediate counts Table, failed with error: {} ***********".format(str(e)))
    f_msg = "**************** [ERROR] Error reading rsv_dq_error_intermediate Table Counts, failed with error: {} ***********".format(str(e))
    f_sub = "Reservation Audit Job - {} Failed".format(job_name)
    
    # Generating logs for ES
    streaminfo(generateESLogs(job_name,'ERROR',str(e),log_process_start_datetime,log_process_start_datetime,source_count,0,source_count))
    notifymsg(f_sub,f_msg)
    exit(1)   
   

########################### SQL for Audit Log table ###################################

logger.info("{}: Starting Audit Process".format(str(datetime.now())))
try:
    
    starttime_df = spark.sql(""" select max(starttime) as starttime from echoToken_temp """)
    starttime=starttime_df.first()['starttime']
    
    AuditTokens_sql = (""" select 'Synxis' as  src_system_nm, current_timestamp as land_insert_ts, 
                             A._EchoToken as id, case when err.error_token is null then 'S' else 'F' end as record_land_status,
                             case when err.error_token is not null then err.err_reason else null end as land_error_txt,
							 case when err.error_token is not null then err.filename else null end as errored_file_path,
							 case when err.error_token is not null then err.raw_line else null end as errored_record,
							 case when err.error_token is not null then err.colname else null end as errored_col,
                             case when err.error_token is not null then err.raw_field_value else null end as errored_field_value,
							 dq.pros_flag as pros_flag
                             from echoToken_temp A left join 
                             (select distinct SUBSTRING_INDEX(raw_line,',',1) as error_token,err_reason,filename,raw_line,colname,raw_field_value from RSerror where starttime > {0}) err 
                              on A._EchoToken = err.error_token left join
                             (select AA.id,AA.pros_flag from 
                             (select id,pros_flag, ROW_NUMBER() OVER ( PARTITION BY id ORDER BY pros_flag ) row_num FROM RSDQerror) AA where AA.row_num = 1) dq
                             on A._EchoToken = dq.id
                             """.format("'"+starttime+"'"))
    AuditTokens  = spark.sql(AuditTokens_sql)

    AuditTokens_df = DynamicFrame.fromDF(	AuditTokens, 	glueContext, 	"AuditTokens_df")	

    AuditTokens_table_map = ResolveChoice.apply(
	                                            frame = AuditTokens_df,
	                                            choice = "make_cols",
	                                            transformation_ctx 	= "AuditTokens_table_map"
                                               )
    AuditTokens.createTempView("echoToken_stats")

except Exception as e:
    logger.error(str(e))
    logger.error("**************** [ERROR] Error with Audit process, failed with error: {} ***********".format(str(e)))
    f_msg = "**************** [ERROR] Error with Audit process, failed with error: {} ***********".format(str(e))
    f_sub = "Reservation Audit Glue Job - {} Failed".format(job_name)
    notifymsg(f_sub,f_msg)
    
    # Generating logs for ES
    streaminfo(generateESLogs(job_name,'ERROR',str(e),log_process_start_datetime,log_process_start_datetime,source_count,0,source_count))
    exit(1) 

try:
    ########################### Write to Audit Log table ###################################

    logger.info("{}: Updating Audit table with status ".format(str(datetime.now())))

    erroredTokensAudit = glueContext.write_dynamic_frame.from_jdbc_conf(
	                                             frame = AuditTokens_table_map, 
	                                             catalog_connection = redshiftconnection, 
	                                             connection_options = {
		                                                                "url": rs_url_db_dest,
                                                                        "database": rsdb, 
                                                                        "user": rs_user_dest, 
                                                                        "password": rs_pwd_dest,  
		                                                                "dbtable" : schemaname + ".{}".format(audittable)
	                                                                  },  
	                                                                     redshift_tmp_dir = REDSHIFT_PATH+"Audit/"+str(datetime.now()).replace(" ","_")+"/"
                                                   )
    
    AuditTokens_error = spark.sql(""" select count(record_land_status) as count from echoToken_stats where  record_land_status='F' """)
    AuditTokens_error_count=AuditTokens_error.first()['count'] 
    AuditTokens_success = spark.sql(""" select count(record_land_status) as count from echoToken_stats where  record_land_status='S' """)
    AuditTokens_success_count=AuditTokens_success.first()['count'] 
    
    #logger.info("Success Tokens count: {}  Errored Tokens count: {}".format(str(AuditTokens_success_count),str(AuditTokens_error_count)))

    ErroredTokens_df = spark.sql(""" select distinct id as id from echoToken_stats where  record_land_status='F' """)
    ErroredTokens_df.repartition(1).write.csv('s3://{}/sabre/reservation/'.format(blue_bucket) +  'Audit/'+'ErroredTokens/'+currentimestamp+'/',header = 'true')
    # ErroredTokens_df.repartition(1).write.csv(WRITE_S3_PATH + TODAY +  '/Audit/'+'ErroredTokens/'+currentimestamp+'/',header = 'true')
    bucket_location = s3Client.get_bucket_location(Bucket=blue_bucket)
    errored_url = requote_uri("https://{1}.s3.amazonaws.com/{2}".format( bucket_location['LocationConstraint'],blue_bucket,'sabre/reservation/'+'Audit/ErroredTokens/'+currentimestamp+"/"))
    # errored_url = requote_uri("https://{1}.s3.amazonaws.com/{2}".format( bucket_location['LocationConstraint'],SOURCE_BUCKET,'reservation-glue-workflow-triggers/'+TODAY +'/Audit/ErroredTokens/'+currentimestamp+"/"))
    
    notify_msg= "Success Tokens count: {}  Errored Tokens count: {} \n".format(str(AuditTokens_success_count),str(AuditTokens_error_count))
    
    errored_msg= notify_msg+ " \n "+" Below is the link for errored tokens \n {} ".format(errored_url)
    
    notifymsg('RSV Errored Tokens',errored_msg)
    
    logger.info(notify_msg)
    
    table_list = ['stg_rsv_addr', 'stg_rsv_cancelpenaltypolicy','stg_rsv_comments','stg_rsv_guaranteepayment','stg_rsv_guestcount','stg_rsv_hotelreservation','stg_rsv_hotelreservationid','stg_rsv_custloyalty',
                  'stg_rsv_membership','stg_rsv_paymentaccepted','stg_rsv_profileinfo','stg_rsv_rate','stg_rsv_resguestrph','stg_rsv_roomstay','stg_rsv_taxbreakdown','stg_rsv_telephone','stg_rsv_uniqueid']
                  
    for tablename in table_list:
        EchotokenValidation(tablename,starttime)
    
    success_msg= notify_msg +" \n "+" Below are the links for the successfully processed tokens {} \n ".format('\n'.join(SuccessTokens))
    notifymsg('RSV Success Tokens',success_msg)
    
    missing_msg= " Below are the links for the missing tokens {} \n".format('\n'.join(MissingTokens))
    notifymsg('RSV Missing Tokens',missing_msg)
    
    # Generating logs for ES
    if AuditTokens_error_count != 0:
        streaminfo(generateESLogs(job_name,'SUCCESS','Check Redshift RSV Audit Table (dwstg.stg_rsv_audit_log) for more details',log_process_start_datetime,log_process_start_datetime,source_count,AuditTokens_success_count,AuditTokens_error_count))
    else:
        streaminfo(generateESLogs(job_name,'SUCCESS','',log_process_start_datetime,log_process_start_datetime,source_count,AuditTokens_success_count,AuditTokens_error_count))

except Exception as e:
    logger.error(str(e))
    logger.error("**************** [ERROR] Error with Audit process, failed with error: {} ***********".format(str(e)))
    f_msg = "**************** [ERROR] Error with Audit process, failed with error: {} ***********".format(str(e))
    f_sub = "Reservation Audit Glue Job - {} Failed".format(job_name)
    notifymsg(f_sub,f_msg)
    
    # Generating logs for ES
    streaminfo(generateESLogs(job_name,'ERROR',str(e),log_process_start_datetime,log_process_start_datetime,source_count,0,source_count))
    exit(1) 
    
#################### Dataload to rsv_data_errors table ########################
try:
    redshift_load_rsv_dq_error  = glueContext.write_dynamic_frame.from_jdbc_conf(
                                                  frame = DQ_intermediate_dyf, 
                                                  catalog_connection = redshiftconnection, 
                                                  connection_options = {
                                                                      "url": rs_url_db_dest,
                                                                      "database": rsdb, 
                                                                      "user": rs_user_dest, 
                                                                      "password": rs_pwd_dest, 
                                                                      "dbtable" : schemaname+'.'+dq_tablename ,
                                                                      "postactions":"delete from {}.{};".format(schemaname,dq_intermediate_tablename),
                                                                      "extracopyoptions":"MAXERROR 100000"},  
                                                  redshift_tmp_dir = "s3://"+blue_bucket+'/sabre/reservation/rsv_data_errors/{}/{}/'.format(job_name,str(datetime.now()).replace(" ","_"))
                                                      )
    logger.info(" Data Load Process for rsv_dq_erro to redshift complete")
except Exception as e:
    logger.error(str(e))
    logger.info("  [ERROR] Error while loading to Redshift rsv_data_errors table, failed with : {} ".format(str(e)))
    f_msg="  Error while loading to rsv_data_errors table for the job {}, failed with error: {} ".format(job_name,str(e))
    f_sub = "Reservation Audit Glue Job "+job_name+" failed"
    
    # Generating logs for ES
    streaminfo(generateESLogs(job_name,'ERROR',str(e),log_process_start_datetime,log_process_start_datetime,source_count,AuditTokens_success_count,AuditTokens_error_count))
    notifymsg(f_sub, f_msg)
    exit(1)      
    
############################### read_s3_dataset #######################
                            # Delete Marker files #
##########################################################################
bucket = s3resource.Bucket(blue_bucket)

try:
    objects = bucket.objects.filter(Prefix='sabre/reservation/reservation-glue-workflow-marker-triggers/WHG-Glue-UW2-Resv')
    logger.info(" Deleting the marker files")
    objects.delete()
except Exception as e:
    logger.error(" Error while deleting the marker files, failed with error: {}".format(str(e)))
    f_msg = "Error while deleting the marker files, failed with error: {}".format(str(e))
    f_sub = "ERROR Deleting Marker Files for Reservation Audit Job - ".format(job_name)
    
    # Generating logs for ES
    streaminfo(generateESLogs(job_name,'ERROR',str(e),log_process_start_datetime,log_process_start_datetime,source_count,AuditTokens_success_count,AuditTokens_error_count))
    notifymsg(f_sub,f_msg)
    exit(1)
    
####################### generating an ETL Trigger File ###########################
try:
    etl_trigger_key = 'trigger_files/reservation/rsrv_glue.trg'
    etl_trigger_body = json.dumps({"reservation":"/whgdata/Facts/TriggerFiles/Reservation/rsrv_glue.trg","timestamp":"{}".format(create_trigger_file_ts())})
    response = s3Client.put_object(Bucket=gold_bucket, Body=etl_trigger_body, Key=etl_trigger_key)
    print(response)
except Exception as error:
    logger.error("************ {} [ERROR] Exception while writing the trigger file to S3 for Audit Glue Job************".format(str(datetime.now())))
    logger.error("*********** [ERROR] Failing with error: {} **************".format(str(error)))
    f_msg="Error while writing the trigger file from Glue Job {}, failed with Error: {}".format(job_name,str(error))
    f_sub = "Error writing Trigger File for Glue Job - {}".format(job_name)
    
    # Generating logs for ES
    streaminfo(generateESLogs(job_name,'ERROR',str(e),log_process_start_datetime,log_process_start_datetime,source_count,AuditTokens_success_count,AuditTokens_error_count))
    notifymsg(f_sub, f_msg)
    exit(1)
    
logger.info(" End of AuditLog job run ")
    