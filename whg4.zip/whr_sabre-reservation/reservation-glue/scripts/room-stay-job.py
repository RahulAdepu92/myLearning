import sys
from datetime import datetime
from datetime import timedelta
import pytz
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.dynamicframe import DynamicFrame
from pyspark.sql import SQLContext
import boto3
import logging
from pyspark.sql import functions as f
from pyspark.sql.functions import  col, when, lit, input_file_name, substring_index,year, month, dayofmonth, round
from pyspark.sql.types import TimestampType, DoubleType, StructType, StructField, StringType, IntegerType, LongType, FloatType, DecimalType

################################### Setting up Spark environment and enabling Glue to interact with Spark Platform ##################################
sc=SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
sqlContext = SQLContext(sc)

################################### Enabling access to the arguments ##################################
job = Job(glueContext)
args = getResolvedOptions(sys.argv, ['JOB_NAME','blue_bucket','error_bucket','SNS','rsdb','redshiftconnection','tablename','schemaname','audittable','ScriptBucketName','configfile','gold_bucket','rules_tablename','dq_intermediate_tablename'])
job.init(args['JOB_NAME'], args)

################################### Setting up logger for event logging ##################################
logging.basicConfig()
logger = logging.getLogger()
logger.setLevel(logging.INFO)

################################### Assigning job arguments to variables  ##################################

rsdb = args['rsdb']
redshiftconnection = args['redshiftconnection']
blue_bucket = args['blue_bucket']
gold_bucket = args['gold_bucket']
file_path_gen = 's3://{}/sabre/reservation/processing/'.format(blue_bucket)
error_bucket = args['error_bucket']
job_name = args['JOB_NAME']
tablename = args['tablename']
schemaname = args['schemaname']
audittable = args['audittable']
sns_notify = args['SNS']
MARKER_FILE = "sabre/reservation/reservation-glue-workflow-marker-triggers/" +args["JOB_NAME"]
PARQUET_FILE_PATH = "s3://{}/reservation/{}".format(gold_bucket,'RoomStay')
job_run = True
file_path_gen_lkup = 's3://{}/sabre/reservation/lkup-site/'.format(blue_bucket)
rules_tablename = args['rules_tablename']
dq_intermediate_tablename = args['dq_intermediate_tablename']
round_off_cols =['totalamountbeforetax','totalamountaftertax','totaltaxesamount']

################################### Create low level reosurce service client for S3 ans SNS  ##################################

s3Client = boto3.client('s3',region_name='us-west-2')
s3resource = boto3.resource('s3',region_name='us-west-2')
glueClient = boto3.client('reservation-glue', region_name='us-west-2')


try:
    sns_client = boto3.client('sns',region_name = 'us-west-2')
    logger.info("Enabled SNS Notification")
except Exception as e:
    logger.error(str(e))
    logger.info(" Unable to enable SNS, failed with error: {}".format(str(e)))
    logger.info("Continuing with load without SNS notification")
    
    
def notifymsg(sub, msg):
    sns_client.publish(TopicArn = sns_notify, Message = msg , Subject= sub) 
    logger.info("**************** [INFO] SNS Notification Sent: {} *************************".format(job_name))

################## Create Timestamp ############################

def create_timestamp_est():
    
    now = datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')
    
    # est = pytz.timezone('US/Eastern')
    # now_est = now.astimezone(est).strftime('%Y-%m-%d %H:%M:%S.%f')
    
    return now

  

######## Check if this is rerun based on the marker file, if so the job execution is skipped ###################################
try:
    response = s3Client.head_object(Bucket=blue_bucket, Key=MARKER_FILE)
    print(response)
    print("*******************[INFO] JOB ALREADY EXECUTED ********************")
    job_run = False
except Exception as HeadObjectException:
    ##############################################################################################
    # No Marker file present, then this is first time execution
    # Will read the file based on get_input_s3_path response
    ##############################################################################################
    print(HeadObjectException)

if job_run:
    
    ################################### Retriving connection information from Glue connections for Redshift  ##################################
    try:
       logger.info("Getting Redshift Connection Information")    
       rs_connection_dest = glueContext.extract_jdbc_conf(redshiftconnection)
       rs_url_dest = rs_connection_dest["url"]
       rs_user_dest = rs_connection_dest["user"]
       rs_pwd_dest = rs_connection_dest["password"]
       rs_url_db_dest = rs_url_dest+'/'+rsdb
    except Exception as e:
       logger.error(str(e))
       f_msg=" Unable to connect to Redshift while processing the reservation-glue job {0} , failed with error: {1}  ".format(job_name,str(e))
       f_sub = "Reservation Room Stay Glue job "+job_name+" failed" 
       notifymsg(f_sub, f_msg)
       logger.info(" Exiting with error: {}".format(str(e)))
       exit(1)  
       
    ############################## Reading Data from Processing Folder #################################################
    try:
        logger.info(" Reading Room Stay Data from JSON ")
        res_s3_read_dyf = glueContext.create_dynamic_frame.from_options(connection_type="s3", 
                    connection_options={"paths": [file_path_gen],'recurse':True, 'groupFiles': 'inPartition'},
                    format="json",
                    format_options={"jsonPath": "$.stg_rsv_Roomstay[*]"})
        
        res_df = res_s3_read_dyf.toDF()
        res_df_count = res_df.count()
        print('Total Cound DF: {}'.format(res_df_count))
        res_df.printSchema()
        # res_df.show(10, False)
        
               
        
    except Exception as e:
        logger.error("************ {} [ERROR] Exception while reading the file from S3 *************".format(str(datetime.now())))
        logger.error("*********** [ERROR] Failing with error:  {} **************".format(str(e)))
        f_msg="  Error while reading Room Stay data from S3 for the job {0} , failed with error: {1}  ".format(job_name,str(e))
        f_sub = "Reservation Room Stay Glue job "+job_name+" failed" 
        notifymsg(f_sub, f_msg)
        exit(1)
        
        ############################## Reading Data from Processing Folder #################################################
    
    try:
        logger.info(" Reading lkup-site Data from JSON ")
        res_s3_read_dyf_lkup_site = glueContext.create_dynamic_frame.from_options(connection_type="s3", 
                    connection_options={"paths": [file_path_gen_lkup],'recurse':True, 'groupFiles': 'inPartition'},
                    format="json")
                    
        res_df_lkup_site = res_s3_read_dyf_lkup_site.toDF()
        res_df_lkup_site_count = res_df_lkup_site.count()
        print('Total lkup-site Count DF: {}'.format(res_df_lkup_site_count))
        res_df_lkup_site.printSchema()        
        
        res_df_lkup_site.show(10,False)      
        
        new_column_name_list = list(map(lambda x:'lkup_'+x,res_df_lkup_site.columns))
        res_df_lkup_site_lkup = res_df_lkup_site.toDF(*new_column_name_list)
        
        print('res_df_lkup_site_lkup')
        res_df_lkup_site_lkup.printSchema()        
        
        res_df_lkup_site_lkup.show(10,False)

    except Exception as e:
        logger.error("************ {} [ERROR] Exception while reading the lkup-site file from S3 *************".format(str(datetime.now())))
        logger.error("*********** [ERROR] Failing with error:  {} **************".format(str(e)))
        f_msg="  Error while reading Room Stay data from S3 for the job {0} , failed with error: {1}  ".format(job_name,str(e))
        f_sub = "Reservation Room Stay Glue job "+job_name+" failed" 
        notifymsg(f_sub, f_msg)
        exit(1)        
    
    ################## Data read from redshift to df for rsv_data_valrules#################################
    try:
        dyf_data_valrules = glueContext.create_dynamic_frame.from_options(
                                            connection_type = "redshift", 
                                            connection_options = {
                                                            "url": rs_url_db_dest,
                                                            "database": rsdb, 
                                                            "user": rs_user_dest, 
                                                            "password": rs_pwd_dest, 
                                                            "dbtable" : schemaname+'.'+rules_tablename ,
                                                            "extracopyoptions":"MAXERROR 100000",
                                                            "redshiftTmpDir": "s3://"+blue_bucket+'/sabre/reservation/stl_load_errors/dataread_valrules/{}/{}/'.format(job_name,str(datetime.now()).replace(" ","_"))} 
                                            
                                                )
        res_df_data_valrules = dyf_data_valrules.toDF()
        res_df_data_valrules_count = res_df_data_valrules.count()
        print('Total lkup-site Count DF: {}'.format(res_df_data_valrules_count))
        res_df_data_valrules.printSchema()
        res_df_data_valrules.show(10,False)
        logger.info(" Data Read from rsv_data_valrules to df complete")
        
        new_column_name_list = list(map(lambda x:'val_'+x,res_df_data_valrules.columns))
        res_df_data_valrules_val = res_df_data_valrules.toDF(*new_column_name_list)
            
    except Exception as e:
        logger.error(str(e))
        logger.info("  [ERROR] Error while loading to df from rsv_data_valrules table, failed with : {} ".format(str(e)))
        f_msg="  Error while loading to df from rsv_data_valrules table for the job {}, failed with error: {} ".format(job_name,str(e))
        f_sub = "Reservation Room Stay Glue job "+job_name+" failed" 
        notifymsg(f_sub, f_msg)
        exit(1) 
    
    if res_df_count == 0:
        logger.info('No Data to process for Room Stay for {} run'.format(str(datetime.now())))
        f_msg = "No Data to Process for Room Stay Glue Job - {} for run {}".format(job_name,str(datetime.now()))
        f_sub = "No Data to Process for Room Stay Glue Job - {}".format(job_name)
        notifymsg(f_sub, f_msg)
        # exit(0)
    else:
        ################## Data Transformation Step #################################
        try:
            logger.info('Mapping Field Name with Redshift Column')
            
            ################## Filling in blank values with Null values #################################
            for x in res_df.columns:
                res_df = res_df.withColumn(x, when(col(x) != '', col(x)).otherwise(None)) 

            for y in round_off_cols:
                res_df= res_df.withColumn(y,round(col(y).cast('float'),2))
                res_df= res_df.withColumn(y,col(y).cast('string'))

            df_final = res_df.withColumn('inserted_ts',lit(create_timestamp_est()).cast(TimestampType()))
                     
            
            # df_final.printSchema()
            # df_final.show(10, False)
            
            df_final_new = df_final.drop("uniqueidid","resstatus")

            dyf_final = DynamicFrame.fromDF(df_final_new, glueContext,'dyf_final')
            
        except Exception as e:
            logger.error("************ {} [ERROR] Exception while doing Data Transformtion on Room Stay Data *************".format(str(datetime.now())))
            logger.error("*********** [ERROR] Failing with error:  {} **************".format(str(e)))
            f_msg="  Error while doing Data Transformtion on Room Stay Data for Glue Job {0} , failed with error: {1}  ".format(job_name,str(e))
            f_sub = "Reservation Room Stay Glue job "+job_name+" failed" 
            notifymsg(f_sub, f_msg)
            exit(1)
            
           
        ################## Data Quality Checks #################################
        try:
            logger.info('Start of DQ checks')
            ################## Rule 2 Data Check No Arrival Date #################################
            logger.info('DQ Check for rule 2')
            dq_check_rule_2 =  df_final.withColumn('Qid', when((df_final.timespan_start.isNull()) & (df_final.resstatus!='Cancel'),'2').otherwise('NOACTION')) \
                                    .withColumn('src_col_value', when((df_final.timespan_start.isNull()) & (df_final.resstatus!='Cancel'),None).otherwise('NOACTION'))
            
            df_DQ_check =  dq_check_rule_2.filter(dq_check_rule_2.Qid != 'NOACTION')
            
            logger.info('DQ Check for Rule 2 Completed ')
            ################## Rule 4 Data Check No Departure Date #################################
            logger.info(' Start of DQ check for Rule 4')
            dq_check_rule_4 =  df_final.withColumn('Qid', when((df_final.timespan_end.isNull()) & (df_final.resstatus!='Cancel'),'4').otherwise('NOACTION')) \
                                    .withColumn('src_col_value', when((df_final.timespan_end.isNull()) & (df_final.resstatus!='Cancel'),None).otherwise('NOACTION'))
            df_DQ_check =  df_DQ_check.union(dq_check_rule_4.filter(dq_check_rule_4.Qid != 'NOACTION'))
            
            logger.info('DQ Check for Rule 4 Completed ')
            ################## Rule 30 Data Check No Market Segment #################################
            logger.info(' Start of DQ check for Rule 30')
            
            dq_check_rule_30 =  df_final.withColumn('Qid', when((df_final.marketcode.isNull()) & (df_final.resstatus!='Cancel'),'30').otherwise('NOACTION')) \
                                    .withColumn('src_col_value', when((df_final.marketcode.isNull()) & (df_final.resstatus!='Cancel'),None).otherwise('NOACTION'))
            
            df_DQ_check =  df_DQ_check.union(dq_check_rule_30.filter(dq_check_rule_30.Qid != 'NOACTION'))
            
            logger.info('DQ Check for Rule 30 Completed ')
            ################## Rule 9 Data Check No Hotel Code #################################
            logger.info(' Start of DQ check for Rule 9')
            
            dq_check_rule_9 =  df_final.withColumn('Qid', when(df_final.basicpropertyinfohotelcode.isNull(),'9').otherwise('NOACTION')) \
                                    .withColumn('src_col_value', when(df_final.basicpropertyinfohotelcode.isNull(),None).otherwise('NOACTION'))

            df_DQ_check =  df_DQ_check.union(dq_check_rule_9.filter(dq_check_rule_9.Qid != 'NOACTION'))
            
            logger.info('DQ Check for Rule 9 Completed ')
            ################## Rule 34 Data Check No Currency Code #################################
            logger.info(' Start of DQ check for Rule 34')
            
            dq_check_rule_34 =  df_final.withColumn('Qid', when((df_final.totalcurrencycode.isNull()) & (df_final.resstatus!='Cancel'),'34').otherwise('NOACTION')) \
                                    .withColumn('src_col_value', when((df_final.totalcurrencycode.isNull()) & (df_final.resstatus!='Cancel'),None).otherwise('NOACTION'))
            
            df_DQ_check =  df_DQ_check.union(dq_check_rule_34.filter(dq_check_rule_34.Qid != 'NOACTION'))
            
            logger.info('DQ Check for Rule 34 Completed ')
            ################## Rule 3 Data Check Incorrect Arrival Date format #################################
            logger.info(' Start of DQ check for Rule 3')
            
            dq_check_rule_3 =  df_final.withColumn('Qid', when((df_final.timespan_start.isNotNull()) & (df_final.resstatus!='Cancel') & ((f.to_date( (f.col('timespan_start').cast(StringType())), 'yyyy-MM-dd').isNull()) | (f.length(f.trim(f.col('timespan_start').cast(StringType())))<10)),'3').otherwise('NOACTION')) \
                                    .withColumn('src_col_value', when((df_final.timespan_start.isNotNull()) & (df_final.resstatus!='Cancel') & ((f.to_date( (f.col('timespan_start').cast(StringType())), 'yyyy-MM-dd').isNull()) | (f.length(f.trim(f.col('timespan_start').cast(StringType())))<10)) ,f.col('timespan_start')).otherwise('NOACTION'))
            
            df_DQ_check =  df_DQ_check.union(dq_check_rule_3.filter(dq_check_rule_3.Qid != 'NOACTION'))
            
            logger.info('DQ Check for Rule 3 Completed ')
            ################## Rule 5 Data Check Incorrect Departure Date format #################################
            logger.info(' Start of DQ check for Rule 5')
            
            dq_check_rule_5 =  df_final.withColumn('Qid', when((df_final.timespan_end.isNotNull()) & (df_final.resstatus!='Cancel') & ((f.to_date( (f.col('timespan_end').cast(StringType())), 'yyyy-MM-dd').isNull()) | (f.length(f.trim(f.col('timespan_end').cast(StringType())))<10)),'5').otherwise('NOACTION')) \
                                    .withColumn('src_col_value', when((df_final.timespan_end.isNotNull()) & (df_final.resstatus!='Cancel') & ((f.to_date( (f.col('timespan_end').cast(StringType())), 'yyyy-MM-dd').isNull()) | (f.length(f.trim(f.col('timespan_end').cast(StringType())))<10)) ,f.col('timespan_end')).otherwise('NOACTION'))
            
            df_DQ_check =  df_DQ_check.union(dq_check_rule_5.filter(dq_check_rule_5.Qid != 'NOACTION'))

            logger.info('DQ Check for Rule 5 Completed ')
            ################## Rule 1 Data Check Test Site ID #################################
            logger.info(' Start of DQ check for Rule 1')
            
            dq_check_rule_1 = df_final.withColumn('Qid',    
                                   when(df_final.basicpropertyinfohotelcode.isin([54924,80128,80143,80146,80149,80150,80170,80203,80441,82230,99911,'HPQA','PBHTNGEDW',88642]), '1')
                                   .otherwise('NOACTION')
                                   ).withColumn('src_col_value',
                                   when(df_final.basicpropertyinfohotelcode.isin([54924,80128,80143,80146,80149,80150,80170,80203,80441,82230,99911,'HPQA','PBHTNGEDW',88642]),f.col('basicpropertyinfohotelcode'))
                                   .otherwise('NOACTION'))
           
            df_DQ_check =  df_DQ_check.union(dq_check_rule_1.filter(dq_check_rule_1.Qid != 'NOACTION'))
            
            logger.info('DQ Check for Rule 1 Completed ')


            df_DQ_error = df_DQ_check.filter(df_DQ_check.Qid != 'NOACTION')
            ################## Join Lkup_site table to df_DQ_valrules_join data frame based on basicpropertyinfohotelcode = lkup_crs_site_id and considering only matched values #################################
            

            df_DQ_valrules_lkup_site_join_1 = df_DQ_error.join(res_df_lkup_site_lkup,(df_DQ_error.basicpropertyinfohotelcode == res_df_lkup_site_lkup.lkup_crs_site_id),how='inner')
            ################## Join Lkup_site table to df_DQ_valrules_join data frame based on basicpropertyinfohotelcode = lkup_site_id & brandcode = lkup_brand_id  and considering only matched values #################################                                         
            df_DQ_valrules_lkup_site_join_2 = df_DQ_error.join(res_df_lkup_site_lkup,((((df_DQ_error.basicpropertyinfohotelcode == res_df_lkup_site_lkup.lkup_site_id) 
                                                                                    & (df_DQ_error.basicpropertyinfobrandcode == res_df_lkup_site_lkup.lkup_brand_id)) & df_DQ_error.basicpropertyinfobrandcode.isNotNull() )
                                                                                    ),how='inner' )
                                                                                    

            df_DQ_valrules_lkup_site_union = df_DQ_valrules_lkup_site_join_1.union(df_DQ_valrules_lkup_site_join_2)
            df_DQ_valrules_lkup_site_union = df_DQ_valrules_lkup_site_union.distinct()
            ################## Join Lkup_site table to df_DQ_valrules_join data frame based on basicpropertyinfohotelcode = lkup_site_id & brandcode is null  and considering only matched values #################################      
            df_DQ_valrules_lkup_site_join_3 = df_DQ_error.join(res_df_lkup_site_lkup,((df_DQ_error.basicpropertyinfohotelcode ==  res_df_lkup_site_lkup.lkup_site_id) & df_DQ_error.basicpropertyinfobrandcode.isNull()),how='inner')
            
            df_DQ_valrules_lkup_site_union_2 = df_DQ_valrules_lkup_site_union.union(df_DQ_valrules_lkup_site_join_3)
            df_DQ_valrules_lkup_site_union_2 = df_DQ_valrules_lkup_site_union_2.distinct()
            ################## Join Lkup_site table to df_DQ_valrules_join data frame excluding above joined values ################################# 
            df_DQ_error_exclude  = df_DQ_error.join(df_DQ_valrules_lkup_site_union_2, (df_DQ_error.basicpropertyinfohotelcode == df_DQ_valrules_lkup_site_union_2.basicpropertyinfohotelcode),how='leftanti').select(df_DQ_error['*'])
            
            df_DQ_valrules_lkup_site_join_4 =  df_DQ_error_exclude.join(res_df_lkup_site_lkup,(df_DQ_error_exclude.basicpropertyinfohotelcode == res_df_lkup_site_lkup.lkup_crs_site_id),how='left')
 
            df_DQ_valrules_lkup_site_join = df_DQ_valrules_lkup_site_union_2.union(df_DQ_valrules_lkup_site_join_4)
            df_DQ_valrules_lkup_site_join = df_DQ_valrules_lkup_site_join.distinct()
            ################## Join Dq Val rules table to df_DQ_error data frame based on Qid value ################################

            df_DQ_valrules_join = df_DQ_valrules_lkup_site_join.join(res_df_data_valrules_val,(df_DQ_valrules_lkup_site_join.Qid == res_df_data_valrules_val.val_id),how='inner')
            

            ################## Join Lkup_site table to df_final data frame based on basicpropertyinfohotelcode = lkup_crs_site_id and considering only matched values #################################
            df_df_final_lkup_site_join_1 = df_final.join(res_df_lkup_site_lkup,(df_final.basicpropertyinfohotelcode == res_df_lkup_site_lkup.lkup_crs_site_id),how='inner')
            ################## Join Lkup_site table to df_final data frame based on basicpropertyinfohotelcode = lkup_site_id & brandcode = lkup_brand_id  and considering only matched values #################################                                                
            df_df_final_lkup_site_join_2 = df_final.join(res_df_lkup_site_lkup,(((df_final.basicpropertyinfohotelcode == res_df_lkup_site_lkup.lkup_site_id) 
                                                                              & (df_final.basicpropertyinfobrandcode == res_df_lkup_site_lkup.lkup_brand_id)) & df_final.basicpropertyinfobrandcode.isNotNull()
                                                                              ),how='inner' )

            
            df_df_final_lkup_site_join = df_df_final_lkup_site_join_1.union(df_df_final_lkup_site_join_2)
            df_df_final_lkup_site_join = df_df_final_lkup_site_join.distinct()
             ################## Join Lkup_site table to df_final data frame based on basicpropertyinfohotelcode = lkup_site_id & brandcode is null  and considering only matched values #################################      

            df_df_final_lkup_site_join_3 = df_final.join(res_df_lkup_site_lkup,((df_final.basicpropertyinfohotelcode == res_df_lkup_site_lkup.lkup_site_id) & df_final.basicpropertyinfobrandcode.isNull()),how='inner')

            df_df_final_lkup_site_join_union = df_df_final_lkup_site_join.union(df_df_final_lkup_site_join_3)
            df_df_final_lkup_site_join_union = df_df_final_lkup_site_join_union.distinct()
            ################## Join Lkup_site table to df_final data frame excluding above joined values ################################# 
            df_df_final_exclude = df_final.join(df_df_final_lkup_site_join_union,(df_final.basicpropertyinfohotelcode == df_df_final_lkup_site_join_union.basicpropertyinfohotelcode),how='leftanti').select(df_final['*'])
            
            df_df_final_lkup_site_join_4 = df_df_final_exclude.join(res_df_lkup_site_lkup,(df_df_final_exclude.basicpropertyinfohotelcode == res_df_lkup_site_lkup.lkup_crs_site_id),how='left')

            df_df_final_lkup_site_join_union_2 = df_df_final_lkup_site_join_union.union(df_df_final_lkup_site_join_4)
            df_df_final_lkup_site_join_union_2 = df_df_final_lkup_site_join_union_2.distinct()


            logger.info(' Start of DQ check for Rule 10')
            ################## Rule 10 Data Check Hotel Code not mapped to WHR Site ID when basicpropertyinfohotelcode is not in test ids and basicpropertyinfohotelcode == lkup_crs_site_id & lkup_site_id is null #################################
            
            logger.info('DQ Check for rule 10_1')
            dq_check_rule_10_1 =  df_df_final_lkup_site_join_union_2.withColumn('Qid',when(~(df_df_final_lkup_site_join_union_2.basicpropertyinfohotelcode.isin([54924,80128,80143,80146,80149,80150,80170,80203,80441,82230,99911,'HPQA','PBHTNGEDW',88642])) & (df_df_final_lkup_site_join_union_2.basicpropertyinfohotelcode== df_df_final_lkup_site_join_union_2.lkup_crs_site_id) & (df_df_final_lkup_site_join_union_2.lkup_site_id.isNull()) ,'10')
                                          .otherwise('NOACTION'))\
                                          .withColumn('src_col_value', when(~(df_df_final_lkup_site_join_union_2.basicpropertyinfohotelcode.isin([54924,80128,80143,80146,80149,80150,80170,80203,80441,82230,99911,'HPQA','PBHTNGEDW',88642])) & (df_df_final_lkup_site_join_union_2.basicpropertyinfohotelcode== df_df_final_lkup_site_join_union_2.lkup_crs_site_id) & (df_df_final_lkup_site_join_union_2.lkup_site_id.isNull()) ,None).otherwise('NOACTION'))
            ################## Rule 10 Data Check Hotel Code not mapped to WHR Site ID when basicpropertyinfohotelcode is not in test ids and basicpropertyinfohotelcode == lkup_site_id & basicpropertyinfobrandcode == lkup_brand_id & lkup_site_id is null #################################
            
            logger.info('DQ Check for rule 10_2')
            dq_check_rule_10_2 =  df_df_final_lkup_site_join_union_2.withColumn('Qid',when(((~(df_df_final_lkup_site_join_union_2.basicpropertyinfohotelcode.isin([54924,80128,80143,80146,80149,80150,80170,80203,80441,82230,99911,'HPQA','PBHTNGEDW',88642])))) & df_df_final_lkup_site_join_union_2.basicpropertyinfobrandcode.isNotNull() & ((df_df_final_lkup_site_join_union_2.basicpropertyinfohotelcode== df_df_final_lkup_site_join_union_2.lkup_site_id) & (df_df_final_lkup_site_join_union_2.basicpropertyinfobrandcode == df_df_final_lkup_site_join_union_2.lkup_brand_id) ) &  (df_df_final_lkup_site_join_union_2.basicpropertyinfohotelcode != df_df_final_lkup_site_join_union_2.lkup_crs_site_id) & (df_df_final_lkup_site_join_union_2.lkup_crs_site_id.isNull()) ,'10')
                                          .otherwise('NOACTION'))\
                                          .withColumn('src_col_value', when(((~(df_df_final_lkup_site_join_union_2.basicpropertyinfohotelcode.isin([54924,80128,80143,80146,80149,80150,80170,80203,80441,82230,99911,'HPQA','PBHTNGEDW',88642])))) & df_df_final_lkup_site_join_union_2.basicpropertyinfobrandcode.isNotNull() & ((df_df_final_lkup_site_join_union_2.basicpropertyinfohotelcode== df_df_final_lkup_site_join_union_2.lkup_site_id) & (df_df_final_lkup_site_join_union_2.basicpropertyinfobrandcode == df_df_final_lkup_site_join_union_2.lkup_brand_id)) &  (df_df_final_lkup_site_join_union_2.basicpropertyinfohotelcode != df_df_final_lkup_site_join_union_2.lkup_crs_site_id) & (df_df_final_lkup_site_join_union_2.lkup_crs_site_id.isNull()) ,None).otherwise('NOACTION'))
            dq_check_rule_10_join_1_2 = dq_check_rule_10_1.union(dq_check_rule_10_2)
            dq_check_rule_10_join_1_2 = dq_check_rule_10_join_1_2.distinct()
            ################## Rule 10 Data Check Hotel Code not mapped to WHR Site ID when basicpropertyinfohotelcode is not in test ids and basicpropertyinfohotelcode == lkup_site_id & basicpropertyinfobrandcode is null & lkup_site_id is null #################################
            logger.info('DQ Check for rule 10_3')
            dq_check_rule_10_3 =  df_df_final_lkup_site_join_union_2.withColumn('Qid',when(((~(df_df_final_lkup_site_join_union_2.basicpropertyinfohotelcode.isin([54924,80128,80143,80146,80149,80150,80170,80203,80441,82230,99911,'HPQA','PBHTNGEDW',88642])))) & df_df_final_lkup_site_join_union_2.basicpropertyinfobrandcode.isNull() & ((df_df_final_lkup_site_join_union_2.basicpropertyinfohotelcode== df_df_final_lkup_site_join_union_2.lkup_site_id)) &  (df_df_final_lkup_site_join_union_2.basicpropertyinfohotelcode != df_df_final_lkup_site_join_union_2.lkup_crs_site_id) & (df_df_final_lkup_site_join_union_2.lkup_crs_site_id.isNull()) ,'10')
                                          .otherwise('NOACTION'))\
                                          .withColumn('src_col_value', when(((~(df_df_final_lkup_site_join_union_2.basicpropertyinfohotelcode.isin([54924,80128,80143,80146,80149,80150,80170,80203,80441,82230,99911,'HPQA','PBHTNGEDW',88642])))) & df_df_final_lkup_site_join_union_2.basicpropertyinfobrandcode.isNull() & ((df_df_final_lkup_site_join_union_2.basicpropertyinfohotelcode== df_df_final_lkup_site_join_union_2.lkup_site_id)) &  (df_df_final_lkup_site_join_union_2.basicpropertyinfohotelcode != df_df_final_lkup_site_join_union_2.lkup_crs_site_id) & (df_df_final_lkup_site_join_union_2.lkup_crs_site_id.isNull()) ,None).otherwise('NOACTION'))
            
           

            
            dq_check_rule_10_join = dq_check_rule_10_join_1_2.union(dq_check_rule_10_3)
            dq_check_rule_10_join = dq_check_rule_10_join.distinct()
            ################## Rule 10 Data Check Hotel Code not mapped to WHR Site ID when basicpropertyinfohotelcode is not in test ids and basicpropertyinfohotelcode is not null & lkup_site_id is null & lkup_crs_site_id #################################



            logger.info('DQ Check for rule 10_4')
            dq_check_rule_10_4 = df_df_final_lkup_site_join_union_2.withColumn('Qid',when(~(dq_check_rule_10_join.basicpropertyinfohotelcode.isin([54924,80128,80143,80146,80149,80150,80170,80203,80441,82230,99911,'HPQA','PBHTNGEDW',88642])) & dq_check_rule_10_join.basicpropertyinfohotelcode.isNotNull() & dq_check_rule_10_join.lkup_crs_site_id.isNull() & dq_check_rule_10_join.lkup_site_id.isNull(),'10').otherwise('NOACTION'))\
                                                    .withColumn('src_col_value', when(~(dq_check_rule_10_join.basicpropertyinfohotelcode.isin([54924,80128,80143,80146,80149,80150,80170,80203,80441,82230,99911,'HPQA','PBHTNGEDW',88642])) & dq_check_rule_10_join.basicpropertyinfohotelcode.isNotNull() & dq_check_rule_10_join.lkup_crs_site_id.isNull() & dq_check_rule_10_join.lkup_site_id.isNull(), None).otherwise('NOACTION'))
            dq_check_rule_10_union = dq_check_rule_10_join.union(dq_check_rule_10_4)
            dq_check_rule_10_union = dq_check_rule_10_union.distinct()
                      
           
            print("Site id Validation done")
            
            print(" filter invalid site data")
            
            df_DQ_site_id_error = dq_check_rule_10_union.filter(dq_check_rule_10_union.Qid != 'NOACTION')
             ################## Join Dq Val rules table to df_DQ_site_id_error data frame based on Qid value ################################
            df_DQ_site_id_valrules_join = df_DQ_site_id_error.join(res_df_data_valrules_val,(df_DQ_site_id_error.Qid == res_df_data_valrules_val.val_id),how='inner')
            
            logger.info('DQ Check for Rule 10 Completed ')

            df_DQ_union = df_DQ_valrules_join.union(df_DQ_site_id_valrules_join)

            df_DQ_union.createOrReplaceTempView("DQ_final_ins_view") 
            
            df_DQ_final_ins = spark.sql("""  select distinct id, uniqueidid as conf_num, 
                                             case when basicpropertyinfohotelcode = lkup_crs_site_id  then basicpropertyinfohotelcode
                                                  when basicpropertyinfohotelcode = lkup_site_id then lkup_crs_site_id  else basicpropertyinfohotelcode end as synxis_site_id
                                            ,case when basicpropertyinfohotelcode =  lkup_crs_site_id then lkup_site_id 
                                                  when basicpropertyinfohotelcode = lkup_site_id then basicpropertyinfohotelcode else lkup_site_id end as wyn_site_id
                                            ,case when resstatus='Commit' then 'N' when resstatus='Modify' then 'O' when resstatus='Cancel' then 'X' else null end as log_type, val_src_colname as src_column_name
                                            ,src_col_value as src_column_value,  val_data_quality_validation_rule as error_message, inserted_ts as insert_ts, inserted_ts as updated_ts,  
											Replace(case when basicpropertyinfobrandcode IS NULL then lkup_brand_id else basicpropertyinfobrandcode end ,'WY' , 'WD') as brand_id
                                            ,  val_id as dataval_id, val_quarantine_flag as pros_flag from DQ_final_ins_view
											 """)

            df_DQ_final_ins.printSchema()
            
            
            dyf_DQ_final = DynamicFrame.fromDF(df_DQ_final_ins, glueContext,'dyf_DQ_final')
            
            
        except Exception as e:
            logger.error("************ {} [ERROR] Exception while doing Data Quality Checks on Room Stay Data *************".format(str(datetime.now())))
            logger.error("*********** [ERROR] Failing with error:  {} **************".format(str(e)))
            f_msg="  Error while doing Data Quality Checks on Room Stay Data for Glue Job {0} , failed with error: {1}  ".format(job_name,str(e))
            f_sub = "Reservation Room Stay Glue job "+job_name+" failed" 
            notifymsg(f_sub, f_msg)
            exit(1)
            
        #################### Dataload to Redshift ########################
        try:
            redshift_load = glueContext.write_dynamic_frame.from_jdbc_conf(
                                        frame = dyf_final, 
                                        catalog_connection = redshiftconnection, 
                                        connection_options = {
                                                            "url": rs_url_db_dest,
                                                            "database": rsdb, 
                                                            "user": rs_user_dest, 
                                                            "password": rs_pwd_dest, 
                                                            "dbtable" : schemaname+'.'+tablename ,
                                                            "extracopyoptions":"MAXERROR 100000"},  
                                        redshift_tmp_dir = "s3://"+blue_bucket+'/sabre/reservation/dataload/{}/{}/'.format(job_name,str(datetime.now()).replace(" ","_"))
                                            )
            logger.info(" Data Load Process for Room Stay to redshift complete")
        except Exception as e:
            logger.error(str(e))
            logger.info("  [ERROR] Error while loading to Redshift Staging table, failed with : {} ".format(str(e)))
            f_msg="  Error while loading to Staging table for the job {}, failed with error: {} ".format(job_name,str(e))
            f_sub = "Reservation Room Stay Glue job "+job_name+" failed" 
            notifymsg(f_sub, f_msg)
            exit(1)
            
            #################### Dataload to rsv_dq_error_intermediate table ########################
        try:
            redshift_load_dq_error  = glueContext.write_dynamic_frame.from_jdbc_conf(
                                                  frame = dyf_DQ_final, 
                                                  catalog_connection = redshiftconnection, 
                                                  connection_options = {
                                                                      "url": rs_url_db_dest,
                                                                      "database": rsdb, 
                                                                      "user": rs_user_dest, 
                                                                      "password": rs_pwd_dest, 
                                                                      "dbtable" : schemaname+'.'+dq_intermediate_tablename ,
                                                                      "extracopyoptions":"MAXERROR 100000"},  
                                                  redshift_tmp_dir = "s3://"+blue_bucket+'/sabre/reservation/dqerrorload/{}/{}/'.format(job_name,str(datetime.now()).replace(" ","_"))
                                                      )
            logger.info(" Data Load Process for rsv_dq_error_intermediate to redshift complete")
        except Exception as e:
            logger.error(str(e))
            logger.info("  [ERROR] Error while loading to Redshift rsv_dq_error_intermediate table, failed with : {} ".format(str(e)))
            f_msg="  Error while loading to rsv_dq_error_intermediate table for the job {}, failed with error: {} ".format(job_name,str(e))
            f_sub = "Reservation Room Stay Glue job "+job_name+" failed" 
            notifymsg(f_sub, f_msg)
            exit(1)
        
        ############### Creating Parquet Files and saving it to Gold S3 ##############
        df_parquet = df_final.withColumn('year',year(col("inserted_ts"))).withColumn('month',month(col("inserted_ts"))).withColumn('day',dayofmonth(col("inserted_ts"))).repartition(1)
        
        dyf_parquet = DynamicFrame.fromDF(df_parquet, glueContext,'dyf_parquet')
        # dyf_parquet.show(10)
        # dyf_parquet.printSchema()
        
        try:
            mb_write_to_s3 = glueContext.write_dynamic_frame.from_options(
                    frame = dyf_parquet, 
                    connection_type = "s3", 
                    connection_options = {"path": PARQUET_FILE_PATH,"partitionKeys": ['year','month','day']}, 
                    format = "parquet"
                    )
        except Exception as e:
            logger.error(str(e))
            logger.info("  [ERROR] Error while writing parquet files to S3, failed with : {} ".format(str(e)))
            f_msg="  Error while writing parquet files to S3 for the job {}, failed with error: {} ".format(job_name,str(e))
            f_sub = "Reservation Address Glue job "+job_name+" failed" 
            notifymsg(f_sub, f_msg)
            exit(1)
        
        ####################### Creating a Marker File ###########################
        try:
            response = s3Client.put_object(Bucket=blue_bucket, Body="Completed", Key=MARKER_FILE)
            print(response)
        except Exception as error:
            logger.error("************ {} [ERROR] Exception while writing the marker file to S3 for Room Stay Glue Job************".format(str(datetime.now())))
            logger.error("*********** [ERROR] Failing with error: {} **************".format(str(error)))
            f_msg="  Error while writing the marker file to S3 for Room Stay Glue Job {}, failed with Error: {}".format(job_name,str(e))
            f_sub = "Error writing Marker File for Glue Job - {}".format(job_name) 
            notifymsg(f_sub, f_msg)
            exit(1)

logger.info(" ************** {} End of Load process for Room Stay *********************** ".format(str(datetime.now())))
job.commit()