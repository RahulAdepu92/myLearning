import sys
from datetime import datetime
from datetime import timedelta
import pytz
import json
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.dynamicframe import DynamicFrame
from pyspark.sql import SQLContext
import boto3
import logging
from pyspark.sql.functions import  col, when, lit, input_file_name, substring_index, explode
from pyspark.sql.types import TimestampType, DoubleType, StructType, StructField, StringType, IntegerType, LongType, FloatType, DecimalType

sc=SparkContext()
glue_context = GlueContext(sc)
spark = glue_context.spark_session
sqlContext = SQLContext(sc)

################################### Enabling access to the arguments ##################################
job = Job(glue_context)
args = getResolvedOptions(sys.argv, ['JOB_NAME','blue_bucket','error_bucket','SNS','configfile','ScriptBucketName','env'])
job.init(args['JOB_NAME'], args)

################################### Setting up logger for event logging ##################################
logging.basicConfig()
logger = logging.getLogger()
logger.setLevel(logging.INFO)



################################### Assigning job arguments to variables  ##################################

blue_bucket = args['blue_bucket']
# file_path_gen = 's3://{}/sabre/reservation/intermediate/{}/'.format(blue_bucket,datetime_folder)
error_bucket = args['error_bucket']
job_name = args['JOB_NAME']
sns_notify = args['SNS']
WRITE_S3_PATH = 's3://{}/sabre/reservation/processing/'.format(blue_bucket)
MARKER_FILE = "sabre/reservation/reservation-glue-workflow-marker-triggers/"  +args["JOB_NAME"]
ECO_TOKEN_PATH = "s3://{}/sabre/reservation/echotoken/".format(blue_bucket)
CONFIG_FILE = "sabre/reservation/{}".format(args['configfile'])
env = args['env']
WRITE_S3_DynDB_PATH ='s3://{}/sabre/reservation/lkup-site/'.format(blue_bucket)

# Variables for DynamoDB Source Table
dim_site_lookup_table_name = "WHG-DynamoDB-USW2-LkupSite-{0}".format(env)

################################### Create low level reosurce service client for S3 ans SNS  ##################################

s3Client = boto3.client('s3',region_name='us-west-2')
s3resource = boto3.resource('s3',region_name='us-west-2')
glueClient = boto3.client('reservation-glue', region_name='us-west-2')

job_run=True

try:
    sns_client = boto3.client('sns',region_name = 'us-west-2')
    logger.info("Enabled SNS Notification")
except Exception as e:
    logger.error(str(e))
    logger.info(" Unable to enable SNS, failed with error: {}".format(str(e)))
    logger.info("Continuing with load without SNS notification")
    

############# Notification Function ################################################
def notifymsg(sub, msg):
    sns_client.publish(TopicArn = sns_notify, Message = msg , Subject= sub) 
    logger.info("**************** [INFO] SNS Notification Sent: {} *************************".format(job_name))

def create_timestamp_est():
    
    now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    # est = pytz.timezone('US/Eastern')
    # now_est = now.astimezone(est).strftime('%Y-%m-%d %H:%M:%S.%f')
    
    return now

def read_table_to_dataframe(glue_context, source_table_name):
    """
    This method used to write the spark dataframe from DynamoDB Table.
    If record does not exist, create brand new record, if record exist, it overwrites

    :param glue_context: Glue Job Context
    :param source_table_name: Table from where to read the records
    :return : Spark Dataframe
    """
    try:
        logger.info("#### Getting initial set of records from DynamoDB Table : " + source_table_name)

        # Step:1 - Read the Data from DynamoDB Table to Glue Dynamic Frame
        dynamodb_dynamic_frame = glue_context.create_dynamic_frame.from_options(
            connection_type="dynamodb",
            connection_options={
                "dynamodb.input.tableName": source_table_name,
                "dynamodb.throughput.read.percent": "1.0",
                "dynamodb.splits": "100"
            }
        )
        logger.info("#### Count of successfully loaded records: " + str(dynamodb_dynamic_frame.count()))

        # Step:2 - Translate Glue Dynamic Frame to Spark DataFrame and return
        return DynamicFrame.toDF(dynamodb_dynamic_frame)

    except Exception as e:
        logger.error("Unable to read from DynamoDB tables, to place into Dataframe for query %s. "
                     "Error is %s" % (source_table_name, str(e)))

        logger.info(" Exiting with error: {}".format(str(e)))


#################################### get_input_s3_path ##########################################
#    This function will frame the input s3 path.
#    By default it will take all the files in the current date
#    i.e [whg-sabre-synxisfeed/rqa/SynxisData/2019/7/4/]
#    If rerun field in the config file at [] has value, then that path will be added as well
#################################################################################################
def get_input_s3_path():
    print("Framing S3 Path ***********")
    s3_path=[]
    
    try:
        obj = s3Client.get_object(Bucket=blue_bucket, Key=CONFIG_FILE)
        json_obj = json.loads(obj['Body'].read())
        
        rerun_dates = [x.strip() for x in json_obj["rerun"].split(',')]
        s3_prefix = "s3://{}/sabre/reservation/intermediate/".format(blue_bucket)
        if len(rerun_dates)>0 and rerun_dates != ['']:
            for date in rerun_dates:
                s3_path.append(s3_prefix + date + '/')
        else:
            print("*******************NO Files to ReRun********************")
            try:
                ############### Creating Datetime Folder #######################
                today = datetime.now().strftime('%Y/%m/%d')
                yesterday = (datetime.now() - timedelta(1)).strftime('%Y/%m/%d')
                
                print("Today: {}".format(today))
                print("Yesterday: {}".format(yesterday))
                
                s3_path.append(s3_prefix + today + '/')
                ############### Add yesterday files if the last execution is previous day ###################
                client = boto3.client('reservation-glue', region_name='us-west-2')
                response = client.get_job_runs(
                    JobName=args['JOB_NAME'],
                    MaxResults=10
                )
                job_runs = response['JobRuns']
                start_time=None
                for run in job_runs:
                    if run['JobRunState'] != 'SUCCEEDED':
                        continue
                    else:
                        start_time = run['StartedOn']
                        break
                #print(start_time)
                if  start_time and start_time.date() < datetime.today().date():
                    s3_path.append(s3_prefix + yesterday + '/')
                print(s3_path)
                ##########################################################################################3
            except Exception as error:
                logger.error("****************** [ERROR] Unable to frame s3 Input Path : {} **************".format(str(error)))
                f_msg = "Unable to Frame S3 Input Path, Error Details: {}".format(str(error))
                f_sub = "S3 Read Glue job "+job_name+" failed"                              
                notifymsg(f_sub,f_msg)
                exit(1)        
    except Exception as error:
        logger.error("*********************** [ERROR] Unable to frame S3 Input path from Rerun config file : {} *********".format(str(error)))
        f_msg = "Unable to Frame S3 Input Path, Error Details: {}".format(str(error))
        f_sub = "S3 Read Glue job "+job_name+" failed"                              
        notifymsg(f_sub,f_msg)
        exit(1)        
    return s3_path
    
####### Extract data from Dynamodb table and load data to s3 ###################################
try:
    lkup_site_df = read_table_to_dataframe(glue_context,dim_site_lookup_table_name)
    lkup_site_df_new = lkup_site_df.filter(lkup_site_df.cur_site_flg == "Y")
    lkup_site_df_new.repartition(1).write.format('json').mode("overwrite").option("header","true").save(WRITE_S3_DynDB_PATH) 
    
except Exception as e:
            logger.error("************ {} [ERROR] Exception while writing the lkup-site file to S3 *************".format(str(datetime.now())))
            logger.error("*********** [ERROR] Failing with error:  {} **************".format(str(e)))
            f_msg="  Error while writing data to lkup-site Folder on S3 for the job {0} , failed with error: {1}  ".format(job_name,str(e))
            f_sub = "S3 Read Glue job "+job_name+" failed" 
            notifymsg(f_sub, f_msg)
            exit(1)
    

####### Check if this is rerun based on the marker file, if so the job execution is skipped ###################################
try:
    response = s3Client.head_object(Bucket=blue_bucket, Key=MARKER_FILE)
    print(response)
    print("*******************[INFO] JOB ALREADY EXECUTED ********************")
    job_run = False
except Exception as HeadObjectException:
    ##############################################################################################
    # No Marker file present, then this is first time execution
    # Will read the file based on get_input_s3_path response
    ##############################################################################################
    print(HeadObjectException)
    

    
if job_run:
    
    ########################### Reading Res JSON Data ####################################
    try:
            
        logger.info(" Reading S3 file")
        res_s3_read_dyf = glue_context.create_dynamic_frame.from_options(connection_type="s3", 
                    connection_options={"paths": get_input_s3_path(),'recurse':True, 'groupFiles': 'inPartition'},
                    format="json",transformation_ctx='res_s3_read_dyf')
        
        res_df = res_s3_read_dyf.toDF()
        res_df_count = res_df.count()
        
        print('Total Cound DF: {}'.format(res_df.count()))
        res_df.printSchema()
        
    except Exception as e:
        logger.error("************ {} [ERROR] Exception while reading the file from S3 *************".format(str(datetime.now())))
        logger.error("*********** [ERROR] Failing with error:  {} **************".format(str(e)))
        f_msg="  Error while reading data from S3 for the job {0} , failed with error: {1}  ".format(job_name,str(e))
        f_sub = "S3 Read Glue job "+job_name+" failed" 
        notifymsg(f_sub, f_msg)
        exit(1)

    if res_df_count == 0:
        logger.info('No Data to process for S3 Read Job for {} run'.format(str(datetime.now())))
        f_msg = "No Data to Process for S3 Read Glue Job - {} for run {}".format(job_name,str(datetime.now()))
        f_sub = "No Data to Process for S3 Read Glue Job - {}".format(job_name)
        notifymsg(f_sub, f_msg)
        # exit(0)
    else:
        ############# Writing EchoToken for Audit Job Validation #################################
        
        res_df_ecotoken = res_df.withColumn('starttime',lit(create_timestamp_est()))
        res_df_ecotoken = res_df_ecotoken.withColumn('eco_list', explode('stg_rsv_HotelReservation'))
        res_df_ecotoken_final = res_df_ecotoken.select(col('eco_list.id').alias('_EchoToken'),col('starttime')).distinct()
        
        res_df_ecotoken_final.repartition(1).write.csv(ECO_TOKEN_PATH,mode="overwrite",header = 'true')
        
        ############## Saving the JSON Res Files for Processing Stage #########################

        try:
            logger.info("Writing S3 Files to Processing Folder")
            
            res_df.write.format('json').mode("overwrite").option("header","true").save(WRITE_S3_PATH)
        except:
            logger.error("************ {} [ERROR] Exception while writing the file to S3 *************".format(str(datetime.now())))
            logger.error("*********** [ERROR] Failing with error:  {} **************".format(str(e)))
            f_msg="  Error while writing data to Processing Folder on S3 for the job {0} , failed with error: {1}  ".format(job_name,str(e))
            f_sub = "S3 Read Glue job "+job_name+" failed" 
            notifymsg(f_sub, f_msg)
            exit(1)
        
        ####################### Creating a Marker File ###########################
        try:
            response = s3Client.put_object(Bucket=blue_bucket, Body="Completed", Key=MARKER_FILE)
            print(response)
        except Exception as error:
            logger.error("************ {} [ERROR] Exception while writing the marker file to S3 for S3 Read Glue Job************".format(str(datetime.now())))
            logger.error("*********** [ERROR] Failing with error: {} **************".format(str(error)))
            f_msg="Error while writing the marker file to S3 Read Glue Job {}, failed with Error: {}".format(job_name,str(e))
            f_sub = "Error writing Marker File for Glue Job - {}".format(job_name) 
            notifymsg(f_sub, f_msg)
            exit(1)

logger.info(" ************** {} End of Load process for S3 Read *********************** ".format(str(datetime.now())))
job.commit()
