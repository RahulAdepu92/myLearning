import pytz
import logging
import sys
from datetime import datetime
from dateutil.relativedelta import relativedelta
import time
import boto3
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from pyspark.sql import SQLContext
from awsglue.dynamicframe import DynamicFrame
from pyspark.sql.functions import lit
from pyspark.sql.types import TimestampType, DoubleType, StructType, StructField, StringType, \
    IntegerType, LongType, FloatType, DecimalType, DateType

################################### Setting up Spark environment and enabling Glue to interact with Spark Platform ##################################
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
sqlContext = SQLContext(sc)

################################### Enabling access to the arguments ##################################
job = Job(glueContext)
args = getResolvedOptions(sys.argv,
                          ['rsdb', 'JOB_NAME', 'blue_bucket', 'sns','redshift_dw_connection',
                            'rs_schema_name', 'rs_table_name', 'dynamo_table'])
job.init(args['JOB_NAME'], args)

################################### Setting up logger for event logging ##################################
logging.basicConfig()
logger = logging.getLogger()
logger.setLevel(logging.INFO)

################################### Assigning job arguments to variables  ##################################

rsdb = args['rsdb']
redshift_dw_connection = args['redshift_dw_connection']
blue_bucket = args['blue_bucket']
job_name = args['JOB_NAME']
rs_schema_name = args['rs_schema_name']
rs_table_name = args['rs_table_name']
sns_notify = args['sns']
dynamo_table = args['dynamo_table']
dynamo_table_name = dynamo_table.split("/")[1]  # excluding suffix "table/" from dynamo_table param
redshift_path = f"s3://{blue_bucket}/lkup_bloomberg_crncy/redshift/"
temp_directory = f"s3://{blue_bucket}/lkup_bloomberg_crncy/dataload/{job_name}/{str(datetime.now()).replace(' ', '_')}"


################################### Create low level reosurce service client for S3 ans SNS  ##################################

s3Client = boto3.client('s3', region_name='us-west-2')
s3resource = boto3.resource('s3', region_name='us-west-2')
glueClient = boto3.client('glue', region_name='us-west-2')

try:
    sns_client = boto3.client('sns', region_name='us-west-2')
    logger.info("Enabled SNS Notification")
except Exception as e:
    logger.error(str(e))
    logger.info(f" Unable to enable SNS, failed with error: {str(e)}")
    logger.info("Continuing with load without SNS notification")

################################### Sending SNS notifications for job failures  ##################################

def notifymsg(sub, msg):
    sns_client.publish(TopicArn=sns_notify, Message=msg, Subject=sub)
    logger.info(f"**************** [INFO] SNS Notification Sent: {job_name} *************************")

################## Create Timestamp ############################

def create_timestamp_est():
    utc_now = datetime.now()
    est = pytz.timezone('US/Eastern')
    est_now = utc_now.astimezone(est).strftime('%Y-%m-%d %H:%M:%S.%f')
    return est_now

############ Retrieving connection information from Glue connections for Redshift  #############
try:
    logger.info("Getting Redshift Connection Information")
    rs_connection_dest = glueContext.extract_jdbc_conf(redshift_dw_connection)
    rs_url_dest = rs_connection_dest["url"]
    rs_user_dest = rs_connection_dest["user"]
    rs_pwd_dest = rs_connection_dest["password"]
    rs_url_db_dest = rs_url_dest + '/' + rsdb
except Exception as e:
    f_msg = f" Unable to connect to Redshift while processing the glue job {job_name} , failed with error: {str(e)}  "
    f_sub = f"Folio Btch Hdr Glue job {job_name} failed"
    notifymsg(f_sub, f_msg)
    logger.info(f" Exiting with error: {str(e)}")
    raise SystemExit(e)

########################### Read LKUP_BLOOMBERG_CRNCY redshift table ###################################

logger.info(f"{str(datetime.now())}: Getting Data from lkup_bloomberg_crncy Table ")

##########################################################################################
def get_job_last_run_ts():
    try:
        job_runs = glueClient.get_job_runs(JobName=job_name)
        job_run_count = len(job_runs["JobRuns"])
        last_job_start_time = None
        # iterate through the job till we find the first successful job
        for res in job_runs['JobRuns']:
            if res.get("JobRunState") == "SUCCEEDED":
                logger.info("found a last successful job run")
                last_job_start_time_utc = res.get("StartedOn")  # 2021-06-21 08:08:33.525000+00:00
                est = pytz.timezone('US/Eastern')
                last_job_start_time = last_job_start_time_utc.astimezone(est).strftime('%Y-%m-%d %H:%M:%S.%f')
                break
        logger.info("Count of the job run is : {}".format(str(job_run_count)))
        if last_job_start_time:
            logger.info("Start time of the last job run is : {}".format(str(last_job_start_time)))
        else:
            logger.info("There are no previous job run")
        return last_job_start_time
    except Exception as e:
        logger.error(str(e))
        logger.info(" Unable to fetch glue job runs, failed with error: {}".format(str(e)))


def read_rstable_to_dataframe(last_sucess_job_ts):
    # applying row_number function to avoid item level duplicates (if any)
    sql_common = f""" select cal_key, crncy_cd, lkup_bloomberg_crncy_hash, err_cd, num_of_fld, cntry_cd,
            crncy_desc, crncy_conver_prior_rt, crncy_lst_updt_dt, crncy_conver_exst_rt, crncy_conver_dt,
            invers_quot_flg, create_by, create_ts, lst_updt_by, lst_updt_ts
            from ( SELECT *,
            row_number() OVER(PARTITION BY crncy_cd,cal_key ORDER BY lst_updt_ts desc) rnum
            from {rs_schema_name}.{rs_table_name} rs """
    if last_sucess_job_ts is None:  # applicable for the first ever job run only (a full load)
        sql_query = f""" {sql_common} where extract(year from lst_updt_ts) >= 2019)A
            where rnum =1 """
    else:
        sql_query = f""" {sql_common} where lst_updt_ts >= '{last_sucess_job_ts}' )A
            where rnum =1 """

    logger.info("sql query : " + str(sql_query))

    load_schema_df = spark.read.format("com.databricks.spark.redshift") \
        .option("url", rs_url_db_dest + '?user=' + rs_user_dest + '&password=' + rs_pwd_dest) \
        .option("query", sql_query) \
        .option("forward_spark_s3_credentials", "true") \
        .option("tempdir", temp_directory).load()

    load_df = spark.read.schema(set_nullable_for_all_string_columns(load_schema_df, True)). \
        format("com.databricks.spark.redshift"). \
        option("url", rs_url_db_dest + '?user=' + rs_user_dest + '&password=' + rs_pwd_dest) \
        .option("query", sql_query) \
        .option("forward_spark_s3_credentials", "true") \
        .option("tempdir", temp_directory + '/').load()

    return load_df


def set_nullable_for_all_string_columns(df, nullable):
    new_schema = StructType([StructField(f.name, f.dataType, nullable, f.metadata)
                             if (isinstance(f.dataType, StringType))
                             else StructField(f.name, f.dataType, f.nullable, f.metadata)
                             for f in df.schema.fields])
    return new_schema


try:
    last_job_run_ts = get_job_last_run_ts()
    logger.info('last_job_run_ts : ' + str(last_job_run_ts))

    rs_src_df = read_rstable_to_dataframe(last_job_run_ts).distinct()
    logger.info(f"Total Count DF(no.of unique items that are to be inserted to dynamodb): {rs_src_df.count()}")

    if rs_src_df.limit(1).count() == 0:
        logger.info("No new records to pull into dynamodb for this run. Hence exiting!")
    else:
        # Converting all columns to 'String' data type to fit into dynamotable whose schema is defined with strings
        for col in rs_src_df.columns:
            rs_src_df = rs_src_df.withColumn(col, rs_src_df[col].cast(StringType()))

        utc_now = datetime.now()
        utc_after_3_yrs = utc_now + relativedelta(years=3)
        utc_to_epoch_time = time.mktime(utc_after_3_yrs.timetuple())
        # logger.info(f"epoch_time is: {est_to_epoch_time}")

        rs_src_ttl_df = rs_src_df.withColumn('calkey_ttl', lit(utc_to_epoch_time).cast(IntegerType()))
        rs_src_ttl_df.limit(1).show()
        rs_src_dyf_final = DynamicFrame.fromDF(rs_src_ttl_df, glueContext, "rs_src_dyf_final")
        logger.info(f"'rs_src_dyf_final' is created")

        ########################### Load LKUP_BLOOMBERG_CRNCY dynamo table ###################################
        try:
            logger.info(f"{str(datetime.now())}: Updating 'LKUP_BLOOMBERG_CRNCY' dynamo table")

            lkup_bloomberg_crncy_dynamo = glueContext.write_dynamic_frame_from_options(
                frame=rs_src_dyf_final,
                connection_type="dynamodb",
                connection_options={
                    "dynamodb.output.tableName": dynamo_table_name,
                    "dynamodb.throughput.write.percent": "1.0",
                    "dynamodb.output.retry": 50
                }
            )

        except Exception as e:
            logger.error(
                f"**************** [ERROR] Error loading dynamo table, failed with error: {str(e)} ***********")
            f_msg = f"[ERROR] Error loading LKUP_BLOOMBERG_CRNCY DynamoDB Table from Redshift, failed with error: {str(e)}"
            f_sub = f"LKUP_BLOOMBERG_CRNCY Glue Job - {job_name} Failed"
            notifymsg(f_sub, f_msg)
            raise SystemExit(e)

except Exception as e:
    logger.error(
        f"************** [ERROR] Error reading LKUP_BLOOMBERG_CRNCY Redshift Table, failed with error: {str(e)} ***********")
    f_msg = f"[ERROR] Error reading LKUP_BLOOMBERG_CRNCY Redshift Table, failed with error: {str(e)}"
    f_sub = f"LKUP_BLOOMBERG_CRNCY Glue Job - {job_name} Failed"
    notifymsg(f_sub, f_msg)
    raise SystemExit(e)

logger.info("End of lkup_bloomberg_crncy dynamo table load")
job.commit()
logger.info("JOB COMPLETE!!")