import boto3
import botocore.exceptions
import os
import urllib
from urllib.parse import unquote_plus
import time
import datetime
import csv
from datetime import timedelta
# from datetime import date
from datetime import datetime
from dateutil import tz
import logging
# setting loggers
logger = logging.getLogger()
logger.setLevel(logging.INFO)


s3resource = boto3.resource('s3')
s3Client = boto3.client('s3')
snsClient = boto3.client('sns')
glueClient = boto3.client('load-bloomberg-glue')

SNS_Notify = os.environ['SNSTopicArn']
red_bucket = os.environ['redBucket']


glue_bloombrgCurncy_job = os.environ['glueJobName']

loadtime_utc = datetime.now()
loadtime_utc_str = loadtime_utc.strftime("%Y-%m-%d-%H-%M-%S")
from_zone = tz.tzutc()
to_zone = tz.gettz('US/Eastern')
newloadtime = loadtime_utc.replace(tzinfo=from_zone)
s3upload_local = newloadtime.astimezone(to_zone)
s3upload_local_str = s3upload_local.strftime("%Y-%m-%d %H:%M:%S")
datesplit = s3upload_local_str.split("-")
#print(datesplit)
YR = datesplit[0]
MO = datesplit[1]
DY = datesplit[2].split(" ")[0]
datepath = YR + '/' + MO + '/' + DY
print(datepath)
source_file_full_path=''
S3_BUCKET_NAME= red_bucket 
target_bucket_name=red_bucket
S3_BUCKET_PREFIX='Bloomberg/currency/'+ datepath +'/cendant_currency.txt'
#S3_BUCKET_PREFIX='Bloomberg/currency/2022/10/01/cendant_currency.txt'
WORKLOAD_FILENAME='cendant_currency.txt'
S3_BUCKET_PATH='Bloomberg/currency/'

try:
    sns_client = boto3.client('sns', region_name='us-west-2')
    print("Enabled SNS Notification")
except Exception as e:
    logger.error(e)
    print(" Unable to enable SNS, failed with error: {}".format(str(e)))
    print("Continuing with Lambda execution without SNS notification")
    
def notifyFalure(filePath, error):
    sns_client.publish(TopicArn=SNS_Notify,
                       Message="Lambda to trigger load-bloomberg-glue job is failed for the file {0} with error: {1}".format(filePath,
                                                                                                              error),
                       Subject="BloomBerg Lambda Process failed")
                       
                       
def notifyFalure2(filePath,datepath):
    sns_client.publish(TopicArn=SNS_Notify,
                       Message="Bloom Berg currency file not found in the directory path file {0} ".format(filePath  ),
                       Subject="BloomBerg File Not Recieved")
    sns_client.publish(TopicArn=SNS_Notify,
                       Message="""Hi SD, \n Please create a  P2 ticket  for EDW PSS Team to look into the issue 
                       .\n Hi EDW PSS, \n We have not recieved the Bloomberg file for current date--{0}.""".format(datepath),
                       Subject="Request to raise a P2 ticket for BloomBerg File Not Recieved Issue")
                       
                       
########## Trigger Handler ################

def getLambdaEventSource(event) :
    if ( 'source' in event and event['source'] == 'aws.events' ):
        return 'isScheduledEvent'
    elif 'Records' in event and len(event['Records']) > 0 and 'eventSource' in event['Records'][0] and event['Records'][0]['eventSource'] == 'aws:s3':
        return 's3'
        
def copy_file(S3_BUCKET_NAME, source_file_key, target_bucket_name, target_file_key):
    copy_source_object = {'Bucket': S3_BUCKET_NAME, 'Key': source_file_key}
    logger.info('Source file path: s3://%s', S3_BUCKET_NAME)
    logger.info('Target file path: s3://%s', target_file_key)
    s3Client.copy_object(CopySource=copy_source_object, Bucket=target_bucket_name, Key=target_file_key)
        
        
########## Lambda Handler ################
def main(event, context):
    try:
        findEventSource=getLambdaEventSource(event)  
        print(findEventSource)
        if findEventSource == 'isScheduledEvent' :
            print ("Check the source is already avaliable in the folder else raise alarm")
            try:
                
                obj = s3Client.get_object(Bucket=S3_BUCKET_NAME, Key=S3_BUCKET_PREFIX)
                print(obj)
                if obj is None:
                    print("*********** File not received processing for today ***********")
                    notifyFalure2(S3_BUCKET_PREFIX,datepath)
                    exit (1)
                else:
                    print("************ File processed for today ***********")
               
            except Exception as e:
                error = str(e)
                print(error)
                print("File not received for the date, raising Alarm")
                notifyFalure2("File not received for the date, raising Alarm",datepath)
              

        elif findEventSource == 's3' :
            print("insdies3")
            try :
                File_name=[]
                landing_bucket_name = event['Records'][0]['s3']['bucket']['name']
                landing_file_key = event['Records'][0]['s3']['object']['key']
                print(f"  landing_file_key  {landing_file_key}")
                File_name=landing_file_key
                landfile_name = os.path.basename(landing_file_key)
                ##This part is only for preview env
                if landfile_name == "cendant_currency.txt" :
                    fileS3Path= 's3://' + os.sep.join([landing_bucket_name, landing_file_key])
                    source_file_full_path= 's3://' + os.sep.join([landing_bucket_name, landing_file_key])
                else:
                    print(f"landfile_name  {landfile_name}")
                    splitfile=os.path.splitext(landfile_name)[0]
                    print(f"splitfile  {splitfile}")
                    File_name=splitfile.split('.')
                    date_value=File_name[-1]
                  
                    year = date_value[0:4]
                    month = date_value[4:6]
                    day = date_value[6:8]
                    source_file_path = os.path.dirname(landing_file_key)
                    target_file_key=S3_BUCKET_PATH + year +'/'+ month +'/'+ day+'/'+ WORKLOAD_FILENAME
                    target_file_key_1=S3_BUCKET_PATH + year +'/'+ month +'/'+ day+'/'
                    
                    fileS3Path= 's3://' + os.sep.join([landing_bucket_name, target_file_key_1]) 
                    print(fileS3Path)
                    #copy_file(landing_bucket_name, landing_file_key, target_bucket_name, target_file_key)
                    ###Delete the file after copying
                    #s3Client.delete_object(Bucket=S3_BUCKET_NAME, Key=landing_file_key)
                    
                    source_file_full_path = os.sep.join([landing_bucket_name, target_file_key])
                    source_file_full_path='s3://' + source_file_full_path
                    print(source_file_full_path)
                    path = os.path.dirname(source_file_full_path)

            except Exception as e:
                error = str(e)
                print(error)
                print("load-bloomberg-lambda job variable for file {0} failed with error : {1}".format(source_file_path, error))
                notifyFalure(source_file_path, str(e))
                exit(1)
        
            # ########################## Start Glue job #############################
        
            try:
        
                print("Starting Glue job")
                executeGlueresponse = glueClient.start_job_run(
                    JobName=glue_bloombrgCurncy_job,
                    Arguments={
                       '--fileNamewithPath': source_file_full_path,
                          '--fileS3Path'    :fileS3Path                
                   })
        
                httpcode = executeGlueresponse['ResponseMetadata']['HTTPStatusCode']
        
                if (httpcode == 200):
                    jobrunid = executeGlueresponse['JobRunId']
                    print(" Glue job with job id {} has been kicked off ".format(jobrunid))
                return True
                exit()
            except Exception as e:
                print(str(e))
                print(" Unable to kick off Glue job, failed with error: {}".format(str(e)))
                notifyFalure(source_file_path, str(e))
                exit(1)
    except Exception as e:
        print(str(e))
        print(" Unable to kick off Lam job, failed with error: {}".format(str(e)))
        notifyFalure("Error-BloomBerg loading failed", str(e))
        exit(1)