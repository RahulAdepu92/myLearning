import json
import pytz
import logging
import os
import sys
from datetime import datetime
from datetime import timedelta
from dateutil.relativedelta import relativedelta
import pandas as pd
import time
import boto3
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from pyspark.sql import SQLContext
from awsglue.dynamicframe import DynamicFrame
from pyspark.sql.functions import lit, substring, col, upper, trim, md5, concat_ws, when, to_date,round,date_format,instr,length,expr,input_file_name,udf,regexp_replace,regexp_extract,split
from pyspark.sql.types import TimestampType, DoubleType, StructType, StructField, StringType, \
    IntegerType, LongType, FloatType, DecimalType, DateType
import random

rand_value=random.randint(0,100)

################################### Setting up Spark environment and enabling Glue to interact with Spark Platform ##################################
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
sqlContext = SQLContext(sc)

################################### Enabling access to the arguments ##################################
job = Job(glueContext)
args = getResolvedOptions(sys.argv,
                          ['rsdb', 'JOB_NAME', 'Source_bucket', 'sns', 'redshift_dw_connection', 'ScriptBucketName',
                           'rs_schema_name', 'rs_table_name','fileNamewithPath','fileS3Path','configfile','audittable','errortable','load_error_view','schemanamestg','redshift_connection','snstwo'])
job.init(args['JOB_NAME'], args)

################################### Setting up logger for event logging ##################################
logging.basicConfig()
logger = logging.getLogger()
logger.setLevel(logging.INFO)
today = datetime.now().strftime('%Y/%m/%d')
################################### Assigning job arguments to variables  ##################################

rsdb = args['rsdb']
redshiftconnection = args['redshift_dw_connection']
redshift_connectionstg = args['redshift_connection']
source_bucket = args['Source_bucket']
scriptBucketName = args['ScriptBucketName']
job_name = args['JOB_NAME']
schema_name = args['rs_schema_name']
rs_table_name = args['rs_table_name']
sns_notify = args['sns']
sns_notify_two = args['snstwo']
fileName=args['fileNamewithPath']
fileS3Path=args['fileS3Path']
configfile = "Bloomberg/config/{}".format(args['configfile'])
schemanamestg = args['schemanamestg']
audittable = args['audittable']
errortable = args['errortable']
load_error_view = args['load_error_view']

redshift_path = f"s3://{source_bucket}/load_bloomberg_crncy/redshift/"
temp_directory = f"s3://{source_bucket}/load_bloomberg_crncy/dataload/{job_name}/{str(datetime.now()).replace(' ', '_')}"
calkey=''
################################### Create low level reosurce service client for S3 ans SNS  ##################################

s3Client = boto3.client('s3', region_name='us-west-2')
s3resource = boto3.resource('s3', region_name='us-west-2')
glueClient = boto3.client('load-bloomberg-glue', region_name='us-west-2')

Is_Manaul_load = False
REPROCESS_DATA = False

try:
    sns_client = boto3.client('sns', region_name='us-west-2')
    logger.info("Enabled SNS Notification")
except Exception as e:
    logger.error(str(e))
    logger.info(f" Unable to enable SNS, failed with error: {str(e)}")
    logger.info("Continuing with load without SNS notification")

try:
    sns_client_2 = boto3.client('sns', region_name='us-west-2')
    logger.info("Enabled SNS Notification")
except Exception as e:
    logger.error(str(e))
    logger.info(f" Unable to enable SNS, failed with error: {str(e)}")
    logger.info("Continuing with load without SNS notification")


################################### Sending SNS notifications for job failures  ##################################

def notifymsg(sub, msg):
    sns_client.publish(TopicArn=sns_notify, Message=msg, Subject=sub)
    logger.info(f"**************** [INFO] SNS Notification Sent: {job_name} *************************")

def notifymsg2(sub, msg):
    sns_client_2.publish(TopicArn=sns_notify_two, Message=msg, Subject=sub)
    logger.info(f"**************** [INFO] SNS Notification Sent: {job_name} *************************")

################## Create Timestamp ############################

def create_timestamp_est():
    utc_now = datetime.now()
    est = pytz.timezone('US/Eastern')
    est_now = utc_now.astimezone(est).strftime('%Y-%m-%d %H:%M:%S.%f')
    return est_now


############ Retrieving connection information from Glue connections for Redshift DW  #############
try:
    logger.info("Getting Redshift Connection Information")
    rs_connection_dest = glueContext.extract_jdbc_conf(redshiftconnection)
    rs_url_dest = rs_connection_dest["url"]
    rs_user_dest = rs_connection_dest["user"]
    rs_pwd_dest = rs_connection_dest["password"]
    rs_url_db_dest = rs_url_dest + '/' + rsdb
except Exception as e:
    f_msg = f" Unable to connect to Redshift while processing the load-bloomberg-glue job {job_name} , failed with error: {str(e)}  "
    f_sub = f"bloom Btch Hdr Glue job {job_name} failed"
    notifymsg(f_sub, f_msg)
    logger.info(f" Exiting with error: {str(e)}")
    raise SystemExit(e)


# ############ Retrieving connection information from Glue connections for Redshift DWSTG  #############
try:
    logger.info("Getting Redshift Connection Information")
    redshift_connectionstg_dest = glueContext.extract_jdbc_conf(redshift_connectionstg)
    rs_url_stg_dest = redshift_connectionstg_dest["url"]
    rs_user_stg_dest = redshift_connectionstg_dest["user"]
    rs_pwd_stg_dest = redshift_connectionstg_dest["password"]
    rs_url_db_stg_dest = rs_url_stg_dest + '/' + rsdb
except Exception as e:
    f_msg = f" Unable to connect to Redshift while processing the load-bloomberg-glue job {job_name} , failed with error: {str(e)}  "
    f_sub = f"bloom Btch Hdr Glue job {job_name} failed"
    notifymsg(f_sub, f_msg)
    logger.info(f" Exiting with error: {str(e)}")
    raise SystemExit(e)

########################### Read load_bloomberg_crncy redshift table ###################################

logger.info(f"{str(datetime.now())}: Getting Data from load_bloomberg_crncy Table ")



def set_nullable_for_all_string_columns(df, nullable):
    new_schema = StructType([StructField(f.name, f.dataType, nullable, f.metadata)
                             if (isinstance(f.dataType, StringType))
                             else StructField(f.name, f.dataType, f.nullable, f.metadata)
                             for f in df.schema.fields])
    return new_schema
#################################### get cal key from filename #################################
s3_path_from_data_frame=''
def get_cal_key(s3_path_from_data_frame):
    datetime_components = []
    for field in s3_path_from_data_frame.split('/'):
       datetime_components.append(field)
    print(datetime_components)
    numbers=[]
    for subitem in datetime_components:
        if(subitem.isdigit()):
                numbers.append(subitem)
    return numbers[0] + numbers[1] + numbers[2]
    
    
###################################creating a udf function #################################

####################################Check if date is already processed #########################
def is_calkey_processed(calkey):
    ######### The function to check data is already processed , if data is already processed, that will be deleted #######################
    previous_loads_check_sql = f"""select count(*) as cnt from {schema_name}.{rs_table_name} where cal_key={calkey}  """
    logger.info(" Checking if the files were already been prcoessed{previous_loads_check_sql}")
    logger.info(previous_loads_check_sql)
    previous_load_check_df = spark.read.format("com.databricks.spark.redshift")\
                                .option("url", rs_url_db_dest+'?user='+rs_user_dest+'&password='+rs_pwd_dest)\
                                .option("query", previous_loads_check_sql)\
                                .option("forward_spark_s3_credentials", "true")\
                                .option("tempdir",f"s3://{scriptBucketName}/bloomberg/redshift/dataload/{job_name}/")\
                                .load()
    previous_load_check_df.show()   
    rs_error_count1 = previous_load_check_df.select(col('cnt')).collect()[0][0]
    rs_error_count = previous_load_check_df.collect()[0][0]
    print(rs_error_count,rs_error_count1)
    if rs_error_count != 0 :
       logger.info(f" Data already processed " + str(rs_error_count))
       logger.info('Results for Lkup Bloomberg curency  Table: ')
       previous_load_check_df.show()
       f_msg = f"  Data already loaded for the  file and file  will not be processed again for {calkey}"
       global REPROCESS_DATA
       REPROCESS_DATA = True
       print (f"Reprocesdata{REPROCESS_DATA}")
       #notifymsg("Data Already Processed for calkey ", f_msg)
       #exit()
    return rs_error_count


#################################### get_input_s3_path ##########################################
# This function will frame the input s3 path.
# By default, it will take all the files in the current date
def get_input_s3_path():
    s3_path = []
    config_redshift_path = f"s3a://{source_bucket}/" + configfile
    s3_prefix =f"s3://{source_bucket}/"+"Bloomberg/currency/"
    try:
        print(configfile)
        obj = s3Client.get_object(Bucket=source_bucket, Key=configfile)
    except Exception:
        obj = None
        logger.info("*********** NO config file present to check ReRun dates ***********")
    
    if obj is not None:
        logger.info("*********** Framing S3 Path ***********")
        Is_Manaul_load=True
        json_obj = json.loads(obj['Body'].read())
        print(json_obj)
        values=json_obj['Dates']
        print(values)
        #rerun_dates = [x.strip() for x in json_obj["Dates"].split(',')]
        for rows in values:
            s3_path_1=s3_prefix + rows + '/'
            print(s3_path_1)
            global calkey
            calkey=get_cal_key(s3_path_1)
            countofitems=is_calkey_processed(calkey)
            if countofitems > 0:
                exit()
            s3_path.append(s3_prefix + rows + '/')
            print(s3_path)
    
    else:
        s3_path = []
        s3_prefix = "s3://{}/Bloomberg/currency/".format(source_bucket)
        print(f"s3 prefix{s3_prefix}")
        fileNamePath=fileName #'s3://whg-s3-usw2a-redterminal-dev/Bloomberg/currency/2022/09/07/currencyfile.txt'
        calkey=get_cal_key(fileNamePath)
        print(f"s3 calkey is {calkey}")
        countofitems=is_calkey_processed(calkey)
        #if countofitems > 0:
        # #   exit()
        #else :
        s3_path.append(fileS3Path)
            #s3_path.append('s3://whg-s3-usw2a-redterminal-dev/Bloomberg/currency/2022/09/11/')
    
    print(s3_path)
    return s3_path

########################### SQL for prcs_ctrl_log table ###################################

def auditload(redshift_tmp_dir,fileName,filePath,create_ts_val,file_count):        
    logger.info("{}: Starting Audit Process".format(str(datetime.now())))
    logger.info("Getting Data from Load Error Table for Audit based on filename and and the latest starttime")
    
    try:
        
        rs_error_sql = "select distinct colname,filename,line_number, raw_field_value,err_reason from {0} where filename like '%{1}%' and starttime in (select max(starttime) from {0} where filename like '%{1}%') ".format(schemanamestg + "."+load_error_view, redshift_tmp_dir)
        
        rs_error_df = spark.read.format("com.databricks.spark.redshift").option("url", rs_url_db_dest+'?user='+rs_user_dest+'&password='+rs_pwd_dest)\
                            .option("query", rs_error_sql)\
                            .option("forward_spark_s3_credentials", "true")\
                            .option("tempdir", f"s3://{scriptBucketName}/bloomberg/redshift/errortable/{job_name}/")\
                            .load()

        rs_error_count = rs_error_df.count()
        rs_error_df.show()
        if rs_error_count != 0:
           msg="  {0} records errored out for the file {1}. Refer to Stg_glue_error for the records".format(rs_error_count, filePath)
           sub = "Error Report for {} ".format(job_name)
           notifymsg(sub, msg)
           msg="""Hi SD, \nKinldy raise a P3 ticket for AWS PSS team. \n\n Hi AWS PSS , \n\nBloomberg currency file has error records.  {0} records errored out for the file {1}. Refer to Stg_glue_error for the records and details""".format(rs_error_count, filePath)
           sub = "Request to raise a P3 ticket for AWS PSS team- Bloomberg loading has error data"
           notifymsg2(sub, msg)
           
        
        print(" Count of errored records: "+str(rs_error_count))
        
        
        
        ########################### Mark the status in case to Failed if the count is zero for otherwise mark it as Completed  ###################################
        rs_load_count=file_count
        if rs_load_count == 0:
           src_sts = 'F'
        else :
           src_sts = 'C'  

    except Exception as e:
        logger.error(str(e))
        logger.error("**************** [ERROR] Error while fetching count from Redshift, failed with : {} ***********".format(str(e)))
        f_msg="  Error while fetching count from Redshift for the job {0} and the file {1}, failed with error: {2}  ".format(job_name,filePath,str(e))
        f_sub = "BloomBerg Reject-record Process Alert: Glue Job - "+job_name+" failed" 
        notifymsg(f_sub, f_msg)
        exit(1)
########################## Insert the error records to Stg_glue_error. This is used to track the records that failed to load to  table #####################################
    
    if rs_error_count != 0:
        
        try:
            rs_error_df.createOrReplaceTempView("rs_error_temp") 
        
            rs_error_load_sql = spark.sql(""" select 'StayFeed' as sub_area, 'BloomBergCurrency' as prcs_nm, '{0}' as feed_nm, '{1}' as file_pth, 'Inbound' as feed_typ, filename as err_file_nm, cast(line_number as string) as file_line_num, colname as err_clumn_nm, raw_field_value as actl_field_value,
                                 err_reason as err_rsn, cast('{2}' as timestamp) as create_ts, 'Glue' as create_usr from rs_error_temp """.format(fileName,filePath,create_ts_val))
            rs_error_load_dyf = DynamicFrame.fromDF(rs_error_load_sql, 	glueContext, 	"rs_error_load_dyf")

            rs_error_load = glueContext.write_dynamic_frame.from_jdbc_conf(frame = rs_error_load_dyf,catalog_connection = redshift_connectionstg,connection_options = {"url": rs_url_db_stg_dest,"database": rsdb,"user": rs_user_stg_dest, "password": rs_pwd_stg_dest, "dbtable" : schemanamestg+'.'+errortable},redshift_tmp_dir =f"s3://{scriptBucketName}/bloomberg/redshift/errorload/{job_name}/")    

        except Exception as e:
            logger.error(str(e))
            logger.error("**************** [ERROR] Error while loading to stg_glue_error table : {} ***********".format(str(e)))
            f_msg="  Error while loading to stg_glue_error for the job {0} and the file {1}, failed with error: {2}  ".format(job_name,filePath,str(e))
            f_sub = "BloomBerg Reject-record Process Alert: Glue Job - "+job_name+" failed" 
            notifymsg(f_sub, f_msg)
            exit(1)
			
########################## Insert the error records to prcs_crl_log. This is used to track the file loading  to  table #####################################			        
        
    try:
        s3upload_local=create_timestamp_est()
        audit_df = sqlContext.createDataFrame([('Stay','BloomBergCurrency',fileName ,filePath,'Inbound', file_count, src_sts, 'Glue',s3upload_local)],["sub_area","prcs_nm","feed_nm","file_pth","feed_typ", "tot_cnt", "src_sts", "create_by","src_insert_ts"]) 
        audit_df.show()
        audit_df.createTempView("auditview")
        audit_df2 = spark.sql( """select cast(sub_area as string) as sub_area,cast(prcs_nm as string) as prcs_nm, cast(feed_nm as string) as feed_nm ,cast (file_pth as string )  as file_pth,cast(tot_cnt as integer ) as tot_cnt, cast(src_sts as string ) as src_sts, cast(create_by as string) as create_by,cast(src_insert_ts as timestamp) as src_insert_ts from auditview """)
        audit_dyf = DynamicFrame.fromDF(audit_df2, 	glueContext, 	"audit_dyf")
        audit_dyf.printSchema()
        audit_dyf.show()
        print(rs_url_db_stg_dest,rs_pwd_dest,schemanamestg,redshift_connectionstg)
        audit_load = glueContext.write_dynamic_frame.from_jdbc_conf(frame=audit_dyf, catalog_connection=redshift_connectionstg, connection_options={ "url": rs_url_db_stg_dest,            "database": rsdb, "user": rs_user_stg_dest, "password": rs_pwd_stg_dest, "dbtable": schemanamestg + '.' + audittable,"extracopyoptions": "MAXERROR 100"},        redshift_tmp_dir=f"s3://{scriptBucketName}/bloomberg/redshift/auditload/{job_name}/")
    

    except Exception as e:
        logger.error(str(e))
        logger.error("**************** [ERROR] Error while loading to prcs_ctrl_log table : {} ***********".format(str(e)))
        f_msg="  Error while fetching count from Redshift for the file {0}, failed with error: {1}  ".format(fileName,str(e))
        f_sub = "SOX Glue job "+job_name+" failed" 
        notifymsg(f_sub, f_msg)
        exit(1)
  

try:
    s3upload_local=create_timestamp_est()
    logger.info(" Reading S3 file")
    bloom_s3_read_dyf = glueContext.create_dynamic_frame.from_options(connection_type="s3",
                                                                      connection_options={
                                                                          "paths": get_input_s3_path(),
                                                                          'recurse': True},
                                                                      format="csv",
                                                                      format_options={
                                                                          'withHeader': True,
                                                                          "separator": "|"
                                                                      },
                                                                      transformation_ctx='bloom_s3_read_dyf')

    bloom_df = bloom_s3_read_dyf.toDF()
    bloom_df.show()
    bloom_df.printSchema()
    for colname in bloom_df.columns:
        bloom_df = bloom_df.withColumn(colname, trim(col(colname)))

    bloom_df_count = bloom_df.count()
    logger.info('Total Cound DF (no.of input files): {}'.format(bloom_df.count()))
    s3_path = get_input_s3_path()
    #str1 = s3_path[0].split('/')
    print(f"we reached data processing {s3_path}")
    #newstring = str1[-4:]
    #calkey = newstring[0] + newstring[1] + newstring[2]
    #print(calkey)
    #bloom_df.show()
    create_ts=create_timestamp_est()
    bloom_df3 = bloom_df.withColumn('crncy_cd',  col("SECURITIES").substr(lit(1), instr(col("SECURITIES"), ' '))) \
        .withColumn('instr', instr(trim(col("SECURITIES")), ' ')) \
        .withColumn('crncy_desc', upper(col('NAME'))) \
        .withColumn('create_by', lit('ETL')) \
        .withColumn('create_ts', lit(create_ts))\
        .withColumn('lst_updt_by', lit('ETL')) \
        .withColumn('filepath',input_file_name())\
        .withColumn('lst_updt_ts', lit(create_ts))

    bloom_df3 = bloom_df3.where(length(trim(col("crncy_cd"))) <= 4)
    #bloom_df3 = bloom_df3.withColumn("calkey2",regexp_replace(col("filepath").substr(lit(54), lit(10)),'/',''))
    bloom_df3 = bloom_df3.withColumn("calkey3" ,regexp_replace(regexp_extract(bloom_df3['filepath'], "\\d{4}\/\\d{1,2}\/\\d{1,2}",0),'/',''))
    bloom_df3.select(col("calkey3")).show()
    s3_filename =  bloom_df3.select(col("filepath")).distinct().head()[0]
    #print(s3_filename)
    df2 = bloom_df3.select(col("calkey3"), col("crncy_cd"), col("ERROR CODE").alias('err_cd'),
                          col("NUM FLDS").alias('num_of_fld'),
                          col("COUNTRY_ISO").alias('cntry_cd'), col("crncy_desc"),
                          col("PX_LAST").alias('crncy_conver_exst_rt'),
                          col('PX_CLOSE_DT').alias('crncy_lst_updt_dt'),
                          col('PRIOR_CLOSE_MID').alias('crncy_conver_prior_rt'),
                          col('LAST_UPDATE_DT').alias('crncy_conver_dt'), col('INVERSE_QUOTED').alias('invers_quot_flg'),
                          col('create_by'), col('create_ts'),
                          col('lst_updt_by'), col('lst_updt_ts'))
    df3 = df2.withColumn("lkup_bloomberg_crncy_hash", md5(concat_ws("", 'calkey3', 'cntry_cd')))
    dropDisDF = df3.dropDuplicates(["crncy_cd", "cntry_cd"])
    
    final_df = dropDisDF.withColumn('err_cd', when((col('err_cd') == 'N.A.') | (col("err_cd").cast('int').isNull()),
                                                  None).otherwise(col("err_cd"))) \
        .withColumn('num_of_fld',
                    when((col('num_of_fld') == 'N.A.') | (col("num_of_fld").cast('int').isNull()), None).otherwise(
                        col("num_of_fld"))) \
        .withColumn('cntry_cd', when((col('cntry_cd') == 'N'), None).otherwise(col("cntry_cd"))) \
        .withColumn('crncy_desc', when((col('crncy_desc') == 'N'), None).otherwise(col("crncy_desc"))) \
        .withColumn('crncy_conver_prior_rt',
                    when((col('crncy_conver_prior_rt') == 'N.A.') | (col("crncy_conver_prior_rt").cast('double').isNull()),
                         None).otherwise(col("crncy_conver_prior_rt"))) \
        .withColumn('crncy_lst_updt_dt',
                    when((to_date(trim(col("crncy_lst_updt_dt").cast(StringType())), "yyyyMMdd").isNull()), None).otherwise(
                        trim(col("crncy_lst_updt_dt")))) \
        .withColumn('crncy_conver_exst_rt',
                    when((col('crncy_conver_exst_rt') == 'N.A.') | (col("crncy_conver_exst_rt").cast('double').isNull()),
                         None).otherwise(col("crncy_conver_exst_rt"))) \
        .withColumn('crncy_conver_dt',
                    when((col('crncy_conver_dt') == 'N.A.') | 
                    (to_date(trim(col("crncy_conver_dt").cast(StringType())), "yyyyMMdd").isNull() ),
                         None).otherwise(trim(col("crncy_conver_dt")))) 
    
    #final_df = final_df.withColumn("crncy_conver_dt",to_date(col("crncy_conver_dt"), "YYYYMMDD"))
    #final_df.show()
    final_df.select(col("crncy_lst_updt_dt"),col("crncy_conver_dt")).show()
    final_df.createTempView("bloomcurncytemp")
    final_df2 = spark.sql( """ select cal_key,crncy_cd,lkup_bloomberg_crncy_hash,err_cd,num_of_fld,cntry_cd,\
      crncy_desc,cast(case when invers_quot_flg ='Y' then 1/crncy_conver_exst_rt else crncy_conver_exst_rt end as decimal(16,6)) as crncy_conver_exst_rt
,crncy_lst_updt_dt,cast(case when invers_quot_flg ='Y' then 1/crncy_conver_prior_rt else crncy_conver_prior_rt end as decimal(16,6)) as crncy_conver_prior_rt  ,\
      crncy_conver_dt,invers_quot_flg,create_by,create_ts,lst_updt_by,lst_updt_ts from (select cast(calkey3 as int) as cal_key,cast(crncy_cd as string) as crncy_cd, cast(lkup_bloomberg_crncy_hash as string) as lkup_bloomberg_crncy_hash,cast(err_cd as int) as err_cd, 
    cast(num_of_fld as int) as num_of_fld, cast(cntry_cd as string) as cntry_cd,cast(crncy_desc as string) as crncy_desc,cast(crncy_conver_prior_rt as decimal(16,6)) as crncy_conver_prior_rt,to_date(trim(crncy_lst_updt_dt),'yyyyMMdd') as crncy_lst_updt_dt,cast(crncy_conver_exst_rt as decimal(16,6)) as crncy_conver_exst_rt,to_date(trim(crncy_conver_dt ),'yyyyMMdd')  as crncy_conver_dt, cast(invers_quot_flg as string)as invers_quot_flg, cast(create_by as string) as create_by,cast(create_ts as timestamp) as create_ts,cast(lst_updt_by as string) as lst_updt_by, 
cast(lst_updt_ts as timestamp) as lst_updt_ts  from bloomcurncytemp)
    """)
            
    final_df2=final_df2.na.drop(subset=["crncy_conver_prior_rt"])
  
    final_df2.printSchema()
    #final_df2.show()
    final_df2_write = DynamicFrame.fromDF(final_df2, glueContext, "final_df2_write")
    print(final_df2_write)
    ###############Database loading############################################################
    
  
    redshift_tmp_dir=f"s3://{scriptBucketName}/bloomberg/redshift/dataload/{job_name}{calkey}{rand_value}/"
    print(redshift_tmp_dir)
    try:
        if not REPROCESS_DATA :
            
            redshift_load = glueContext.write_dynamic_frame.from_jdbc_conf(
                frame=final_df2_write,
                catalog_connection=redshiftconnection,
                connection_options={
                    "url": rs_url_db_dest,
                    "database": rsdb,
                    "user": rs_user_dest,
                    "password": rs_pwd_dest,
                    "dbtable": schema_name + '.' + rs_table_name,
                    "extracopyoptions": "MAXERROR 100000"},
                redshift_tmp_dir=f"s3://{scriptBucketName}/bloomberg/redshift/dataload/{job_name}{calkey}{rand_value}/"
            )
        else :
            pre_query ="delete from {0}.{1} where cal_key = {2};".format(schema_name,rs_table_name,calkey)
            print(pre_query)
            redshift_load = glueContext.write_dynamic_frame.from_jdbc_conf(
            frame=final_df2_write,
            catalog_connection=redshiftconnection,
            connection_options={
                "url": rs_url_db_dest,
                "preactions": pre_query,
                "database": rsdb,
                "user": rs_user_dest,
                "password": rs_pwd_dest,
                "dbtable": schema_name + '.' + rs_table_name,
                "extracopyoptions": "MAXERROR 100000"},
                redshift_tmp_dir=f"s3://{scriptBucketName}/bloomberg/redshift/dataload/{job_name}{calkey}{rand_value}/"
            )
    except Exception as e:
        logger.error(
        "************ {} [ERROR] Exception while loading data to file *************".format(
            str(datetime.now())))
        auditload(redshift_tmp_dir,'cendant_currency.txt',s3_filename,s3upload_local,0)
        f_msg = "  Error while reading data from S3 for the job {0} , failed with error: {1}  ".format(
        job_name, str(e))
        notifymsg("S3 Read", f_msg)            
        
    ###############################Audit table loading ###################################################################################
    s3upload_local=create_timestamp_est()
    #print(filename)
    if Is_Manaul_load:
        for p in s3_path:
            print("inside audit")
            #filename=os.path.basename(s3_filename)
            auditload(redshift_tmp_dir,'cendant_currency.txt',p,s3upload_local,final_df2.count())
    else:
        s3upload_local=create_timestamp_est()
        filename=os.path.basename(s3_filename)
        auditload(redshift_tmp_dir,filename,s3_filename,s3upload_local,final_df2.count())
        
    logger.info("Data Load Process BloomBerg Onging to redshift complete!")
    f_msg = "  Data Load Process BloomBerg Onging to redshift complete {0}  ".format(create_timestamp_est())
    notifymsg("BloomBerg Onging Completed", f_msg)
except Exception as e:
    logger.error(
    "************ {} [ERROR] Exception while reading the file from S3 *************".format(
        str(datetime.now())))
    logger.error("*********** [ERROR] Failing with error:  {} **************".format(str(e)))
    s3upload_local=create_timestamp_est()
    auditload(redshift_tmp_dir,'cendant_currency.txt',s3_filename,s3upload_local,0)
    f_msg = "  Error while reading data from S3 for the job {0} , failed with error: {1}  ".format(
    job_name, str(e))
    notifymsg("S3 Read", f_msg)
    raise SystemExit(e)

logger.info(" ************** {} End of Load process for S3 Read *********************** ".format(
    str(datetime.now())))
job.commit()
logger.info("JOB COMPLETE!!")

