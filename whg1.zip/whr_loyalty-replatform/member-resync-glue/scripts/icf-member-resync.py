import sys
from datetime import datetime
from datetime import timedelta
import pytz
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.dynamicframe import DynamicFrame
from pyspark.sql import SQLContext
import boto3
import logging
from pyspark.sql.functions import from_unixtime, unix_timestamp, col, when, lit, input_file_name, substring_index, udf
from pyspark.sql.types import TimestampType, DoubleType, StructType, StructField, StringType, IntegerType, LongType, FloatType, DecimalType, DateType
from pyspark.sql import functions as f

################################### Setting up Spark environment and enabling Glue to interact with Spark Platform #################################
sc=SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
sqlContext = SQLContext(sc)

################################### Enabling access to the arguments #####################################
job = Job(glueContext)
args = getResolvedOptions(sys.argv, ['JOB_NAME','gold_bucket','source_bucket','blue_bucket','error_bucket','SNS','rsdb','redshiftconnection','tablename','schemaname','audittable','env','errortable','load_error_view'])
job.init(args['JOB_NAME'], args)

################################### Setting up logger for event logging ###################################
logging.basicConfig()
logger = logging.getLogger()
logger.setLevel(logging.INFO)

################################### Assigning job arguments to variables  #################################

rsdb = args['rsdb']
redshiftconnection = args['redshiftconnection']
data_bucket_name = args['gold_bucket']
blue_bucket = args['blue_bucket']
error_bucket = args['error_bucket']
job_name = args['JOB_NAME']
tablename = args['tablename']
schemaname = args['schemaname']
audittable = args['audittable']
errortable = args['errortable']
load_error_view = args['load_error_view']
sns_notify = args['SNS']
source_bucket = args['source_bucket']
file_path_gen = 's3://{}/ICF-Olson/member_resync/'.format(source_bucket)
env = args['env']

job_run=True


################################### Create low level reosurce service client for S3 and SNS  ##################################

s3Client = boto3.client('s3',region_name='us-west-2')
s3resource = boto3.resource('s3',region_name='us-west-2')
glueClient = boto3.client('glue', region_name='us-west-2')


try:
    sns_client = boto3.client('sns',region_name = 'us-west-2')
    logger.info("Enabled SNS Notification")
except Exception as e:
    logger.error(str(e))
    logger.info(" Unable to enable SNS, failed with error: {}".format(str(e)))
    logger.info("Continuing with load without SNS notification")
    
    
def notifymsg(sub, msg):
    sns_client.publish(TopicArn = sns_notify, Message = msg , Subject= sub) 
    logger.info("**************** [INFO] SNS Notification Sent: {} *************************".format(job_name))

################################### Retriving connection information from Glue connections for Redshift  ##################################

try:
   logger.info("Getting Redshift Connection Information")    
   rs_connection_dest = glueContext.extract_jdbc_conf(redshiftconnection)
   rs_url_dest = rs_connection_dest["url"]
   rs_user_dest = rs_connection_dest["user"]
   rs_pwd_dest = rs_connection_dest["password"]
   rs_url_db_dest = rs_url_dest+'/'+rsdb
except Exception as e:
   logger.error(str(e))
   f_msg=" Unable to connect to Redshift while processing the glue job {0} , failed with error: {1}  ".format(job_name,str(e))
   f_sub = "ICF-Olson Member_Resync Glue Job "+job_name+" failed" 
   notifymsg(f_sub, f_msg)
   logger.info(" Exiting with error: {}".format(str(e)))
   exit(1)  


################## Create Timestamp ############################

def create_timestamp_est():
    
    now = datetime.now()
    
    est = pytz.timezone('US/Eastern')
    now_est = now.astimezone(est).strftime('%Y-%m-%d %H:%M:%S.%f')
    
    return now_est


def get_s3_path():
    print('Creating S3 Path')
    s3_path=[]
    key_list=[]
    try:
                s3_prefix = 'ICF-Olson/member_resync/'
                #today = datetime.now().strftime('%Y/%m/%d')
                #day1 = (datetime.now() - timedelta(1)).strftime('%Y/%m/%d')
                #day2 = (datetime.now() - timedelta(2)).strftime('%Y/%m/%d')
                s3_path.append(s3_prefix)
                ############### Add previous day files if the last execution is previous day ###################
                """
                response = glueClient.get_job_runs(
                    JobName=args['JOB_NAME'],
                    MaxResults=15
                )
                job_runs = response['JobRuns']
                start_time=None
                for run in job_runs:
                    if run['JobRunState'] != 'SUCCEEDED':
                        continue
                    else:
                        start_time = run['StartedOn']
                        break
                #print(start_time)
                if  start_time and start_time.date() < datetime.today().date():
                    if (datetime.today().date()-start_time.date()).days >=1:
                       s3_path.append(s3_prefix + day1 + '/')
                    if (datetime.today().date()-start_time.date()).days >=2:
                       s3_path.append(s3_prefix + day2 + '/')
                """
                
                for path in s3_path:
                    result = s3Client.list_objects(Bucket=source_bucket, Prefix=path)
                    print(result)
                    if result.get('Contents') is not None:
                        for obj in result.get('Contents'):
                            key = obj['Key']
                            print(key)
                            key_lower = key.lower()
                            if key_lower.endswith('.txt') or key_lower.endswith('.bz2') or key_lower.endswith('.gz'):
                                key_list.append("s3://"+source_bucket+'/'+key)
                logger.info(" List of files in the S3 Path")
                logger.info(key_list)
                previous_loads_check_sql = "select distinct file_pth as path from {0} where prcs_nm='Member_Resync' and sub_area ='ICF-Olson' and src_sts='C' order by src_insert_ts desc".format(schemaname+'.'+audittable)
                logger.info(" Checking if the files were already been prcoessed")
                logger.info(previous_loads_check_sql)

                previous_load_check_df = spark.read.format("com.databricks.spark.redshift").option("url", rs_url_db_dest+'?user='+rs_user_dest+'&password='+rs_pwd_dest)\
                            .option("query", previous_loads_check_sql)\
                            .option("forward_spark_s3_credentials", "true")\
                            .option("tempdir", "s3://"+error_bucket+'/ICF-Olson/member_resync/')\
                            .load()
                logger.info('Results for PRCS Table: ')
                previous_load_check_df.show()
                previous_load_check = [row.path for row in previous_load_check_df.select('path').collect()]
                logger.info('Checking LOAD List: {}'.format(previous_load_check))
                final_list = []
                for val in key_list:
                    if val not in previous_load_check:
                       final_list.append(val)
                logger.info(" Final list of files that will be processed for this run")
                logger.info(final_list)
                
                ##########################################################################################3

    except Exception as e:
                logger.error("****************** [ERROR] Unable to frame s3 Input Path : {} **************".format(str(e)))
                logger.error(str(e))
                f_msg=" Unable to frame the S3 path for the job {0} , failed with error: {1}  ".format(job_name,str(e))
                f_sub = "ICF-Olson Member_Resync Glue Job "+job_name+" failed" 
                notifymsg(f_sub, f_msg)
                exit(1)
                
    return final_list
    




def auditload(fileName,filePath,create_ts_val,audit_record,audit_df_schema, file_count):

    ########################### Read from stl_load_errors_view to get errored records ###################################

    logger.info("Getting Data from Load Error Table for Audit based on filename and and the latest starttime")
    
    try:
        
        rs_error_sql = "select distinct colname,filename,line_number, raw_field_value,err_reason from {0} where filename like '%{1}%' and starttime in (select max(starttime) from {0} where filename like '%{1}%') ".format(schemaname + "."+load_error_view, fileName)
        
        rs_error_df = spark.read.format("com.databricks.spark.redshift").option("url", rs_url_db_dest+'?user='+rs_user_dest+'&password='+rs_pwd_dest)\
                            .option("query", rs_error_sql)\
                            .option("forward_spark_s3_credentials", "true")\
                            .option("tempdir", "s3://"+error_bucket+'/ICF-Olson/member_resync/error/'+'{}/'.format(job_name)+fileName+'/')\
                            .load()

        rs_error_count = rs_error_df.count()
        
        if rs_error_count != 0:
           msg="  {0} records errored out for the file {1}. Refer to Stg_glue_error for the records".format(rs_error_count, filePath)
           sub = "Error Report for {} ".format(job_name)
           notifymsg(sub, msg)
        
        print(" Count of errored records: "+str(rs_error_count))

        ########################### Read from the staging table to get the count of records loaded from the file ###################################
        
        rs_load_sql = " select count(*) as count from  {0} where create_ts  = '{1}' and file_nm = '{2}' ".format(schemaname+'.'+tablename,create_ts_val,fileName)

        #rs_load_sql = " select count(*) as count from  {0} where create_ts  >= '{1}' ".format(schemaname+'.'+tablename,create_ts_val)
        
        rs_load_df = spark.read.format("com.databricks.spark.redshift").option("url", rs_url_db_dest+'?user='+rs_user_dest+'&password='+rs_pwd_dest)\
                            .option("query", rs_load_sql)\
                            .option("forward_spark_s3_credentials", "true")\
                            .option("tempdir", "s3://"+blue_bucket+'/ICF-Olson/member_resync/logs/'+'{}/'.format(job_name)+fileName+'/')\
                            .load()

        rs_load_count = int(rs_load_df.first()['count'])
        print(" Count of successfully loaded records: "+str(rs_load_count))

        ########################### Mark the status in case to Failed if the count is zero for otherwise mark it as Completed  ###################################
        
        if rs_load_count == 0:
           src_sts = 'F'
        else :
           src_sts = 'C'  

    except Exception as e:
        logger.error(str(e))
        logger.error("**************** [ERROR] Error while fetching count from Redshift, failed with : {} ***********".format(str(e)))
        f_msg="  Error while fetching count from Redshift for the job {0} and the file {1}, failed with error: {2}  ".format(job_name,filePath,str(e))
        f_sub = "ICF-Olson Member_Resync Glue Job "+job_name+" failed" 
        notifymsg(f_sub, f_msg)
        exit(1)

########################## Insert the error records to Stg_glue_error. This is used to track the records that failed to load to staging table #####################################
    
    if rs_error_count != 0:
        
        try:
            rs_error_df.createOrReplaceTempView("rs_error_temp") 
        
            rs_error_load_sql = spark.sql(""" select 'ICF-Olson' as sub_area, 'Member_Resync' as prcs_nm, '{0}' as feed_nm, '{1}' as file_pth, 'Inbound' as feed_typ, filename as err_file_nm, cast(line_number as string) as file_line_num, colname as err_clumn_nm, raw_field_value as actl_field_value,
                                 err_reason as err_rsn, cast('{2}' as timestamp) as create_ts, 'Glue' as create_usr from rs_error_temp """.format(fileName,filePath,create_ts_val))
            rs_error_load_dyf = DynamicFrame.fromDF(rs_error_load_sql, 	glueContext, 	"rs_error_load_dyf")

            rs_error_load = glueContext.write_dynamic_frame.from_jdbc_conf(frame = rs_error_load_dyf,catalog_connection = redshiftconnection,connection_options = {"url": rs_url_db_dest,"database": rsdb,"password": rs_pwd_dest, "dbtable" : schemaname+'.'+errortable},redshift_tmp_dir = "s3://"+blue_bucket+'/ICF-Olson/member_resync/auditload/'+'{}/'.format(job_name)+fileName+"/")    

        except Exception as e:
            logger.error(str(e))
            logger.error("**************** [ERROR] Error while loading to stg_glue_error table : {} ***********".format(str(e)))
            f_msg="  Error while loading to stg_glue_error for the job {0} and the file {1}, failed with error: {2}  ".format(job_name,filePath,str(e))
            f_sub = "ICF-Olson Member_Resync Glue Job "+- job_name+" failed" 
            notifymsg(f_sub, f_msg)
            exit(1)
    
    ########################### Load to prcs_ctrl_log table ###################################

    logger.info("{}: Starting Audit Process".format(str(datetime.now())))
    
    ########################### Create a temp dataframe audit_df_temp for each file and append to the audit_df in a loop ###################################
    
    global audit_df
    audit_record = audit_record + [(['ICF-Olson','Member_Resync',fileName,'{}'.format(filePath),'Inbound', file_count ,rs_load_count, rs_error_count, src_sts, 'Glue'])]
    audit_df_temp = sqlContext.createDataFrame(audit_record,audit_df_schema) 
    audit_df = audit_df.union(audit_df_temp)
    # audit_df_temp.unpersist()
    
    audit_df.createOrReplaceTempView("audit_df_view")
    audit_df_sql = spark.sql(""" select *, cast('{}' as timestamp) as src_insert_ts from audit_df_view where feed_nm = '{}' """.format(create_ts_val, fileName))
    
    audit_dyf = DynamicFrame.fromDF(audit_df_sql, 	glueContext, 	"audit_dyf")    

    try:
            
        audit_load = glueContext.write_dynamic_frame.from_jdbc_conf(frame = audit_dyf,catalog_connection = redshiftconnection,connection_options = {"url": rs_url_db_dest,"database": rsdb,"password": rs_pwd_dest, "dbtable" : schemaname+'.'+audittable},redshift_tmp_dir = "s3://"+blue_bucket+'/ICF-Olson/member_resync/auditload/'+'{}/'.format(job_name)+fileName+"/")    
        logger.info('Audit process for glue job {} and file {} is complete'.format(job_name, filePath))
    except Exception as e:
        logger.error(str(e))
        logger.error("**************** [ERROR] Error while loading to prcs_ctrl_log table : {} ***********".format(str(e)))
        f_msg="  Error while inserting to prcs_ctrl_log table for the job {0} and the file {1}, failed with error: {2}  ".format(job_name,filePath,str(e))
        f_sub = "ICF-Olson Member_Resync Glue Job "+job_name+" failed" 
        notifymsg(f_sub, f_msg)
        exit(1)

s3_input = get_s3_path()

print(s3_input)
print("okay1")

################################ Reading the data from the file ##############################################
if len(s3_input) == 0:
        logger.info(' No Data to process for S3 Read Inbound - ICF-Olson Job for {} run'.format(str(datetime.now())))
        f_msg = "No new files to process for this run for the job - {0} for run {1}".format(job_name,str(datetime.now()))
        f_sub = "ICF-Olson Member_Resync Glue Job "+job_name+" failed" 
        notifymsg(f_sub, f_msg)
        #exit(0)
else:
  for eachfile in   s3_input:
    try:
        df = spark.read.csv(eachfile, sep="|", header="true")
        print(eachfile)
        logger.info('Success reading the data')   
        #df = df.filter(~(col("GUEST_MEMBER_NUM").like("%Records%")))
        #df = df.filter(~(col("GUEST_MEMBER_NUM").like("%Total%")))
        
        df.show()
        df_count = df.count()
        logger.info('Total Count for the files: {}'.format(df_count))
        df = df.withColumn('filePath', input_file_name())
        df.printSchema()
        df.show()

    except Exception as e:
        logger.error("*********** [ERROR] Creating the DataFrame:  {} **************".format(str(e)))
        f_msg="  Error while reading data from S3 "
        f_sub = "ICF-Olson Member_Resync Glue Job "+job_name+" failed" 
        notifymsg(f_sub, f_msg)
        exit(1)

    df_count = df.count()
    logger.info('Total Count for the files: {}'.format(df_count))

    df = df.withColumn('filePath', input_file_name())
    
    df.createOrReplaceTempView("s3_read_temp")

    
    ################################### Create empty dataframe to be used for inserting to prcs_ctrl_log table ###############################
    audit_df_schema = StructType([StructField("sub_area", StringType(), True), StructField("prcs_nm", StringType(), True),StructField("feed_nm", StringType(), True),
                                    StructField("file_pth", StringType(), True),StructField("feed_typ", StringType(), True), StructField("tot_cnt", IntegerType(), True),
                                    StructField("src_sucss_cnt", IntegerType(), True),StructField("src_fail_cnt", IntegerType(), True),StructField("src_sts", StringType(), True),
                                    StructField("create_by", StringType(), True)])
    audit_df = spark.createDataFrame(sc.emptyRDD(), audit_df_schema)
    audit_record = []
    
    ################################### Get the filename, timestamp and the record count for each file and order by timestamp ###############################
        ################################### Fileilename and timestamp is extracted from file path ###############################
        
    file_count_sql = spark.sql(""" select *, SUBSTRING_INDEX(filePath,'/',-1) as fileName from ( select filePath,  count(*) as s3_file_record_count from  s3_read_temp group by filePath) """)
    file_count_sql.show(10, False)
    
    ################################### Extract each row from the dataframe. Will loop through each filename to load the data #################################
        ################################### Doing loop instead of bulk load is to maintain the sequence of incremental data that we get from source to match with the data we load to staging table #################################
        
    s3_file_list = [ { 'filePath':x['filePath'], 'fileName':x['fileName'], 's3_file_record_count':x['s3_file_record_count'] } for x in file_count_sql.rdd.collect()]
    
    for row in s3_file_list:
        
        s3_file_record_count = row["s3_file_record_count"] 
        fileName = row["fileName"]
        filePath = row["filePath"]
    
        now_est = create_timestamp_est()
        ########################## Applying Transformation ##############################

        try:
            # df1 = df.withColumn('insert_ts',lit(now_est).cast(TimestampType())).withColumn('file_nm', substring_index('filePath', '/',-1).cast(StringType())).withColumn('SFMC_SENT_TS', from_unixtime(unix_timestamp(col(('SFMC_SENT_TS')),"MM/dd/yyyy hh:mm:ss aa"),"yyyy-MM-dd' 'HH:mm:ss"))
            # df1 = df1.filter(~(col("SFMC_SENT_TS").isNull()))

            df1 = df.withColumn('create_ts',lit(now_est).cast(TimestampType())).withColumn('file_nm', substring_index('filePath', '/',-1).cast(StringType()))
            # df1 = df1.filter(~(col("SFMC_SENT_TS").isNull()))
            df1.printSchema()
            df1.show(10, False)
            logger.info('df1 rcrds')

            # df1 = df.withColumn('insert_ts',lit(now_est).cast(TimestampType())).withColumn('file_nm', substring_index('filePath', '/',-1).cast(StringType()))
            

            col_list = ['UniqueID_id,SecondaryData__StatusCode,CustLoyalty__SignupDate,SecondaryData__Level,EnrollmentInfo__EnrollmentChannel,EnrollmentInfo__EnrollmentSource,CustLoyalty__ValidEnrollmentDate,SecondaryData_PointBalance,ICF_sent_timestamp']

            for colname in col_list:
                if not colname in df1.columns :
                    logger.info(" Adding missing column: "+colname)
                    df1 = df1.withColumn(colname,lit(None).cast(StringType()))
      
            df_final = df1.select(col('UniqueID_id').cast(StringType()).alias('loylty_mbr_num'), col('SecondaryData__StatusCode').cast(StringType()).alias('mbr_sts'), col('CustLoyalty__SignupDate').cast(DateType()).alias('eff_strt_dt'), col('SecondaryData__Level').cast(StringType()).alias('cur_loylty_lvl'), col('EnrollmentInfo__EnrollmentChannel').cast(StringType()).alias('enrl_chanl'),
                             col('EnrollmentInfo__EnrollmentSource').cast(StringType()).alias('enrl_src'), col('CustLoyalty__ValidEnrollmentDate').cast(DateType()).alias('vld_enrl_dt'), col('SecondaryData_PointBalance').cast(IntegerType()).alias('pt_bal'),col('ICF_sent_timestamp').cast(TimestampType()).alias('icf_sent_ts') ,col('create_ts'),col('file_nm')).where(df1.file_nm == fileName)

            
            logger.info('Each File Count: {}'.format(s3_file_record_count))
            df_final.printSchema()
            df_final.show(10, False)
            logger.info('df_final rcrds')
    
            dyf = DynamicFrame.fromDF(df_final, glueContext,'dyf')
            
            logger.info('Success creating final Dynamic Frame')
            logger.info('Total Count DyF: {}'.format(dyf.count()))
            
        except Exception as e:
            logger.error("*********** [ERROR] Creating the DynamicFrame:  {} **************".format(str(e)))
            f_msg="  Error while applying transformation to file {0}, failed with error: {1}  ".format(filePath,str(e))
            f_sub = "ICF-Olson Member_Resync Glue Job "+job_name+" failed" 
            auditload(fileName, filePath, now_est, audit_record, audit_df_schema, s3_file_record_count)
            notifymsg(f_sub, f_msg)
            exit(1)
            

        ########################## Loading Data to Redshift #####################################

        try:
            redshift_load = glueContext.write_dynamic_frame.from_jdbc_conf(
                                        frame = dyf, 
                                        catalog_connection = redshiftconnection, 
                                        connection_options = {
                                                            "url": rs_url_db_dest,
                                                            "database": rsdb, 
                                                            "user": rs_user_dest, 
                                                            "password": rs_pwd_dest, 
                                                            "dbtable" : schemaname+'.'+tablename ,
                                                            "extracopyoptions":"MAXERROR 100000"},  
                                        redshift_tmp_dir = "s3://"+blue_bucket+'/ICF-Olson/member_resync/dataload/{}/'.format(job_name)+'{}/'.format(fileName)
            
            
                                            )
            auditload(fileName, filePath, now_est, audit_record, audit_df_schema, s3_file_record_count)
            logger.info(" Data Load Process to redshift complete for {}".format(filePath))
        except Exception as e:
            logger.error(str(e))
            logger.info("  [ERROR] Error while loading to Redshift Staging table, failed with : {} ".format(str(e)))
            f_msg="  Error while loading to Staging table for the job {0} and the file {1}, failed with error: {2}  ".format(job_name,filePath,str(e))
            f_sub = "ICF-Olson Member_Resync Glue Job "+job_name+" failed" 
            auditload(fileName, filePath, now_est, audit_record, audit_df_schema, s3_file_record_count)
            notifymsg(f_sub, f_msg)
            exit(1)

logger.info('Load Process end for Guest member_resync Member_Resync')
job.commit()
