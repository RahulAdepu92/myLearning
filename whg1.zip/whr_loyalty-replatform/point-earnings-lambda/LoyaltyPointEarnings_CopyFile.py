import boto3
import logging
import os

# Setting Logger
logging.basicConfig()
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# calling services using boto3
s3_client = boto3.client('s3', region_name='us-west-2')
s3_resource = boto3.resource('s3', region_name='us-west-2')
sns_client = boto3.client('sns', region_name='us-west-2')
glue_client = boto3.client('glue', region_name='us-west-2')

# Get the Environment Variables of Lambda-Scripts
target_bucket_name = os.environ["blueBucket"]
error_bucket_name = os.environ["errorBucket"]
glue_job_name = os.environ["glueJobName"]
SNSTopicArn = os.environ["SNSTopicArn"]
env = target_bucket_name.split("-")[-1].upper()  # gets environment name
num_of_cols = 52    # this is fixed value and specified by business (can be found in JIRA story)


# SNS Notification
def notifymsg(sub, msg):
    sns_client.publish(TopicArn=SNSTopicArn, Message=msg, Subject=env+": "+sub)
    logger.info("**************** SNS Notification Sent *************************")


# Defining handler
def main(event, context):
    global latest_job_run
    file_processing = True
    response = {}
    logger.info("Received Event is: %r", event)
    # Bucket Name where file was uploaded
    source_bucket_name = event['Records'][0]['s3']['bucket']['name']
    # Source Filename with path
    source_file_key = event['Records'][0]['s3']['object']['key']

    # source and target full paths
    source_file_full_path = os.sep.join([source_bucket_name, source_file_key])
    logger.info('Source file path is: s3://%s', source_file_full_path)
    source_file_name = source_file_key.split(os.sep)[-1]
    target_file_path = source_file_key.split("/")
    target_file_path.insert(2, "intermediate")  # adding 'intermediate' to the path
    target_file_path = "/".join(target_file_path)
    logger.info('Target file path is: s3://%s/%s', target_bucket_name, target_file_path)

    try:
        s3_obj = s3_client.get_object(Bucket=source_bucket_name, Key=source_file_key)
        content = s3_obj["Body"].read().decode(encoding="ascii", errors="ignore")
        data = content.splitlines()  # splitting each line into string and making a list

        logger.info("validating the structure of the incoming file..")
        # checking lengths of first and last records (excluding header and footer)
        if len(data[1].split("|")) != num_of_cols or len(data[-2].split("|")) != num_of_cols:
            # moving the error file to error bucket as it has incorrect num of columns
            # initially copying the file from src path to error path and then deleting it
            s3_resource.Object(error_bucket_name, source_file_key).copy_from(
                CopySource={"Bucket": source_bucket_name, "Key": source_file_key}
            )
            # deleting the file from src path
            s3_resource.Object(source_bucket_name, source_file_key).delete()
            error_file_path = os.sep.join([error_bucket_name, source_file_key])
            logger.error(f"As the src file has structure format issues,"
                         f" '{source_file_name}' is moved to error path 's3://{error_file_path}'")
            sub = f"Lambda to process 'Loyalty Point Earnings' File failed"
            msg = f"As the number of input columns is not equal to the specified num of columns '{num_of_cols}', " \
                  f"the file is rejected and moved to Error bucket path 's3://{error_file_path}'"
            notifymsg(sub, msg)
            file_processing = False

        else:
            parsed_data = data[1:-1]  # removing unwanted header & footer as per business req
            # adding extra column 'source_file_count' to the data to help glue processing
            header = parsed_data[0]
            header_new = header + "|source_file_count"
            source_file_count = data[0].split('|')[-1]  # gets the file count from file header information
            lst = []
            for line in parsed_data[1:]:
                str = line + f"|{source_file_count}"
                lst.append(str)
            lst_new = "\n".join(lst)
            body = header_new + "\n" + lst_new  # converting to all lines finally
            # logger.info(f"body is: {body}")
            # moving the parsed file to target location
            s3_client.put_object(Bucket=target_bucket_name, Body=body, Key=target_file_path)
            logger.info(f"src file '{source_file_name}' moved to "
                        f"target location 's3://{target_bucket_name}/{target_file_path}'")

    except Exception as e:
        logger.error(f"FAILED with error {e}")
        sub = f"Lambda to read 'Loyalty Point Earnings' File failed"
        msg = f"Error while reading Loyalty Point Earnings File, failed with error: {e}"
        notifymsg(sub, msg)
        raise SystemExit(e)

    if file_processing:
        try:
            get_run_response = glue_client.get_job_runs(
                JobName=glue_job_name,
                MaxResults=1
            )
            job_runs = get_run_response['JobRuns']
            logger.info(f"previous job_run details: {job_runs}")

            # if the glue run is first time ever, we get empty list above. So to avoid error writing below
            if job_runs:
                latest_job_run = job_runs[0]

            if not job_runs or latest_job_run['JobRunState'] == 'SUCCEEDED' \
                    or latest_job_run['JobRunState'] == 'FAILED'\
                    or latest_job_run['JobRunState'] == 'STOPPED':
                # triggering the glue job if previous glue job run status is "FirstRun/SUCCEEDED/FAILED/STOPPED"
                response = glue_client.start_job_run(JobName=glue_job_name)
                if "JobRunId" in response:
                    job_id = response["JobRunId"]
                    logger.info("Glue job '%s' started with id '%s'", glue_job_name, job_id)
            else:
                logger.info("The previous job is already in RUNNING state currently,"
                            " so exiting without triggering the same job..")

        except Exception as e:
            logger.error(f"FAILED with error {e}")
            sub = f"Lambda to trigger 'Loyalty Point Earnings' glue job failed"
            msg = f"Error occurred while triggering Glue job '{glue_job_name}', failed with error: {e}"
            notifymsg(sub, msg)
            raise SystemExit(e)
