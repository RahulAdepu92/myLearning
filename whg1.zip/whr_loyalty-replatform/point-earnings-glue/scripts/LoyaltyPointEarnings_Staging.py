import logging
import re
import sys
from datetime import datetime, timedelta
import pytz

import boto3
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from pyspark.sql import SQLContext
from pyspark.sql.functions import col, when, lit, input_file_name, monotonically_increasing_id, row_number
from awsglue.dynamicframe import DynamicFrame
from pyspark.sql.types import TimestampType, DoubleType, StructType, StructField, StringType, IntegerType, LongType, \
    FloatType, DecimalType

sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
sqlContext = SQLContext(sc)

# Enabling access to the arguments
job = Job(glueContext)
args = getResolvedOptions(sys.argv, ['JOB_NAME', 'blue_bucket', 'SNS', 'rsdb',
                                     'redshiftconnection', 'schemaname', 'tablename', 'stgerrortable',
                                     'audittable', 'errortable', 'load_error_view', 'error_bucket' ])
job.init(args['JOB_NAME'], args)

# Setting Logger
logging.basicConfig()
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Assigning job arguments to variables
rsdb = args['rsdb']
blue_bucket = args['blue_bucket']
error_bucket = args['error_bucket']
job_name = args['JOB_NAME']
SNSTopicArn = args['SNS']
redshiftconnection = args['redshiftconnection']
schema_name = args['schemaname']
stg_table = args['tablename']
audit_table = args['audittable']
error_table = args['errortable']
stg_err_table = args['stgerrortable']
load_error_view = args['load_error_view']
today = datetime.now().strftime('%Y/%m/%d')
stl_load_errors_file_path = f"s3://{blue_bucket}/ICF-Olson/earning/stl_load_errors/{today}/"
env = blue_bucket.split("-")[-1].upper()  # gets environment name

# calling services using boto3
s3Client = boto3.client('s3', region_name='us-west-2')
s3resource = boto3.resource('s3', region_name='us-west-2')
glueClient = boto3.client('glue', region_name='us-west-2')

try:
    sns_client = boto3.client('sns', region_name='us-west-2')
    logger.info("Enabled SNS Notification")
except Exception as e:
    logger.error(f"Unable to enable SNS, failed with error: {str(e)}")
    logger.info("Continuing with load without SNS notification")


# SNS Notification
def notifymsg(sub, msg):
    sns_client.publish(TopicArn=SNSTopicArn, Message=msg, Subject=env+": "+sub)
    logger.info("**************** [INFO] SNS Notification Sent *************************")


def timestamp_now() -> dict:
    utc_now = datetime.now()
    utc_now_str = utc_now.strftime('%Y-%m-%d %H:%M:%S.%f')
    est = pytz.timezone('US/Eastern')
    est_now_str = utc_now.astimezone(est).strftime('%Y-%m-%d %H:%M:%S.%f')
    return {"utc_now": utc_now_str, "est_now": est_now_str}


def get_input_s3_path() -> list:
    """
    # This function will frame the input s3 path.
    # By default, it will take all the files in the current date
    :return: s3 paths list
    """
    logger.info("*********** Framing S3 Path ***********")
    s3_path = []
    s3_prefix = f"s3://{blue_bucket}/ICF-Olson/earning/intermediate/"
    try:
        # Creating Datetime Folder
        today = datetime.now().strftime('%Y/%m/%d')
        yesterday = (datetime.now() - timedelta(1)).strftime('%Y/%m/%d')

        logger.info(f"Today's date is: {today}")
        logger.info(f"Yesterday's date is: {yesterday}")

        s3_path.append(s3_prefix + today + '/')
        # Add yesterday files if the last execution is previous day
        response = glueClient.get_job_runs(
            JobName=args['JOB_NAME'],
            MaxResults=10
        )
        job_runs = response['JobRuns']
        start_time = None
        for run in job_runs:
            if run['JobRunState'] != 'SUCCEEDED':
                continue
            else:
                start_time = run['StartedOn']
                break
        logger.info("start_time of latest successful job is: %s", start_time)
        # logger.info("UTC_TIME is: %s", datetime.now())
        if start_time and start_time.date() < datetime.today().date():
            logger.info(
                "adding yesterday file(s) if left over any for processing.")
        # whether previous day file processed or not will be detected by glue's job-bookmark option
            s3_path.append(s3_prefix + yesterday + '/')
        logger.info("input s3 path: %s", s3_path)
    except Exception as e:
        logger.error(
            f"****************** [ERROR] Unable to frame s3 Input Path : {str(e)} **************")
        sub = f"LR Point Earnings Glue Job '{job_name}' failed"
        msg = f"Unable to Frame S3 Input Path, Error Details: {str(e)}"
        notifymsg(sub, msg)
        raise SystemExit(e)

    return s3_path


def audit_load(audit_record, audit_df_schema, s3_file_record_count, fileName, filePath) -> None:
    """
    This function will write errors (if any) to error table 'stg_glue_error' and write the success/failure status
    of the file to audit table 'prcs_cntrl_log' post staging process is completed
    :param audit_record: audit record for current processing file
    :param audit_df_schema: audit schema for current processing file
    :param s3_file_list: list of s3 files for processing
    :return:
    """
    try:
        # Read from 'stl_load_errors_view' table to get error records
        logger.info("Getting audit log data based on filename and and the latest createtime..")
        rs_error_sql = f"""select distinct colname, filename, line_number, raw_line, raw_field_value, err_reason 
                            from {schema_name}.{load_error_view} where filename like '%{fileName}%' and 
                            starttime >= '{utc_now}' """

        logger.info("stl_load_errors_sql: %s", rs_error_sql)
        rs_errors_df = spark.read.format("com.databricks.spark.redshift") \
            .option("url", rs_url_db_dest + '?user=' + rs_user_dest + '&password=' + rs_pwd_dest) \
            .option("query", rs_error_sql) \
            .option("forward_spark_s3_credentials", "true") \
            .option("tempdir",
                    "s3://" + error_bucket + '/ICF-Olson/earning/logs/' + '{}/'.format(job_name) + fileName + '/') \
            .load()
        rs_error_count = rs_errors_df.count()
        logger.info(f"Count of failed records for file '{fileName}': " + str(rs_error_count))

        # Read staging table to get the count of records loaded from the file
        rs_load_sql = f""" select count(*) as count from {schema_name}.{stg_table} 
                            where src_file_nm = '{fileName}' and create_ts >= '{est_now}'"""

        rs_load_df = spark.read.format("com.databricks.spark.redshift") \
            .option("url", rs_url_db_dest + '?user=' + rs_user_dest + '&password=' + rs_pwd_dest) \
            .option("query", rs_load_sql) \
            .option("forward_spark_s3_credentials", "true") \
            .option("tempdir",
                    "s3://" + blue_bucket + '/ICF-Olson/earning/logs/' + '{}/'.format(job_name) + fileName + '/') \
            .load()

        rs_load_count = int(rs_load_df.first()['count'])
        logger.info(f"Count of successfully loaded records for file '{fileName}': " + str(rs_load_count))

        # Mark the status as 'Failed' if count is zero, otherwise mark it as 'Completed'
        if rs_load_count == 0:
            src_sts = 'F'
        else:
            src_sts = 'C'

    except Exception as e:
        logger.error(
            f"**************** [ERROR] Error while fetching count from Redshift, failed with : {str(e)} ***********")
        msg = f"Error while fetching count from Redshift for the job '{job_name}' and the file '{filePath}', " \
              f"failed with error: {str(e)}"
        sub = f"LR Point Earnings Glue Job '{job_name}' failed"
        notifymsg(sub, msg)
        raise SystemExit(e)

    # Insert the error records to stg_glue_error to track the records that failed while loading staging table
    if rs_error_count != 0:
        # archiving 'stl_load_errors' to S3 path as .csv file
        rs_errors_df.repartition(1).write.csv(stl_load_errors_file_path, mode='append', header='true')
        sub = f"Error Report for Glue job '{job_name}'"
        msg = f"{rs_error_count} error record(s) found for the file '{filePath}'. Refer {schema_name}." \
              f"{error_table} table for the details.."
        notifymsg(sub, msg)
        try:
            rs_errors_df.createOrReplaceTempView("rs_error_temp")
            rs_error_load_sql = \
                spark.sql(f""" select 'ICF-Olson' as sub_area, 'Point Earnings' as prcs_nm,
                        '{fileName}' as feed_nm, '{filePath}' as file_pth, 'Inbound' as feed_typ,
                         pe.filename as err_file_nm, cast(pe.line_number as string) as file_line_num,
                         pe.colname as err_clumn_nm, pe.raw_field_value as actl_field_value,
                         pe.err_reason as err_rsn, cast('{est_now}' as timestamp) as create_ts, 
                         'Glue' as create_usr from rs_error_temp pe""")
            rs_error_load_dyf = DynamicFrame.fromDF(rs_error_load_sql, glueContext, "rs_error_load_dyf")

            rs_error_load = glueContext.write_dynamic_frame.from_jdbc_conf(frame=rs_error_load_dyf,
                                                                           catalog_connection=redshiftconnection,
                                                                           connection_options={
                                                                               "url": rs_url_db_dest,
                                                                               "database": rsdb,
                                                                               "password": rs_pwd_dest,
                                                                               "dbtable": schema_name + '.' +
                                                                                          error_table},
                                                                           redshift_tmp_dir="s3://" + blue_bucket +
                                                                                            '/ICF-Olson/earning/redshift/stl_load_errors/' + '{}/'.format(
                                                                               job_name) + fileName + "/")

        except Exception as e:
            logger.error(
                f"**************** [ERROR] Error while loading to stg_glue_error table : {str(e)} ***********")
            msg = f"Error while loading to {error_table} for the job {job_name} and the file '{filePath}', " \
                  f"failed with error: {str(e)}"
            sub = f"LR Point Earnings Glue Job '{job_name}' failed"
            notifymsg(sub, msg)
            raise SystemExit(e)

    # Load to prcs_ctrl_log table
    logger.info(f"Starting Audit Process for prcs_ctrl_log table..")

    # Create a temp dataframe audit_df_temp for each file and append to the audit_df in a loop
    global audit_df
    audit_record = audit_record + [(['ICF-Olson', 'Point Earnings', fileName, filePath, 'Inbound', int(s3_file_record_count),
                                     rs_load_count, rs_error_count, src_sts, 'Glue'])]
    audit_df_temp = sqlContext.createDataFrame(audit_record, audit_df_schema)
    audit_df = audit_df.union(audit_df_temp)
    # audit_df_temp.unpersist()

    audit_df.createOrReplaceTempView("audit_df_view")
    audit_df_sql = spark.sql(
        f""" select *, cast('{est_now}' as timestamp) as src_insert_ts from audit_df_view 
        where feed_nm = '{fileName}' """)

    audit_dyf = DynamicFrame.fromDF(audit_df_sql, glueContext, "audit_dyf")

    try:
        audit_load = glueContext.write_dynamic_frame.from_jdbc_conf(frame=audit_dyf,
                                                                    catalog_connection=redshiftconnection,
                                                                    connection_options={"url": rs_url_db_dest,
                                                                                        "database": rsdb,
                                                                                        "password": rs_pwd_dest,
                                                                                        "dbtable": schema_name + '.'
                                                                                                   + audit_table},
                                                                    redshift_tmp_dir="s3://" + blue_bucket +
                                                                                     '/ICF-Olson/earning/redshift/audit_load/' + '{}/'.format(
                                                                        job_name) + fileName + "/")
        logger.info(f"Audit process for the file '{filePath}' is complete!")
    except Exception as e:
        logger.error(
            "**************** [ERROR] Error while loading to prcs_ctrl_log table : {} ***********".format(str(e)))
        msg = f"Error while inserting to 'prcs_ctrl_log' audit table for the job {job_name} and the file {filePath}, " \
              f"failed with error: {str(e)}"
        sub = f"LR Point Earnings Glue Job '{job_name}' failed"
        notifymsg(sub, msg)
        raise SystemExit(e)


########################### Reading .txt Data ####################################
try:
    logger.info("Reading S3 processing file")
    pnt_erngs_s3_read_dyf = \
        glueContext.create_dynamic_frame.from_options(connection_type="s3",
                                                      connection_options={
                                                               "paths": get_input_s3_path(),
                                                               "recurse": True},
                                                      format="csv",
                                                      format_options={
                                                               "withHeader": True,
                                                               "separator": "|"
                                                      },
                                                      transformation_ctx="pnt_erngs_s3_read_dyf")

    pnt_erngs_df = pnt_erngs_s3_read_dyf.toDF()
    # pnt_erngs_df.limit(1).show()
    pnt_erngs_df_count = pnt_erngs_df.count()
    logger.info(f"Total DF count (total no.of records to be loaded): {pnt_erngs_df_count}")

except Exception as e:
    logger.error(
        f"************ {datetime.now()} [ERROR] Exception while reading the file from S3 *************")
    sub = f"LR Point Earnings Glue Job '{job_name}' failed"
    msg = f"Error while reading data from S3 for the job '{job_name}' , failed with error: {str(e)}"
    notifymsg(sub, msg)
    raise SystemExit(e)

if pnt_erngs_df_count == 0:
    logger.info('No Data to process for S3 Read Job for {} run'.format(str(datetime.now())))
    sub = f"Glue job '{job_name}' has NO data to run"
    msg = "No Data to Process for Glue Job - {} for run {}".format(job_name,
                                                                                 str(datetime.now()))
    notifymsg(sub, msg)
else:
    # Retrieving connection information from 'Glue connections' for Redshift
    try:
        logger.info("Getting Redshift Connection Information..")
        rs_connection_dest = glueContext.extract_jdbc_conf(redshiftconnection)
        rs_url_dest = rs_connection_dest["url"]
        rs_user_dest = rs_connection_dest["user"]
        rs_pwd_dest = rs_connection_dest["password"]
        rs_url_db_dest = rs_url_dest + '/' + rsdb
        logger.info("Redshift Connection details retrieved successfully")
    except Exception as e:
        logger.error(" Failed with error: %s", str(e))
        sub = f"LR Point Earnings Glue Job '{job_name}' failed"
        msg = f"Unable to connect to Redshift while processing the glue job {job_name}, failed with error: {e}"
        notifymsg(sub, msg)
        raise SystemExit(e)

    try:
        # Filling in blank values with Null values
        for x in pnt_erngs_df.columns:
            pnt_erngs_df = pnt_erngs_df.withColumn(x, when(col(x) != '', col(x)).otherwise(None))
        pnt_erngs_df_full = pnt_erngs_df.withColumn('filePath', input_file_name())
        pnt_erngs_df_full.limit(1).show()

        # creating temp view for the staging table
        pnt_erngs_df_full.createTempView("pnt_erngs_temp")
        logger.info("'pnt_erngs_temp' is created")

        ############ Data Quality Checks ############
        logger.info('Start of DQ checks')
        # DQ check required fields are specified in the user story where only nullability was asked to verify.
        # validating hard check columns
        df_DQ_HardCheck_failed = pnt_erngs_df_full.filter(pnt_erngs_df_full.trans_id.isNull())
        logger.info(f'Total count of DQ (Hard Check) failed records: {df_DQ_HardCheck_failed.count()}')
        df_DQ_HardCheck_failed_final = df_DQ_HardCheck_failed.withColumn('dq_flag', lit('H'))
        # validating soft check columns
        df_DQ_SoftCheck_failed = pnt_erngs_df_full.filter(pnt_erngs_df_full.memb_num.isNull() |
                                                          pnt_erngs_df_full.earn_type.isNull() |
                                                          pnt_erngs_df_full.post_dt.isNull() |
                                                          pnt_erngs_df_full.earn_descr.isNull() |
                                                          pnt_erngs_df_full.credit_debit_ind.isNull() |
                                                          pnt_erngs_df_full.ICF_sent_ts.isNull())
        logger.info(f'Total count of DQ (Soft Check) failed records: {df_DQ_SoftCheck_failed.count()}')
        df_DQ_SoftCheck_failed_final = df_DQ_SoftCheck_failed.withColumn('dq_flag', lit('S'))

        df_DQ_failed_final = df_DQ_HardCheck_failed_final.union(df_DQ_SoftCheck_failed_final)
        # creating temp view for the staging error table
        df_DQ_failed_final.createTempView("pnt_erngs_error_temp")
        logger.info("'pnt_erngs_error_temp' is created")

        # Create empty dataframe to be used for inserting to prcs_ctrl_log table
        audit_df_schema = StructType(
            [StructField("sub_area", StringType(), True), StructField("prcs_nm", StringType(), True),
             StructField("feed_nm", StringType(), True),
             StructField("file_pth", StringType(), True), StructField("feed_typ", StringType(), True),
             StructField("tot_cnt", IntegerType(), True),
             StructField("src_sucss_cnt", IntegerType(), True), StructField("src_fail_cnt", IntegerType(), True),
             StructField("src_sts", StringType(), True),
             StructField("create_by", StringType(), True)])
        audit_df = spark.createDataFrame(sc.emptyRDD(), audit_df_schema)
        audit_record = []

        # we get the 'source_file_count' from the column that we appended while parsing the file initially
        file_count_sql = spark.sql(
            """ select *, SUBSTRING_INDEX(filePath,'/',-1) as fileName from 
            (select distinct filePath, source_file_count as s3_file_record_count from pnt_erngs_temp) """)
        # file_count_sql.show(5, False)

        # Extract each row from the dataframe. Will loop through each filename to load the data
        s3_file_list = \
            [{'filePath': x['filePath'], 'fileName': x['fileName'], 's3_file_record_count': x['s3_file_record_count']}
             for x in file_count_sql.rdd.collect()
             if x['s3_file_record_count'] is not None if re.search('[a-zA-Z]', x['s3_file_record_count']) is None]
        # above if condition is to safeguard against data errors in 'src_file_count' column and allows only int values
        logger.info(f"s3_file_list is: {s3_file_list}")

        for row in s3_file_list:
            s3_file_record_count = row["s3_file_record_count"]
            fileName = row["fileName"]
            filePath = row["filePath"]

            logger.info('Mapping Field Names with Redshift Column')
            utc_now = timestamp_now()["utc_now"]
            est_now = timestamp_now()["est_now"]
            common_sql = \
                f""" SELECT cast(pe.trans_id as bigint), pe.memb_num as mbr_nbr, pe.earn_type as earn_typ, 
                     cast(pe.post_dt as date), pe.earn_descr as earn_dscr, cast(pe.points as bigint) mbr_pnts,
                     cast(pe.miles as bigint) as mbr_miles, pe.earn_pref_partner as earn_pref_prtnr,
                     pe.earn_pref_id, pe.earn_pref_fname as earn_pref_frst_nm,
                     pe.earn_pref_lname as earn_pref_lst_nm, pe.data_src_id, pe.credit_debit_ind,
                     pe.partner_code as prtnr_cd, pe.partner_name as prtnr_nm, pe.res_fname as 
                     res_frst_nm, pe.res_lname as res_lst_nm, cast(pe.awd_num as bigint) awrd_nbr,
                     cast(pe.occ_rate as decimal(20, 5)) occ_rt, cast(pe.loyalty_adr as decimal(20, 5)) 
                     lylty_adr, cast(pe.reimburse_amt as decimal(20, 5)) rmbrsmnt_amt, 
                     pe.stay_qual_hash_key, pe.lylty_evnt_key, pe.conf_num, pe.fol_num as fol_nbr, cast(pe.fol_amt_usd as 
                     decimal(20, 5)) fol_amt_usd, cast(pe.fol_wotx_amt_usd as decimal(20, 5)) fol_wotx_amt_usd, 
                     pe.q_dq_code as q_dq_cd, pe.srp_rate_code as srp_rt_cd, cast(pe.room_rev_usd as decimal(20, 5)) 
                     rm_rev_usd, cast(pe.base_chrg_amt_usd as decimal(20, 5)) base_chrg_amt_usd, 
                     cast(pe.q_dq_strt_dt as date) q_dq_strt_dt, cast(pe.q_dq_end_dt as date) q_dq_end_dt,
                     cast(pe.num_rooms as bigint) num_rms, cast(pe.numberofnights as bigint) no_of_nghts,
                     pe.bookingchannel as bkng_chnl, pe.bookingcode as bkng_cd, pe.forced_qualified as 
                     frcd_qual_flg, pe.ui_flag as ui_flg, pe.site_id, pe.site_reg as site_rgn_cd, 
                     pe.site_country as site_cntry_cd, pe.site_state as site_state_cd, pe.brand_id as brnd_id, 
                     pe.affiliation_code as affltn_cd, pe.lcl_crncy_cd, cast(pe.exch_rt as decimal(20, 5)) exch_rt,
                     cast(pe.parent_id as bigint) prnt_id, pe.promo_code as promo_cd, cast(pe.promo_registered_date 
                     as date) promo_reg_dt, pe.adjust_code as adjst_cd,
                     coalesce(to_timestamp(pe.ICF_sent_ts,'dd-MMMM-yy HH.mm.ss'),
                     to_timestamp(pe.ICF_sent_ts,'dd-MMMM-yy')) as icf_sent_ts, SUBSTRING_INDEX(pe.filePath, '/',-1) 
                     as src_file_nm, 'Glue' as create_by, cast('{est_now}' as timestamp) as create_ts 
                     """
            ################ Dataload to Redshift stg table ########################
            # sql for loading file data into staging table
            stg_sql = f""" {common_sql} FROM pnt_erngs_temp pe 
                         where SUBSTRING_INDEX(filePath,'/',-1)  = '{fileName}' """
            stg = spark.sql(stg_sql)
            stg.limit(1).show()
            stg_df = DynamicFrame.fromDF(stg, glueContext, "stg_df")

            stg_table_map = ResolveChoice.apply(
                frame=stg_df,
                choice="make_cols",
                transformation_ctx="stg_table_map"
            )

            logger.info("Starting Data load to Staging table")
            redshift_load = glueContext.write_dynamic_frame.from_jdbc_conf(
                frame=stg_table_map,
                catalog_connection=redshiftconnection,
                connection_options={
                    "url": rs_url_db_dest,
                    "database": rsdb,
                    "user": rs_user_dest,
                    "password": rs_pwd_dest,
                    "dbtable": schema_name + '.' + stg_table,
                    "extracopyoptions": "MAXERROR 100000"},
                redshift_tmp_dir=f"s3://{blue_bucket}/ICF-Olson/earning/redshift/dataload/{job_name}/"
                                 f"{str(datetime.now()).replace(' ', '_')}/{fileName}/"
            )
            logger.info("Data Load Process for Point Earnings to redshift complete!")
            # loading the prcs_cntrl_log table and stg_glue_error tables (if any errors)
            audit_load(audit_record, audit_df_schema, s3_file_record_count, fileName, filePath)

            ################ Dataload to Redshift stg error table ########################
            # sql for loading file data into staging error table
            stg_err_sql = f""" {common_sql}, pe.dq_flag FROM pnt_erngs_error_temp pe
                                 where SUBSTRING_INDEX(filePath,'/',-1)  = '{fileName}' """
            stg_err = spark.sql(stg_err_sql)
            stg_err.limit(1).show()
            stg_err_df = DynamicFrame.fromDF(stg_err, glueContext, "stg_err_df")

            stg_err_table_map = ResolveChoice.apply(
                frame=stg_err_df,
                choice="make_cols",
                transformation_ctx="stg_table_map"
            )

            logger.info("Starting Data load to Staging Error table")
            redshift_err_load = glueContext.write_dynamic_frame.from_jdbc_conf(
                frame=stg_err_table_map,
                catalog_connection=redshiftconnection,
                connection_options={
                    "url": rs_url_db_dest,
                    "database": rsdb,
                    "user": rs_user_dest,
                    "password": rs_pwd_dest,
                    "dbtable": schema_name + '.' + stg_err_table,
                    "extracopyoptions": "MAXERROR 100000"},
                redshift_tmp_dir=f"s3://{blue_bucket}/ICF-Olson/earning/redshift/errorload/{job_name}/"
                                 f"{str(datetime.now()).replace(' ', '_')}/{fileName}/"
            )
            logger.info("Data Load Process for Point Earnings to redshift Error Table complete!")

    except Exception as e:
        logger.error(f"*********** [ERROR] Error while loading to Redshift Staging table, failed with : {str(e)} ***********")
        sub = f"LR Point Earnings Glue Job '{job_name}' failed"
        msg = f"Error while loading to Staging table for the job '{job_name}', failed with error: {str(e)}"
        notifymsg(sub, msg)
        # loading the prcs_cntrl_log table if any process failure happens
        audit_load(audit_record, audit_df_schema, s3_file_record_count, fileName, filePath)
        raise SystemExit(e)

logger.info(" ************** End of Load process for Loyalty Point Earnings Staging Table *********************** ")
job.commit()
logger.info("JOB COMPLETE!!")