import sys
from datetime import datetime
from datetime import timedelta
import pytz
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.dynamicframe import DynamicFrame
from pyspark.sql import SQLContext
import boto3
import logging
from pyspark.sql.functions import  col, when, lit, input_file_name, substring_index
from pyspark.sql.types import TimestampType, StringType, IntegerType, DecimalType, DateType

################################### Setting up Spark environment and enabling Glue to interact with Spark Platform ##################################
sc=SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
sqlContext = SQLContext(sc)

################################### Enabling access to the arguments ##################################
job = Job(glueContext)
args = getResolvedOptions(sys.argv, ['JOB_NAME','data_bucket_name','raw_data_bucket_name','blue_bucket','error_bucket','SNS','rsdb','connection','tablename','schemaname','filePath','batchNum'])
job.init(args['JOB_NAME'], args)

################################### Setting up logger for event logging ##################################
logging.basicConfig()
logger = logging.getLogger()
logger.setLevel(logging.INFO)

################################### Assigning job arguments to variables  ##################################

rsdb = args['rsdb']
connection = args['connection']
data_bucket_name = args['data_bucket_name']
raw_data_bucket_name = args['raw_data_bucket_name']
blue_bucket = args['blue_bucket']
error_bucket = args['error_bucket']
job_name = args['JOB_NAME']
tablename = args['tablename']
schemaname = args['schemaname']
sns_notify = args['SNS']
filePath = args['filePath']
fileName = filePath.split('/')[-1]
btch_num = args['batchNum']

################################### Create low level reosurce service client for S3 ans SNS  ##################################

s3Client = boto3.client('s3',region_name='us-west-2')
s3resource = boto3.resource('s3',region_name='us-west-2')
glueClient = boto3.client('glue', region_name='us-west-2')


try:
    sns_client = boto3.client('sns',region_name = 'us-west-2')
    logger.info("Enabled SNS Notification")
except Exception as e:
    logger.error(str(e))
    logger.info(" Unable to enable SNS, failed with error: {}".format(str(e)))
    logger.info("Continuing with load without SNS notification")
    
    
def notifymsg(sub, msg):
    sns_client.publish(TopicArn = sns_notify, Message = msg , Subject= sub) 
    logger.info("**************** [INFO] SNS Notification Sent: {} *************************".format(job_name))

################## Create Timestamp ############################

def create_timestamp_est():
    now = datetime.now()
    est = pytz.timezone('US/Eastern')
    now_est = now.astimezone(est).strftime('%Y-%m-%d %H:%M:%S.%f')
    return now_est


################################### Retriving connection information from Glue connections for DB2  ##################################
  
try:
   logger.info("Getting DB2 Connection Information")  
   connection_dest = glueContext.extract_jdbc_conf(connection)
   url_dest = connection_dest["url"]
   user_dest = connection_dest["user"]
   pwd_dest = connection_dest["password"]
   url_db_dest = url_dest+'/'+rsdb
   driver = "com.ibm.db2.jcc.DB2Driver"
except Exception as e:
   logger.error(e)
   msg = 'Unable to connect to DB2 while processing the glue job {0} , failed with error: {1}'.format(job_name,str(e))
   sub="ICF Incentive File Process Alert: Glue Job - {} failed".format(job_name)
   notifymsg(sub, msg)
   logger.info(" Exiting with error: {}".format(str(e)))
   exit(1)


############################## Reading the data from S3 #######################################

try:
    df = spark.read.load(filePath, format="csv", sep="|", header="true")
    df_count = df.count()
    logger.info('Success reading the data')
    df.printSchema()
        
except Exception as e:
    logger.error("*********** [ERROR] Creating the DataFrame:  {} **************".format(str(e)))
    f_msg="  Error while reading data from S3. Error Details: {} ".format(str(e))
    f_sub = "ICF Incentive File Process Alert: Glue Job - "+job_name+" failed" 
    notifymsg(f_sub, f_msg)
    exit(1)


#################################### Data Transformation #######################################
if df_count == 0:
    logger.error(" ************** [INFO] No Data to process for this run *********************** ".format(str(datetime.now())))
    f_msg="  No Data is available for this run for the job {0} ".format(job_name)
    f_sub = " No new Data available to process for ICF Incentive File Glue job "+job_name
    notifymsg(f_sub, f_msg)
else:
    
    try:
        ########### Extracting the Total Records Information from the file which is avaialble at the end of the file ###############
        RecordDf = df.where(df['Row Number'].contains('Total Records'))
        RecordsInfoCount = int([row[0] for row in RecordDf.select('Row Number').collect()][0].split(' ')[-1])
        logger.info('Total Records Information in the File: {}'.format(RecordsInfoCount))
        
        ############## Excluding the Total Records Information from the file ########################
        df1 = df.where(~df['Row Number'].contains('Total Records'))
        df1_count = df1.count()
        logger.info('Total number of records after excluding the information: {}'.format(df1_count))
        
        ###################### Adding extra columns to DF ##############################
        now_est = create_timestamp_est()
        
        df2 = df1.withColumn('INSERT_TS', lit(now_est).cast(TimestampType())).withColumn('INSERT_BY', lit('Glue').cast(StringType())).withColumn('LST_UPDT_TS', lit(now_est).cast(TimestampType())).withColumn('LST_UPDT_BY', lit('Glue').cast(StringType())).withColumn('BATCH_NUM', lit(btch_num).cast(StringType())).withColumn('BATCH_STAT', lit('C').cast(StringType())).withColumn('FILE_NAME', lit(fileName).cast(StringType())).withColumn('TOT_FILE_REC_COUNT', lit(RecordsInfoCount).cast(IntegerType()))
        
        df_final = df2.select(col('Row Number').cast(IntegerType()).alias('REC_NUM'), col('Chain Code').cast(StringType()).alias('CHAIN_CODE'), 
                              col('Site Owner').cast(StringType()).alias('SITE_OWNR'), col('SiteID').cast(StringType()).alias('SITE_ID'),
                              col('Charge Date').cast(DateType()).alias('CHARGE_DT'), col('Charge Amount').cast(DecimalType(9,2)).alias('CHARGE_AMT'),
                              col('Currency code').cast(StringType()).alias('CURRENCY_CD'), col('CDCF').cast(StringType()).alias('CHG_DB_CR_FLAG'),
                              col('Number of Rooms').cast(IntegerType()).alias('NUM_OF_ROOMS'), col('Member Number').cast(StringType()).alias('MEMBER_NUM'),
                              col('Member First Name').cast(StringType()).alias('MBR_FRST_NM'), col('Member Last Name').cast(StringType()).alias('MBR_LST_NM'),
                              col('CAT Code').cast(StringType()).alias('CAT_CODE'), col('SRP').cast(StringType()).alias('SRP_RT_CD'), col('Folio Number').cast(StringType()).alias('FOLIO_ID'),
                              col('Folio Amount').cast(DecimalType(14,4)).alias('FOLIO_AMT'), col('Arrival Date').cast(DateType()).alias('ARVL_DT'),
                              col('Departure Date').cast(DateType()).alias('DEPTR_DT'), col('Number of Nights').cast(IntegerType()).alias('NUM_OF_NIGHTS'),
                              col('Confirmation Number').cast(StringType()).alias('CONF_NUM'), col('Creation Date').cast(DateType()).alias('ICF_CREATE_DT'),
                              col('Stay Post Date').cast(DateType()).alias('STAY_POST_DT'), col('CCR').cast(DecimalType(12,4)).alias('CURRENCY_RATE'),
                              col('INSERT_TS'), col('INSERT_BY'), col('LST_UPDT_TS'), col('LST_UPDT_BY'), col('BATCH_NUM'), col('BATCH_STAT'),
                              col('FILE_NAME'), col('TOT_FILE_REC_COUNT'))
        
        df_final.printSchema()
        df_final.show(10, False)
    except Exception as e:
        
        logger.error("*********** [ERROR] Creating the DataFrame:  {} **************".format(str(e)))
        f_msg="  Error while applying transformation to file {0}, failed with error: {1}  ".format(filePath,str(e))
        f_sub = "ICF Incentive File Process Alert: Glue Job - "+job_name+" failed" 
        notifymsg(f_sub, f_msg)
        exit(1)
        
    ################ Write data to DB2 table  ######################
    logger.info(" Starting Incentive Fee load Process to DB2 for file {}".format(filePath))

    try:

        df_final.write.format("jdbc").option("driver", driver).option("url", url_db_dest).option("dbtable", '{}.{}'.format(schemaname,tablename)).option("user", user_dest).option("password", pwd_dest).mode("append").save()
        logger.info("Incentive Fee {} load Process to DB2 Complete".format(filePath))

    except Exception as e:
        logger.error("*********** [ERROR] Inserting into DB2: {} **************".format(str(e)))
        f_msg="Error while writing Incentive Fee File - {} to DB2. Error Details: {}".format(filePath,str(e))
        f_sub = "ICF Incentive File Process Alert: Glue Job - "+job_name+" failed" 
        notifymsg(f_sub, f_msg)
        exit(1)

job.commit()
