import logging
import sys
import pytz
from datetime import datetime
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from pyspark.sql import SQLContext
from awsglue.dynamicframe import DynamicFrame
import boto3
from pyspark.sql.types import TimestampType, DoubleType, StructType, StructField, StringType, \
    IntegerType, LongType, FloatType, DecimalType, DateType
from pyspark.sql.functions import col, when, lit, input_file_name, substring, year, month, \
    concat, unix_timestamp, from_unixtime, length
from pyspark.sql import functions as f

sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
sqlContext = SQLContext(sc)

################################### Enabling access to the arguments ##################################
job = Job(glueContext)
args = getResolvedOptions(sys.argv, ['JOB_NAME', 'rsdb', 'SNS', 'env', 'redshift_dw_connection',
                                     'redshift_dwstg_connection', 'blue_bucket', 'src_schema', 'tgt_schema',
                                     'tgt_table', 'tgt_error_table', 'excluded_chain_cds', 'closure_rsn',
                                     'no_of_days_to_load', 'report_dt_plus_1day'])
job.init(args['JOB_NAME'], args)

################################### Setting up logger for event logging ##################################
logging.basicConfig()
logger = logging.getLogger()
logger.setLevel(logging.INFO)

################################### Assigning job arguments to variables  ##################################

rsdb = args['rsdb']
job_name = args['JOB_NAME']
SNSTopicArn = args['SNS']
env = args['env']
rs_dw_conn = args['redshift_dw_connection']
rs_dwstg_conn = args['redshift_dwstg_connection']
blue_bucket = args['blue_bucket']
dw_schema = args['src_schema']
dwstg_schema = args['tgt_schema']
trgt_table_name = args['tgt_table']
trgt_error_table_name = args['tgt_error_table']
excluded_chain_cds = args['excluded_chain_cds']  # ('HFS', 'TRP', 'ZMD', 'EMD', 'WVO', 'CET', 'KNI', 'KNH')
closure_rsn = args['closure_rsn']  # ('Seasonal Closing', 'Temporary Closing- COVID', 'Temporary Closing')
temp_directory = f"s3://{blue_bucket}/nightlyaccruals/tgt/dataload/temp/{job_name}/{str(datetime.now()).replace(' ', '_')}"
tmp_trgt_error_table_name = f"{trgt_error_table_name}_tmp"
# in case of job failures, consider below parameter to change (rule is: 90 days + how many days job didnot run/failed)
# currently we are providing 90 days only and u can change this value in glue job parameters
no_of_days_to_load = args['no_of_days_to_load']
# for report_dt_plus_1day param, by default 'sysdate' will be the value for ongoing/daily runs.
# But if you want to run for any specific report_dt for ex, '2023-05-01' then the input value should be '2023-05-02 11:00:00' (11 hr is given to account for UTC-ET time difference, it shouldnt be changed, only date is to be changed)
# i.e, run date is 2nd may and it will get 1st May data)
report_dt_plus_1day = args['report_dt_plus_1day']

# Create low level reosurce service client for S3 ans SNS

s3Client = boto3.client('s3', region_name='us-west-2')
s3resource = boto3.resource('s3', region_name='us-west-2')
glueClient = boto3.client('glue', region_name='us-west-2')
snsClient = boto3.client('sns', region_name='us-west-2')

job_title = " ".join(trgt_table_name.split("_")[:]).title()  # used to print it in logs but nothing else.


# Notification Function
def notifymsg(sub, msg):
    env_var = f"{env}: P3-High-PSS" if env.upper() == 'PROD' else env
    snsClient.publish(TopicArn=SNSTopicArn, Message=msg, Subject=env_var+": "+sub)
    logger.info("**************** [INFO] SNS Notification Sent *************************")


# Create Timestamp
def create_timestamp_est():
    utc_now = datetime.now()
    est = pytz.timezone('US/Eastern')
    est_now = utc_now.astimezone(est).strftime('%Y-%m-%d %H:%M:%S.%f')
    return est_now


############ Retrieving dw and dwstg connection details from Glue connections for Redshift  #############

logger.info(f"Getting Redshift Connection Information for '{rs_dw_conn}' and '{rs_dwstg_conn}'")
rs_conn_dest_dw = glueContext.extract_jdbc_conf(rs_dw_conn)  # returns rs details (id, pswd, url) in dict for dw
rs_conn_dest_dwstg = glueContext.extract_jdbc_conf(rs_dwstg_conn)  # returns rs details in dict for dwstg


def set_nullable_for_all_columns(df, nullable):
    new_schema = StructType([StructField(f.name, f.dataType, nullable, f.metadata)
                             for f in df.schema.fields])
    return new_schema


def read_rs_tables_to_df_using_sql(rs_conn_dest1: dict, sql: str, rs_conn_dest2: dict = None):
    # TODO: refactor this whole function
    try:
        if rs_conn_dest2 is not None:
            load_schema_df = spark.read.format("com.databricks.spark.redshift") \
                .option("url", rs_conn_dest1["url"] + '/' + rsdb +
                        '?user=' + rs_conn_dest1["user"] + '&password=' + rs_conn_dest1["password"]) \
                .option("url", rs_conn_dest2["url"] + '/' + rsdb +
                        '?user=' + rs_conn_dest2["user"] + '&password=' + rs_conn_dest2["password"]) \
                .option("query", sql) \
                .option("forward_spark_s3_credentials", "true") \
                .option("tempdir", temp_directory).load()

            load_df = spark.read.schema(set_nullable_for_all_columns(load_schema_df, True)). \
                format("com.databricks.spark.redshift") \
                .option("url", rs_conn_dest1["url"] + '/' + rsdb +
                        '?user=' + rs_conn_dest1["user"] + '&password=' + rs_conn_dest1["password"]) \
                .option("url", rs_conn_dest2["url"] + '/' + rsdb +
                        '?user=' + rs_conn_dest2["user"] + '&password=' + rs_conn_dest2["password"]) \
                .option("query", sql) \
                .option("forward_spark_s3_credentials", "true") \
                .option("tempdir", temp_directory + '/').load()

        else:
            load_schema_df = spark.read.format("com.databricks.spark.redshift") \
                .option("url", rs_conn_dest1["url"] + '/' + rsdb +
                        '?user=' + rs_conn_dest1["user"] + '&password=' + rs_conn_dest1["password"]) \
                .option("query", sql) \
                .option("forward_spark_s3_credentials", "true") \
                .option("tempdir", temp_directory).load()

            load_df = spark.read.schema(set_nullable_for_all_columns(load_schema_df, True)). \
                format("com.databricks.spark.redshift") \
                .option("url", rs_conn_dest1["url"] + '/' + rsdb +
                        '?user=' + rs_conn_dest1["user"] + '&password=' + rs_conn_dest1["password"]) \
                .option("query", sql) \
                .option("forward_spark_s3_credentials", "true") \
                .option("tempdir", temp_directory + '/').load()

    except Exception as e:
        msg = f"Priority: P3-High\nAssignment Team: PSS AWS\nImpacted System: NT- EBS\nAWS Component: {job_name}\n"\
        f"\nError Details: Unable to connect to Redshift/execute SQL while processing the glue job '{job_name}' , failed with error: {str(e)}"
        sub = f"Nightly Accrual Daily Glue job failed"
        notifymsg(sub, msg)
        logger.info(f" Exiting with error: {str(e)}")
        raise SystemExit(e)

    return load_df


def get_nt_rs_data_to_df():
    """
    this function is used to get the NT data(actuals/estimates) at that point of time and creates a temp df
    :return: spark dataframe
    """
    try:
        # running sql initially to get threshold values from rs src table
        # (because there is no join condition given for this table to include it in main sql)
        threshold_sql = f""" select low_threshold_adr, high_threshold_adr, 
                                low_threshold_occ, high_threshold_occ from dw.ref_accr_threshold
                                where actv_flg = 'A' and curr_rec_ind = 'Y' order by lst_updt_ts desc limit 1 """

        threshold_df = read_rs_tables_to_df_using_sql(rs_conn_dest_dw, threshold_sql)

        # putting all possible ways to safeguard errors
        if threshold_df.count() != 0:  # i.e, table is not empty
            lad = threshold_df.first()['low_threshold_adr'] if threshold_df.first()['low_threshold_adr'] is not None else 0
            had = threshold_df.first()['high_threshold_adr'] if threshold_df.first()['high_threshold_adr'] is not None else 999
            loc = threshold_df.first()['low_threshold_occ'] if threshold_df.first()['low_threshold_occ'] is not None else 0
            hoc = threshold_df.first()['high_threshold_occ'] if threshold_df.first()['high_threshold_occ'] is not None else 1.25
        else:
            lad = 0.01
            had = 999
            loc = 0
            hoc = 1.25
            msg = f"Priority: P3-High\nAssignment Team: PSS AWS\nImpacted System: NT- EBS\nAWS Component: {job_name}\n"\
                f"\nError Details: No Threshold Value present for NT stg process. 'dw.ref_accr_threshold' has no records"
            sub = f"Nightly Accrual Daily Glue job warning"
            notifymsg(sub, msg)

        est_while_writing_records_to_main = create_timestamp_est()

        # running full sql (temp left join with stg) to implement scd2
        full_nt_sql = \
            f""" select distinct temp.site_id 
	,case when stg.site_id is null then temp.brand_id  --for old entry take old brnd_id value, for new entry take value frm temp
		else stg.brnd_id end as brnd_id, temp.site_key
	,case when stg.site_id is null then temp.entity_id 
		else stg.entity_id end as entity_id
	,case when stg.site_id is null then temp.site_seq_number
		else stg.site_seq_num end as site_seq_num, temp.report_date as report_dt
	,md5(concat(temp.site_id, temp.report_date)) as site_reportdt_hash
    ,case when stg.site_id is null then temp.record_type_original
		else stg.rcrd_typ_orgnl end as rcrd_typ_orgnl, temp.record_type_original as rcrd_typ_ltst
	,case when stg.site_id is null then temp.account_number 
		else stg.acnt_num_ltst end as acnt_num_ltst
    ,case when stg.site_id is null then temp.rooms_rented_original
		else stg.rms_rntd_orgnl end as rms_rntd_orgnl, temp.rooms_rented_original as rms_rntd_ltst
    ,case when stg.site_id is null then temp.room_revenue_local_currency_original
		else stg.rm_rev_lcl_crncy_orgnl end as rm_rev_lcl_crncy_orgnl, temp.room_revenue_local_currency_original as rm_rev_lcl_crncy_ltst	
    ,case when stg.site_id is null then temp.room_revenue_billing_currency_original
		else stg.rm_rev_bil_crncy_orgnl end as rm_rev_bil_crncy_orgnl, temp.room_revenue_billing_currency_original as rm_rev_bil_crncy_ltst
	,case when temp.record_type_original in ('O78', 'IAC') then '1' else '0' end as calc_flg_ltst
	,case when stg.site_id is null then temp.insert_date
		else stg.insrt_dt end as insrt_dt  --run date(day on which first time record made entry into nt main table). It remains constant.
	,temp.update_date as updt_dt --day on which record makes entry into fact_sls_occp. Whenever reactualization/change happens, it keeps updating..
    ,case when temp.record_type_original in ('O78', 'IAC') then temp.insert_date end as actl_updt_dt  --run date(day on which actual/IAC record made entry into nt main table). Whenever reactualization/change happens, it keeps updating
    ,cast(temp.rooms_open as INTEGER) as rms_opn
	,temp.local_currency_code as lcl_crncy_cd, temp.billing_currency_code as bil_crncy_cd
	,temp.conversion_rate as cnvrsn_rt, 'Y' as cur_rec_ind, 'GLUE' as create_by
	,temp.thrshld_chk, temp.OCC, temp.ADR, temp.blm_lst_updt_ts
	,case when temp.record_type_original is null then 'MISS' else 'CALC' end as calc_mis
	,cur_calc_cnvrsn_rt as cur_cnvrsn_rt
    ,cast('{est_while_writing_records_to_main}' as timestamp) as src_create_ts
    ,cast('{est_while_writing_records_to_main}' as timestamp) as src_updt_ts
    from 
    (
	select distinct actl.site_id as site_id, actl.iac_site_id, actl.report_date, actl.account_number, actl.site_key, actl.insert_date, actl.update_date,
        case 
        	when actl.record_type_original = 'EST'
        		then coalesce(es1.record_type_original, ad1.record_type_original, df1.record_type_original, 
        		df2.record_type_original)
        	else actl.record_type_original end as record_type_original,
        case 
        	when actl.record_type_original = 'EST'
        		then coalesce(es1.rooms_rented_original, ad1.rooms_rented_original,
        		 (cast(df1.occup_qty/substring(last_day(actl.report_date),9,2) as INTEGER)),    --formula for DF1
        		 (cast((df2.occup_qty*actl.rooms_open) as INTEGER)))    --formula for DF2
        	when actl.record_type_original = 'IAC' then 0  --defaulting to 0 for IAC
        	else actl.rooms_rented_original end as rooms_rented_original,
		case 
        	when actl.record_type_original = 'EST'
        		then coalesce(es1.room_revenue_local_currency_original, ad1.room_revenue_local_currency_original,
        		cast((cast(df1.adr_nbr/substring(last_day(actl.report_date),9,2) as NUMERIC(22, 6)))*actl.lcl_crncy_cnvrsn_rt as NUMERIC(22, 6)),    --applying DF1 formula & cnverting into lcl rvnus
        		cast(cast((df2.adr_num*df2.occup_qty*actl.rooms_open) as NUMERIC(22, 6))*actl.lcl_crncy_cnvrsn_rt as NUMERIC(22, 6)))      --applying DF2 formula & cnverting into lcl rvnus
        	when actl.record_type_original = 'IAC' then 0
        	else actl.room_revenue_local_currency_original end as room_revenue_local_currency_original,
		case 
        	when actl.record_type_original = 'EST'
        		then coalesce(cast(es1.room_revenue_local_currency_original*actl.conversion_rate as NUMERIC(22, 6)),
				cast(ad1.room_revenue_local_currency_original*actl.conversion_rate as NUMERIC(22, 6)), 
				cast((cast(df1.adr_nbr/substring(last_day(actl.report_date),9,2) as NUMERIC(22, 6)))*actl.bil_crncy_cnvrsn_rt as NUMERIC(22, 6)), 	--applying DF1 formula & cnverting into bil rvnus
        		cast(((cast((df2.adr_num*df2.occup_qty*actl.rooms_open) as NUMERIC(22, 6))))*actl.bil_crncy_cnvrsn_rt as NUMERIC(22, 6)))	--applying DF2 formula & cnverting into bil rvnus
        	when actl.record_type_original = 'IAC' then 0
        	else cast(actl.room_revenue_local_currency_original*actl.conversion_rate as NUMERIC(22, 6)) end as room_revenue_billing_currency_original,
		actl.rooms_open, actl.local_currency_code, actl.billing_currency_code, actl.conversion_rate,
        actl.brand_id, actl.entity_id, actl.site_seq_number, 
        case when actl.record_type_original = 'IAC' then 'P' else actl.thrshld_chk end as thrshld_chk,
        case when actl.record_type_original = 'IAC' then 0 else actl.OCC end as OCC,
        case when actl.record_type_original = 'IAC' then 0 else actl.ADR end as ADR,
        actl.blm_lst_updt_ts, actl.cur_calc_cnvrsn_rt, actl.lcl_crncy_cnvrsn_rt, actl.bil_crncy_cnvrsn_rt
        from(
		select distinct orig_site_id as site_id, iac_site_id, reported_site_id, reported_site_sts, orig_site_sts,  
		orig_report_date as report_date, coalesce(reported_account_number, orig_account_number) account_number, cast(coalesce(reported_site_key, orig_site_key) as bigint) site_key, 
		coalesce(reported_brand_id, orig_brand_id) brand_id, coalesce(reported_entity_id, orig_entity_id) entity_id, coalesce(reported_site_seq_number, orig_site_seq_number) site_seq_number,
		cast(to_date(convert_timezone('America/New_York', sysdate), 'YYYY-MM-DD') as timestamp) as insert_date,  --run date (day on which record made entry into nt table)
		coalesce(update_date, to_date(convert_timezone('America/New_York', {report_dt_plus_1day}), 'YYYY-MM-DD')) as update_date, --defaulting to current date when thers in no entry into sls_occp to get lst_updt_ts value
        --below sequence is important and the order shouldnt be changed
		case
			when coalesce(reported_site_sts, orig_site_sts) ='ACTV' and iac_site_id is not null
        		and ((rooms_rented_original is not null and rooms_rented_original > 0) 
        		or (room_revenue_local_currency_original is not null and room_revenue_local_currency_original > 0)) 
				and (coalesce(OCC, 0) <= {hoc} and coalesce(ADR, 0) <= {had}) and cur_calc_cnvrsn_rt is not null then 'O78'
        	when coalesce(reported_site_sts, orig_site_sts) ='ACTV' and iac_site_id is not null
        		and ((coalesce(rooms_rented_original, 0) = 0 or rooms_rented_original < 0)
        		or (coalesce(room_revenue_local_currency_original, 0) = 0 or room_revenue_local_currency_original < 0))
				then 'IAC'
			when coalesce(reported_site_sts, orig_site_sts) ='ACTV' and iac_site_id is not null and (iac_site_id, orig_report_date) in
				(select site_id, report_dt from dw.nightly_accruals where
				DATEDIFF('day', to_date(report_dt,'YYYY-MM-DD'),  to_date(convert_timezone('America/New_York', {report_dt_plus_1day}), 'YYYY-MM-DD')) > 0 and
    			DATEDIFF('day', to_date(report_dt,'YYYY-MM-DD'),  to_date(convert_timezone('America/New_York', {report_dt_plus_1day}), 'YYYY-MM-DD')) <= {no_of_days_to_load}
				and cur_rec_ind = 'Y' and coalesce(rcrd_typ_ltst, 'NULL') in ('IAC','ES1','AD1','DF1','DF2','NULL'))
				then 'IAC' ---special case to cover estimation to IAC scenario and avoid IAC to IAC scenario
			when coalesce(reported_site_sts, orig_site_sts) ='ACTV' and cur_calc_cnvrsn_rt is null then 'EST'
			when coalesce(reported_site_sts, orig_site_sts) ='ACTV' and reported_site_id is null then 'EST'	
        	when coalesce(reported_site_sts, orig_site_sts) ='ACTV' and iac_site_id is null and (coalesce(OCC, 0) < {loc} or coalesce(OCC, 0) > {hoc} or coalesce(ADR, 0) < {lad} or coalesce(ADR, 0) > {had}) then 'EST'
        	when coalesce(reported_site_sts, orig_site_sts) ='ACTV' and iac_site_id is null and ((rooms_rented_original is not null and rooms_rented_original > 0) 
        		and (room_revenue_local_currency_original is not null and room_revenue_local_currency_original > 0)) 
				and (coalesce(OCC, 0) >= {loc} and coalesce(OCC, 0) <= {hoc} and coalesce(ADR, 0) >= {lad} and coalesce(ADR, 0) <= {had}) then 'O78'
			when reported_site_sts ='NON-ACTV' and cur_calc_cnvrsn_rt is not null then 'O78'
        	when reported_site_sts ='NON-ACTV' then 'NA'
			else 'EST' end as record_type_original,
        rooms_rented_original, room_revenue_local_currency_original,
    	case
			when iac_site_id is null and (coalesce(OCC, 0) < {loc} or coalesce(OCC, 0) > {hoc} or coalesce(ADR, 0) < {lad} or coalesce(ADR, 0) > {had}) then 'F'
			when iac_site_id is not null
        		and ((rooms_rented_original is not null and rooms_rented_original <> 0) 
        		or (room_revenue_local_currency_original is not null and room_revenue_local_currency_original<> 0))
				and (coalesce(OCC, 0) >= {hoc} or coalesce(ADR, 0) >= {had}) then 'F' 
				else 'P' end as thrshld_chk,
        coalesce(reported_rooms_open, orig_rooms_open) rooms_open,
		local_currency_code, billing_currency_code,
		cast(coalesce(cur_calc_cnvrsn_rt, ltst_calc_cnvrsn_rt) as NUMERIC(16, 6)) as conversion_rate, cur_calc_cnvrsn_rt,
		coalesce(lcl_crncy_cnvrsn_rt, ltst_lcl_crncy_cnvrsn_rt) as lcl_crncy_cnvrsn_rt,  --this needs to be multiplied with actl rvnu (if in USD) to get it in lcl_crncy rvnu value
		coalesce(bil_crncy_cnvrsn_rt, ltst_bil_crncy_cnvrsn_rt) as bil_crncy_cnvrsn_rt,	 --this needs to be multiplied with actl rvnu (if in USD) to get it in bil_crncy rvnu value
		coalesce(OCC, 0) as OCC, coalesce(ADR, 0) as ADR,
		coalesce(blm_lst_updt_ts, to_date(DATEADD('day', -1, convert_timezone('America/New_York', {report_dt_plus_1day})), 'YYYY-MM-DD')) as blm_lst_updt_ts
        from
		(select ste_dtl.*
		, lcl_blm.lst_updt_ts as blm_lst_updt_ts --, bil_blm.lst_updt_ts as bil_blm_lst_updt_ts
		, lcl_blm.crncy_conver_exst_rt as lcl_crncy_cnvrsn_rt, bil_blm.crncy_conver_exst_rt as bil_crncy_cnvrsn_rt
		, case when lcl_blm.crncy_conver_exst_rt is not null and bil_blm.crncy_conver_exst_rt is not null
		then cast((bil_blm.crncy_conver_exst_rt/lcl_blm.crncy_conver_exst_rt) as NUMERIC(16, 6)) end as cur_calc_cnvrsn_rt,
		--ltst_lcl_blm.lst_updt_ts as ltst_blm_lst_updt_ts, bil_blm.lst_updt_ts as bil_blm_lst_updt_ts
		ltst_lcl_blm.crncy_conver_exst_rt as ltst_lcl_crncy_cnvrsn_rt, ltst_bil_blm.crncy_conver_exst_rt as ltst_bil_crncy_cnvrsn_rt
		, case when ltst_lcl_blm.crncy_conver_exst_rt is not null and ltst_bil_blm.crncy_conver_exst_rt is not null 
		then cast((ltst_bil_blm.crncy_conver_exst_rt/ltst_lcl_blm.crncy_conver_exst_rt) as NUMERIC(16, 6)) end as ltst_calc_cnvrsn_rt,
		case 
        	when rooms_rented_original > 0 and room_revenue_local_currency_original > 0 then
        	coalesce(CAST(CAST(room_revenue_local_currency_original/coalesce(lcl_blm.crncy_conver_exst_rt, ltst_lcl_blm.crncy_conver_exst_rt) AS NUMERIC(22, 6))/CAST(rooms_rented_original AS NUMERIC(22, 6)) AS NUMERIC(22, 6)), 0)
        	else 0 end as ADR,  --this should be in USD. So, dividing by lcl_crncy_cd's conversion rate.
        case 
        	when coalesce(reported_rooms_open, 0) > 0 and rooms_rented_original > 0
        	then coalesce(CAST((CAST(rooms_rented_original AS NUMERIC(22, 6)))/CAST(coalesce(reported_rooms_open, 0) AS NUMERIC(22, 6)) AS NUMERIC(22, 6)), 0)
        	else 0 end as OCC
		from
        (select orig.*, reported.*, iac.*,
        case when coalesce(reported_local_currency_code, orig_local_currency_code) = 'VEF' then 'VES'
			else coalesce(reported_local_currency_code, orig_local_currency_code) end as local_currency_code, 
		case when coalesce(reported_billing_currency_code, orig_billing_currency_code) = 'VEF' then 'VES'
		else coalesce(reported_billing_currency_code, orig_billing_currency_code) end as billing_currency_code
        from
        (select lkpste.*, case when orig_site_sts_cd = '7' then 'ACTV' else 'NON-ACTV' end as orig_site_sts, cal.bus_dt as orig_report_date
		from
		(
		select distinct a.site_id as orig_site_id, a.site_sts_cd as orig_site_sts_cd, a.fran_agr_acct_num  as orig_account_number, a.site_key as orig_site_key,
		a.brand_id as orig_brand_id, a.acct_num as orig_entity_id, substring(a.fran_agr_acct_num, 13,2) as orig_site_seq_number, cast(a.rms_lic_num as bigint) as orig_rooms_open
		,a.commc_dt as orig_commc_dt, a.site_svc_term_dt as orig_site_svc_term_dt, a.lcl_crncy_cd as orig_local_currency_code, a.ldgr_crncy_cd as orig_billing_currency_code
		from dw.lkup_site a
		join dw.fact_sls_occp b
		on  a.site_id = b.site_id and a.site_key = b.site_key
		where a.cur_site_flg ='Y'   --this filter has to be present so as to get the latest record details (site_key, acntnum etc.,) from lkupsite for MISS records in sls_occp and do estimation
		and b.cur_rec_ind = 'Y' 
		and a.chain_cd not in {excluded_chain_cds}
		--and a.site_id = '00441'
		UNION 
		select distinct a.site_id as orig_site_id, a.site_sts_cd as orig_site_sts_cd, a.fran_agr_acct_num  as orig_account_number, a.site_key as orig_site_key,
		a.brand_id as orig_brand_id, a.acct_num as orig_entity_id, substring(a.fran_agr_acct_num, 13,2) as orig_site_seq_number, cast(a.rms_lic_num as bigint) as orig_rooms_open
		,a.commc_dt as orig_commc_dt, a.site_svc_term_dt as orig_site_svc_term_dt, a.lcl_crncy_cd as orig_local_currency_code, a.ldgr_crncy_cd as orig_billing_currency_code
		from (select * from dw.lkup_site a where a.site_key not in (select site_key from dw.fact_sls_occp where cur_rec_ind = 'Y')) a 
		join dw.fact_sls_occp b
		on  a.site_id = b.site_id  --site_key joiniing shouldnt be there here
		where a.cur_site_flg ='Y'   --this filter has to be present so as to get the latest record details (site_key, acntnum etc.,) from lkupsite for MISS records in sls_occp and do estimation
		and b.cur_rec_ind = 'Y' 
		and a.chain_cd not in {excluded_chain_cds}
		--and a.site_id = '00441'
		) lkpste,
		(
		select cal_dt as bus_dt from dw.lkup_calendar lc 
		where 
		DATEDIFF('day', to_date(cal_dt,'YYYY-MM-DD'),  to_date(convert_timezone('America/New_York', {report_dt_plus_1day}), 'YYYY-MM-DD')) > 0 and
		DATEDIFF('day', to_date(cal_dt,'YYYY-MM-DD'),  to_date(convert_timezone('America/New_York', {report_dt_plus_1day}), 'YYYY-MM-DD')) <= {no_of_days_to_load}
		) cal
		--and site_id = '00441' order by report_date desc
		)orig
        left join
		(select distinct b.site_id as reported_site_id, b.bus_dt as reported_report_date,
		a.commc_dt as reported_commc_dt, a.site_svc_term_dt as reported_site_svc_term_dt,
		case when a.site_sts_cd = '7' then 'ACTV' else 'NON-ACTV' end as reported_site_sts,
		a.site_sts_cd as reported_site_sts_cd, a.fran_agr_acct_num  as reported_account_number, a.site_key as reported_site_key,
		a.brand_id as reported_brand_id, a.acct_num as reported_entity_id, substring(a.fran_agr_acct_num, 13,2) as reported_site_seq_number,
        cast((coalesce(b.rm_sld_tot_cnt, 0) - coalesce(b.cmplmt_rm_sld_cnt, 0) - coalesce(b.crs_rsrv_no_show_cnt, 0) - coalesce(b.prop_rsrv_no_show_cnt, 0)) as INTEGER) as  
        rooms_rented_original,
        cast(coalesce(b.rm_rvnu_tot_amt, 0) - coalesce(abs(b.rm_rvnu_adj_amt), 0) AS NUMERIC(22, 6)) as room_revenue_local_currency_original,
        b.lst_updt_ts as update_date,
        coalesce(b.lic_rms_avail, cast(a.rms_lic_num as bigint)) as reported_rooms_open,  -- considering sls_occp for rms_open, if it is null we pull from lkp_site
        coalesce(b.der_lcl_crncy_cd, b.lcl_crncy_cd, a.lcl_crncy_cd) as reported_local_currency_code,  -- considering sls_occp for crncy_cd, if it is null we pull from lkp_site
        coalesce(b.bil_crncy_cd, a.ldgr_crncy_cd) as reported_billing_currency_code
        from dw.lkup_site a
        join dw.fact_sls_occp  b 
        on a.site_id = b.site_id and a.site_key = b.site_key  --for reported, we join on site_key and get the nt site current details
        where
        (DATEDIFF('day', to_date(b.bus_dt,'YYYY-MM-DD'),  to_date(convert_timezone('America/New_York', {report_dt_plus_1day}), 'YYYY-MM-DD')) > 0 and
        DATEDIFF('day', to_date(b.bus_dt,'YYYY-MM-DD'),  to_date(convert_timezone('America/New_York', {report_dt_plus_1day}), 'YYYY-MM-DD')) <= {no_of_days_to_load})
        and b.cur_rec_ind = 'Y'
        and a.chain_cd not in {excluded_chain_cds}
        --and b.site_id = '00001'
        ) reported
        on orig_report_date = reported_report_date and orig_site_id = reported_site_id
        left join
        (select distinct site_id as iac_site_id, fran_agr_acct_num as account_number, rstrct_strt_dt, rstrct_end_dt from dw.lkup_site_rstrct
        where rsn in {closure_rsn}
		and cur_rec_ind = 'Y' and del_ind ='N' 
        ) iac   --IAC logic  --we should join on account numbers but not siteid to check closure status of a site
        on coalesce(reported_account_number, orig_account_number) = iac.account_number and to_date(coalesce(reported_report_date, orig_report_date),'YYYY-MM-DD') >= to_date(iac.rstrct_strt_dt,'YYYY-MM-DD') and to_date(coalesce(reported_report_date, orig_report_date),'YYYY-MM-DD') <= to_date(coalesce(iac.rstrct_end_dt, '9999-12-31'),'YYYY-MM-DD')
		--where orig_site_id = '22974' and orig_report_date = '2023-04-23'
        )ste_dtl
        -- BLOOMBERG LKUPS
		left join
		(select to_date(cal_key, 'yyyyMMdd') cal_key, crncy_cd, crncy_conver_exst_rt, lst_updt_ts
		from dw.lkup_bloomberg_crncy
		where
		DATEDIFF('day', to_date(cal_key, 'yyyyMMdd'),  to_date(convert_timezone('America/New_York', {report_dt_plus_1day}), 'YYYY-MM-DD')) > 0 and
		DATEDIFF('day', to_date(cal_key, 'yyyyMMdd'),  to_date(convert_timezone('America/New_York', {report_dt_plus_1day}), 'YYYY-MM-DD')) <= {no_of_days_to_load}
		) lcl_blm
		on lcl_blm.cal_key = orig_report_date and lcl_blm.crncy_cd = local_currency_code
		left join
		(select to_date(cal_key, 'yyyyMMdd') cal_key, crncy_cd, crncy_conver_exst_rt, lst_updt_ts
		from dw.lkup_bloomberg_crncy
		where
		DATEDIFF('day', to_date(cal_key, 'yyyyMMdd'),  to_date(convert_timezone('America/New_York', {report_dt_plus_1day}), 'YYYY-MM-DD')) > 0 and
		DATEDIFF('day', to_date(cal_key, 'yyyyMMdd'),  to_date(convert_timezone('America/New_York', {report_dt_plus_1day}), 'YYYY-MM-DD')) <= {no_of_days_to_load}
		) bil_blm
		on bil_blm.cal_key = orig_report_date and bil_blm.crncy_cd = billing_currency_code
		left join
		(select * from (select to_date(cal_key, 'yyyyMMdd') cal_key, crncy_cd, crncy_conver_exst_rt, lst_updt_ts,
		row_number() over (partition by crncy_cd order by cal_key desc) rnum 
		from dw.lkup_bloomberg_crncy
		where
		DATEDIFF('day', to_date(cal_key, 'yyyyMMdd'),  to_date(convert_timezone('America/New_York', {report_dt_plus_1day}), 'YYYY-MM-DD')) > 0 and
		DATEDIFF('day', to_date(cal_key, 'yyyyMMdd'),  to_date(convert_timezone('America/New_York', {report_dt_plus_1day}), 'YYYY-MM-DD')) <= {no_of_days_to_load}
		)where rnum = 1
		) ltst_lcl_blm
		on  ltst_lcl_blm.crncy_cd = local_currency_code
		left join
		(select * from (select to_date(cal_key, 'yyyyMMdd') cal_key, crncy_cd, crncy_conver_exst_rt, lst_updt_ts,
		row_number() over (partition by crncy_cd order by cal_key desc) rnum 
		from dw.lkup_bloomberg_crncy
		where
		DATEDIFF('day', to_date(cal_key, 'yyyyMMdd'),  to_date(convert_timezone('America/New_York', {report_dt_plus_1day}), 'YYYY-MM-DD')) > 0 and
		DATEDIFF('day', to_date(cal_key, 'yyyyMMdd'),  to_date(convert_timezone('America/New_York', {report_dt_plus_1day}), 'YYYY-MM-DD')) <= {no_of_days_to_load}
		)where rnum = 1
		) ltst_bil_blm
		on ltst_bil_blm.crncy_cd = billing_currency_code
		--below where filter is crucial to decide whether a site has to flow or not
		where (((reported_site_sts ='ACTV' and (reported_report_date >= coalesce(reported_commc_dt, '0001-01-01') and reported_report_date <= coalesce(reported_site_svc_term_dt, '9999-12-31'))) or --if reported site is ACTIVE, check if it falls under reported cmncmnt_dt and reported term_dt range for actualization/reactualization/estimation/IAC
        ((coalesce(reported_site_sts, orig_site_sts) ='ACTV' and (orig_report_date >= coalesce(orig_commc_dt, '0001-01-01') and orig_report_date <= coalesce(orig_site_svc_term_dt, '9999-12-31'))))) --if a site is not reported, check if orig_site_sts is ACTIVE and it falls under orig cmncmnt_dt and orig term_dt range for estimation/IAC
        or
		(reported_site_sts ='NON-ACTV' and ((reported_site_id is not null and coalesce(room_revenue_local_currency_original,0) > 0 and coalesce(rooms_rented_original,0) > 0)))) --considering non-actv sites that send actuals only. Additionally closure sites are also excluded (latest requirement as per 04/17 release)
		--and orig_site_id = '22974' and orig_report_date = '2023-04-23'
		)
		--where orig_site_id = '22974' and orig_report_date = '2023-04-23'
        ) actl
        LEFT JOIN
        (
		select distinct site_id, report_dt, cast(avg(rms_rntd_ltst) as INTEGER) as rooms_rented_original, 
        cast(avg(rm_rev_lcl_crncy_ltst) as NUMERIC(22, 6)) as room_revenue_local_currency_original,
        'ES1' as record_type_original
        from (
        select * from (
        select *, row_number() over (partition by site_id, report_dt order by prev_report_dt desc) rnum
        from (
		select distinct na.lkup_site_id as site_id, 
		DATEDIFF('day', to_date(na1.lkup_report_dt,'YYYY-MM-DD'),  to_date(na.lkup_report_dt,'YYYY-MM-DD')),
		na.lkup_report_dt as report_dt, na1.lkup_report_dt as prev_report_dt,
		na1.rms_rntd_ltst, na1.rm_rev_lcl_crncy_ltst
        from (select distinct lc.report_date as lkup_report_dt, lc.site_id as lkup_site_id, na.* as cal_report_dt 
        from (select lkpste.*, cal.bus_dt as report_date
		from
		(
		select distinct a.site_id as site_id from dw.lkup_site a
		where a.cur_site_flg ='Y'  --having this filter just to restrict the lkupsite data
		and a.chain_cd not in {excluded_chain_cds}
		) lkpste,
		(select cal_dt as bus_dt from dw.lkup_calendar lc 
		where 
		DATEDIFF('day', to_date(cal_dt,'YYYY-MM-DD'),  to_date(convert_timezone('America/New_York', {report_dt_plus_1day}), 'YYYY-MM-DD')) > 0 and
		DATEDIFF('day', to_date(cal_dt,'YYYY-MM-DD'),  to_date(convert_timezone('America/New_York', {report_dt_plus_1day}), 'YYYY-MM-DD')) <= {no_of_days_to_load}
		) cal) lc  -- just we are trying to attach 90 previous report_dts to all sites as they may not be available already in nt main table for -1 bus_dt or any missing day 
		left join 
		(select * from dw.nightly_accruals where cur_rec_ind = 'Y' 
		and (DATEDIFF('day', to_date(report_dt,'YYYY-MM-DD'),  to_date(convert_timezone('America/New_York', {report_dt_plus_1day}), 'YYYY-MM-DD')) > 0 and
        DATEDIFF('day', to_date(report_dt,'YYYY-MM-DD'),  to_date(convert_timezone('America/New_York', {report_dt_plus_1day}), 'YYYY-MM-DD')) <= 500)  -- pulling just more than 1 year data only
        ) na
        on lc.report_date = na.report_dt and lc.site_id = na.site_id 
        --where lkup_site_id = '03343'
		) na 
        join 
        (select distinct lc.report_date as lkup_report_dt, lc.site_id as lkup_site_id, na.* as cal_report_dt 
        from (select lkpste.*, cal.bus_dt as report_date
		from
		(select distinct a.site_id as site_id from dw.lkup_site a
		where a.cur_site_flg ='Y'
		and a.chain_cd not in {excluded_chain_cds}
		) lkpste,
		(
		select cal_dt as bus_dt from dw.lkup_calendar lc 
		where 
		DATEDIFF('day', to_date(cal_dt,'YYYY-MM-DD'),  to_date(convert_timezone('America/New_York', {report_dt_plus_1day}), 'YYYY-MM-DD')) > 0 and
		DATEDIFF('day', to_date(cal_dt,'YYYY-MM-DD'),  to_date(convert_timezone('America/New_York', {report_dt_plus_1day}), 'YYYY-MM-DD')) <= {no_of_days_to_load}
		) cal) lc
		left join 
		(select * from dw.nightly_accruals where cur_rec_ind = 'Y' 
		and (DATEDIFF('day', to_date(report_dt,'YYYY-MM-DD'),  to_date(convert_timezone('America/New_York', {report_dt_plus_1day}), 'YYYY-MM-DD')) > 0 and
        DATEDIFF('day', to_date(report_dt,'YYYY-MM-DD'),  to_date(convert_timezone('America/New_York', {report_dt_plus_1day}), 'YYYY-MM-DD')) <= 500)  -- pulling just more than 1 year data only
        ) na
        on lc.report_date = na.report_dt and lc.site_id = na.site_id 
        --where lkup_site_id = '03343'
		) na1
        on na.lkup_site_id = na1.lkup_site_id --and na.report_dt = na1.report_dt 
        where
        (DATEDIFF('day', to_date(na1.lkup_report_dt,'YYYY-MM-DD'),  to_date(na.lkup_report_dt,'YYYY-MM-DD')) > 0 and
        DATEDIFF('day', to_date(na1.lkup_report_dt,'YYYY-MM-DD'),  to_date(na.lkup_report_dt,'YYYY-MM-DD')) <= 30)
        and na1.rcrd_typ_ltst = 'O78'
		and coalesce(na1.rms_rntd_ltst, 0) > 0
        and coalesce(na1.rm_rev_lcl_crncy_ltst, 0) > 1
        and na1.lkup_report_dt < na.lkup_report_dt
        --and na.lkup_site_id = '00359' and na.lkup_report_dt = '2023-02-08' 
    	)
        ) where rnum <= 7
        )
        --where site_id = '03343' and report_dt = '2023-01-14'
        group by site_id, report_dt
		having count(*) >= 7
		)es1   --ES1 logic
        on actl.site_id = es1.site_id and actl.report_date = es1.report_dt
        LEFT JOIN
        (
		select distinct site_id, substring(report_dt, 1, 7) report_dt,
        cast(avg(rms_rntd_ltst) as INTEGER) as rooms_rented_original,
        cast(avg(rm_rev_lcl_crncy_ltst) as NUMERIC(22, 6)) as room_revenue_local_currency_original,
		'AD1' as record_type_original
        from (
        select distinct na.site_id, na.report_dt, na.updt_dt, (na.rms_rntd_ltst*mm.mkt_multiplr_occ) as rms_rntd_ltst,
        (na.rm_rev_lcl_crncy_ltst*mm.mkt_multiplr_adr) as rm_rev_lcl_crncy_ltst, (na.rm_rev_bil_crncy_ltst*mm.mkt_multiplr_adr) as rm_rev_bil_crncy_ltst,
        mm.mkt_multiplr_occ ,mm.mkt_multiplr_adr  
        from dw.ref_accr_mkt_multplr mm 
        join dw.lkup_site s
        on  lower(s.tier_nm) = lower(mm.indstry_tier) and s.chain_cd = mm.chain_cd
        join 
		(select distinct na.site_id, na.report_dt, na.updt_dt, na.rms_rntd_ltst, na.rm_rev_lcl_crncy_ltst, na.rm_rev_bil_crncy_ltst
        from dw.nightly_accruals na
        where na.cur_rec_ind = 'Y'
        and (DATEDIFF('day', to_date(na.report_dt,'YYYY-MM-DD'),  to_date(convert_timezone('America/New_York', {report_dt_plus_1day}), 'YYYY-MM-DD')) > 0 and
        DATEDIFF('day', to_date(na.report_dt,'YYYY-MM-DD'),  to_date(convert_timezone('America/New_York', {report_dt_plus_1day}), 'YYYY-MM-DD')) <= 500)  -- pulling just more than 1 year data only
        and na.rcrd_typ_ltst = 'O78'
        and coalesce(na.rms_rntd_ltst, 0) > 0
        and coalesce(na.rm_rev_lcl_crncy_ltst, 0) > 1) na
        on s.site_id = na.site_id 
        join (select distinct ls.site_id, ls.chain_cd ,lfr.iso_cntry_cd , lfr.cntry_nm , lfr.cntry_sub_rgn_nm as st_prvnc_rgn_nm,ls.site_sts_cd  
		from dw.lkup_finc_rgn lfr
		join (select distinct site_id,chain_cd,iso_cntry_3_char_cd,site_sts_cd  from dw.lkup_site
		where cur_site_flg='Y' and iso_cntry_3_char_cd not in ('USA','CAN')) ls 
		on lfr.iso_cntry_thee_char_cd =ls.iso_cntry_3_char_cd 
		and lfr.iso_cntry_thee_char_cd not in ('USA','CAN')
		union
		select distinct ls.site_id,ls.chain_cd , lfr.iso_cntry_cd , lfr.cntry_nm ,lfr.st_prvnc_rgn_nm,ls.site_sts_cd
		from dw.lkup_finc_rgn lfr
		join dw.lkup_site ls 
		on ls.iso_cntry_3_char_cd =lfr.iso_cntry_thee_char_cd and ls.lgl_st_prvnc =lfr.st_prvnc_cd 
		where lfr.iso_cntry_thee_char_cd in ('USA','CAN')
		and ls.cur_site_flg ='Y'
		and ls.iso_cntry_3_char_cd in ('USA','CAN')) fr		--latest fix for 03/30 as discrepancy found in preview for st_prvnc_cd joining with lkupsite
        on lower(mm.rgn_nm) = lower(fr.st_prvnc_rgn_nm)
		and s.site_id = fr.site_id
        where
        mm.ACTV_FLG = 'A' and mm.curr_rec_ind = 'Y'
        --and s.cur_site_flg ='Y'
        --and s.site_sts_cd = '7'
        and to_date(na.report_dt,'YYYY-MM-DD') >= to_date(mm.start_dt,'YYYY-MM-DD') and to_date(na.report_dt,'YYYY-MM-DD') <= to_date(mm.end_dt,'YYYY-MM-DD')
        --and na.site_id = '08090'
        )
        group by site_id, substring(report_dt, 1, 7)
        having count(*) >= 7
        )ad1  --AD1 logic
        on actl.site_id = ad1.site_id
		and DATE_PART(month, DATEADD('year', -1, to_date(actl.report_date,'YYYY-MM-DD'))) = DATE_PART(month, to_date(ad1.report_dt,'YYYY-MM-DD'))
        and DATE_PART(year, DATEADD('year', -1, to_date(actl.report_date,'YYYY-MM-DD'))) = DATE_PART(year, to_date(ad1.report_dt,'YYYY-MM-DD'))
        LEFT JOIN
        (
        select distinct cast(sd.site_id as varchar) as site_id, sd.year, sd.month, sd.start_dt, sd.end_dt,
        cast(sd.occup_qty as numeric(22, 6)) occup_qty, cast(sd.adr_nbr as numeric(22, 6)) adr_nbr
        ,'DF1' as record_type_original
        from dw.ref_accr_site_dflt sd
        where sd.ACTV_FLG = 'A' and sd.curr_rec_ind = 'Y'
        --and site_id = '56235'
        --and DATE_PART(year, to_date('2023-04-18','YYYY-MM-DD')) = sd.year
        --and DATE_PART(month, to_date('2023-04-18','YYYY-MM-DD')) = sd.month
        ) df1  --DF1 logic
        on actl.site_id = df1.site_id
		and DATE_PART(year, to_date(actl.report_date,'YYYY-MM-DD')) = df1.year and DATE_PART(month, to_date(actl.report_date,'YYYY-MM-DD')) = df1.month
        and to_date(actl.report_date,'YYYY-MM-DD') >= to_date(df1.start_dt,'YYYY-MM-DD') and to_date(actl.report_date,'YYYY-MM-DD') <= to_date(df1.end_dt,'YYYY-MM-DD')
		LEFT JOIN
        (
        select distinct s.site_id, bd.year, bd.month, bd.strt_dt, bd.end_dt,
        cast(bd.dflt_occup_pct as numeric(22, 6)) occup_qty, cast(bd.dflt_adr as numeric(22, 6)) adr_num
        ,'DF2' as record_type_original
        from (select * from dw.lkup_site a where a.cur_site_flg ='Y'
		and a.chain_cd not in {excluded_chain_cds}) s --lkup_site is needed to get tier_nm and all
        join dw.ref_accr_brand_dflt bd
        on s.chain_cd = bd.chain_cd and lower(s.tier_nm) = lower(bd.indstry_tier)
        join (select distinct ls.site_id, ls.chain_cd ,lfr.iso_cntry_cd , lfr.cntry_nm , lfr.cntry_sub_rgn_nm as st_prvnc_rgn_nm,ls.site_sts_cd  
		from dw.lkup_finc_rgn lfr
		join (select *  from dw.lkup_site
		where cur_site_flg='Y' and iso_cntry_3_char_cd not in ('USA','CAN')
		and chain_cd not in {excluded_chain_cds}) ls 
		on lfr.iso_cntry_thee_char_cd =ls.iso_cntry_3_char_cd -- for NON usa, canadian sites we no need to join on st_prvnc_cd 
		and lfr.iso_cntry_thee_char_cd not in ('USA','CAN')
		union
		select distinct ls.site_id,ls.chain_cd , lfr.iso_cntry_cd , lfr.cntry_nm ,lfr.st_prvnc_rgn_nm,ls.site_sts_cd
		from dw.lkup_finc_rgn lfr
		join (select *  from dw.lkup_site
		where cur_site_flg='Y' and iso_cntry_3_char_cd in ('USA','CAN')
		and chain_cd not in {excluded_chain_cds}) ls 
		on ls.iso_cntry_3_char_cd =lfr.iso_cntry_thee_char_cd 
		and ls.lgl_st_prvnc =lfr.st_prvnc_cd   -- for usa, canadian sites we need to join on st_prvnc_cd 
		where lfr.iso_cntry_thee_char_cd in ('USA','CAN')) fr		--latest fix for 03/30 as discrepancy found in preview for st_prvnc_cd joining with lkupsite
        on lower(bd.rgn_nm) = lower(fr.st_prvnc_rgn_nm)
        and s.site_id = fr.site_id
        where
        bd.ACTV_FLG = 'A'
		and bd.curr_rec_ind = 'Y'
        --and s.site_id = '57865'
        --and DATE_PART(year, to_date('2023-04-14','YYYY-MM-DD')) = bd.year 
		--and DATE_PART(month, to_date('2023-04-14','YYYY-MM-DD')) = bd.month
        ) df2  --DF2 logic
        on actl.site_id = df2.site_id
        and DATE_PART(year, to_date(actl.report_date,'YYYY-MM-DD')) = df2.year 
		and DATE_PART(month, to_date(actl.report_date,'YYYY-MM-DD')) = df2.month
		and to_date(actl.report_date,'YYYY-MM-DD') >= to_date(df2.strt_dt,'YYYY-MM-DD') and to_date(actl.report_date,'YYYY-MM-DD') <= to_date(df2.end_dt,'YYYY-MM-DD')
        --where actl.site_id = '00001' and actl.report_date = '2023-04-18'
	) temp
    left join
    (select * from dw.nightly_accruals 
	where 
	DATEDIFF('day', to_date(report_dt,'YYYY-MM-DD'),  to_date(convert_timezone('America/New_York', {report_dt_plus_1day}), 'YYYY-MM-DD')) > 0 and
    DATEDIFF('day', to_date(report_dt,'YYYY-MM-DD'),  to_date(convert_timezone('America/New_York', {report_dt_plus_1day}), 'YYYY-MM-DD')) <= {no_of_days_to_load}
	and cur_rec_ind = 'Y'
    ) stg
    on temp.site_id = stg.site_id
    and temp.report_date = stg.report_dt
    where 
    ((stg.site_id is null)  -- first time entry records
	or  -- updated records with actuals or miss -> actual/estmn
	(stg.site_id is not null --and temp.insert_date >= coalesce(stg.updt_dt,'11-11-1111')
	and ((temp.record_type_original = 'O78') or (coalesce(stg.rcrd_typ_ltst, 'NULL') = 'NULL' and temp.record_type_original in ('O78','ES1','AD1','DF1','DF2')))
	and ((coalesce(temp.rooms_rented_original, 0) <> coalesce(stg.rms_rntd_ltst, 0) or (coalesce(temp.room_revenue_local_currency_original, 0) <> coalesce(stg.rm_rev_lcl_crncy_ltst, 0)) or
	(coalesce(temp.room_revenue_billing_currency_original, 0) <> coalesce(stg.rm_rev_bil_crncy_ltst, 0)) or (coalesce(temp.rooms_open, 0) <> coalesce(stg.rms_opn, 0))
	))) 
	or -- updated bloombrg records (currencies coming later) with actuals only
    (stg.site_id is not null and temp.blm_lst_updt_ts > coalesce(stg.blm_lst_updt_ts,'11-11-1111') and temp.blm_lst_updt_ts <> coalesce(stg.blm_lst_updt_ts,'11-11-1111')
	and temp.record_type_original = 'O78') 
	or --for closure sites
	(stg.site_id is not null and ((stg.rcrd_typ_ltst = 'IAC' and temp.record_type_original = 'O78') or
	(stg.rcrd_typ_ltst = 'IAC' and temp.record_type_original in ('ES1','AD1','DF1','DF2')) or --Doug's latest requirement (IAC -> estmn)
	(temp.iac_site_id is not null and stg.rcrd_typ_ltst in ('ES1','AD1','DF1','DF2') and temp.record_type_original = 'IAC' 
	and (temp.update_date > coalesce(stg.updt_dt,'11-11-1111') or temp.blm_lst_updt_ts > coalesce(stg.blm_lst_updt_ts,'11-11-1111'))) -- for closure sites, estmn (due to upper threshold failed) -> IAC, update when thers change in sls_occp. This is to avoid duplication of iac to estn and estn to iac.
	or (coalesce(stg.rcrd_typ_ltst, 'NULL') in ('ES1','AD1','DF1','DF2','NULL') and temp.record_type_original = 'IAC'))) --estn/miss (for non-iac sites) to IAC
	)
	--and temp.site_id in ('12158') and temp.report_date = '2023-02-26'
    """

        # logger.info("full_nt_sql: %s", full_nt_sql)
        nt_df_full = read_rs_tables_to_df_using_sql(rs_conn_dest_dw, full_nt_sql, rs_conn_dest_dwstg)
        # logger.info(f"No.of records on which DQ checks to be applied "
        #    f"(obtained from left joining RS src tables and main accrual table): {nt_df_full.count()}")

    except Exception as e:
        logger.error(f"Error while reading Redshift src tables, failed with : {str(e)}")
        msg = f"Priority: P3-High\nAssignment Team: PSS AWS\nImpacted System: NT- EBS\nAWS Component: {job_name}\n"\
                f"\nError Details:Error while reading Redshift src tables for the job '{job_name}', failed with error: {str(e)}"
        sub = f"Nightly Accrual Daily Glue job failed"
        notifymsg(sub, msg)
        raise SystemExit(e)

    return nt_df_full


logger.info("Running NT Sql..")
stg_nt_df = get_nt_rs_data_to_df()
stg_nt_df = stg_nt_df.cache()
# stg_nt_df.printSchema()
# stg_nt_df.filter(stg_nt_df.site_id.isin('00001') & stg_nt_df.report_dt.isin('2023-03-12')).show()
df_count = stg_nt_df.count()
logger.info(f"Total df count: {df_count}")
stg_nt_df.limit(1).show()
stg_nt_df.createOrReplaceTempView('stg_nt_df_temp')
# converting all columns to strings to simplify dq validations so that any rule can be applied easily
# for x in stg_nt_df.columns:
#     stg_nt_df_str = stg_nt_df.withColumn(x, when(col(x).cast(StringType()) != '', col(x)).otherwise(''))
# stg_nt_df_str.limit(1).show()
# stg_nt_df_str.printSchema()


if df_count != 0:
    #################### DQ Rules(Hard & Soft check validations)  ########################
    logger.info("Starting DQ validations on 'stg_nt_df'..")

    # hard checks
    df_siteid_H_failed = stg_nt_df. \
        withColumn('err_typ', when(stg_nt_df.site_id.isNull() | stg_nt_df.site_id.isin('0'), 'SITE_ID')). \
        withColumn('err_msg', when(stg_nt_df.site_id.isNull() | stg_nt_df.site_id.isin('0'), 'site_id not found')
                              .when(length(col('site_id')) > 5, 'site_id exceeds max length'))\
        .withColumn('dq_flg', lit('H')).withColumn('crctd_flg', lit('E'))
    df_brndid_H_failed = stg_nt_df. \
        withColumn('err_typ', when(stg_nt_df.brnd_id.isNull() | stg_nt_df.brnd_id.isin('0'), 'BRND_ID')). \
        withColumn('err_msg', when(stg_nt_df.brnd_id.isNull() | stg_nt_df.brnd_id.isin('0'), 'brand_id not found'))\
        .withColumn('dq_flg', lit('H')).withColumn('crctd_flg', lit('E'))
    df_rprtdt_H_failed = stg_nt_df. \
        withColumn('err_typ', when(stg_nt_df.report_dt.isNull() | ~stg_nt_df.report_dt.contains('-'), 'REPORT_DT'))\
        .withColumn('err_msg', when(stg_nt_df.report_dt.isNull(), 'report_date is null')
                               .when(~stg_nt_df.report_dt.contains('-'), 'report_date has invalid date format'))\
        .withColumn('dq_flg', lit('H')).withColumn('crctd_flg', lit('E'))
    df_rmsrntdltst_H_failed = stg_nt_df. \
        withColumn('err_typ', when((stg_nt_df.rms_rntd_ltst.isNull() | stg_nt_df.rms_rntd_ltst.isin('0', '', 'null')) | stg_nt_df.rms_rntd_ltst.contains('-'), 'RMS_RNTD_LTST')). \
        withColumn('err_msg', when((stg_nt_df.rms_rntd_ltst.isNull() | stg_nt_df.rms_rntd_ltst.isin('0', '', 'null')), 'rooms_rented_latest not found')
                   .when(stg_nt_df.rms_rntd_ltst.contains('-'), 'rooms_rented_latest has -ve value'))\
        .withColumn('dq_flg', lit('H')).withColumn('crctd_flg', lit('E'))
    df_rmrevlclltst_H_failed = stg_nt_df. \
        withColumn('err_typ', when((stg_nt_df.rm_rev_lcl_crncy_ltst.isNull() | stg_nt_df.rm_rev_lcl_crncy_ltst.isin('0', '', 'null') | stg_nt_df.rm_rev_lcl_crncy_ltst.contains('-')), 'RM_REV_LCL_CRNCY_LTST')). \
        withColumn('err_msg',
                   when((stg_nt_df.rm_rev_lcl_crncy_ltst.isNull() | stg_nt_df.rm_rev_lcl_crncy_ltst.isin('0', '', 'null')), 'room_revenue_local_currency_latest is null')
                   .when(stg_nt_df.rm_rev_lcl_crncy_ltst.contains('-'), 'room_revenue_local_currency_latest has -ve value'))\
        .withColumn('dq_flg', lit('H')).withColumn('crctd_flg', lit('E'))
    df_calcflgltst_H_failed = stg_nt_df. \
        withColumn('err_typ', when(stg_nt_df.calc_flg_ltst.isNull(), 'CALC_FLG_LTST')). \
        withColumn('err_msg', when(stg_nt_df.calc_flg_ltst.isNull(), 'calc_flg_ltst is null'))\
        .withColumn('dq_flg', lit('H')).withColumn('crctd_flg', lit('E'))
    df_rectypltst_H_failed = stg_nt_df. \
        withColumn('err_typ', when(stg_nt_df.rcrd_typ_ltst.isNull(), 'RCRD_TYP_LTST')). \
        withColumn('err_msg', when(stg_nt_df.rcrd_typ_ltst.isNull(), 'record_type_latest is null'))\
        .withColumn('dq_flg', lit('H')).withColumn('crctd_flg', lit('E'))
    df_cnvrsn_rt_H_failed = stg_nt_df. \
        withColumn('err_typ', when(stg_nt_df.cur_cnvrsn_rt.isNull() | stg_nt_df.cur_cnvrsn_rt.isin('0', '', 'null'), 'CNVRSN_RT')). \
        withColumn('err_msg', when(stg_nt_df.cur_cnvrsn_rt.isNull() | stg_nt_df.cur_cnvrsn_rt.isin('0', '', 'null'), 'conversion_rate is null'))\
        .withColumn('dq_flg', lit('H')).withColumn('crctd_flg', lit('E'))
    df_lcl_crncy_cd_H_failed = stg_nt_df. \
        withColumn('err_typ', when(stg_nt_df.lcl_crncy_cd.isNull(), 'LCL_CRNCY_CD')). \
        withColumn('err_msg', when(stg_nt_df.lcl_crncy_cd.isNull(), 'local_currency_code is null')) \
        .withColumn('dq_flg', lit('H')).withColumn('crctd_flg', lit('E'))
    df_bil_crncy_cd_H_failed = stg_nt_df. \
        withColumn('err_typ', when(stg_nt_df.bil_crncy_cd.isNull(), 'BIL_CRNCY_CD')). \
        withColumn('err_msg', when(stg_nt_df.bil_crncy_cd.isNull(), 'billing_currency_code is null')) \
        .withColumn('dq_flg', lit('H')).withColumn('crctd_flg', lit('E'))
    # soft checks
    df_actlupdtdt_S_failed = stg_nt_df. \
        withColumn('err_typ', when(stg_nt_df.actl_updt_dt.isNull() | stg_nt_df.actl_updt_dt.isin('', 'null'), 'ACTL_UPDT_DT')). \
        withColumn('err_msg', when(stg_nt_df.actl_updt_dt.isNull() | stg_nt_df.actl_updt_dt.isin('', 'null'), 'actl_updt_dt is not found'))\
        .withColumn('dq_flg', lit('S')).withColumn('crctd_flg', lit('E'))
    df_acntnumltst_S_failed = stg_nt_df. \
        withColumn('err_typ', when(stg_nt_df.acnt_num_ltst.isNull(), 'ACNT_NUM_LTST')). \
        withColumn('err_msg', when(stg_nt_df.acnt_num_ltst.isNull(), 'account_number_latest is null'))\
        .withColumn('dq_flg', lit('S')).withColumn('crctd_flg', lit('E'))
    df_thresholdcheck_S_failed = stg_nt_df. \
        withColumn('err_typ', when(stg_nt_df.thrshld_chk.isin('F'), 'THRSHLD_CHK')). \
        withColumn('err_msg', when(stg_nt_df.thrshld_chk.isin('F'), 'threshold_check failed'))\
        .withColumn('dq_flg', lit('S')).withColumn('crctd_flg', lit('E'))

    # now making union of all validations and pulling records only which have diff kind of error types
    df_DQ_H_failed_NOT_allowed_to_nt = df_siteid_H_failed.filter(df_siteid_H_failed.err_typ != '') \
        .union(df_brndid_H_failed.filter(df_brndid_H_failed.err_typ != '')) \
        .union(df_rprtdt_H_failed.filter(df_rprtdt_H_failed.err_typ != '')) \
        .union(df_calcflgltst_H_failed.filter(df_calcflgltst_H_failed.err_typ != ''))

    # IAC records are skipped off for rmsrntd and rvnus errors as they will be having 0s as defaults
    df_DQ_H_failed_allowed_to_nt = df_rectypltst_H_failed.filter(df_rectypltst_H_failed.err_typ != '')\
        .union(df_rmsrntdltst_H_failed.filter(df_rmsrntdltst_H_failed.err_typ != '').filter(df_rmsrntdltst_H_failed.rcrd_typ_ltst.isNull() | ~df_rmsrntdltst_H_failed.rcrd_typ_ltst.isin('IAC'))) \
        .union(df_rmrevlclltst_H_failed.filter(df_rmrevlclltst_H_failed.err_typ != '').filter(df_rmrevlclltst_H_failed.rcrd_typ_ltst.isNull() | ~df_rmrevlclltst_H_failed.rcrd_typ_ltst.isin('IAC'))) \
        .union(df_cnvrsn_rt_H_failed.filter(df_cnvrsn_rt_H_failed.err_typ != '')) \
        .union(df_lcl_crncy_cd_H_failed.filter(df_lcl_crncy_cd_H_failed.err_typ != '')) \
        .union(df_bil_crncy_cd_H_failed.filter(df_bil_crncy_cd_H_failed.err_typ != ''))

    # special case for non-actv sites (records with crncy as null are nt allowed to main but captured in err table)
    df_DQ_H_failed_NOT_allowed_to_nt_special = \
        df_DQ_H_failed_allowed_to_nt.filter(df_DQ_H_failed_allowed_to_nt.rcrd_typ_ltst.isin('NA'))

    df_DQ_S_failed_allowed_to_nt = df_acntnumltst_S_failed.filter(df_acntnumltst_S_failed.err_typ != '') \
        .union(df_thresholdcheck_S_failed.filter(df_thresholdcheck_S_failed.err_typ != '')) \
        .union(df_actlupdtdt_S_failed.filter(df_actlupdtdt_S_failed.err_typ != ''))

    logger.info("DQ validation on 'stg_nt_df' is completed")
    # Note: below data frames/dynamic frames  for main table and err table are to be built before merge query only.
    # Else they are returning 0 (Not sure why)
    ##### building schema and filtering good records (excluding hard check failed) to load into Main table

    df_NOT_allowed_to_nt = df_DQ_H_failed_NOT_allowed_to_nt.union(df_DQ_H_failed_NOT_allowed_to_nt_special)
    df_NOT_allowed_to_nt.createOrReplaceTempView('df_NOT_allowed_to_nt_temp')

    df_DQ_allowed_to_nt = spark.sql(f""" select * from stg_nt_df_temp where (site_id, report_dt) not in 
                        (select site_id, report_dt from df_NOT_allowed_to_nt_temp)
                        """)
    logger.info(f"No.of records to be loaded to NT main table: {df_DQ_allowed_to_nt.count()}")

    for x in df_DQ_allowed_to_nt.columns:
        # col(x).cast(StringType() is crucial below. Else all non-string cols will get converted to Null. by this,
        # we are casting all cols to strings to check for Non-null values.
        # if you skip to write this for loop, you will get 'NullPointerException' error
        df_DQ_allowed_to_nt = df_DQ_allowed_to_nt.withColumn(x, when(col(x).cast(StringType()) != '', col(x)).otherwise(None))
    # df_DQ_allowed_to_nt.limit(1).show()

    stg_nt_dynf_full = DynamicFrame.fromDF(df_DQ_allowed_to_nt, glueContext, "stg_nt_dynf_full")

    # ResolveChoice leaves the cols Null when other datatypes arrive than expected but creates 2 new cols in the result dataset
    stg_nt_main_table_map = \
        ResolveChoice.apply(
            frame=stg_nt_dynf_full,
            choice="make_cols",
            transformation_ctx="stg_nt_main_table_map"
        )

    ##### building schema and collecting bad records (hard+soft check failed) to load into Error table

    df_DQ_failed = df_DQ_H_failed_NOT_allowed_to_nt.union(df_DQ_H_failed_allowed_to_nt).union(df_DQ_S_failed_allowed_to_nt)
    df_DQ_failed.createOrReplaceTempView('df_DQ_failed_temp')
    logger.info("df_DQ_failed_temp created")

    est_while_writing_records_to_err = create_timestamp_est()
    df_DQ_err_tbl_df = spark.sql(f""" 
            SELECT site_id, site_key, entity_id, site_reportdt_hash, site_seq_num, report_dt, err_typ, err_msg,
            insrt_dt, updt_dt, dq_flg, rms_opn, crctd_flg, 'GLUE' create_by, cast('{est_while_writing_records_to_err}' as timestamp) src_create_ts, 
            cast('{est_while_writing_records_to_err}' as timestamp) src_updt_ts    
            FROM df_DQ_failed_temp """)

    logger.info(f"No.of records to be loaded to NT Err table: {df_DQ_err_tbl_df.count()}")

    err_nt_dynf_full = DynamicFrame.fromDF(df_DQ_err_tbl_df, glueContext, "err_nt_dynf_full")

    #################### Dataload to Redshift Main table ########################
    logger.info("Starting Data load to NT Main table..")

    # update query works only as below, I was not able to execute update query directly on db as ending up with errors.
    # so put update command in postquery as below and run it after loading your main table in write_dynamic_frame.
    # So no need of prequery or temp table here as SCD3 we are covering as part of full large query in first and
    # filtering the records (new/updated) there itself

    est_while_updating_Y_records = create_timestamp_est()
    post_query_main = f"""begin;
            -- to update when updt_dt got changed while blm_lst_updt_ts remain same (irrespective of src_create_ts)
            update dw.nightly_accruals
            set cur_rec_ind = 'N', src_updt_ts = '{est_while_updating_Y_records}'
            where (site_id, report_dt, updt_dt, blm_lst_updt_ts) in (
            select site_id, report_dt, updt_dt, blm_lst_updt_ts from (
            select site_id, report_dt, updt_dt, blm_lst_updt_ts, rank() over (partition by site_id, report_dt, blm_lst_updt_ts order by updt_dt desc) rnk
            from dw.nightly_accruals
            where DATEDIFF('day', to_date(report_dt,'YYYY-MM-DD'),  to_date(convert_timezone('America/New_York', {report_dt_plus_1day}), 'YYYY-MM-DD')) > 0 and
    		DATEDIFF('day', to_date(report_dt,'YYYY-MM-DD'),  to_date(convert_timezone('America/New_York', {report_dt_plus_1day}), 'YYYY-MM-DD')) <= {no_of_days_to_load}
            ) where rnk <> 1 );
            -- to update when blm_lst_updt_ts got changed while updt_dt remain same (irrespective of src_create_ts)
            update dw.nightly_accruals
            set cur_rec_ind = 'N', src_updt_ts = '{est_while_updating_Y_records}'
            where (site_id, report_dt, updt_dt, blm_lst_updt_ts) in (
            select site_id, report_dt, updt_dt, blm_lst_updt_ts from (
            select site_id, report_dt, updt_dt, blm_lst_updt_ts, rank() over (partition by site_id, report_dt, updt_dt order by blm_lst_updt_ts desc) rnk
            from dw.nightly_accruals
            where DATEDIFF('day', to_date(report_dt,'YYYY-MM-DD'),  to_date(convert_timezone('America/New_York', {report_dt_plus_1day}), 'YYYY-MM-DD')) > 0 and
    		DATEDIFF('day', to_date(report_dt,'YYYY-MM-DD'),  to_date(convert_timezone('America/New_York', {report_dt_plus_1day}), 'YYYY-MM-DD')) <= {no_of_days_to_load}
            ) where rnk <> 1 );
            --to update when updt_dt, blm_updt_ts, site_sts, src_create_ts all got changed 
            --if src_create_ts also remained same, row_num will protect us by assigning 'N' to random record (unexepected scenerio)
            update dw.nightly_accruals
            set cur_rec_ind = 'N', src_updt_ts = '{est_while_updating_Y_records}'
            where (site_id, report_dt, cur_rec_ind, src_create_ts) in (
            select site_id, report_dt, cur_rec_ind, src_create_ts from (
            select site_id, report_dt, cur_rec_ind, src_create_ts, row_number() over (partition by site_id, report_dt, cur_rec_ind order by src_create_ts desc) rnum
            from dw.nightly_accruals
            where DATEDIFF('day', to_date(report_dt,'YYYY-MM-DD'),  to_date(convert_timezone('America/New_York', {report_dt_plus_1day}), 'YYYY-MM-DD')) > 0 and
    		DATEDIFF('day', to_date(report_dt,'YYYY-MM-DD'),  to_date(convert_timezone('America/New_York', {report_dt_plus_1day}), 'YYYY-MM-DD')) <= {no_of_days_to_load}
            ) where rnum <> 1 );
            end;"""

    try:
        redshift_load = glueContext.write_dynamic_frame.from_jdbc_conf(
            frame=stg_nt_main_table_map,
            catalog_connection=rs_dw_conn,
            connection_options={
                "url": rs_conn_dest_dw["url"] + '/' + rsdb,
                "database": rsdb,
                "user": rs_conn_dest_dw["user"],
                "password": rs_conn_dest_dw["password"],
                "dbtable": f"{dw_schema}.{trgt_table_name}",
                "extracopyoptions": "MAXERROR 100000",
                "postactions": post_query_main},
            redshift_tmp_dir=
            f"""s3://{blue_bucket}/nightlyaccruals/tgt/dataload/stg/{job_name}/{str(datetime.now()).replace(" ", "_")}/"""
        )
        logger.info(f" Data Load Process for '{job_title} Main' to redshift Complete!")
    except Exception as e:
        logger.error(
            f"Error while loading to Redshift Staging table, failed with : {str(e)}")
        f_msg = f"Priority: P3-High\nAssignment Team: PSS AWS\nImpacted System: NT- EBS\nAWS Component: {job_name}\n"\
                f"\nError Details: Error while loading to Staging table for the job '{job_name}' failed with error: {str(e)}"
        f_sub = f"Nightly Accrual Daily Glue job failed"
        notifymsg(f_sub, f_msg)
        raise SystemExit(e)

    #################### Dataload to Redshift Error table ########################

    logger.info("Starting Data load to NT Err table..")
    # First as part of prequery step we are truncating the existing data from tmp table
    pre_query_err = f"""begin;
            delete from {dw_schema}.{tmp_trgt_error_table_name} where 1=1;
            end;"""
    # Next tmp table will be loaded with entire df result set using write_dynamic_frame as below
    # finally as part of postquery step, we are loading new errors came any from first select query by left joining
    # tmp err and err table. If not there, it leaves as is.
    # Next we left join err with main accrual table to check if the existing err record went into main table by
    # qualifying the DQ so that we can update the New corrected record with 'Y'
    # However err ecords coming from src will always carry N as indicator
    est_while_updating_records_to_N_when_E_comes = create_timestamp_est()
    est_while_updating_records_to_N_when_Y_comes = create_timestamp_est()
    post_query_err = f"""begin;
            -- STEP 1: for records that came dq failed as new entry or came again with new/same errors on diff src_create_ts
            insert into {dw_schema}.{trgt_error_table_name}
            select et.* from {dw_schema}.{tmp_trgt_error_table_name} et
            left join (select * from {dw_schema}.{trgt_error_table_name}  where
            DATEDIFF('day', to_date(report_dt,'YYYY-MM-DD'),  to_date(convert_timezone('America/New_York', {report_dt_plus_1day}), 
            'YYYY-MM-DD')) > 0 and
            DATEDIFF('day', to_date(report_dt,'YYYY-MM-DD'),  to_date(convert_timezone('America/New_York', {report_dt_plus_1day}), 
            'YYYY-MM-DD')) <= {no_of_days_to_load}
            and crctd_flg = 'E') e
            on  et.site_id = e.site_id and et.report_dt = e.report_dt and et.err_typ = e.err_typ
            where ((e.site_id is null) or (e.site_id is not null and et.src_create_ts <> e.src_create_ts));
            --STEP 2: update old records to N and let latest records be E status only
            update dw.nightly_accruals_error
            set crctd_flg = 'N' , src_updt_ts = '{est_while_updating_records_to_N_when_E_comes}' 
            where (site_id, report_dt, err_typ, src_create_ts) in (
            select site_id, report_dt, err_typ, src_create_ts from (
            select site_id, report_dt, err_typ, src_create_ts, rank() over (partition by site_id, report_dt order by src_create_ts desc) rnk
            from dw.nightly_accruals_error
            where DATEDIFF('day', to_date(report_dt,'YYYY-MM-DD'),  to_date(convert_timezone('America/New_York', {report_dt_plus_1day}), 'YYYY-MM-DD')) > 0 and
    		DATEDIFF('day', to_date(report_dt,'YYYY-MM-DD'),  to_date(convert_timezone('America/New_York', {report_dt_plus_1day}), 'YYYY-MM-DD')) <= {no_of_days_to_load}
            --and report_dt= '2023-01-31' and site_id ='15294'
            ) where rnk <> 1);
            -- STEP 3: for records that were error earlier but now got inserted to Nt main table due to all checks passed
            -- NOTE: the sequence of columns is imp below. it should match the structure of insertion table.
            insert into {dw_schema}.{trgt_error_table_name}
            select e.site_id, e.site_key, e.entity_id, e.site_reportdt_hash, e.site_seq_num, e.report_dt, 
            Null as err_typ, Null as err_msg, e.insrt_dt, m.updt_dt, Null as dq_flg, m.rms_opn, 'Y' as crctd_flg, 
            m.create_by, m.src_create_ts, m.src_updt_ts  from 
            (select distinct site_id, site_key, entity_id, site_reportdt_hash, site_seq_num, report_dt, insrt_dt, src_create_ts
            from (
            select * from dw.nightly_accruals_error where 
            crctd_flg = 'E'
            and
            (DATEDIFF('day', to_date(report_dt,'YYYY-MM-DD'),  to_date(convert_timezone('America/New_York', {report_dt_plus_1day}), 
            'YYYY-MM-DD')) > 0 and
            DATEDIFF('day', to_date(report_dt,'YYYY-MM-DD'),  to_date(convert_timezone('America/New_York', {report_dt_plus_1day}), 
            'YYYY-MM-DD')) <= {no_of_days_to_load})
            --and site_id  = '11213' and report_dt = '2023-01-27'
            )
            ) e
            left join 
            (select * from dw.nightly_accruals
            where cur_rec_ind = 'Y'
            and (DATEDIFF('day', to_date(report_dt,'YYYY-MM-DD'),  to_date(convert_timezone('America/New_York', {report_dt_plus_1day}), 
            'YYYY-MM-DD')) > 0 and
            DATEDIFF('day', to_date(report_dt,'YYYY-MM-DD'),  to_date(convert_timezone('America/New_York', {report_dt_plus_1day}), 
            'YYYY-MM-DD')) <= {no_of_days_to_load})
            and rcrd_typ_ltst in ('O78', 'IAC')  -- this tells you the record if its fully qualified passing main dq checks
            and site_id is not null and brnd_id is not null and report_dt is not null and calc_flg_ltst is not null and 
            cur_cnvrsn_rt is not null and lcl_crncy_cd is not null and bil_crncy_cd is not null and acnt_num_ltst is not null and thrshld_chk = 'P'
            --and site_id  = '11188' and report_dt = '2023-02-05'
            ) m
            on e.site_id = m.site_id and e.report_dt = m.report_dt 
            where m.site_id is not null and m.src_create_ts > e.src_create_ts;
            --STEP 4: updating all old records(which are in E status also) to 'N' as soon as records have turned to 'Y'
            update dw.nightly_accruals_error
            set crctd_flg = 'N' , src_updt_ts = '{est_while_updating_records_to_N_when_Y_comes}' 
            where (site_id, report_dt, err_typ, src_create_ts) in (
            select site_id, report_dt, err_typ, src_create_ts from (
            select site_id, report_dt, err_typ, src_create_ts, rank() over (partition by site_id, report_dt order by src_create_ts desc) rnk
            from dw.nightly_accruals_error
            where DATEDIFF('day', to_date(report_dt,'YYYY-MM-DD'),  to_date(convert_timezone('America/New_York', {report_dt_plus_1day}), 'YYYY-MM-DD')) > 0 and
    		DATEDIFF('day', to_date(report_dt,'YYYY-MM-DD'),  to_date(convert_timezone('America/New_York', {report_dt_plus_1day}), 'YYYY-MM-DD')) <= {no_of_days_to_load}
            --and report_dt= '2023-01-31' and site_id ='15294'
            ) where rnk <> 1);
            --STEP 5: cleanup the older error records with crctd_flg = 'N'
            delete from dw.nightly_accruals_error 
            where (site_id, report_dt, crctd_flg) in 
            (select site_id, report_dt, crctd_flg from dw.nightly_accruals_error  
            where crctd_flg = 'N'  
            and DATEDIFF('day', to_date(report_dt,'YYYY-MM-DD'),  to_date(convert_timezone('America/New_York', {report_dt_plus_1day}), 'YYYY-MM-DD')) > 90);
            end;
            --STEP 6: To deactivate threshold records errors for which fact table doesn't have data DIA-49664
            update dw.nightly_accruals_error
            set crctd_flg ='N', create_by = 'GLUE_THRSHLD_NOACTUL_UPD'
            from (select nae.site_key,nae.report_dt,nae.err_typ from
                dw.nightly_accruals_error nae ,
                dw.fact_sls_occp fso
            where
                nae.crctd_flg = 'E'	and nae.err_typ = 'THRSHLD_CHK'
                and fso.cur_rec_ind = 'Y' and nae.site_key = fso.site_key
                and nae.report_dt = fso.bus_dt	and fso.rm_sld_tot_cnt is null
                and fso.cmplmt_rm_sld_cnt is null and fso.crs_rsrv_no_show_cnt is null
                and fso.prop_rsrv_no_show_cnt is null and fso.rm_rvnu_tot_amt is null
                and fso.rm_rvnu_adj_amt is null
                and DATEDIFF('day', to_date(report_dt,'YYYY-MM-DD'),  to_date(convert_timezone('America/New_York', {report_dt_plus_1day}), 'YYYY-MM-DD')) > 0 and
                DATEDIFF('day', to_date(report_dt,'YYYY-MM-DD'),  to_date(convert_timezone('America/New_York', {report_dt_plus_1day}), 'YYYY-MM-DD')) <= {no_of_days_to_load}
            ) tmp
            where nightly_accruals_error.site_key = tmp.site_key and 
            nightly_accruals_error.report_dt = tmp.report_dt and 
            nightly_accruals_error.err_typ =tmp.err_typ;"""

    try:
        redshift_load = glueContext.write_dynamic_frame.from_jdbc_conf(
            frame=err_nt_dynf_full,
            catalog_connection=rs_dw_conn,
            connection_options={
                "url": rs_conn_dest_dw["url"] + '/' + rsdb,
                "database": rsdb,
                "user": rs_conn_dest_dw["user"],
                "password": rs_conn_dest_dw["password"],
                "dbtable": f"{dw_schema}.{tmp_trgt_error_table_name}",
                "extracopyoptions": "MAXERROR 100000",
                "preactions": pre_query_err,
                "postactions": post_query_err},
            redshift_tmp_dir=
            f"""s3://{blue_bucket}/nightlyaccruals/tgt/dataload/err/{job_name}/{str(datetime.now()).replace(" ", "_")}/"""
        )
        logger.info(f" Data Load Process for '{job_title} Err' to redshift Complete!")
    except Exception as e:
        logger.error(
            f"Error while loading to Redshift Staging Err table, failed with : {str(e)}")
        f_msg = f"Priority: P3-High\nAssignment Team: PSS AWS\nImpacted System: NT- EBS\nAWS Component: {job_name}\n"\
                f"\nError Details: Error while loading to Staging Error table for the job '{job_name}' failed with error: {str(e)}"
        f_sub = f"Nightly Accrual Daily Glue job failed"
        notifymsg(f_sub, f_msg)
        raise SystemExit(e)
else:
    logger.info("there is no updated data found for current run to run NT process!")

logger.info(
    f" *********** %s: End of Glue process for '{job_title}' *********** ", str(datetime.now()))
job.commit()
logger.info("JOB COMPLETE!!")
