import logging
import sys
import pytz
from datetime import datetime
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from pyspark.sql import SQLContext
from awsglue.dynamicframe import DynamicFrame
import boto3
from pyspark.sql.types import TimestampType, DoubleType, StructType, StructField, StringType, \
    IntegerType, LongType, FloatType, DecimalType, DateType
from pyspark.sql.functions import col, when, lit, input_file_name, substring, year, month, \
    concat, unix_timestamp, from_unixtime, length
from pyspark.sql import functions as f

sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
sqlContext = SQLContext(sc)

################################### Enabling access to the arguments ##################################
job = Job(glueContext)
args = getResolvedOptions(sys.argv, ['JOB_NAME', 'rsdb', 'SNS', 'env',
                                     'redshift_dw_dwstg_connection', 'blue_bucket', 'src_schema', 'tgt_schema',
                                     'tgt_table', 'tgt_cumltv_table', 'months_to_update'])
job.init(args['JOB_NAME'], args)

################################### Setting up logger for event logging ##################################
logging.basicConfig()
logger = logging.getLogger()
logger.setLevel(logging.INFO)

################################### Assigning job arguments to variables  ##################################

rsdb = args['rsdb']
job_name = args['JOB_NAME']
SNSTopicArn = args['SNS']
env = args['env']
rs_dw_dwstg_conn = args['redshift_dw_dwstg_connection']
# only 'Redshift_DWSTG_DW_QA' conn has access to ebs schema in QA/higher envs but in dev use same RedshiftCopy only which has access to ebs
blue_bucket = args['blue_bucket']
src_schema_name = args['src_schema']
dwstg_schema = args['tgt_schema']
trgt_table_name = args['tgt_table']
ebs_schema = 'dw_ebs'
trgt_ebs_cntrl_table = 'ebs_cntrl_tbl'
trgt_cumltv_table_name = args['tgt_cumltv_table']
temp_directory = f"s3://{blue_bucket}/nightlyaccruals/cumltv/dataload/temp/{job_name}/{str(datetime.now()).replace(' ', '_')}"
tmp_trgt_cumltv_table_name = f"{trgt_cumltv_table_name}_tmp"
dt_var = args['months_to_update']  # if previous month, give (1); if previous 2 months give (1,2)

# Create low level reosurce service client for S3 ans SNS

s3Client = boto3.client('s3', region_name='us-west-2')
s3resource = boto3.resource('s3', region_name='us-west-2')
glueClient = boto3.client('glue', region_name='us-west-2')
snsClient = boto3.client('sns', region_name='us-west-2')

job_title = " ".join(trgt_cumltv_table_name.split("_")[:]).title()  # used to print it in logs but nothing else.


# Notification Function
def notifymsg(sub, msg):
    env_var = f"{env}: P3-High-PSS" if env.upper() == 'PROD' else env
    snsClient.publish(TopicArn=SNSTopicArn, Message=msg, Subject=env_var + ": " + sub)
    logger.info("**************** [INFO] SNS Notification Sent *************************")


# Create Timestamp
def create_timestamp_est():
    utc_now = datetime.now()
    est = pytz.timezone('US/Eastern')
    est_now = utc_now.astimezone(est).strftime('%Y-%m-%d %H:%M:%S.%f')
    return est_now


############ Retrieving dw and dwstg connection details from Glue connections for Redshift  #############

logger.info(f"Getting Redshift Connection Information for '{rs_dw_dwstg_conn}'")
# rs_conn_dest_dw = glueContext.extract_jdbc_conf(rs_dw_conn)  # returns rs details (id, pswd, url) in dict for dw
rs_conn_dest_dwstg = glueContext.extract_jdbc_conf(rs_dw_dwstg_conn)  # returns rs details in dict for dwstg


def set_nullable_for_all_columns(df, nullable):
    new_schema = StructType([StructField(f.name, f.dataType, nullable, f.metadata)
                             for f in df.schema.fields])
    return new_schema


def read_rs_tables_to_df_using_sql(rs_conn_dest1: dict, sql: str, rs_conn_dest2: dict = None):
    # TODO: refactor this whole function
    try:
        if rs_conn_dest2 is not None:
            load_schema_df = spark.read.format("com.databricks.spark.redshift") \
                .option("url", rs_conn_dest1["url"] + '/' + rsdb +
                        '?user=' + rs_conn_dest1["user"] + '&password=' + rs_conn_dest1["password"]) \
                .option("url", rs_conn_dest2["url"] + '/' + rsdb +
                        '?user=' + rs_conn_dest2["user"] + '&password=' + rs_conn_dest2["password"]) \
                .option("query", sql) \
                .option("forward_spark_s3_credentials", "true") \
                .option("tempdir", temp_directory).load()

            load_df = spark.read.schema(set_nullable_for_all_columns(load_schema_df, True)). \
                format("com.databricks.spark.redshift") \
                .option("url", rs_conn_dest1["url"] + '/' + rsdb +
                        '?user=' + rs_conn_dest1["user"] + '&password=' + rs_conn_dest1["password"]) \
                .option("url", rs_conn_dest2["url"] + '/' + rsdb +
                        '?user=' + rs_conn_dest2["user"] + '&password=' + rs_conn_dest2["password"]) \
                .option("query", sql) \
                .option("forward_spark_s3_credentials", "true") \
                .option("tempdir", temp_directory + '/').load()

        else:
            load_schema_df = spark.read.format("com.databricks.spark.redshift") \
                .option("url", rs_conn_dest1["url"] + '/' + rsdb +
                        '?user=' + rs_conn_dest1["user"] + '&password=' + rs_conn_dest1["password"]) \
                .option("query", sql) \
                .option("forward_spark_s3_credentials", "true") \
                .option("tempdir", temp_directory).load()

            load_df = spark.read.schema(set_nullable_for_all_columns(load_schema_df, True)). \
                format("com.databricks.spark.redshift") \
                .option("url", rs_conn_dest1["url"] + '/' + rsdb +
                        '?user=' + rs_conn_dest1["user"] + '&password=' + rs_conn_dest1["password"]) \
                .option("query", sql) \
                .option("forward_spark_s3_credentials", "true") \
                .option("tempdir", temp_directory + '/').load()

    except Exception as e:
        msg = f"Priority: P3-High\nAssignment Team: PSS AWS\nImpacted System: NT- EBS\nAWS Component: {job_name}\n"\
            f"\nError Details: Unable to connect to Redshift/execute SQL while processing the glue job {job_name} , failed with error: {str(e)}  "
        sub = f"Nightly Accrual Mnthly Updt Cumulative Glue job failed"
        notifymsg(sub, msg)
        logger.info(f" Exiting with error: {str(e)}")
        raise SystemExit(e)

    return load_df


try:
    # this will tell you which previous 3 months records are to be updated for _mnthnd cols
    # but basically we are dumping all data as new instead of just updating those cols
    report_dts_to_updt_sql = \
        f""" select distinct report_dt, DATEDIFF('month', report_dt,  to_date(convert_timezone('America/New_York', sysdate), 'YYYY-MM-DD')) mnth_diff  --, src_create_ts, src_updt_ts, cum.report_dt 
             from
             (select distinct chg_date as report_dt--, status 
             from dw_ebs.ebs_cntrl_tbl ect 
             where prcs_nm = 'EBS_NT' and upper(status) not in ('READY', 'REPROCESS') --considering mnthd dates which are in PROCESSED/IN PROCESS state only
             and DATEDIFF('month', chg_date,  to_date(convert_timezone('America/New_York', sysdate), 'YYYY-MM-DD')) in (1,2,3)
             and chg_date = last_day(chg_date)  --picking up last date of that month only
             and chg_date not in 
             (select distinct report_dt --, create_by 
             from dw_ebs.nightly_accruals_cumulative ect 
             where DATEDIFF('month', report_dt,  to_date(convert_timezone('America/New_York', sysdate), 'YYYY-MM-DD')) in (1,2,3) --donot consider current month for updating _mnthnd cols
             and report_dt = last_day(report_dt)  --picking up last date of that month only
             and acnt_num_mnthnd is not null) 
             --just choosing acnt_num_mnthnd col as reference to know whether _mnthnd cols got already updated fr that mnth or not. 
             --if march month has all null acnt_mnthnd values, then that report_dt will not come out of this inner query. But the outer query which checks for mnthnd dates which are in PROCESSED state but not present in this inner query will be the o/p and that dates alone goes for update in next step.
             )
             """

    report_dts_to_updt_df = read_rs_tables_to_df_using_sql(rs_conn_dest_dwstg, report_dts_to_updt_sql)
    cnt = report_dts_to_updt_df.count()

    if dt_var == 'NA':  # no external variable input is provided. so trying to get 'dt_var' from above qry
        if cnt != 0:
            dt = [report_dts_to_updt_df.collect()[i][1] for i in range(cnt)]
            dt_var = str(tuple(dt)) if len(dt) > 1 else str(tuple(dt)).replace(",", "")  # o/p = (1, 2, 3)
        else:
            dt_var = None

    logger.info(f"dt_var= {dt_var}")
    if dt_var is not None:
        logger.info(f"updating the mnthnd cols in cumltv table for previous {dt_var} month(s)..")
        est_while_updating_mnthnd_cols = create_timestamp_est()
        logger.info(f"est_while_updating_mnthnd_cols: {est_while_updating_mnthnd_cols}")

        # dumping just _ltst into _mnthnd cols
        updt_mnthnd_cols_sql = f""" select 
            a.site_id, a.brnd_id, a.entity_id, a.site_key, a.site_reportdt_hash,
        	a.site_seq_num, a.report_dt, a.rcrd_typ_orgnl, a.rcrd_typ_ltst, 
        	coalesce(a.rcrd_typ_ltst, 'MIS') as rcrd_typ_mnthnd,  --new change on 02/15, if _ltst is null rcrd_typ_mnthnd val should be MIS 
        	a.acnt_num_ltst, a.acnt_num_ltst as acnt_num_mnthnd,
        	a.rms_rntd_orgnl, a.rms_rntd_ltst as rms_rntd_mnthnd,
        	a.rms_rntd_ltst, a.rm_rev_lcl_crncy_orgnl, a.rm_rev_lcl_crncy_ltst as rm_rev_lcl_crncy_mnthnd,
        	a.rm_rev_lcl_crncy_ltst, a.rm_rev_bil_crncy_orgnl, 
        	a.rm_rev_bil_crncy_ltst as rm_rev_bil_crncy_mnthnd,
        	a.rm_rev_bil_crncy_ltst, a.calc_flg_ltst, a.calc_flg_ltst as calc_flg_mnthnd,
        	a.insrt_dt, a.updt_dt, a.actl_updt_dt, a.rms_opn, a.bil_crncy_cd, a.lcl_crncy_cd, a.cnvrsn_rt, 
        	a.othr_rev_lcl_orgnl, a.othr_rev_lcl_mnthnd, a.othr_rev_lcl_ltst, a.othr_rev_bil_orgnl, a.othr_rev_bil_mnthnd, 
        	a.othr_rev_bil_ltst, a.mtng_rm_rev_lcl_orgnl, a.mtng_rm_rev_mnthnd, a.mtng_rm_rev_lcl_ltst,
        	a.mtng_rm_rev_bil_orgnl, a.mtng_rm_rev_bil_mnthnd, a.mtng_rm_rev_bil_ltst, a.tax_ltst, a.tax_orgnl, 
        	a.tax_mnthnd, a.tax_bil_ltst, a.tax_bil_orgnl, a.tax_bil_mnthnd,
        	a.fd_bvrg_rvnu_lcl_orgnl, a.fd_bvrg_rvnu_lcl_mnthnd, a.fd_bvrg_rvnu_lcl_ltst, a.fd_bvrg_rvnu_bill_orgnl, 
        	a.fd_bvrg_rvnu_bil_mnthnd, a.fd_bvrg_rvnu_bil_ltst,
        	a.rms_rntd_updtby_ebs, a.rms_opn_updtby_ebs, a.rm_rev_bil_crncy_updtby_ebs, a.mtng_rm_rev_bil_updtby_ebs, a.othr_rev_bil_updtby_ebs, 
	        a.calc_mis_updtby_ebs, a.fb_bil_updtby_ebs,
        	a.occ, a.adr, a.calc_mis, a.calc_flg_ltst_ebs, a.days_estm_cntr, a.calc_mis_ltst, 
        	a.cum_rm_rev_bil_crncy_ltst, a.cum_rms_rntd_ltst, a.cum_rms_opn, a.create_by,
        	a.src_create_ts
        	,cast('{est_while_updating_mnthnd_cols}' as timestamp) as src_updt_ts
            from
            dw_ebs.nightly_accruals_cumulative a
            where DATEDIFF('month', to_date(a.report_dt,'YYYY-MM-DD'),  to_date(convert_timezone('America/New_York', 
            sysdate), 'YYYY-MM-DD')) in {dt_var} -- updating values of previous 3 months from sysdate(if sysdate is feb, it picks nov,dec,jan months report_dts)
			--and a.site_id = '00001' 
            --order by report_dt desc 
            """
        updt_mnthnd_cols_df = read_rs_tables_to_df_using_sql(rs_conn_dest_dwstg, updt_mnthnd_cols_sql)
        updt_mnthnd_cols_df = updt_mnthnd_cols_df.cache()
        updt_mnthnd_cols_df.limit(1).show()

        for x in updt_mnthnd_cols_df.columns:
            updt_mnthnd_cols_df = updt_mnthnd_cols_df.withColumn(x, when(col(x).cast(StringType()) != '',
                                                                         col(x)).otherwise(None))
        # df_DQ_allowed_to_nt.limit(1).show()
        updt_mnthnd_cols_dynf = DynamicFrame.fromDF(updt_mnthnd_cols_df, glueContext, "updt_mnthnd_cols_dynf")

        pre_query = f"""begin;
                delete from {dwstg_schema}.{tmp_trgt_cumltv_table_name} where 1=1;
                end;"""

        post_query = f"""begin;
                delete from {ebs_schema}.{trgt_cumltv_table_name} using {dwstg_schema}.{tmp_trgt_cumltv_table_name} 
                where {dwstg_schema}.{tmp_trgt_cumltv_table_name}.site_id = {ebs_schema}.{trgt_cumltv_table_name}.site_id 
                and {dwstg_schema}.{tmp_trgt_cumltv_table_name}.report_dt = {ebs_schema}.{trgt_cumltv_table_name}.report_dt; 
                insert into {ebs_schema}.{trgt_cumltv_table_name} select * from {dwstg_schema}.{tmp_trgt_cumltv_table_name};
                end;"""


        redshift_load = glueContext.write_dynamic_frame.from_jdbc_conf(
            frame=updt_mnthnd_cols_dynf,
            catalog_connection=rs_dw_dwstg_conn,
            connection_options={
                "url": rs_conn_dest_dwstg["url"] + '/' + rsdb,
                "database": rsdb,
                "user": rs_conn_dest_dwstg["user"],
                "password": rs_conn_dest_dwstg["password"],
                "dbtable": f"{dwstg_schema}.{tmp_trgt_cumltv_table_name}",
                "extracopyoptions": "MAXERROR 100000",
                "preactions": pre_query,
                "postactions": post_query
            },
            redshift_tmp_dir=
            f"""s3://{blue_bucket}/nightlyaccruals/cumltv/dataload/cntrl/{job_name}/{str(datetime.now()).replace(" ", "_")}/"""
        )
        logger.info(f" Data Load Process for Nt cumulative table to redshift Complete!")

        # updt_mnthnd_cols_df.write \
        #     .format("com.databricks.spark.redshift") \
        #     .option("forward_spark_s3_credentials", "true")\
        #     .option("dbtable", f"{dwstg_schema}.{tmp_trgt_cumltv_table_name}") \
        #     .option("tempdir", f"""s3://{blue_bucket}/nightlyaccruals/cumltv/dataload/cntrl/{job_name}/{str(datetime.now()).replace(" ", "_")}/""") \
        #     .option("url", rs_conn_dest_dwstg["url"] + '/' + rsdb) \
        #     .option("user", rs_conn_dest_dwstg["user"]) \
        #     .option("password", rs_conn_dest_dwstg["password"]) \
        #     .option("preactions", pre_query) \
        #     .option("postactions", post_query) \
        #     .mode("append") \
        #     .save()
        # logger.info(f" Data Load Process for Nt cumulative table to redshift Complete!")

    else:
        logger.info(f" No report_dts found to take up mnthnd cols update activity!")

except Exception as e:
    logger.error(
        f"Error while loading to Redshift Cumulative table, failed with : {str(e)}")
    f_msg = f"Priority: P3-High\nAssignment Team: PSS AWS\nImpacted System: NT- EBS\nAWS Component: {job_name}\n"\
        f"\nError Details: Error while loading to Redshift Cumulative table for the job '{job_name}', failed with error: {str(e)}"
    f_sub = f"Nightly Accrual Mnthly Updt Cumulative Glue job failed"
    notifymsg(f_sub, f_msg)
    raise SystemExit(e)

logger.info(
    f" *********** %s: End of Glue process for '{job_title}' *********** ", str(datetime.now()))
job.commit()
logger.info("JOB COMPLETE!!")
