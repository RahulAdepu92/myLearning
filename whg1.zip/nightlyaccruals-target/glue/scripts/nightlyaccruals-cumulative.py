import logging
import sys
import pytz
from datetime import datetime
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from pyspark.sql import SQLContext
from awsglue.dynamicframe import DynamicFrame
import boto3
from pyspark.sql.types import TimestampType, DoubleType, StructType, StructField, StringType, \
    IntegerType, LongType, FloatType, DecimalType, DateType
from pyspark.sql.functions import col, when, lit, input_file_name, substring, year, month, \
    concat, unix_timestamp, from_unixtime, length
from pyspark.sql import functions as f

sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
sqlContext = SQLContext(sc)

################################### Enabling access to the arguments ##################################
job = Job(glueContext)
args = getResolvedOptions(sys.argv, ['JOB_NAME', 'rsdb', 'SNS', 'env',
                                     'redshift_dw_dwstg_connection', 'blue_bucket', 'src_schema', 'tgt_schema',
                                     'tgt_table', 'tgt_cumltv_table', 'no_of_days_to_load'])
job.init(args['JOB_NAME'], args)

################################### Setting up logger for event logging ##################################
logging.basicConfig()
logger = logging.getLogger()
logger.setLevel(logging.INFO)

################################### Assigning job arguments to variables  ##################################

rsdb = args['rsdb']
job_name = args['JOB_NAME']
SNSTopicArn = args['SNS']
env = args['env']
rs_dw_dwstg_conn = args['redshift_dw_dwstg_connection']
# only 'Redshift_DWSTG_DW_QA' conn has access to ebs schema in QA/higher envs but in dev use same RedshiftCopy only which has access to ebs
blue_bucket = args['blue_bucket']
src_schema_name = args['src_schema']
dwstg_schema = args['tgt_schema']
trgt_table_name = args['tgt_table']
trgt_cumltv_table_name = args['tgt_cumltv_table']
ebs_schema = 'dw_ebs'
trgt_ebs_cntrl_table = 'ebs_cntrl_tbl'
temp_directory = f"s3://{blue_bucket}/nightlyaccruals/cumltv/dataload/temp/{job_name}/{str(datetime.now()).replace(' ', '_')}"
tmp_trgt_cumltv_table_name = f"{trgt_cumltv_table_name}_tmp"
# in case of job failures, consider below parameter to change (rule is: 90 days + how many days job didnot run/failed)
# we already provided 30 days buffer i.e, 90+ 30 days = 120 (if more than 30 days, change this)
no_of_days_to_load = args['no_of_days_to_load']

# Create low level reosurce service client for S3 ans SNS

s3Client = boto3.client('s3', region_name='us-west-2')
s3resource = boto3.resource('s3', region_name='us-west-2')
glueClient = boto3.client('glue', region_name='us-west-2')
snsClient = boto3.client('sns', region_name='us-west-2')

job_title = " ".join(trgt_cumltv_table_name.split("_")[:]).title()  # used to print it in logs but nothing else.


# Notification Function
def notifymsg(sub, msg):
    env_var = f"{env}: P3-High-PSS" if env.upper() == 'PROD' else env
    snsClient.publish(TopicArn=SNSTopicArn, Message=msg, Subject=env_var + ": " + sub)
    logger.info("**************** [INFO] SNS Notification Sent *************************")


# Create Timestamp
def create_timestamp_est():
    utc_now = datetime.now()
    est = pytz.timezone('US/Eastern')
    est_now = utc_now.astimezone(est).strftime('%Y-%m-%d %H:%M:%S.%f')
    return est_now


############ Retrieving dw and dwstg connection details from Glue connections for Redshift  #############

logger.info(f"Getting Redshift Connection Information for '{rs_dw_dwstg_conn}'")
# rs_conn_dest_dw = glueContext.extract_jdbc_conf(rs_dw_conn)  # returns rs details (id, pswd, url) in dict for dw
rs_conn_dest_dwstg = glueContext.extract_jdbc_conf(rs_dw_dwstg_conn)  # returns rs details in dict for dwstg


def set_nullable_for_all_columns(df, nullable):
    new_schema = StructType([StructField(f.name, f.dataType, nullable, f.metadata)
                             for f in df.schema.fields])
    return new_schema


def read_rs_tables_to_df_using_sql(rs_conn_dest1: dict, sql: str, rs_conn_dest2: dict = None):
    # TODO: refactor this whole function
    try:
        if rs_conn_dest2 is not None:
            load_schema_df = spark.read.format("com.databricks.spark.redshift") \
                .option("url", rs_conn_dest1["url"] + '/' + rsdb +
                        '?user=' + rs_conn_dest1["user"] + '&password=' + rs_conn_dest1["password"]) \
                .option("url", rs_conn_dest2["url"] + '/' + rsdb +
                        '?user=' + rs_conn_dest2["user"] + '&password=' + rs_conn_dest2["password"]) \
                .option("query", sql) \
                .option("forward_spark_s3_credentials", "true") \
                .option("tempdir", temp_directory).load()

            load_df = spark.read.schema(set_nullable_for_all_columns(load_schema_df, True)). \
                format("com.databricks.spark.redshift") \
                .option("url", rs_conn_dest1["url"] + '/' + rsdb +
                        '?user=' + rs_conn_dest1["user"] + '&password=' + rs_conn_dest1["password"]) \
                .option("url", rs_conn_dest2["url"] + '/' + rsdb +
                        '?user=' + rs_conn_dest2["user"] + '&password=' + rs_conn_dest2["password"]) \
                .option("query", sql) \
                .option("forward_spark_s3_credentials", "true") \
                .option("tempdir", temp_directory + '/').load()

        else:
            load_schema_df = spark.read.format("com.databricks.spark.redshift") \
                .option("url", rs_conn_dest1["url"] + '/' + rsdb +
                        '?user=' + rs_conn_dest1["user"] + '&password=' + rs_conn_dest1["password"]) \
                .option("query", sql) \
                .option("forward_spark_s3_credentials", "true") \
                .option("tempdir", temp_directory).load()

            load_df = spark.read.schema(set_nullable_for_all_columns(load_schema_df, True)). \
                format("com.databricks.spark.redshift") \
                .option("url", rs_conn_dest1["url"] + '/' + rsdb +
                        '?user=' + rs_conn_dest1["user"] + '&password=' + rs_conn_dest1["password"]) \
                .option("query", sql) \
                .option("forward_spark_s3_credentials", "true") \
                .option("tempdir", temp_directory + '/').load()

    except Exception as e:
        msg = f"Priority: P3-High\nAssignment Team: PSS AWS\nImpacted System: NT- EBS\nAWS Component: {job_name}\n"\
            f"\nError Details: Unable to connect to Redshift/execute SQL while processing the glue job '{job_name}' , failed with error: {str(e)}  "
        sub = f"Nightly Accrual Daily Cumulative Glue job failed"
        notifymsg(sub, msg)
        logger.info(f" Exiting with error: {str(e)}")
        raise SystemExit(e)

    return load_df


def get_nt_rs_data_to_df():
    """
    this function is used to get the NT data(actuals/estimates) at that point of time and creates a temp df
    :return: spark dataframe
    """
    try:
        # running full sql (temp left join with stg) to implement scd2
        full_nt_cum_sql = \
            f""" select reported.site_id, reported.brnd_id, reported.entity_id, reported.site_key, reported.site_reportdt_hash,
	reported.site_seq_num, reported.report_dt, reported.rcrd_typ_orgnl, reported.rcrd_typ_ltst, nt_cum.rcrd_typ_mnthnd,
	reported.acnt_num_ltst, nt_cum.acnt_num_mnthnd, reported.rms_rntd_orgnl, nt_cum.rms_rntd_mnthnd, reported.rms_rntd_ltst, reported.rm_rev_lcl_crncy_orgnl, nt_cum.rm_rev_lcl_crncy_mnthnd,
	reported.rm_rev_lcl_crncy_ltst, reported.rm_rev_bil_crncy_orgnl, nt_cum.rm_rev_bil_crncy_mnthnd, reported.rm_rev_bil_crncy_ltst, reported.calc_flg_ltst, nt_cum.calc_flg_mnthnd,
	reported.insrt_dt, reported.updt_dt, reported.actl_updt_dt, reported.rms_opn, reported.bil_crncy_cd, reported.lcl_crncy_cd, reported.cnvrsn_rt, reported.othr_rev_lcl_orgnl,
	nt_cum.othr_rev_lcl_mnthnd, reported.othr_rev_lcl_ltst, reported.othr_rev_bil_orgnl, nt_cum.othr_rev_bil_mnthnd, reported.othr_rev_bil_ltst, reported.mtng_rm_rev_lcl_orgnl, nt_cum.mtng_rm_rev_mnthnd, reported.mtng_rm_rev_lcl_ltst,
	reported.mtng_rm_rev_bil_orgnl, nt_cum.mtng_rm_rev_bil_mnthnd, reported.mtng_rm_rev_bil_ltst, reported.tax_ltst, reported.tax_orgnl, nt_cum.tax_mnthnd, reported.tax_bil_ltst, reported.tax_bil_orgnl, nt_cum.tax_bil_mnthnd,
	reported.fd_bvrg_rvnu_lcl_orgnl, nt_cum.fd_bvrg_rvnu_lcl_mnthnd, reported.fd_bvrg_rvnu_lcl_ltst, reported.fd_bvrg_rvnu_bill_orgnl, nt_cum.fd_bvrg_rvnu_bil_mnthnd, reported.fd_bvrg_rvnu_bil_ltst,
	reported.occ, reported.adr, reported.calc_mis, nt_cum.rms_rntd_updtby_ebs, nt_cum.rms_opn_updtby_ebs, nt_cum.rm_rev_bil_crncy_updtby_ebs, nt_cum.mtng_rm_rev_bil_updtby_ebs, nt_cum.othr_rev_bil_updtby_ebs, 
	nt_cum.calc_mis_updtby_ebs, nt_cum.fb_bil_updtby_ebs,
	case when nt_cum.site_id is null then reported.calc_flg_ltst_ebs
		 when nt_cum.site_id is not null then nt_cum.calc_flg_ltst_ebs
		 end as calc_flg_ltst_ebs,
	case when nt_cum.site_id is null then reported.days_estm_cntr
		 when nt_cum.site_id is not null then nt_cum.days_estm_cntr
		 end as days_estm_cntr,
	case when nt_cum.site_id is null then reported.calc_mis_ltst
		 when nt_cum.site_id is not null then nt_cum.calc_mis_ltst
		 end as calc_mis_ltst,
	case when nt_cum.site_id is null then reported.cum_rm_rev_bil_crncy_ltst
		 when nt_cum.site_id is not null then nt_cum.cum_rm_rev_bil_crncy_ltst
		 end as cum_rm_rev_bil_crncy_ltst,
	case when nt_cum.site_id is null then reported.cum_rms_rntd_ltst
		 when nt_cum.site_id is not null then nt_cum.cum_rms_rntd_ltst
		 end as cum_rms_rntd_ltst,
	case when nt_cum.site_id is null then reported.cum_rms_opn
		 when nt_cum.site_id is not null then nt_cum.cum_rms_opn
		 end as cum_rms_opn,
	reported.create_by, reported.src_create_ts, reported.src_updt_ts
	from
	(
	select nt.site_id, nt.brnd_id, nt.entity_id, nt.site_key, nt.site_reportdt_hash
	, nt.site_seq_num, nt.report_dt, nt.rcrd_typ_orgnl, nt.rcrd_typ_ltst
	, nt.rcrd_typ_mnthnd, nt.acnt_num_ltst, nt.acnt_num_mnthnd, nt.rms_rntd_orgnl, nt.rms_rntd_mnthnd, nt.rms_rntd_ltst, nt.rm_rev_lcl_crncy_orgnl
	, nt.rm_rev_lcl_crncy_mnthnd, nt.rm_rev_lcl_crncy_ltst, nt.rm_rev_bil_crncy_orgnl, nt.rm_rev_bil_crncy_mnthnd, nt.rm_rev_bil_crncy_ltst, nt.calc_flg_ltst, nt.calc_flg_mnthnd
	, nt.insrt_dt, nt.updt_dt, nt.actl_updt_dt, nt.rms_opn, nt.bil_crncy_cd, nt.lcl_crncy_cd, nt.cnvrsn_rt, nt.othr_rev_lcl_orgnl
	, nt.othr_rev_lcl_mnthnd, nt.othr_rev_lcl_ltst, nt.othr_rev_bil_orgnl, nt.othr_rev_bil_mnthnd, nt.othr_rev_bil_ltst, nt.mtng_rm_rev_lcl_orgnl, nt.mtng_rm_rev_mnthnd, nt.mtng_rm_rev_lcl_ltst
	, nt.mtng_rm_rev_bil_orgnl, nt.mtng_rm_rev_bil_mnthnd, nt.mtng_rm_rev_bil_ltst, nt.tax_ltst, nt.tax_orgnl, nt.tax_mnthnd, nt.tax_bil_ltst, nt.tax_bil_orgnl, nt.tax_bil_mnthnd
	, nt.fd_bvrg_rvnu_lcl_orgnl, nt.fd_bvrg_rvnu_lcl_mnthnd, nt.fd_bvrg_rvnu_lcl_ltst, nt.fd_bvrg_rvnu_bill_orgnl, nt.fd_bvrg_rvnu_bil_mnthnd, nt.fd_bvrg_rvnu_bil_ltst
	, nt.occ, nt.adr, nt.calc_mis as calc_mis
	, case when (select count(1)
		from dw.nightly_accruals where 
		site_id  = nt.site_id and acnt_num_ltst = nt.acnt_num_ltst
		and DATE_PART(year, to_date(report_dt,'YYYY-MM-DD')) = substring(nt.report_dt, 1, 4)
		and lpad(DATE_PART(month, to_date(report_dt,'YYYY-MM-DD')), 2, '0') = substring(nt.report_dt, 6, 2)
		and cur_rec_ind = 'Y'
		and calc_flg_ltst = '0' -- count of estimated and missed
		and to_date(report_dt,'YYYY-MM-DD') <= to_date(nt.report_dt,'YYYY-MM-DD')) > 0 then '0'
		else '1' end as calc_flg_ltst_ebs
	, (select count(1)
		from dw.nightly_accruals where 
		site_id  = nt.site_id and acnt_num_ltst = nt.acnt_num_ltst
		and DATE_PART(year, to_date(report_dt,'YYYY-MM-DD')) = substring(nt.report_dt, 1, 4)
		and lpad(DATE_PART(month, to_date(report_dt,'YYYY-MM-DD')), 2, '0') = substring(nt.report_dt, 6, 2)
		and cur_rec_ind = 'Y'
		and calc_flg_ltst = '0'  -- count of estimated and missed
		and to_date(report_dt,'YYYY-MM-DD') <= to_date(nt.report_dt,'YYYY-MM-DD')) as days_estm_cntr
	, case when (select count(1)
		from dw.nightly_accruals where 
		site_id  = nt.site_id and acnt_num_ltst = nt.acnt_num_ltst
		and DATE_PART(year, to_date(report_dt,'YYYY-MM-DD')) = substring(nt.report_dt, 1, 4)
		and lpad(DATE_PART(month, to_date(report_dt,'YYYY-MM-DD')), 2, '0') = substring(nt.report_dt, 6, 2)
		and cur_rec_ind = 'Y'
		and calc_mis = 'MISS'
		and to_date(report_dt,'YYYY-MM-DD') <= to_date(nt.report_dt,'YYYY-MM-DD')) > 0 then 'MISS' 
		else 'CALC' end as calc_mis_ltst
	, (select sum(rm_rev_bil_crncy_ltst)
		from dw.nightly_accruals where 
		site_id  = nt.site_id and acnt_num_ltst = nt.acnt_num_ltst
		and DATE_PART(year, to_date(report_dt,'YYYY-MM-DD')) = substring(nt.report_dt, 1, 4)
		and lpad(DATE_PART(month, to_date(report_dt,'YYYY-MM-DD')), 2, '0') = substring(nt.report_dt, 6, 2)
		and to_date(report_dt,'YYYY-MM-DD') <= to_date(nt.report_dt,'YYYY-MM-DD')
		and cur_rec_ind = 'Y'
		group by site_id, substring(report_dt, 1,7), acnt_num_ltst) cum_rm_rev_bil_crncy_ltst
	, (select sum(rms_rntd_ltst)
		from dw.nightly_accruals where 
		site_id  = nt.site_id and acnt_num_ltst = nt.acnt_num_ltst
		and DATE_PART(year, to_date(report_dt,'YYYY-MM-DD')) = substring(nt.report_dt, 1, 4)
		and lpad(DATE_PART(month, to_date(report_dt,'YYYY-MM-DD')), 2, '0') = substring(nt.report_dt, 6, 2)
		and to_date(report_dt,'YYYY-MM-DD') <= to_date(nt.report_dt,'YYYY-MM-DD')
		and cur_rec_ind = 'Y'
		group by site_id, substring(report_dt, 1,7), acnt_num_ltst) cum_rms_rntd_ltst
	, (select sum(rms_opn)
		from dw.nightly_accruals where 
		site_id  = nt.site_id and acnt_num_ltst = nt.acnt_num_ltst
		and DATE_PART(year, to_date(report_dt,'YYYY-MM-DD')) = substring(nt.report_dt, 1, 4)
		and lpad(DATE_PART(month, to_date(report_dt,'YYYY-MM-DD')), 2, '0') = substring(nt.report_dt, 6, 2)
		and to_date(report_dt,'YYYY-MM-DD') <= to_date(nt.report_dt,'YYYY-MM-DD')
		and cur_rec_ind = 'Y'
		group by site_id, substring(report_dt, 1,7), acnt_num_ltst) cum_rms_opn
	--, null as cum_mtng_rm_rev_bil_ltst, null as cum_othr_rev_bil_ltst, null as cum_fd_bvrg_rvnu_bil_ltst, null as fb_bil_updtby_ebs
	, nt.create_by
	, nt.src_create_ts
	, nt.src_updt_ts
	from 
	(select * from dw.nightly_accruals  
	where 
	(DATEDIFF('day', to_date(report_dt,'YYYY-MM-DD'),  to_date(convert_timezone('America/New_York', sysdate), 'YYYY-MM-DD')) > 0 and
	DATEDIFF('day', to_date(report_dt,'YYYY-MM-DD'),  to_date(convert_timezone('America/New_York', sysdate), 'YYYY-MM-DD')) <= {no_of_days_to_load})
	and cur_rec_ind = 'Y'
	) nt
	--where site_id = '00001' and report_dt like '2023-03%'
	) reported
	left join 
	(
	select * from dw_ebs.nightly_accruals_cumulative  
	where
	DATEDIFF('day', to_date(report_dt,'YYYY-MM-DD'),  to_date(convert_timezone('America/New_York', sysdate), 'YYYY-MM-DD')) > 0 and
    DATEDIFF('day', to_date(report_dt,'YYYY-MM-DD'),  to_date(convert_timezone('America/New_York', sysdate), 'YYYY-MM-DD')) <= {no_of_days_to_load}
	) nt_cum
	on reported.site_id = nt_cum.site_id
	and reported.report_dt = nt_cum.report_dt
	where reported.src_create_ts <> coalesce(nt_cum.src_create_ts,'11-11-1111')
	--and reported.site_id = '00042'
	--and reported.report_dt like '2023-01%'
	--order by reported.report_dt
    """

        # logger.info("full_nt_cum_sql: %s", full_nt_cum_sql)
        nt_cum_df_full = read_rs_tables_to_df_using_sql(rs_conn_dest_dwstg, full_nt_cum_sql)
        # logger.info(
        #    f"No.of records to be loaded to NT cumulative table: {nt_cum_df_full.count()}")

    except Exception as e:
        logger.error(f"Error while reading Redshift trgt table, failed with : {str(e)}")
        msg = f"Priority: P3-High\nAssignment Team: PSS AWS\nImpacted System: NT- EBS\nAWS Component: {job_name}\n"\
            f"\nError Details: Error while reading Redshift trgt table for the job '{job_name}', failed with error: {str(e)}"
        sub = f"Nightly Accrual Daily Cumulative Glue job failed"
        notifymsg(sub, msg)
        raise SystemExit(e)

    return nt_cum_df_full


stg_nt_cum_df = get_nt_rs_data_to_df()
stg_nt_cum_df = stg_nt_cum_df.cache()
df_count = stg_nt_cum_df.count()
logger.info(f"No.of cumulative records to be loaded to NT cumulative table: {df_count}")
stg_nt_cum_df.limit(1).show()

if df_count != 0:
    for x in stg_nt_cum_df.columns:
        # col(x).cast(StringType() is crucial below. Else all non-string cols will get converted to Null. by this,
        # we are casting all cols to strings to check for Non-null values.
        # if you skip to write this for loop, you will get 'NullPointerException' error
        stg_nt_cum_df = stg_nt_cum_df.withColumn(x, when(col(x).cast(StringType()) != '', col(x)).otherwise(None))
    # stg_nt_cum_df.limit(1).show()

    stg_nt_cum_dynf_full = DynamicFrame.fromDF(stg_nt_cum_df, glueContext, "stg_nt_cum_dynf_full")
    # ResolveChoice leaves the cols Null when other datatypes arrive than expected but creates 2 new cols in the
    # result dataset
    stg_table_map = \
        ResolveChoice.apply(
            frame=stg_nt_cum_dynf_full,
            choice="make_cols",
            transformation_ctx="stg_table_map"
        )
    # logger.info(f"NT stg_table_map count: {stg_table_map.count()}")

    #################### Dataload to Redshift Main table ########################
    logger.info("Starting Data load (STAGE 1) to NT cumltv table..")

    # update query works only as below, I was not able to execute update query directly on db as ending up with errors.
    # so put update command in postquery as below and run it after loading your main table in write_dynamic_frame.
    # So no need of prequery or temp table here as SCD3 we are covering as part of full large query in first and
    # filtering the records (new/updated) there itself

    pre_query = f"""begin;
            delete from {dwstg_schema}.{tmp_trgt_cumltv_table_name} where 1=1;
            end;"""

    post_query = f"""begin;
            delete from {ebs_schema}.{trgt_cumltv_table_name} using {dwstg_schema}.{tmp_trgt_cumltv_table_name} 
            where {dwstg_schema}.{tmp_trgt_cumltv_table_name}.site_id = {ebs_schema}.{trgt_cumltv_table_name}.site_id 
            and {dwstg_schema}.{tmp_trgt_cumltv_table_name}.report_dt = {ebs_schema}.{trgt_cumltv_table_name}.report_dt; 
            insert into {ebs_schema}.{trgt_cumltv_table_name} select * from {dwstg_schema}.{tmp_trgt_cumltv_table_name};
            end;"""

    try:
        redshift_load = glueContext.write_dynamic_frame.from_jdbc_conf(
            frame=stg_table_map,
            catalog_connection=rs_dw_dwstg_conn,
            connection_options={
                "url": rs_conn_dest_dwstg["url"] + '/' + rsdb,
                "database": rsdb,
                "user": rs_conn_dest_dwstg["user"],
                "password": rs_conn_dest_dwstg["password"],
                "dbtable": f"{dwstg_schema}.{tmp_trgt_cumltv_table_name}",
                "extracopyoptions": "MAXERROR 100000",
                "preactions": pre_query,
                "postactions": post_query},
            redshift_tmp_dir=
            f"""s3://{blue_bucket}/nightlyaccruals/cumltv/dataload/stg/{job_name}/{str(datetime.now()).replace(" ", "_")}/"""
        )
        logger.info(f" Data Load Process (STAGE 1) for '{job_title} Cumulative' to redshift Complete!")
    except Exception as e:
        logger.error(
            f"Error while loading to Redshift Staging table, failed with : {str(e)}")
        f_msg = f"Priority: P3-High\nAssignment Team: PSS AWS\nImpacted System: NT- EBS\nAWS Component: {job_name}\n"\
            f"\nError Details: Error while loading to Staging table for the job '{job_name}' failed with error: {str(e)}"
        f_sub = f"Nightly Accrual Daily Cumulative Glue job failed"
        notifymsg(f_sub, f_msg)
        raise SystemExit(e)

    # stage 2 load is necessary to update cumltv cols on last day
    est_while_updating_mnthnd_rows = create_timestamp_est()  # this is used to get which report_dts got updated and can update their status in cntrl table
    logger.info(f"est_while_updating_mnthnd_rows: {est_while_updating_mnthnd_rows}")
    logger.info("Starting Data load (STAGE 2) to NT cumltv table..")
    # need to execute below query after stage 1 is completed as it is dependant on loaded latest data
    mnthnd_nt_cum_sql = f""" 
    select cum.site_id, cum.brnd_id, cum.entity_id, cum.site_key, cum.site_reportdt_hash,
	cum.site_seq_num, cum.report_dt, cum.rcrd_typ_orgnl, cum.rcrd_typ_ltst, cum.rcrd_typ_mnthnd,
	cum.acnt_num_ltst, cum.acnt_num_mnthnd, cum.rms_rntd_orgnl, cum.rms_rntd_mnthnd, cum.rms_rntd_ltst, cum.rm_rev_lcl_crncy_orgnl, cum.rm_rev_lcl_crncy_mnthnd,
	cum.rm_rev_lcl_crncy_ltst, cum.rm_rev_bil_crncy_orgnl, cum.rm_rev_bil_crncy_mnthnd, cum.rm_rev_bil_crncy_ltst, cum.calc_flg_ltst, cum.calc_flg_mnthnd,
	cum.insrt_dt, cum.updt_dt, cum.actl_updt_dt, cum.rms_opn, cum.bil_crncy_cd, cum.lcl_crncy_cd, cum.cnvrsn_rt, cum.othr_rev_lcl_orgnl,
	cum.othr_rev_lcl_mnthnd, cum.othr_rev_lcl_ltst, cum.othr_rev_bil_orgnl, cum.othr_rev_bil_mnthnd, cum.othr_rev_bil_ltst, cum.mtng_rm_rev_lcl_orgnl, cum.mtng_rm_rev_mnthnd, cum.mtng_rm_rev_lcl_ltst,
	cum.mtng_rm_rev_bil_orgnl, cum.mtng_rm_rev_bil_mnthnd, cum.mtng_rm_rev_bil_ltst, cum.tax_ltst, cum.tax_orgnl, cum.tax_mnthnd, cum.tax_bil_ltst, cum.tax_bil_orgnl, cum.tax_bil_mnthnd,
	cum.fd_bvrg_rvnu_lcl_orgnl, cum.fd_bvrg_rvnu_lcl_mnthnd, cum.fd_bvrg_rvnu_lcl_ltst, cum.fd_bvrg_rvnu_bill_orgnl, cum.fd_bvrg_rvnu_bil_mnthnd, cum.fd_bvrg_rvnu_bil_ltst,
	cum.occ, cum.adr, cum.calc_mis, cum.rms_rntd_updtby_ebs, cum.rms_opn_updtby_ebs, cum.rm_rev_bil_crncy_updtby_ebs, cum.mtng_rm_rev_bil_updtby_ebs, cum.othr_rev_bil_updtby_ebs, 
	cum.calc_mis_updtby_ebs, cum.fb_bil_updtby_ebs,
	mnthnd_cum.calc_flg_ltst_ebs, mnthnd_cum.days_estm_cntr, mnthnd_cum.calc_mis_ltst,
	mnthnd_cum.cum_rm_rev_bil_crncy_ltst, mnthnd_cum.cum_rms_rntd_ltst, mnthnd_cum.cum_rms_opn, 'GLUE_MNTHND_ROWS_UPDT' as create_by, cum.src_create_ts
	,cast('{est_while_updating_mnthnd_rows}' as timestamp) as src_updt_ts
	from
	(select mnthnd_rms_rvnus.site_id, mnthnd_rms_rvnus.report_dt, mnthnd_rms_rvnus.acnt_num_ltst, mnthnd_rms_rvnus.cum_rms_rntd_ltst, mnthnd_rms_rvnus.cum_rms_opn, mnthnd_rms_rvnus.cum_rm_rev_bil_crncy_ltst,
	coalesce(mnthnd_estm_cntr.calc_flg_ltst_ebs, '1') calc_flg_ltst_ebs, coalesce(mnthnd_estm_cntr.days_estm_cntr, 0) days_estm_cntr, coalesce(mnthnd_mis_cntr.calc_mis_ltst, 'CALC') calc_mis_ltst
	from (select site_id, report_dt, acnt_num_ltst, cum_rms_rntd_ltst, cum_rms_opn, cum_rm_rev_bil_crncy_ltst
    from(
    select site_id, last_day(to_date(concat(report_dt, '-01'),'YYYY-MM-DD')) report_dt, acnt_num_ltst, cum_rms_rntd_ltst, cum_rms_opn, cum_rm_rev_bil_crncy_ltst,
	dense_rank() over (partition by site_id order by last_day(to_date(concat(report_dt, '-01'),'YYYY-MM-DD')) desc) rnk
	from (select site_id, substring(report_dt, 1,7) report_dt, acnt_num_ltst, sum(rms_rntd_ltst) cum_rms_rntd_ltst , sum(rms_opn) cum_rms_opn, sum(rm_rev_bil_crncy_ltst) cum_rm_rev_bil_crncy_ltst 
	from dw_ebs.nightly_accruals_cumulative
	where (DATEDIFF('day', to_date(report_dt,'YYYY-MM-DD'),  to_date(convert_timezone('America/New_York', sysdate), 'YYYY-MM-DD')) > 0 and
	DATEDIFF('day', to_date(report_dt,'YYYY-MM-DD'),  to_date(convert_timezone('America/New_York', sysdate), 'YYYY-MM-DD')) <= 150)  --just to be on safer side providing more range, no harm in pulling more data as rank will restrict us
	--and site_id = '17845'
	group by site_id, substring(report_dt, 1,7), acnt_num_ltst)
	)
	where rnk in (1, 2, 3, 4)) mnthnd_rms_rvnus  --considering previous 3 months (considering rank =4 to cover past 3 month ends,means if u r in mid feb, it picks 11/30 also)
	left join
	(select site_id, last_day(to_date(concat(report_dt, '-01'),'YYYY-MM-DD')) report_dt, acnt_num_ltst, calc_flg_ltst_ebs, days_estm_cntr 
	from (select site_id, substring(report_dt, 1,7) report_dt, acnt_num_ltst, 
	case when count(1)> 0 then '0' else '1' end as calc_flg_ltst_ebs,
	count(1) as days_estm_cntr
	from dw_ebs.nightly_accruals_cumulative
	where (DATEDIFF('day', to_date(report_dt,'YYYY-MM-DD'),  to_date(convert_timezone('America/New_York', sysdate), 'YYYY-MM-DD')) > 0 and
	DATEDIFF('day', to_date(report_dt,'YYYY-MM-DD'),  to_date(convert_timezone('America/New_York', sysdate), 'YYYY-MM-DD')) <= 150)     --just to be on safer side providing more range, no harm in pulling more data as rank will restrict us
	and calc_flg_ltst = '0'
	--and site_id = '17845'
	group by site_id, substring(report_dt, 1,7), acnt_num_ltst)) mnthnd_estm_cntr
	on mnthnd_rms_rvnus.site_id = mnthnd_estm_cntr.site_id and mnthnd_rms_rvnus.report_dt = mnthnd_estm_cntr.report_dt and mnthnd_rms_rvnus.acnt_num_ltst = mnthnd_estm_cntr.acnt_num_ltst
	left join
	(select site_id, last_day(to_date(concat(report_dt, '-01'),'YYYY-MM-DD')) report_dt, acnt_num_ltst, calc_mis_ltst 
	from (select site_id, substring(report_dt, 1,7) report_dt, acnt_num_ltst, 
	case when count(1)> 0 then 'MISS' else 'CALC' end as calc_mis_ltst
	from dw_ebs.nightly_accruals_cumulative 
	where (DATEDIFF('day', to_date(report_dt,'YYYY-MM-DD'),  to_date(convert_timezone('America/New_York', sysdate), 'YYYY-MM-DD')) > 0 and
	DATEDIFF('day', to_date(report_dt,'YYYY-MM-DD'),  to_date(convert_timezone('America/New_York', sysdate), 'YYYY-MM-DD')) <= 150)  --just to be on safer side providing more range, no harm in pulling more data as rank will restrict us
	and calc_mis = 'MISS'
	--and site_id = '17845'
	group by site_id, substring(report_dt, 1,7), acnt_num_ltst)) mnthnd_mis_cntr
	on mnthnd_rms_rvnus.site_id = mnthnd_mis_cntr.site_id and mnthnd_rms_rvnus.report_dt = mnthnd_mis_cntr.report_dt and mnthnd_rms_rvnus.acnt_num_ltst = mnthnd_mis_cntr.acnt_num_ltst
	--where mnthnd_rms_rvnus.site_id = '17845' order by report_dt desc
	) mnthnd_cum
	join 
	(select * from (
	select *, row_number() over (partition by site_id order by report_dt desc) rnum
	from (
	select *, rank() over (partition by acnt_num_ltst, substring(report_dt, 1,7) order by report_dt desc) rnk
	from dw_ebs.nightly_accruals_cumulative
	--where  site_id = '17845'
	) where rnk =1 --getting latest report_dts for each acntnum in each month (this is crucial to know on which date flip has happened)
	) where (DATEDIFF('month', to_date(report_dt,'YYYY-MM-DD'),  to_date(convert_timezone('America/New_York', sysdate), 'YYYY-MM-DD')) in (0,1,2,3) and rnum <> 1) --considering previous 3 month end dates/acnt flips & current month's accnt flips only
	--and site_id = '17845' order by report_dt desc
	) cum
	on mnthnd_cum.site_id = cum.site_id and substring(mnthnd_cum.report_dt, 1,7) = substring(cum.report_dt, 1,7) and mnthnd_cum.acnt_num_ltst = cum.acnt_num_ltst
	where ((mnthnd_cum.calc_flg_ltst_ebs <> cum.calc_flg_ltst_ebs) or (coalesce(mnthnd_cum.days_estm_cntr, 0) <> coalesce(cum.days_estm_cntr, 0)) or 
	(mnthnd_cum.calc_mis_ltst <> cum.calc_mis_ltst) or (coalesce(mnthnd_cum.cum_rm_rev_bil_crncy_ltst, 0) <> coalesce(cum.cum_rm_rev_bil_crncy_ltst, 0)) or
	(coalesce(mnthnd_cum.cum_rms_rntd_ltst, 0) <> coalesce(cum.cum_rms_rntd_ltst, 0)) or (coalesce(mnthnd_cum.cum_rms_opn, 0) <> coalesce(cum.cum_rms_opn, 0))) --get the record iff some change is detected in these fields
	--and cum.site_id = '17845'
    """
    mnthnd_nt_cum_df = read_rs_tables_to_df_using_sql(rs_conn_dest_dwstg, mnthnd_nt_cum_sql)
    mnthnd_nt_cum_df = mnthnd_nt_cum_df.cache()
    mnthnd_df_count = mnthnd_nt_cum_df.count()
    logger.info(f"No.of cumulative records that needs mnthnd updates and to be loaded to NT cumulative table: {df_count}")

    if mnthnd_df_count != 0:
        for x in mnthnd_nt_cum_df.columns:
            mnthnd_nt_cum_df = mnthnd_nt_cum_df.withColumn(x, when(col(x).cast(StringType()) != '', col(x)).otherwise(None))

    mnthnd_nt_cum_dynf_full = DynamicFrame.fromDF(mnthnd_nt_cum_df, glueContext, "mnthnd_nt_cum_dynf_full")

    mnthnd_table_map = \
        ResolveChoice.apply(
            frame=mnthnd_nt_cum_dynf_full,
            choice="make_cols",
            transformation_ctx="mnthnd_table_map"
        )

    try:
        redshift_load2 = glueContext.write_dynamic_frame.from_jdbc_conf(
            frame=mnthnd_table_map,
            catalog_connection=rs_dw_dwstg_conn,
            connection_options={
                "url": rs_conn_dest_dwstg["url"] + '/' + rsdb,
                "database": rsdb,
                "user": rs_conn_dest_dwstg["user"],
                "password": rs_conn_dest_dwstg["password"],
                "dbtable": f"{dwstg_schema}.{tmp_trgt_cumltv_table_name}",
                "extracopyoptions": "MAXERROR 100000",
                "preactions": pre_query,
                "postactions": post_query},
            redshift_tmp_dir=
            f"""s3://{blue_bucket}/nightlyaccruals/cumltv/dataload/stg/{job_name}/{str(datetime.now()).replace(" ", "_")}/"""
        )
        logger.info(f" Data Load Process (STAGE 2) for '{job_title} Main' to redshift Complete!")
    except Exception as e:
        logger.error(
            f"Error while loading to Redshift Staging table, failed with : {str(e)}")
        f_msg = f"Priority: P3-High\nAssignment Team: PSS AWS\nImpacted System: NT- EBS\nAWS Component: {job_name}\n"\
            f"\nError Details: Error while loading to Staging table for the job '{job_name}' failed with error: {str(e)}"
        f_sub = f"Nightly Accrual Daily Cumulative Glue job failed"
        notifymsg(f_sub, f_msg)
        raise SystemExit(e)

    logger.info(
        "updating the EBS control table with the report_dts that have added in cumltv table but not in cntrl table..")

    # to delete the PROCESSED dates if REPROCESS date entry was made as part of STAGE 2 process
    post_cntrl_query = f"""begin;
            --STEP 1: deleting older record with PROCESSED status so that latest REPROCESS will only remain out of 2
            delete from dw_ebs.ebs_cntrl_tbl where (prcs_nm, chg_date) in 
            (select prcs_nm, chg_date from (select prcs_nm, chg_date, count(*)  
            from dw_ebs.ebs_cntrl_tbl where prcs_nm = 'EBS_NT'
            group by prcs_nm, chg_date
            having count(*)> 1)) and upper(status) = 'PROCESSED';
            --STEP 2: deleting older record with REPROCESS status based upon insert_ts
            --(since we are having multiple entries) so that latest REPROCESS will only remain
            delete from dw_ebs.ebs_cntrl_tbl where (prcs_nm, chg_date, insert_ts) 
            in (select prcs_nm, chg_date, insert_ts from ( 
            select *, row_number() over (partition by prcs_nm, chg_date order by insert_ts desc) rnum
            from dw_ebs.ebs_cntrl_tbl where upper(status) = 'REPROCESS')
            where rnum >1);
            end;"""

    try:
        ebs_cntrl_sql = f""" 
                        --adding new chng_dts that are not present in cntrl table with READY status
                        select 'EBS_NT' as prcs_nm, cum.report_dt as chg_date, 'DAILY' as frequency, 'READY' as status
                        ,cast('{create_timestamp_est()}' as timestamp) as insert_ts, 'GLUE' as insert_by
                        ,cast('{create_timestamp_est()}' as timestamp) as updated_ts, 'GLUE' as updated_by  
                        from 
                        (select distinct report_dt from dw_ebs.nightly_accruals_cumulative) cum
                        left join
                        (select distinct chg_date from dw_ebs.ebs_cntrl_tbl where prcs_nm = 'EBS_NT') cntrl
                        on cum.report_dt = cntrl.chg_date
                        where cntrl.chg_date is null
    					UNION 
                        --updating existing chng_dts in cntrl table with REPROCESS status
                        select 'EBS_NT' as prcs_nm, cum.report_dt as chg_date, 'DAILY' as frequency, 'REPROCESS' as status
                        ,cast('{create_timestamp_est()}' as timestamp) as insert_ts, 'GLUE' as insert_by
                        ,cast('{create_timestamp_est()}' as timestamp) as updated_ts, 'GLUE' as updated_by  
                        from 
                        (select distinct report_dt from dw_ebs.nightly_accruals_cumulative 
                        where src_updt_ts like '{est_while_updating_mnthnd_rows}%') cum  --fetching report_dts which got updated
                        left join
                        (select distinct chg_date from dw_ebs.ebs_cntrl_tbl where prcs_nm = 'EBS_NT' 
                        and upper(status) in ('PROCESSED', 'REPROCESS')) cntrl  --considering processed & reprocess(in case if ebs team might not have pulled previous entry by our next run, so wanted new entry with latest timestamp) dates
                        on cum.report_dt = cntrl.chg_date
                        where cntrl.chg_date is not null 
                        """
        ebs_cntrl_df = read_rs_tables_to_df_using_sql(rs_conn_dest_dwstg, ebs_cntrl_sql)
        logger.info(f"No.of records to be loaded to EBS cntrl table: {ebs_cntrl_df.count()}")
        ebs_cntrl_df.limit(1).show()

        ebs_cntrl_dynf = DynamicFrame.fromDF(ebs_cntrl_df, glueContext, "ebs_cntrl_dynf")

        redshift_load3 = glueContext.write_dynamic_frame.from_jdbc_conf(
            frame=ebs_cntrl_dynf,
            catalog_connection=rs_dw_dwstg_conn,
            connection_options={
                "url": rs_conn_dest_dwstg["url"] + '/' + rsdb,
                "database": rsdb,
                "user": rs_conn_dest_dwstg["user"],
                "password": rs_conn_dest_dwstg["password"],
                "dbtable": f"{ebs_schema}.{trgt_ebs_cntrl_table}",
                "extracopyoptions": "MAXERROR 100000",
                "postactions": post_cntrl_query},
            redshift_tmp_dir=
            f"""s3://{blue_bucket}/nightlyaccruals/cumltv/dataload/cntrl/{job_name}/{str(datetime.now()).replace(" ", "_")}/"""
        )
        logger.info(f" Data Load Process for 'EBS control table' to redshift Complete!")
    except Exception as e:
        logger.error(
            f"Error while loading to Redshift EBS cntrl table, failed with : {str(e)}")
        f_msg = f"Priority: P3-High\nAssignment Team: PSS AWS\nImpacted System: NT- EBS\nAWS Component: {job_name}\n"\
            f"\nError Details: Error while loading to EBS cntrl for the job '{job_name}', failed with error: {str(e)}"
        f_sub = f"Nightly Accrual Daily Cumulative Glue job failed"
        notifymsg(f_sub, f_msg)
        raise SystemExit(e)

else:
    logger.info("there is no updated data found for current run to run NT cumltv process!")

logger.info(
    f" *********** %s: End of Glue process for '{job_title}' *********** ", str(datetime.now()))
job.commit()
logger.info("JOB COMPLETE!!")
