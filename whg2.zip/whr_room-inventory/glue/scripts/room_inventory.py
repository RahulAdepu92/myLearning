import sys
from datetime import datetime
from datetime import timedelta
from dateutil import tz
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.dynamicframe import DynamicFrame
from pyspark.sql import SQLContext
import boto3
import logging
from pyspark.sql.functions import col, when, lit, input_file_name, substring_index
from pyspark.sql.types import TimestampType, DoubleType, StructType, StructField, StringType, \
    IntegerType, LongType, FloatType, DecimalType, DateType

# character to beautify log statements
design_char = '*' * 10

# Setting up logger for event logging
logging.basicConfig()
logger = logging.getLogger()
logger.setLevel(logging.INFO)

logger.info("%s starting Glue process.. %s", design_char, design_char)

# Setting up Spark environment and enabling Glue to interact with Spark Platform
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
sqlContext = SQLContext(sc)

# Enabling access to the arguments
job = Job(glueContext)
args = getResolvedOptions(sys.argv, ['job_name', 'redshift_path', 'source_bucket', 'sns', 'rsdb',
                                     'redshift_connection', 'table_name', 'schema_name',
                                     'seqno_path', 'processing_path', 'intermediate_path',
                                     'audit_table'])
job.init(args['job_name'], args)

# Assigning job arguments to variables
rsdb = args['rsdb']
redshiftconnection = args['redshift_connection']
source_bucket = args['source_bucket']
job_name = args.get('job_name', "GLUE JOB")  # prevent against key error failures down the road
tablename = args['table_name']
schemaname = args['schema_name']
sns_notify = args['sns']
seqno_path = args['seqno_path']
s3_read = args['intermediate_path']
audittable = args['audit_table']
redshift_path = args['redshift_path']
processing_path = args['processing_path']
logger.info("retrieved all job arguments successfully!!")

# Create low level resource service client for S3 ans SNS
s3Client = boto3.client('s3', region_name='us-west-2')
s3resource = boto3.resource('s3', region_name='us-west-2')
glueClient = boto3.client('glue', region_name='us-west-2')
snsClient = boto3.client('sns', region_name='us-west-2')


def sns_event_notify(sub: str, msg: str):
    response = None
    try:
        response = snsClient.publish(TopicArn=sns_notify, Message=msg, Subject=sub)
        logger.info("%s SNS Notification with subject '%s' is Sent for job '%s' %s",
                    design_char, sub, job_name, design_char)
    except ValueError as em:
        logger.exception("executing in except block with error - %s", em)

    return response


# Create Timestamp
def create_timestamp_est():
    loadtime_utc = datetime.now()
    from_zone = tz.tzutc()
    to_zone = tz.gettz('America/New_York')
    newloadtime = loadtime_utc.replace(tzinfo=from_zone)
    loadtime_local = newloadtime.astimezone(to_zone)
    loadtime_local = loadtime_local.strftime('%Y-%m-%d %H:%M:%S.%f')
    logger.info(loadtime_local)
    return loadtime_local


def get_input_s3_path():
    """
    This function will frame the input s3 path. By default, it will take all the files in the
    current date
    :return: list of s3 file names
    """
    logger.info("Framing S3 Path..")
    s3_path = []
    try:
        # Creating Datetime Folder
        today = datetime.now().strftime('%Y/%m/%d')
        yesterday = (datetime.now() - timedelta(1)).strftime('%Y/%m/%d')

        logger.info("Today: %s", today)
        logger.info("Yesterday: %s", yesterday)

        s3_path.append(s3_read + today + '/')
        # Add yesterday files if the last execution is previous day
        client = boto3.client('glue', region_name='us-west-2')
        response = client.get_job_runs(
            JobName=args['job_name'],
            MaxResults=10
        )
        job_runs = response['JobRuns']
        # logger.info("job_runs are: %s", job_runs)
        start_time = None
        for run in job_runs:
            # current job will have status of RUNNING, so this iteration will skip (i.e, continue)
            if run['JobRunState'] != 'SUCCEEDED':
                continue
            else:
                # in next iteration, system will consider SUCCESSFUL job only.
                # so, getting start_time of latest SUCCEEDED job
                start_time = run['StartedOn']
                break
        logger.info("start_time of latest successful job is: %s", start_time)
        # logger.info("UTC_TIME is: %s", datetime.now())
        if start_time and start_time.date() < datetime.today().date():
            logger.info("adding previous day file(s) as it was left over yesterday for processing.")
            s3_path.append(s3_read + yesterday + '/')
        logger.info("input s3 path : %s", s3_path)
    except Exception as e:
        logger.error("%s Unable to frame s3 Input Path : %s %s", design_char, e, design_char)
        msg = f"Unable to Frame S3 Input Path, Error Details: {str(e)}"
        sub = "S3 Read Glue job " + job_name + " failed"
        sns_event_notify(sub, msg)
        raise SystemExit(e)
        # SystemExit is safer and valuable than just exit(1) as the error will be displayed on the
        # glue console and the current code will be exited at the same time if any error occurred.
    return s3_path


# Reading s3 JSON Data for rminv
try:
    logger.info("Reading S3 file(s) from given path..")
    # this dynamic frame will just read all the files under specified s3 path and gets it count.
    # note: this df cant be used to read the actual data to load rs table
    rminv_s3_read_dyf = glueContext.create_dynamic_frame.from_options(connection_type="s3",
                                                                      connection_options={
                                                                          "paths":
                                                                              get_input_s3_path(),
                                                                          'recurse': True},
                                                                      # donot include 'groupFiles': 'inPartition' here
                                                                      #  because 'filepath' writes empty sometimes
                                                                      format="json",
                                                                      transformation_ctx='rminv_s3_read_dyf')

    # converting dynamic frame to data frame
    rminv_s3_df = rminv_s3_read_dyf.toDF()
    rminv_s3_df.show()
    rminv_s3_df_count = rminv_s3_df.count()
    logger.info('Total Count DF(no.of input files)= %i', rminv_s3_df_count)

except Exception as e:
    logger.error(
        "%s %s Exception while reading the files from S3 path %s", design_char, str(datetime.now()),
        design_char)
    logger.error("%s Failing with error:  %s %s", design_char, e, design_char)
    msg = f"Error while reading files from S3 for the job {job_name} , failed with error: {str(e)}"
    sub = "S3 Read Glue job " + job_name + " failed"
    sns_event_notify(sub, msg)
    raise SystemExit(e)

# actual staging process begins
if rminv_s3_df_count == 0:
    logger.info('No Data present to process for S3 Read Job for %s run', str(datetime.now()))
    msg = f"No Data to Process for S3 Read Glue Job - {job_name} for run {str(datetime.now())}"
    sub = f"No Data to Process for S3 Read Glue Job - {job_name}"
    sns_event_notify(sub, msg)
else:
    # Retrieving connection information from 'Glue connections' for Redshift
    try:
        logger.info("Getting Redshift Connection Information..")
        rs_connection_dest = glueContext.extract_jdbc_conf(redshiftconnection)
        rs_url_dest = rs_connection_dest["url"]
        rs_user_dest = rs_connection_dest["user"]
        rs_pwd_dest = rs_connection_dest["password"]
        rs_url_db_dest = rs_url_dest + '/' + rsdb
        logger.info("Redshift Connection details retrieved successfully")
    except Exception as e:
        msg = f"Unable to connect to Redshift while processing the glue job {job_name}, " \
              f"failed with error: {e}"
        sub = "Room-Inventory Glue job " + job_name + " failed"
        sns_event_notify(sub, msg)
        logger.info(" Exiting with error: %s", str(e))
        raise SystemExit(e)

    ############## writing Seqno File(.csv) for Audit Process and Process file for loading staging table #########################
    try:
        rminv_seqno_df = rminv_s3_df.withColumn('filepath', input_file_name()).withColumn(
            'starttime', lit(create_timestamp_est()))
        rminv_seqno_df_final = rminv_seqno_df.select(col('filepath'), col('starttime')).distinct()
        rminv_seqno_df_final.show()
        logger.info("Writing seq IDs to seqno folder..")
        rminv_seqno_df_final.repartition(1).write.csv(seqno_path, mode="overwrite", header='true')

        logger.info("Writing files to processing folder..")
        rminv_s3_df.write.format('json').mode("overwrite").option("header", "true").save(
            processing_path)
    except Exception as e:
        logger.error(
            "%s Exception while writing the files to S3. Failing with error: %s %s", design_char, e,
            design_char)
        msg = f"Error while writing files to S3 for the job {job_name} , failed with error: {e} "
        sub = "S3 rminv job " + job_name + " failed"
        sns_event_notify(sub, msg)
        raise SystemExit(e)

    ############## Reading the JSON Res Files for Processing Stage #########################
    try:
        logger.info("Reading data from Processing folder s3 files..")
        # note: this df is used to read the actual data to load rs table
        rminv_dyf = glueContext.create_dynamic_frame.from_options(connection_type="s3",
                                                                  connection_options={
                                                                      "paths": [processing_path],
                                                                      'recurse': True,
                                                                      'groupFiles': 'inPartition'},
                                                                  format="json",
                                                                  format_options={
                                                                      "jsonPath":
                                                                          "$.stg_htl_rm_invntry["
                                                                          "*]"})

        # converting dynamic frame to data frame
        rminv_df = rminv_dyf.toDF()
        rminv_df.show()
        rminv_df_count = rminv_df.count()
        logger.info('Total Count DF(no.of records)= %i', rminv_df_count)

    except Exception as e:
        logger.error(
            "%s %s Exception while reading the data from S3 files %s", design_char,
            str(datetime.now()), design_char)
        logger.error("%s Failing with error:  %s %s", design_char, e, design_char)
        msg = f"Error while reading data from S3 files for the job {job_name} , failed with " \
              f"error: {str(e)}"
        sub = "S3 Read Glue job " + job_name + " failed"
        sns_event_notify(sub, msg)
        raise SystemExit(e)

    # third step: construct final glue dynamic frame as per etl logics provided in mapping doc
    try:
        logger.info('Mapping Field Names with Redshift Columns..')
        # Filling in blank values with Null values in rminv dataframe
        for x in rminv_df.columns:
            rminv_df = rminv_df.withColumn(x, when(col(x) != '', col(x)).otherwise(None))

        rminv_df_final = \
            rminv_df.withColumn('insrt_ts', lit(create_timestamp_est()).cast(TimestampType())) \
                .withColumn('strt_dt', col('strt_dt').cast(DateType())) \
                .withColumn('end_dt', col('end_dt').cast(DateType())) \
                .withColumn('src_tmstmp', col('src_tmstmp').cast(TimestampType()))

        rminv_df_final.printSchema()
        rminv_df_final.show(10, False)

        # creating glue dynamic df from above created df
        rminv_glue_dyf_final = DynamicFrame.fromDF(rminv_df_final, glueContext,
                                                   'rminv_glue_dyf_final')

    except Exception as e:
        logger.error("%s Exception while doing Data Transformation on Room Inventory Data. "
                     "Failed with error: %s %s", design_char, e, design_char)
        msg = f"Error while doing Data Transformation for Glue Job {job_name}, failed with error: " \
              f"" \
              f"{str(e)}"
        sub = "Room-Inventory Glue job " + job_name + " failed"
        sns_event_notify(sub, msg)
        raise SystemExit(e)

    # fourth step: Dataload to Redshift
    try:
        redshift_load = glueContext.write_dynamic_frame.from_jdbc_conf(
            frame=rminv_glue_dyf_final,
            catalog_connection=redshiftconnection,
            connection_options={
                "url": rs_url_db_dest,
                "database": rsdb,
                "user": rs_user_dest,
                "password": rs_pwd_dest,
                "dbtable": schemaname + '.' + tablename,
                "extracopyoptions": "MAXERROR 100000"},
            redshift_tmp_dir=f"s3://{source_bucket}/sabre/room_inventory/dataload/{job_name}/"
                             f"{str(datetime.now()).replace(' ', '_')}/"
        )
        logger.info("Data Load Process for Room Inventory to redshift complete")
    except Exception as e:
        logger.info(
            "Error while loading to Redshift Staging table, failed with : %s", str(e))
        msg = f"Error while loading to Staging table for the job {job_name}, failed with error: " \
              f"{str(e)}"
        sub = "Room Inventory Glue job Glue job " + job_name + " failed"
        sns_event_notify(sub, msg)
        raise SystemExit(e)

    logger.info(
        " %s %s End of Load process for Room Inventory Channel %s ", design_char,
        str(datetime.now()), design_char)

    # fifth step: Read the echotokens (.csv s3 data set files) written in step 1 and build a temp table
    try:
        seq_id_df = glueContext.read.format("csv").option("inferSchema", "false") \
            .option("header", "true").load(seqno_path)
        logger.info(seq_id_df.show())
        seq_id_df.createTempView("id_temp")

    except Exception as e:
        logger.error(
            "%s Error reading CSV file, failed with error: %s %s", design_char, e, design_char)
        msg = f"Error reading CSV file, failed with error: {str(e)}"
        sub = f"Room Inventory Audit Job - {job_name} Failed"
        sns_event_notify(sub, msg)
        raise SystemExit(e)

    # final step: Read STL_LOAD_ERRORS table and join with id_temp df for audit processing
    if seq_id_df.count() == 0:
        logger.info("No Data to Process for Room Inventory Audit Job %s for run %s", job_name,
                    str(datetime.now()))
        msg = f"No Data to Process for Room Inventory Audit Job {job_name} for run " \
              f"{str(datetime.now())}"
        sub = f"No Data to Process for Room Inventory Audit Glue Job - {job_name}"
        sns_event_notify(sub, msg)

    # Read STL_LOAD_ERRORS
    else:
        logger.info("%s: Getting Data from Load Error Table for Audit", str(datetime.now()))
        try:
            RSerror_df = glueContext.create_dynamic_frame.from_options(
                connection_type="redshift",
                connection_options={
                    "url": rs_url_db_dest,
                    "database": rsdb,
                    "user": rs_user_dest,
                    "password": rs_pwd_dest,
                    "dbtable": schemaname + ".stl_load_errors_view",
                    "redshiftTmpDir": redshift_path + "stl_load_errors/" + str(
                        datetime.now()).replace(
                        " ", "_") + "/"
                }
            )

            RSerror_df.toDF().createTempView("RSerror")
        except Exception as e:
            logger.error(
                "%s Error reading STL_LOAD_ERRORS Table, failed with error: %s%s", design_char, e,
                design_char)
            msg = f"Error reading STL_LOAD_ERRORS Table. Failed with following error: \n {str(e)}"
            sub = f"Room Inventory Audit Job - {job_name} Failed"
            sns_event_notify(sub, msg)
            raise SystemExit(e)

        # SQL for Audit Log table
        logger.info("Starting Audit Process..")
        try:
            starttime_df = spark.sql(""" select max(starttime) as starttime from id_temp """)
            starttime = starttime_df.first()['starttime']

            audit_sql = (f""" select 'SBR_ROOM_INV' as  src_system_nm, cast(starttime as timestamp) 
                          as stg_insrt_ts, SUBSTRING_INDEX(SUBSTRING_INDEX(A.filepath,'/',-1),'.', 1) 
                          as id, case when err.id is null then 'S' else 'F' end as stg_rcrd_sts,
                          case when err.id is not null then err.err_reason else null end as stg_err_txt,
                          A.filepath as filepath, 'Glue' as create_by, current_timestamp as create_ts
                          from id_temp A 
                          left join 
                          (select distinct SUBSTRING_INDEX(raw_line,',',1) as id, err_reason 
                          from RSerror where starttime > '{starttime}') err 
                          on SUBSTRING_INDEX(SUBSTRING_INDEX(A.filepath,'/',-1), '.',1) = err.id""")

            IDAudit = spark.sql(audit_sql)
            IDAudit.show()
            IDAudit_df = DynamicFrame.fromDF(IDAudit, glueContext, "IDAudit_df")

            IDAudit_table_map = ResolveChoice.apply(
                    frame=IDAudit_df,
                    choice="make_cols",
                    transformation_ctx="IDAudit_table_map"
                )
            IDAudit.createTempView("id_stats")
            IDAudit_table_map.show()

            # Write to Audit Log table
            logger.info("%s: Updating Audit table with status ", str(datetime.now()))
            erroredTokensAudit = glueContext.write_dynamic_frame.from_jdbc_conf(
                    frame=IDAudit_table_map,
                    catalog_connection=redshiftconnection,
                    connection_options={
                        "url": rs_url_db_dest,
                        "database": rsdb,
                        "user": rs_user_dest,
                        "password": rs_pwd_dest,
                        "dbtable": audittable
                    },
                    redshift_tmp_dir=f"{redshift_path}Audit/"
                                     f"{str(datetime.now()).replace(' ', '_')}/"
                )

        except Exception as e:
            logger.error("%s Error with Audit process, failed with error: %s %s", design_char, e,
                         design_char)
            msg = f"Audit process failed with following error: \n {str(e)}"
            sub = f"Room Inventory Audit Glue Job - {job_name} Failed"
            sns_event_notify(sub, msg)
            raise SystemExit(e)

job.commit()
logger.info("JOB COMPLETE!!")
