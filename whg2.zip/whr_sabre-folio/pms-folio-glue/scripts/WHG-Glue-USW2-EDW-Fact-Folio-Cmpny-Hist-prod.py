#######################################################################################################################
# Main Module: WHG-Glue-USW2-EDW-Fact-Folio-Cmpny-Dtl-Hist-{env}.py
# Called Common Module: whg_edwCommon.py
# Source: dwstg.stg_folio_cmpny_dtl_hist
# Destination: dw.fact_folio_cmpny_dtl
# This job will read the data from redshift staging table,perform upsert into Redshift DW fact tables
#######################################################################################################################
import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.dynamicframe import DynamicFrame
from awsglue.job import Job
import boto3
import base64
from botocore.exceptions import ClientError
import json
import time
import logging
import configparser
import datetime
from datetime import date
import pandas as pd
import traceback
from pyspark.sql.functions import *
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DecimalType, LongType
from pyspark.sql.window import Window
import os
import ast
import whg_edwCommon as CommonMod
import pyspark.sql.functions as F

"""This will Initialise the Spark Session and will set relevant configuration"""
args = getResolvedOptions(sys.argv, ['JOB_NAME', 'config_name', 'input_type', 'output_type', 'env', 'ESLogGroup'])
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
spark.conf.set("spark.sql.legacy.timeParserPolicy", "LEGACY")
job = Job(glueContext)

"""Initializing the logger Here"""
logging.basicConfig()
logger = logging.getLogger()
logger.setLevel(logging.INFO)

"""Read the Args & config file"""
job_name = args['JOB_NAME']
config_name = args['config_name']
input_type = args['input_type']
output_type = args['output_type']
env = args['env']
es_log_group_nm = args['ESLogGroup']
params = configparser.ConfigParser()
params.read(config_name)
region_name = params['common_configs']['region_name']
input_table = params['common_configs']['input_table']
target_table = params['common_configs']['target_table']
read_format = params['common_configs']['src_read_format']
process_name = params['common_configs']['process_name']
src_key_pair = params['common_configs']['src_key_pair']
tgt_write_format = params['common_configs']['tgt_write_format']
stg_err_table = params['common_configs']['stg_err_table']
stg_audit_table = params['common_configs']['stg_audit_table']
site_key_lkp_query = params['common_configs']['site_key_lkp_query']
site_lkp_query = params['common_configs']['site_lkp_query']
calendar_table = params['common_configs']['calendar_table']
site_key_table = params['common_configs']['site_key_table']
site_table = params['common_configs']['site_table']
feed_typ = params['common_configs']['feed_typ']
marker_loc = params['common_configs']['marker_loc']
src_query = params['common_configs']['src_query']
tgt_query = params['common_configs']['tgt_query']

input_path = params[env]['input_path']
target_db = params[env]['target_db']
DWSTG_redshiftconnection = params[env]['DWSTG_redshiftconnection']
DW_redshiftconnection = params[env]['DW_redshiftconnection']
sns_topic_arn = params[env]['sns_topic_arn']
blue_bucket = params[env]['blue_bucket']
rs_tmp_dir = params[env]['rs_tmp_dir']
source_system = params['common_configs']['source_system']
task_name = params['common_configs']['task_name']

src_key_pair = ast.literal_eval(src_key_pair)
src_key_pair_nm = "~".join(src_key_pair)
MARKER_FILE = marker_loc + job_name

job.init(job_name, args)

src_table = input_table

"""Flow class that maintains the state of the flow"""


class CoreDriverFlow(object):
    def __init__(self):
        self.site_key_lkp_df = None
        self.site_lkp_df = None
        self.calendar_lkp_df = None
        self.src_df = None
        self.tgt_df = None
        self.input_df = None
        self.write_df = None
        self.final_insert_df = None
        self.final_update_df = None
        self.delta_df = None
        self._error_count = 0
        self.tgt_skip_cnt = 0
        self._src_tot_cnt = 0
        self._tgt_sucss_cnt = 0
        self.cnt = 0
        self.status = "Success"
        self.error_message = ""
        self.input_file_path = input_path

    def run(self):
        self.start_time = datetime.datetime.now()
        logger.info("Process started: " + str(self.start_time))
        try:
            logger.info("Started - Reading Data Source")
            
            #self.src_df = CommonMod.read_input_source_db(spark, glueContext, 'db', src_table, src_query,
                                                         #DWSTG_redshiftconnection, target_db, process_name, job_name,
                                                         #sns_topic_arn, region_name)
             
            print(input_path)                                            
            self.src_df = CommonMod.read_input_source_file_bookmark(spark, glueContext, 'file', read_format,
                                                                      input_path, process_name, job_name, sns_topic_arn,
                                                                      region_name)
            self.src_df.show()
            
            logger.info("Started - Reading site key lkp")
            logger.info(site_key_lkp_query)
            self.site_key_lkp_df = CommonMod.read_input_source_db(spark, glueContext, 'dbq', site_key_table,
                                                                  site_key_lkp_query,
                                                                  DW_redshiftconnection, target_db, process_name,
                                                                  job_name,
                                                                  sns_topic_arn, region_name)
            self.site_key_lkp_df.printSchema()
            logger.info("Started - Reading site lkp")
            logger.info(site_lkp_query)
            self.site_lkp_df = CommonMod.read_input_source_db(spark, glueContext, 'dbq', site_table, site_lkp_query,
                                                              DW_redshiftconnection, target_db, process_name, job_name,
                                                              sns_topic_arn, region_name)
            
            logger.info("Started - Reading calendar lkp")
            self.calendar_lkp_df = CommonMod.read_input_source_db(spark,glueContext,'db',calendar_table,src_query,
                                                              DW_redshiftconnection,target_db,process_name,job_name,
                                                              sns_topic_arn,region_name)
            
            self._src_tot_cnt = self.src_df.count()

            logger.info("Completed - Reading of Data Source")
            if self._src_tot_cnt == 0:
                logger.info(
                    'No Data to process for Glue job-{} for {} run'.format(job_name, str(datetime.datetime.now())))
                alert_msg_body = "No Data to Process for Glue Job - {} for run {}".format(job_name,
                                                                                          str(datetime.datetime.now()))
                alert_msg_sub = "No Data to Process for Glue Job - {}".format(job_name)
                CommonMod.notifymsg(sns_topic_arn, alert_msg_sub, alert_msg_body, region_name)
            else:
                logger.info("Started - DW Transformations")
                self.dw_transformations()
                logger.info("Completed - DW Transformations Done")
                
                logger.info("Started - Inserting Data Source")
                pre_query = "delete from {};".format(target_table)
                post_query = "begin;end;"
                CommonMod.write_details_db(glueContext, output_type, self.final_df, target_table, target_db,
                                           DW_redshiftconnection, pre_query, post_query, rs_tmp_dir, process_name,
                                           job_name, sns_topic_arn, region_name)
                self._tgt_sucss_cnt = self.cnt
                self.tgt_skip_cnt = self._src_tot_cnt - self._tgt_sucss_cnt
                logger.info("Completed - Inserting Data Source")
                logger.info("Completed - Writing of Data Source")

                logger.info("Started - creation of marker file")
                CommonMod.marker_func(sns_topic_arn, blue_bucket, region_name, MARKER_FILE, job_name, process_name)
                logger.info("Completed - creation of marker file")

        except Exception as e:
            logger.info("Error while executing process. Process Failed")
            traceback.print_exc()
            self.error_message = str(e)
            logger.info("Started - Updating Audit error table")
            filename = input_table
            CommonMod.error_update(glueContext, DWSTG_redshiftconnection, target_db, rs_tmp_dir,source_system, job_name,feed_typ,input_table,
                                   src_key_pair_nm, self.error_message, stg_err_table,sns_topic_arn,process_name)
            logger.info("completed - Updating Audit error table")
            self.status = "ERROR"
            exit(1)

        finally:
            logger.info("Started - Updating Audit control table")
            CommonMod.audit_update(glueContext, DWSTG_redshiftconnection, target_db, rs_tmp_dir, job_name,source_system,
                                   self.start_time, feed_typ,input_table, self._src_tot_cnt, target_table,
                                   self._tgt_sucss_cnt, self._error_count, stg_audit_table,sns_topic_arn,process_name,self.tgt_skip_cnt)
            logger.info("completed - Updating Audit control table")
            logger.info("Started - Generating logs to ES")
            CommonMod.streaminfo(es_log_group_nm, job_name, region_name, sns_topic_arn,
                                CommonMod.generateESLogs(source_system, job_name, task_name, self.status,input_table,
                                                         target_table, src_key_pair_nm, self.error_message,
                                                         self._src_tot_cnt, self._tgt_sucss_cnt, self._error_count,
                                                         sns_topic_arn),process_name)
            logger.info("Completed - Generating logs to ES")
            end_time = datetime.datetime.now()

        logger.info("Process completed: " + str(end_time))

    def dw_transformations(self):
        start_time = self.start_time
        self.audit_dt = date.today().strftime('%Y%m%d')
        try:
            column_list = self.src_df.columns
            input_df = self.src_df.dropDuplicates()
            for x in input_df.columns:
                input_df = input_df.withColumn(x, when(col(x) == '', None).otherwise(col(x)))
            input_df = input_df.withColumn("audit_load_ingstn_id",lit(self.audit_dt))
            input_df = input_df.drop("bus_dt_key","chg_dt_key","site_key")
            input_df = input_df.withColumnRenamed('BRAND_ID','brnd_id').withColumnRenamed('SITE_ID','site_id').withColumnRenamed('CHRG_DT','chrg_dt').withColumnRenamed('TRANS_ID','trans_id') 
            input_df = input_df.withColumn("bus_dt", to_date(input_df.BUS_DT, 'yyyy-mm-dd'))
            
            # calendar lookup join
            calendar_lkp_df = self.calendar_lkp_df.select("cal_dt", "dt_key").dropDuplicates(["cal_dt"])
            input_df = input_df.join(calendar_lkp_df, [input_df.bus_dt == calendar_lkp_df.cal_dt], "left_outer").drop("cal_dt")
            input_df = input_df.withColumnRenamed("dt_key", "bus_dt_key")
            input_df = input_df.withColumn('bus_dt_key', coalesce(col('bus_dt_key'),lit(0)))
            input_df = input_df.join(calendar_lkp_df, [input_df.chrg_dt == calendar_lkp_df.cal_dt],"left_outer").drop("cal_dt")
            input_df = input_df.withColumnRenamed("dt_key", "chrg_dt_key")
            input_df = input_df.withColumn('chrg_dt_key', coalesce(col('chrg_dt_key'), lit(0)))
            
            input_df.printSchema()
           
            # site_key lookup
            input_df = input_df.join(self.site_key_lkp_df.alias("site_key_lkp"), [input_df.bus_dt == self.site_key_lkp_df.bus_dt,
                                                            trim(input_df.site_id) == trim(self.site_key_lkp_df.site_id)],
                                                    'left_outer').drop(self.site_key_lkp_df.bus_dt).drop(self.site_key_lkp_df.site_id).withColumnRenamed("site_key", "site_key_lkp_site_key")
            
            input_df.printSchema()
            # site lookup
            input_df = input_df.join(self.site_lkp_df.alias("site_lkp"), [trim(input_df.site_id) == trim(self.site_lkp_df.site_id),
                                                        trim(input_df.brnd_id) == trim(self.site_lkp_df.brand_id)],
                                                    'left_outer').drop(self.site_lkp_df.site_id).drop(self.site_lkp_df.brand_id).withColumnRenamed("site_key", "site_lkp_site_key")
            input_df.printSchema()
            input_df = input_df.withColumn('site_key', coalesce(col('site_key_lkp_site_key'),col('site_lkp_site_key'),lit(0)))
            
            input_df = input_df.withColumn("folio_conf_hash_key", F.md5(concat_ws("||", array(['brnd_id', 'site_id', 'bus_dt', 'trans_id'])))) \
                                .withColumn("folio_hash_key", F.md5(concat_ws("||", array(['brnd_id', 'site_id', 'bus_dt'])))).withColumn("chrg_ts", (concat_ws(" ", input_df.chrg_dt, input_df.CHARGE_TIME))) 
                                
            window_agent = Window.partitionBy(col("brnd_id"),col("site_id"),col("bus_dt"),col("trans_id")).orderBy(col("folio_conf_hash_key").desc())
            input_df = input_df.withColumn("rank",row_number().over(window_agent)).filter(col("rank") == 1).drop("rank")

            input_df = input_df.withColumn("cc_lastfour_dgt",input_df["cc_lastfour_dgt"].substr(0,4).cast(IntegerType()))
            self.final_df = input_df.withColumn("curr_rec_ind", lit('Y')) \
													.withColumn("insrt_by", lit(job_name)) \
													.withColumn("insrt_ts",lit(datetime.datetime.now())) \
													.withColumn("lst_updt_by",lit(job_name)) \
													.withColumn("lst_updt_ts",lit(datetime.datetime.now())) \
													.withColumn("qrntn_flg",lit('N')) \
                                                    .withColumn("amt",input_df["amt_usd"].cast(DecimalType(25,4))) \
													.withColumn("is_tax_exmpt_dscr", lit(None).cast(StringType())) \
													.withColumnRenamed('charge_time','chrg_tm') \
													.withColumnRenamed('chrg_desc','chrg_dscr') \
													.withColumnRenamed('pms_id','pms_conf_num') \
                                                    .withColumnRenamed('comp_nm','pms_cmpny_acct_nm') \
                                                    .withColumnRenamed('comp_id','crs_cmpny_acct_id') \
                                                    .withColumnRenamed('bas_typ','base_typ') \
                                                    .withColumnRenamed('commod_cd','edw_typ') \
                                                    .withColumnRenamed('cc_lastfour_dgt','cc_lstfour_dgt') \
                                                    .withColumnRenamed('from_folio','frm_folio_acct_num') \
                                                    .withColumnRenamed('from_crs_conf','frm_crs_conf_num') \
                                                    .withColumnRenamed('tax_on_item','tax_on_itm_id') \
                                                    .withColumnRenamed('adj_on_item','adjstd_itm_id') \
                                                    .withColumnRenamed('is_tax_exempt','is_tax_exmpt') \
                                                    .withColumnRenamed('is_aud_pst','is_audt_pstng') \
                                                    .withColumnRenamed('clerk_id','clrk_id') \
                                                    .withColumnRenamed('clerk_name','clrk_nm') \
                                            .select('folio_hash_key',
                                                    'folio_conf_hash_key',
                                                    substring(col('brnd_id'),0,30).alias('brnd_id'),
                                                    col('site_key').cast(LongType()).alias('site_key'),
                                                    substring(col('site_id'),0,10).alias('site_id'),
                                                    col('bus_dt_key').cast(LongType()).alias('bus_dt_key'),
                                                    'bus_dt',
                                                    col('pms_conf_num').cast(StringType()).substr(0,30).alias('pms_conf_num'),
                                                    substring(col('pms_cmpny_acct_nm'),0,100).alias('pms_cmpny_acct_nm'),
                                                    substring(col('crs_cmpny_acct_id'),0,30).alias('crs_cmpny_acct_id'),
                                                    substring(col('trans_id'),0,50).alias('trans_id'),
                                                    col('chrg_dt_key').cast(LongType()).alias('chrg_dt_key'),
                                                    to_date(col('chrg_dt'),'yyyy-mm-dd').alias('chrg_dt'),
                                                    substring(col('chrg_tm'),0,12).alias('chrg_tm'),
                                                    to_timestamp(col('chrg_ts'),'yyyy-mm-dd hh:mm:ss').alias('chrg_ts'),
                                                    substring(col('chrg_cd'),0,12).alias('chrg_cd'),
                                                    substring(col('chrg_dscr'),0,250).alias('chrg_dscr'),
                                                    substring(col('trans_typ'),0,10).alias('trans_typ'),
                                                    substring(col('base_typ'),0,10).alias('base_typ'),
                                                    substring(col('edw_typ'),0,10).alias('edw_typ'),
                                                    substring(col('cc_lstfour_dgt'),0,4).alias('cc_lstfour_dgt'),
                                                    substring(col('gl_cd'),0,40).alias('gl_cd'),
                                                    'amt',
                                                    substring(col('frm_folio_acct_num'),0,30).alias('frm_folio_acct_num'),
                                                    substring(col('frm_crs_conf_num'),0,30).alias('frm_crs_conf_num'),
                                                    col('is_audt_pstng').cast(StringType()).substr(0,5).alias('is_audt_pstng'),
                                                    substring(col('tax_on_itm_id'),0,50).alias('tax_on_itm_id'),
                                                    substring(col('adjstd_itm_id'),0,50).alias('adjstd_itm_id'),
                                                    col('is_tax_exmpt').cast(StringType()).substr(0,10).alias('is_tax_exmpt'),
                                                    substring(col('is_tax_exmpt_dscr'),0,20).alias('is_tax_exmpt_dscr'),
                                                    col('clrk_id').cast(StringType()).substr(0,50).alias('clrk_id'),
                                                    substring(col('clrk_nm'),0,100).alias('clrk_nm'),
													'curr_rec_ind',
													'qrntn_flg',
													'insrt_by',
													'insrt_ts',
													'lst_updt_by',
													'lst_updt_ts')
            self.final_df.printSchema()
            self.cnt = self.final_df.cache().count()
            self.final_df.show()
            
        except Exception as e:
            logger.error(str(e))
            logger.info("uncaught error while executing flow. Error Msg: {0}".format(str(e)))
            f_msg = " Error while prep parquet for {}, failed with error: {}".format(process_name, str(e))
            f_sub = "Error while prep parquet for Glue Job {}".format(job_name)
            CommonMod.notifymsg(sns_topic_arn, f_sub, f_msg, region_name)
            raise


def main():
    core = CoreDriverFlow()
    core.run()


if __name__ == '__main__':
    s3Client = boto3.client('s3', region_name)
    job_run = True
    try:
        response = s3Client.head_object(Bucket=blue_bucket, Key=MARKER_FILE)
        logger.info(response)
        if response:
            logger.info("********[INFO] JOB ALREADY EXECUTED ***********")
            job_run = False
    except Exception as HeadObjectException:
        logger.info(HeadObjectException)
    if job_run:
        main()

job.commit()
