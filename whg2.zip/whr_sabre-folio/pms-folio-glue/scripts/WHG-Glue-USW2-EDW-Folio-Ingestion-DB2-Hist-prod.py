################################################################################################################
# Main Module: WHG-Glue-USW2-Edw-Folio-Ingestion-Hist-{env}.py
# Called Common Module: whg_edwCommon.py
# Source: DB2
# Destination: s3://whg-s3-usw2a-redterminal-{env}/;s3://s3://whg-s3-usw2a-blueterminal-{env}/;DWSTG
# Ingestion framework to pull the data from DBs to Data Airport and DWSTG
################################################################################################################
import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
import boto3
import base64
from botocore.exceptions import ClientError
import json
import time
import logging
import configparser
import datetime
from datetime import date
import pandas as pd
import traceback
from pyspark.sql.functions import *
import os
import ast
import whg_edwCommon as CommonMod

"""This will Initialise the Spark Session and will set relevant configuration"""
args = getResolvedOptions(sys.argv, ['JOB_NAME', 'config_name', 'env','ESLogGroup'])
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
spark.conf.set("spark.sql.legacy.timeParserPolicy","LEGACY")
job = Job(glueContext)

"""Initializing the logger Here"""
logging.basicConfig()
logger = logging.getLogger()
logger.setLevel(logging.INFO)

"""Read the Args & config file"""
job_name = args['JOB_NAME']
config_name = args['config_name']
env = args['env']
es_log_group_nm = args['ESLogGroup']
params = configparser.ConfigParser()
params.read(config_name)
region_name = params['common_configs']['region_name']
input_table = params['common_configs']['input_table']
source_query = params['common_configs']['source_query']
read_format = params['common_configs']['src_read_format']
target_table = params['common_configs']['target_table']
process_name = params['common_configs']['process_name']
src_key_pair = params['common_configs']['src_key_pair']
RedTerminal_write_format = params['common_configs']['RedTerminal_write_format']
BlueTerminal_write_format = params['common_configs']['BlueTerminal_write_format']
err_write_format = params['common_configs']['err_write_format']
stg_err_table = params['common_configs']['stg_err_table']
stg_audit_table = params['common_configs']['stg_audit_table']
feed_typ = params['common_configs']['feed_typ']
marker_loc = params['common_configs']['marker_loc']
source_system = params['common_configs']['source_system']
task_name = params['common_configs']['task_name']

input_path = params[env]['input_path']
RedTerminal_target_path = params[env]['RedTerminal_target_path']
BlueTerminal_target_path = params[env]['BlueTerminal_target_path']
redshiftconnection = params[env]['redshiftconnection']
sns_topic_arn = params[env]['sns_topic_arn']
blue_bucket = params[env]['blue_bucket']
rs_tmp_dir = params[env]['rs_tmp_dir']
target_db = params[env]['target_db']
connection = params[env]['DB2_connection']
service_name = params[env]['DB2_service_name']

src_key_pair = ast.literal_eval(src_key_pair)
src_key_pair_nm = "~".join(src_key_pair)
MARKER_FILE = marker_loc + job_name + "-" + process_name

job.init(job_name,args)

"""Flow class that maintains the state of the flow"""
class CoreDriverFlow(object):
    def __init__(self):
        self.input_df = None
        self.final_df = None
        self._error_count = 0
        self._tgt_sucss_cnt = 0
        self.tgt_skip_cnt = 0
        self._src_tot_cnt = 0
        self.status = "Success"
        self.error_message = ""

    def run(self):
        self.start_time = datetime.datetime.now()
        logger.info("Process started: " + str(self.start_time))
        try:
            logger.info("Started - Reading Data Source")
            url, user, password = CommonMod.get_db_credentials(glueContext, connection, job_name, region_name)
            url_db_dest = url + '/' + service_name
            self.input_df = spark.read.format("jdbc") \
                .option("driver", "com.ibm.db2.jcc.DB2Driver") \
                .option("url", url_db_dest) \
                .option("query", source_query) \
                .option("user", user) \
                .option("password", password) \
                .load()
            
            self.input_df.printSchema()
            self._src_tot_cnt = self.input_df.count()
            logger.info("Completed - Reading of Data Source")

            if self._src_tot_cnt == 0:
                logger.info('No Data to process for Glue job-{} for {} run'.format(job_name,str(datetime.datetime.now())))
                alert_msg_body = "No Data to Process for Glue Job - {} for run {}".format(job_name,str(datetime.datetime.now()))
                alert_msg_sub = "No Data to Process for Glue Job - {}".format(job_name)
                CommonMod.notifymsg(sns_topic_arn, alert_msg_sub, alert_msg_body, region_name)
            else:
                logger.info("Started - Writing Data Source")
                redTerminal_df = self.input_df
                logger.info("Started - Writing to Red Terminal")
                redTerminal_df.write.mode("overwrite").option("header", "true").csv(RedTerminal_target_path)
                logger.info("Completed - Writing to Red Terminal")
                logger.info("Started - Writing to Blue Terminal")
                blueTerminal_df = redTerminal_df.dropDuplicates()
                cnt = blueTerminal_df.cache().count()
                blueTerminal_df = blueTerminal_df.withColumn("insrt_ts", lit(datetime.datetime.now())) \
                                                .withColumn("audit_load_ingstn_id",lit(date.today().strftime('%Y%m%d')))
                CommonMod.write_details_file('file', blueTerminal_df, BlueTerminal_target_path, BlueTerminal_write_format, process_name,
                                             job_name, sns_topic_arn, region_name)
                logger.info("Completed - Writing to Blue Terminal")
                logger.info("Started - Writing to Redshift DWSTG")
                self.final_df = blueTerminal_df.drop("audit_load_ingstn_id")
                pre_query = "delete from {};".format(target_table)
                post_query = "begin;end;"
                CommonMod.write_details_db(glueContext, 'db', self.final_df, target_table, target_db,
                                           redshiftconnection, pre_query, post_query, rs_tmp_dir, process_name,
                                           job_name, sns_topic_arn, region_name)
                logger.info("Completed - Writing to Redshift DWSTG")
                self._tgt_sucss_cnt = cnt
                self.tgt_skip_cnt = self._src_tot_cnt - self._tgt_sucss_cnt
                logger.info("Completed - Writing of Data Source")

                logger.info("Started - creation of marker file")
                CommonMod.marker_func(sns_topic_arn, blue_bucket, region_name, MARKER_FILE, job_name, process_name)
                logger.info("Completed - creation of marker file")

        except Exception as e:
            logger.info("Error while executing process. Process Failed")
            traceback.print_exc()
            self.error_message = str(e)
            glue_env = job_name.rsplit('-', 1)[1]
            glue_name = job_name
            alert_msg_sub = "{0}-{1}-{2}-{3}".format("P3", "PSS AWS", glue_env, glue_name)
            alert_msg = "Error while Ingestion for {}, failed with error: {}".format(job_name, str(e))
            alert_msg_body = "Priority: {0}\n Assignment Team: {1}\n Impacted System: Voice\n Type: {2}\n \
                                          AWS Component: {3}\n \
                                          Environment: {4}\n \
                                          {5}".format("P3", "PSS AWS", "Exception in Ingestion", glue_name, glue_env,
                                                      alert_msg)
            CommonMod.notifymsg(sns_topic_arn, alert_msg_sub, alert_msg_body, region_name)
            logger.info("Started - Updating Audit error table")
            filename = input_table
            #CommonMod.error_update(glueContext, redshiftconnection, target_db, rs_tmp_dir, job_name, input_table,src_key_pair_nm, self.error_message, stg_err_table, filename)
            CommonMod.error_update(glueContext,redshiftconnection,target_db,rs_tmp_dir,source_system, job_name, feed_typ, input_table,src_key_pair_nm,self.error_message,stg_err_table,sns_topic_arn,process_name)
            logger.info("completed - Updating Audit error table")
            self.status = "ERROR"
            exit(1)

        finally:
            logger.info("Started - Updating Audit control table")
            #CommonMod.audit_update(glueContext, redshiftconnection, target_db, rs_tmp_dir, job_name, self.start_time, feed_typ, input_table,self._src_tot_cnt, target_table, self._tgt_sucss_cnt, self._error_count,stg_audit_table)
            CommonMod.audit_update(glueContext, redshiftconnection, target_db, rs_tmp_dir, job_name,source_system, self.start_time, feed_typ, input_table,self._src_tot_cnt, target_table, self._tgt_sucss_cnt, self._error_count,stg_audit_table,sns_topic_arn,process_name, self.tgt_skip_cnt)
            logger.info("completed - Updating Audit control table")
            logger.info("Started - Generating logs to ES")
            CommonMod.streaminfo(es_log_group_nm, job_name, region_name, sns_topic_arn,
                                 CommonMod.generateESLogs(source_system, job_name, task_name, self.status, input_table,
                                                          target_table, src_key_pair_nm, self.error_message,
                                                          self._src_tot_cnt, self._tgt_sucss_cnt, self._error_count,
                                                          sns_topic_arn),process_name)
            logger.info("Completed - Generating logs to ES")
            end_time = datetime.datetime.now()

        logger.info("Process completed: " + str(end_time))

def main():
    core = CoreDriverFlow()
    core.run()

if __name__ == '__main__':
    s3Client = boto3.client('s3', region_name)
    job_run = True
    try:
        response = s3Client.head_object(Bucket=blue_bucket, Key=MARKER_FILE)
        logger.info(response)
        if response:
            logger.info("********[INFO] JOB ALREADY EXECUTED ***********")
            job_run = False
    except Exception as HeadObjectException:
        logger.info(HeadObjectException)
    if job_run:
        main()

job.commit()