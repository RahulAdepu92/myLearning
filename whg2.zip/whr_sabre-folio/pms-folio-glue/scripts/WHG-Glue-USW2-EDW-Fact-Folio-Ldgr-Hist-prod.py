#######################################################################################################################
# Main Module: WHG-Glue-USW2-EDW-Fact-Folio-Ldgr-Dtl-Hist-{env}.py
# Called Common Module: whg_edwCommon.py
# Source: dwstg.stg_folio_ldgr_dtl
# Destination: dw.fact_folio_ldgr_dtl
# This job will read the data from redshift staging table,perform upsert into Redshift DW fact tables
#######################################################################################################################
import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.dynamicframe import DynamicFrame
from awsglue.job import Job
import boto3
import base64
from botocore.exceptions import ClientError
import json
import time
import logging
import configparser
import datetime
from datetime import date
import pandas as pd
import traceback
from pyspark.sql.functions import *
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DecimalType, LongType
from pyspark.sql.window import Window
import os
import ast
import whg_edwCommon as CommonMod
import pyspark.sql.functions as F

"""This will Initialise the Spark Session and will set relevant configuration"""
args = getResolvedOptions(sys.argv, ['JOB_NAME', 'config_name', 'input_type', 'output_type', 'env', 'ESLogGroup'])
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
spark.conf.set("spark.sql.legacy.timeParserPolicy", "LEGACY")
job = Job(glueContext)

"""Initializing the logger Here"""
logging.basicConfig()
logger = logging.getLogger()
logger.setLevel(logging.INFO)

"""Read the Args & config file"""
job_name = args['JOB_NAME']
config_name = args['config_name']
input_type = args['input_type']
output_type = args['output_type']
env = args['env']
es_log_group_nm = args['ESLogGroup']
params = configparser.ConfigParser()
params.read(config_name)
region_name = params['common_configs']['region_name']
input_table = params['common_configs']['input_table']
target_table = params['common_configs']['target_table']
process_name = params['common_configs']['process_name']
src_key_pair = params['common_configs']['src_key_pair']
tgt_write_format = params['common_configs']['tgt_write_format']
stg_err_table = params['common_configs']['stg_err_table']
stg_audit_table = params['common_configs']['stg_audit_table']
feed_typ = params['common_configs']['feed_typ']
marker_loc = params['common_configs']['marker_loc']
src_query = params['common_configs']['src_query']
tgt_query = params['common_configs']['tgt_query']
read_format = params['common_configs']['src_read_format']
input_path = params[env]['input_path']
target_path = params[env]['target_path']
target_db = params[env]['target_db']
DWSTG_redshiftconnection = params[env]['DWSTG_redshiftconnection']
DW_redshiftconnection = params[env]['DW_redshiftconnection']
sns_topic_arn = params[env]['sns_topic_arn']
blue_bucket = params[env]['blue_bucket']
rs_tmp_dir = params[env]['rs_tmp_dir']
source_system = params['common_configs']['source_system']
task_name = params['common_configs']['task_name']

site_key_lkp_query = params['common_configs']['site_key_lkp_query']
site_lkp_query = params['common_configs']['site_lkp_query']
calendar_table = params['common_configs']['calendar_table']

src_key_pair = ast.literal_eval(src_key_pair)
src_key_pair_nm = "~".join(src_key_pair)
MARKER_FILE = marker_loc + job_name

job.init(job_name, args)

src_table = input_table

"""Flow class that maintains the state of the flow"""


class CoreDriverFlow(object):
    def __init__(self):
        self.site_key_lkp_df = None
        self.site_lkp_df = None
        self.calendar_lkp_df = None
        self.src_df = None
        self.input_df = None
        self.write_df = None
        self.final_insert_df = None
        self.tgt_skip_cnt = 0
        self.final_update_df = None
        self.delta_df = None
        self._error_count = 0
        self._src_tot_cnt = 0
        self._tgt_sucss_cnt = 0
        self.cnt = 0
        self.status = "Success"
        self.error_message = ""

    def run(self):
        self.start_time = datetime.datetime.now()
        logger.info("Process started: " + str(self.start_time))
        try:
            logger.info("Started - Reading Data Source")
            
            
            self.src_df = CommonMod.read_input_source_file_bookmark(spark, glueContext, input_type, read_format,input_path, process_name, job_name, sns_topic_arn,region_name)                                             
            self.src_df.show()
            self.src_df.printSchema()

            logger.info("Started - Reading site key lkp")
            logger.info(site_key_lkp_query)
            self.site_key_lkp_df = CommonMod.read_input_source_db(spark, glueContext, 'dbq', src_table,
                                                                  site_key_lkp_query,
                                                                  DW_redshiftconnection, target_db, process_name,
                                                                  job_name,
                                                                  sns_topic_arn, region_name)

            logger.info("Started - Reading site lkp")
            logger.info(site_lkp_query)
            self.site_lkp_df = CommonMod.read_input_source_db(spark, glueContext, 'dbq', src_table, site_lkp_query,
                                                              DW_redshiftconnection, target_db, process_name, job_name,
                                                              sns_topic_arn, region_name)
            
            logger.info("Started - Reading calendar lkp")
            self.calendar_lkp_df = CommonMod.read_input_source_db(spark,glueContext,'db',calendar_table,src_query,
                                                              DW_redshiftconnection,target_db,process_name,job_name,
                                                              sns_topic_arn,region_name)
                                                         
                    
            
            self._src_tot_cnt = self.src_df.count()

            logger.info("Completed - Reading of Data Source")
            if self._src_tot_cnt == 0:
                logger.info(
                    'No Data to process for Glue job-{} for {} run'.format(job_name, str(datetime.datetime.now())))
                alert_msg_body = "No Data to Process for Glue Job - {} for run {}".format(job_name,
                                                                                          str(datetime.datetime.now()))
                alert_msg_sub = "No Data to Process for Glue Job - {}".format(job_name)
                CommonMod.notifymsg(sns_topic_arn, alert_msg_sub, alert_msg_body, region_name)
            else:

                logger.info("Started - DW Transformations")
                self.dw_transformations()
                logger.info("Completed - DW Transformations Done")

                logger.info("Started - Inserting Data Source")
                pre_query = "delete from {};".format(target_table)
                post_query = "begin;end;"
                CommonMod.write_details_db(glueContext, output_type, self.final_df, target_table, target_db,
                                           DW_redshiftconnection, pre_query, post_query, rs_tmp_dir, process_name,
                                           job_name, sns_topic_arn, region_name)
                self._tgt_sucss_cnt = self.cnt
                self.tgt_skip_cnt = self._src_tot_cnt - self._tgt_sucss_cnt
                logger.info("Completed - Inserting Data Source")
                logger.info("Completed - Writing of Data Source")

                logger.info("Started - creation of marker file")
                CommonMod.marker_func(sns_topic_arn, blue_bucket, region_name, MARKER_FILE, job_name, process_name)
                logger.info("Completed - creation of marker file")

        except Exception as e:
            logger.info("Error while executing process. Process Failed")
            traceback.print_exc()
            self.error_message = str(e)
            logger.info("Started - Updating Audit error table")
            filename = input_table
            CommonMod.error_update(glueContext, DWSTG_redshiftconnection, target_db, rs_tmp_dir,source_system, job_name, feed_typ,input_table,
                                   src_key_pair_nm, self.error_message, stg_err_table, sns_topic_arn,process_name)
            logger.info("completed - Updating Audit error table")
            self.status = "ERROR"
            exit(1)

        finally:
            logger.info("Started - Updating Audit control table")
            CommonMod.audit_update(glueContext, DWSTG_redshiftconnection, target_db, rs_tmp_dir, job_name,source_system,
                                   self.start_time, feed_typ, input_table, self._src_tot_cnt, target_table,
                                   self._tgt_sucss_cnt, self._error_count, stg_audit_table,sns_topic_arn,process_name, self.tgt_skip_cnt)
            logger.info("completed - Updating Audit control table")
            logger.info("Started - Generating logs to ES")
            CommonMod.streaminfo(es_log_group_nm, job_name, region_name, sns_topic_arn,
                                CommonMod.generateESLogs(source_system, job_name, task_name, self.status, input_table,
                                                         target_table, src_key_pair_nm, self.error_message,
                                                         self._src_tot_cnt, self._tgt_sucss_cnt, self._error_count,
                                                         sns_topic_arn),process_name)
            logger.info("Completed - Generating logs to ES")
            end_time = datetime.datetime.now()

        logger.info("Process completed: " + str(end_time))

    def dw_transformations(self):
        start_time = self.start_time
        self.audit_dt = date.today().strftime('%Y%m%d')
        try:
            col_list = self.src_df.columns
            input_df = self.src_df.dropDuplicates(col_list[:-2])
            input_df = input_df.withColumn("audit_load_ingstn_id",lit(self.audit_dt))

            input_df = input_df.withColumnRenamed("BUS_DT", "bus_dt") \
                               .withColumnRenamed("SITE_ID", "site_id") \
                               .withColumnRenamed("BRAND_ID", "brnd_id") \
                               .withColumnRenamed('LGR_DT','ldgr_dt') \
                    

            input_df = input_df.withColumn("bus_dt", to_date(col("bus_dt"), "yyyy-MM-dd")) \
                               .withColumn("ldgr_dt", to_date(col("ldgr_dt"), "yyyy-MM-dd"))


               # calendar lookup join to dervive bus_dt_key
            calendar_lkp_df = self.calendar_lkp_df.select("cal_dt", "dt_key").dropDuplicates(["cal_dt"])
            input_df = input_df.join(calendar_lkp_df.alias("cal"), [input_df.bus_dt == calendar_lkp_df.cal_dt], "left_outer").drop("cal.cal_dt")
            input_df = input_df.withColumnRenamed("dt_key", "bus_dt_key")
            input_df = input_df.withColumn('bus_dt_key', coalesce(col('bus_dt_key'),lit(0))).drop(col('cal_dt'))

            print('before processing')
            input_df.printSchema()
            calendar_lkp_df.printSchema()

            calendar_lkp2_df = self.calendar_lkp_df.select("cal_dt", "dt_key").dropDuplicates(["cal_dt"])
            input_df = input_df.join(calendar_lkp2_df.alias("cal"), [input_df.ldgr_dt == calendar_lkp2_df.cal_dt], "left_outer").drop("cal.cal_dt")
            input_df = input_df.withColumnRenamed("dt_key", "ldgr_dt_key")
            input_df = input_df.withColumn('ldgr_dt_key', coalesce(col('ldgr_dt_key'),lit(0))).drop(col('cal_dt'))
            
            # site_key lookup
            input_df = input_df.join(self.site_key_lkp_df.alias("site_key_lkp"), [input_df.bus_dt == self.site_key_lkp_df.bus_dt,
                                                            trim(input_df.site_id) == trim(self.site_key_lkp_df.site_id)],
                                                    'left_outer').drop(self.site_key_lkp_df.bus_dt).drop(self.site_key_lkp_df.site_id).withColumnRenamed("site_key", "site_key_lkp_site_key")
            
            # site lookup
            input_df = input_df.join(self.site_lkp_df.alias("site_lkp"), [trim(input_df.site_id) == trim(self.site_lkp_df.site_id),
                                                        trim(input_df.brnd_id) == trim(self.site_lkp_df.brand_id)],
                                                    'left_outer').drop(self.site_lkp_df.site_id).drop(self.site_lkp_df.brand_id).withColumnRenamed("site_key", "site_lkp_site_key")
            
            input_df = input_df.withColumn('site_key', coalesce(col('site_key_lkp_site_key'),col('site_lkp_site_key'),lit(0)))

            #deduplication
            window_agent = Window.partitionBy(col("brnd_id"),col("site_id"),col("bus_dt"),col("ldgr_dt")). \
                          orderBy(col("brnd_id").desc(),col("site_id").desc(),col("bus_dt").desc(),col("ldgr_dt").desc())
            input_df = input_df.withColumn("rank",row_number().over(window_agent)).filter(col("rank") == 1).drop("rank")

            input_df = input_df.withColumn("folio_hash_key", F.md5(concat_ws("||", array(['brnd_id', 'site_id', 'bus_dt','ldgr_dt']))))
            
            
            self.final_df = input_df.withColumn('curr_rec_ind', lit('Y')) \
                                            .withColumn('qrntn_flg', lit('N'))\
                                            .withColumn("insrt_by", lit(job_name)) \
                                            .withColumn("insrt_ts", lit(datetime.datetime.now())) \
                                            .withColumn("lst_updt_by", lit(job_name)) \
                                            .withColumn("lst_updt_ts", lit(datetime.datetime.now())) \
                                            .withColumnRenamed("ADV_DEP_LGR","advnc_dpst_ldgr") \
                                            .withColumnRenamed("GUEST_LGR","guest_ldgr") \
                                            .withColumnRenamed("COMP_LGR","cmpny_ldgr") \
                                            .withColumnRenamed("GRP_LGR","group_ldgr") \
                                            .withColumnRenamed("CTY_LGR","ar_cty_ldgr") \
                                            .select('folio_hash_key',
                                                    substring(col('brnd_id'),0,30).alias('brnd_id'),
                                                    substring(col('site_id'),0,10).alias('site_id'),
                                                    col('site_key').cast(LongType()).alias('site_key'),
                                                    col('bus_dt_key').cast(LongType()).alias('bus_dt_key'),
                                                    'bus_dt',
                                                    col('ldgr_dt_key').cast(LongType()).alias('ldgr_dt_key'),
                                                    'ldgr_dt',
                                                    col('advnc_dpst_ldgr').cast(DecimalType(25,4)).alias('advnc_dpst_ldgr'),
                                                    col('guest_ldgr').cast(DecimalType(25,4)).alias('guest_ldgr'),
                                                    col('cmpny_ldgr').cast(DecimalType(25,4)).alias('cmpny_ldgr'),
                                                    col('group_ldgr').cast(DecimalType(25,4)).alias('group_ldgr'),
                                                    col('ar_cty_ldgr').cast(DecimalType(25,4)).alias('ar_cty_ldgr'),
                                                    'curr_rec_ind',
                                                    'qrntn_flg',
                                                    'insrt_by',
                                                    'insrt_ts',
                                                    'lst_updt_by',
                                                    'lst_updt_ts'
                                                    )
            self.final_df.printSchema()
            self.cnt = self.final_df.cache().count()
            self.final_df.show()
            
        except Exception as e:
            logger.error(str(e))
            logger.info("uncaught error while executing flow. Error Msg: {0}".format(str(e)))
            f_msg = " Error while prep parquet for {}, failed with error: {}".format(process_name, str(e))
            f_sub = "Error while prep parquet for Glue Job {}".format(job_name)
            CommonMod.notifymsg(sns_topic_arn, f_sub, f_msg, region_name)
            raise


def main():
    core = CoreDriverFlow()
    core.run()


if __name__ == '__main__':
    s3Client = boto3.client('s3', region_name)
    job_run = True
    try:
        response = s3Client.head_object(Bucket=blue_bucket, Key=MARKER_FILE)
        logger.info(response)
        if response:
            logger.info("********[INFO] JOB ALREADY EXECUTED ***********")
            job_run = False
    except Exception as HeadObjectException:
        logger.info(HeadObjectException)
    if job_run:
        main()

job.commit()
