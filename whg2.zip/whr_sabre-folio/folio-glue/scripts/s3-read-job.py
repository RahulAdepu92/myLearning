import json
import logging
import sys
from datetime import datetime
from datetime import timedelta
from typing import Optional
import pytz

import boto3
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from pyspark.sql import SQLContext
from pyspark.sql.functions import col, lit, input_file_name, monotonically_increasing_id, row_number
from pyspark.sql.window import Window

sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
sqlContext = SQLContext(sc)

################################### Enabling access to the arguments ##################################
job = Job(glueContext)
args = getResolvedOptions(sys.argv, ['JOB_NAME', 'blue_bucket', 'sns', 'configfile', 'rsdb',
                                     'redshift_connection','ScriptBucketName', 'env', 'btch_hdr_table'])
job.init(args['JOB_NAME'], args)

################################### Setting up logger for event logging ##################################
logging.basicConfig()
logger = logging.getLogger()
logger.setLevel(logging.INFO)

################################### Assigning job arguments to variables  ##################################

rsdb = args['rsdb']
blue_bucket = args['blue_bucket']
job_name = args['JOB_NAME']
sns_notify = args['sns']
env = args['env']
redshiftconnection = args['redshift_connection']
btch_hdr_table_name = args['btch_hdr_table']
schema_name = "dwstg"
write_s3_path = "s3://{}/pms_folio/processing/".format(blue_bucket)
MARKER_FILE = "pms_folio/glue-workflow-marker-triggers/" + args["JOB_NAME"]
seqno_path = "s3://{}/pms_folio/seqno/".format(blue_bucket)
config_file = "pms_folio/{}".format(args['configfile'])


################################### Create low level reosurce service client for S3 ans SNS  ##################################

s3Client = boto3.client('s3', region_name='us-west-2')
s3resource = boto3.resource('s3', region_name='us-west-2')
glueClient = boto3.client('glue', region_name='us-west-2')

job_run = True

try:
    sns_client = boto3.client('sns', region_name='us-west-2')
    logger.info("Enabled SNS Notification")
except Exception as e:
    logger.error(str(e))
    logger.info(" Unable to enable SNS, failed with error: {}".format(str(e)))
    logger.info("Continuing with load without SNS notification")


############# Notification Function ################################################
def notifymsg(subprefix: str, msg: str, action: Optional[str] = "Failed"):
    sub = f"""{subprefix} Glue job '{job_name}' {action}"""
    sns_client.publish(TopicArn=sns_notify, Message=msg, Subject=sub)
    logger.info(
        "**************** [INFO] SNS Notification Sent: {} *************************".format(
            job_name))


def create_timestamp_est():
    utc_now = datetime.now()
    est = pytz.timezone('US/Eastern')
    est_now = utc_now.astimezone(est).strftime('%Y-%m-%d %H:%M:%S.%f')
    return est_now

utc_now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')

#################################### get_input_s3_path ##########################################
# This function will frame the input s3 path.
# By default, it will take all the files in the current date
def get_input_s3_path():
    logger.info("*********** Framing S3 Path ***********")
    s3_path = []
    s3_prefix = "s3://{}/pms_folio/intermediate/".format(blue_bucket)
    try:
        obj = s3Client.get_object(Bucket=blue_bucket, Key=config_file)
    except Exception:
        obj = None
        logger.info("*********** NO config file present to check ReRun dates ***********")
    if obj is not None:
        logger.info("checking for dates to ReRun from config file ")
        json_obj = json.loads(obj['Body'].read())
        rerun_dates = [x.strip() for x in json_obj["rerun"].split(',')]
        if len(rerun_dates) > 0 and rerun_dates != ['']:
            for date in rerun_dates:
                s3_path.append(s3_prefix + date + '/')
        else:
            logger.info("NO files to ReRun")

    logger.info("*********** Now retrieving files from Intermediate path ***********")
    try:
        # Creating Datetime Folder
        today = datetime.now().strftime('%Y/%m/%d')
        yesterday = (datetime.now() - timedelta(1)).strftime('%Y/%m/%d')

        logger.info("Today: {}".format(today))
        logger.info("Yesterday: {}".format(yesterday))

        s3_path.append(s3_prefix + today + '/')
        # Add yesterday files if the last execution is previous day
        client = boto3.client('glue', region_name='us-west-2')
        response = client.get_job_runs(
            JobName=args['JOB_NAME'],
            MaxResults=10
        )
        job_runs = response['JobRuns']
        start_time = None
        for run in job_runs:
            if run['JobRunState'] != 'SUCCEEDED':
                continue
            else:
                start_time = run['StartedOn']
                break
        logger.info("start_time of latest successful job is is: %s", start_time)
        # logger.info("UTC_TIME is: %s", datetime.now())
        if start_time and start_time.date() < datetime.today().date():
            logger.info(
                "adding yesterday file(s) if left over any for processing.")
        # whether previous day file processed or not will be detected by glue's job-bookmark option
            s3_path.append(s3_prefix + yesterday + '/')
        logger.info("input s3 path: %s", s3_path)
    except Exception as e:
        logger.error(
            "****************** [ERROR] Unable to frame s3 Input Path : {} **************".format(
                str(e)))
        f_msg = "Unable to Frame S3 Input Path, Error Details: {}".format(str(e))
        notifymsg("S3 Read", f_msg)
        raise SystemExit(e)

    return s3_path


####### Check if this is rerun based on the marker file, if so the job execution is skipped ###################################
try:
    response = s3Client.head_object(Bucket=blue_bucket, Key=MARKER_FILE)
    logger.info(response)
    logger.info("*******************[INFO] JOB ALREADY EXECUTED ********************")
    # make job_run as TRUE when you want to run same job on same day because marker file will be
    # created already when you execute this job alone instead of glueworkflow while unit testing.
    job_run = False
except Exception as HeadObjectException:
    ##############################################################################################
    # No Marker file present, then this is first time execution
    # Will read the file based on get_input_s3_path response
    ##############################################################################################
    logger.info(HeadObjectException)

if job_run:
    ########################### Reading Res JSON Data ####################################
    try:

        logger.info(" Reading S3 file")
        folio_s3_read_dyf = glueContext.create_dynamic_frame.from_options(connection_type="s3",
                                                                         connection_options={
                                                                             "paths": get_input_s3_path(),
                                                                             'recurse': True},
                                                                         format="json",
                                                                         transformation_ctx='folio_s3_read_dyf')

        folio_df = folio_s3_read_dyf.toDF()
        folio_df.show()
        folio_df_count = folio_df.count()
        logger.info('Total Cound DF (no.of input files): {}'.format(folio_df.count()))
        # folio_df.printSchema()

    except Exception as e:
        logger.error(
            "************ {} [ERROR] Exception while reading the file from S3 *************".format(
                str(datetime.now())))
        logger.error("*********** [ERROR] Failing with error:  {} **************".format(str(e)))
        f_msg = "  Error while reading data from S3 for the job {0} , failed with error: {1}  ".format(
            job_name, str(e))
        notifymsg("S3 Read", f_msg)
        raise SystemExit(e)

    if folio_df_count == 0:
        logger.info('No Data to process for S3 Read Job for {} run'.format(str(datetime.now())))
        f_msg = "No Data to Process for S3 Read Glue Job - {} for run {}".format(job_name,
                                                                                 str(datetime.now()))
        notifymsg("S3 Read", f_msg, "has NO data to run")
        # exit(0)
    else:
        ############# Writing seqno for Audit Job Validation #################################

        # Retrieving connection information from 'Glue connections' for Redshift
        try:
            logger.info("Getting Redshift Connection Information..")
            rs_connection_dest = glueContext.extract_jdbc_conf(redshiftconnection)
            rs_url_dest = rs_connection_dest["url"]
            rs_user_dest = rs_connection_dest["user"]
            rs_pwd_dest = rs_connection_dest["password"]
            rs_url_db_dest = rs_url_dest + '/' + rsdb
            logger.info("Redshift Connection details retrieved successfully")
        except Exception as e:
            f_msg = f"Unable to connect to Redshift while processing the glue job {job_name}, " \
                    f"failed with error: {e}"
            notifymsg("S3 Read", f_msg)
            logger.info(" Exiting with error: %s", str(e))
            raise SystemExit(e)

        logger.info("%s: Getting Data from Batch Header Table for Audit", str(datetime.now()))
        try:
            btch_hdr_df = glueContext.create_dynamic_frame.from_options(
                connection_type="redshift",
                connection_options={
                    "url": rs_url_db_dest,
                    "database": rsdb,
                    "user": rs_user_dest,
                    "password": rs_pwd_dest,
                    "dbtable": schema_name + f".{btch_hdr_table_name}",
                    "redshiftTmpDir": "s3://" + blue_bucket + '/pms_folio/batch_hdr/{}/{}/'.format(
                    job_name, str(datetime.now()).replace(" ", "_"))
                }
            )

            btch_hdr_df.toDF().createTempView("btch_hdr")
        except Exception as e:
            logger.error(
                " Error reading BATCH_HDR Table, failed with error: {0}".format(str(e)))
            f_msg = f"Error reading BATCH_HDR Table. Failed with following error: \n {str(e)}"
            notifymsg("S3 Read", f_msg)
            raise SystemExit(e)

        ############## writing Seqno File(.csv) for Audit Process #########################
        try:
            # adding filepath and start time column to the csv file
            folio_seqno_df = folio_df.withColumn('filepath', input_file_name()) \
                .withColumn('starttime', lit(utc_now_str))
            # adding autoincrement column to the above df
            folio_run_id_gen_df = folio_seqno_df.withColumn("run_id", monotonically_increasing_id())
            w = Window.orderBy("run_id")

            run_id_df = spark.sql(
                f""" select coalesce(max(cast(btch_num as bigint)), 0) as btch_num from btch_hdr """)
            run_id_df_count = run_id_df.first()['btch_num']
            logger.info("run_id_df_count (max batch_hdr count)= %s", run_id_df_count)

            if run_id_df_count == 0:  # in the very first load, btch_num will be zero as there
                # are no previous runs
                count = 0
            else:
                count = run_id_df_count  # gets the max batch id from previous runs till now
            folio_run_id_df = folio_run_id_gen_df.withColumn("btch_num",
                                                           (count + (row_number().over(w))))

            folio_run_id_df_final = folio_run_id_df.select(col('filepath'), col('starttime'),
                                                         col('btch_num')).distinct()
            folio_run_id_df_final.show()
            logger.info("Writing seq IDs to seqno folder..")
            folio_run_id_df_final.repartition(1).write.csv(seqno_path, mode="overwrite",
                                                          header='true')

        except Exception as e:
            logger.error(
                "*********** Error while writing data to Seq Folder."
                " Failing with error:  {} **************".format(str(e)))
            f_msg = "  Error while writing data to Seq Folder on S3 for the job {0} ," \
                    " failed with error: {1}  ".format(job_name, str(e))
            notifymsg("S3 Read", f_msg)
            raise SystemExit(e)


        ############## writing JSON Res Files for Processing Stage #########################

        try:
            logger.info("Writing S3 Files to Processing Folder")
            folio_processing_df = folio_seqno_df.drop("starttime")
            folio_processing_df.write.format('json').mode("overwrite").option("header", "true").save(
                write_s3_path)
        except Exception as e:
            logger.error(
                "*********** Error while writing data to Processing Folder."
                " Failing with error:  {} **************".format(str(e)))
            f_msg = "  Error while writing data to Processing Folder on S3 for the job {0} ," \
                    " failed with error: {1}  ".format(job_name, str(e))
            notifymsg("S3 Read", f_msg)
            raise SystemExit(e)

        ####################### Creating a Marker File ###########################
        try:
            response = s3Client.put_object(Bucket=blue_bucket, Body="Completed", Key=MARKER_FILE)
            logger.info(response)
        except Exception as e:
            logger.error(
                "************ {} [ERROR] Exception while writing the marker file to S3 for S3 Read Glue Job************".format(
                    str(datetime.now())))
            logger.error(
                "*********** [ERROR] Failing with error: {} **************".format(str(e)))
            f_msg = "Error while writing the marker file to S3 Read Glue Job {}, failed with Error: {}".format(
                job_name, str(e))
            notifymsg("S3 Read", f_msg)
            raise SystemExit(e)

logger.info(" ************** {} End of Load process for S3 Read *********************** ".format(
    str(datetime.now())))
job.commit()
logger.info("JOB COMPLETE!!")