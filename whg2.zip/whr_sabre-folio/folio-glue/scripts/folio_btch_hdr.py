import json
import logging
import sys
from datetime import datetime
import time

import boto3
import pytz
from pytz import timezone
from awsglue.context import GlueContext
from awsglue.dynamicframe import DynamicFrame
from awsglue.job import Job
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from pyspark.sql import SQLContext
from pyspark.sql.functions import col, when

################################### Setting up Spark environment and enabling Glue to interact with Spark Platform ##################################
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
sqlContext = SQLContext(sc)

################################### Enabling access to the arguments ##################################
job = Job(glueContext)
args = getResolvedOptions(sys.argv,
                          ['JOB_NAME', 'blue_bucket', 'error_bucket', 'SNS', 'rsdb', 'redshiftconnection', 'schemaname',
                           'tablename', 'ScriptBucketName', 'configfile', 'glueerrortable', 'ESLogGroup', 'stg_sql_file'
                           ])
job.init(args['JOB_NAME'], args)

################################### Setting up logger for event logging ##################################
logging.basicConfig()
logger = logging.getLogger()
logger.setLevel(logging.INFO)

################################### Assigning job arguments to variables  ##################################

rsdb = args['rsdb']
redshiftconnection = args['redshiftconnection']
blue_bucket = args['blue_bucket']
script_bucket = args['ScriptBucketName']
error_bucket = args['error_bucket']
job_name = args['JOB_NAME']
schemaname = args['schemaname']
tablename = args['tablename']
glueerrortable = args['glueerrortable']
sns_notify = args['SNS']
stg_sql_file = args['stg_sql_file']
es_log_group = args['ESLogGroup']
# MARKER_FILE = "Folio/glue-workflow-marker-triggers/" +args["JOB_NAME"]
seqno_path = "s3://{}/pms_folio/seqno/".format(blue_bucket)
REDSHIFT_PATH = "s3://{}/pms_folio/redshift/".format(blue_bucket)
file_path_gen = 's3://{}/pms_folio/processing/'.format(blue_bucket)
# setting path for stl_load_errors file
today = datetime.now().strftime('%Y/%m/%d')
stl_load_errors_file_path = f"s3://{blue_bucket}/pms_folio/stl_load_errors/{today}/"

job_title = " ".join(tablename.split("_")[1:]).title()  # used to print it in logs but nothing else.

################################### Create low level reosurce service client for S3 ans SNS  ##################################

s3Client = boto3.client('s3', region_name='us-west-2')
s3resource = boto3.resource('s3', region_name='us-west-2')
glueClient = boto3.client('glue', region_name='us-west-2')

########## Structuring Log Stream for ES Logs ############
log_stream_n = 'GlueLogs'
ts = datetime.now()
ts_est = timezone('US/Eastern').localize(ts)
ts_est_str = ts_est.strftime('%Y-%m-%d-%H-%M-%S')
log_stream =  '{}-{}'.format(log_stream_n,ts_est_str)

try:
    sns_client = boto3.client('sns', region_name='us-west-2')
    logger.info("Enabled SNS Notification")
except Exception as e:
    logger.error(str(e))
    logger.info(" Unable to enable SNS, failed with error: {}".format(str(e)))
    logger.info("Continuing with load without SNS notification")


#########################################Create ESLogGroup stream################################### 
try:
    logs = boto3.client('logs', region_name = 'us-west-2')
    logs.create_log_stream(logGroupName=es_log_group, logStreamName=log_stream)
    logger.info("Connected to Log Stream {}".format(es_log_group))
except Exception as e:
    logger.error(str(e))

try:
    sns_client = boto3.client('sns', region_name='us-west-2')
    logger.info("Enabled SNS Notification")
except Exception as e:
    logger.error(str(e))
    logger.info(" Unable to enable SNS, failed with error: {}".format(str(e)))
    logger.info("Continuing with load without SNS notification")

def notifymsg(sub, msg):
    sns_client.publish(TopicArn=sns_notify, Message=msg, Subject=sub)
    logger.info("**************** [INFO] SNS Notification Sent: {} *************************".format(job_name))

def create_timestamp_est():
    utc_now = datetime.now()
    est = pytz.timezone('US/Eastern')
    est_now = utc_now.astimezone(est).strftime('%Y-%m-%d %H:%M:%S.%f')
    return est_now


################## Generate ES Logs #################
def generateESLogs(prc_arn,sts,err_desc,src_sys_ts,prc_start_dtm,prc_end_dtm,src_cnt,tgt_success_cnt,tgt_failed_cnt):
    
    _logs_json = json.dumps({
        "source_system": "PMS",
        "domain": "Folio",
        "subdomain": None,
        "process_name": "Folio Batch Load to Redshift Stage",
        "process_arn": "{}".format(prc_arn),
        "task_name": "Glue Batch Load",
        "rule_id": None,
        "rule_name": None,
        "status": sts,
        "source_file_name": None,
        "target_name": None,
        "unique_id": None,
        "unique_value_1": None,
        "unique_value_2": None,
        "unique_value_3": None,
        "error_desc": err_desc,
        "design_pattern": "Batch",
        "source_system_timestamp": src_sys_ts,
        "business_date": None,
        "orginal_file_name": None,
        "process_start_datetime": prc_start_dtm,
        "process_end_datetime": prc_end_dtm,
        "batch_id": None,
        "source_record_count": src_cnt,
        "target_success_count": tgt_success_cnt,
        "target_failed_count": tgt_failed_cnt
    })
    
    return _logs_json

######### Generate CW Log Events ############
def streaminfo(msg):
        timestamp = int(round(time.time() * 1000))
        response = logs.describe_log_streams(
            logGroupName=es_log_group,
            logStreamNamePrefix=log_stream
        )
        event_log = {
            'logGroupName':es_log_group,
            'logStreamName':log_stream,
            'logEvents':[
                {
                    'timestamp': timestamp,
                    'message': msg
                }
            ]
        }
        
        if 'uploadSequenceToken' in response['logStreams'][0]:
            event_log.update({'sequenceToken': response['logStreams'][0]['uploadSequenceToken']})

        response = logs.put_log_events(**event_log)

################################### Retrieving connection information from Glue connections for Redshift  ##################################
try:
    logger.info("Getting Redshift Connection Information")
    rs_connection_dest = glueContext.extract_jdbc_conf(redshiftconnection)
    rs_url_dest = rs_connection_dest["url"]
    rs_user_dest = rs_connection_dest["user"]
    rs_pwd_dest = rs_connection_dest["password"]
    rs_url_db_dest = rs_url_dest + '/' + rsdb
except Exception as e:
    logger.error(str(e))
    f_msg = " Unable to connect to Redshift while processing the glue job {0} , failed with error: {1}  ".format(
        job_name, str(e))
    f_sub = "Folio Btch Hdr Glue job " + job_name + " failed"
    notifymsg(f_sub, f_msg)
    logger.info(" Exiting with error: {}".format(str(e)))
    streaminfo(generateESLogs(job_name,"ERROR",str(e),create_timestamp_est(),create_timestamp_est(),create_timestamp_est(),0,0,0))
    raise SystemExit(e)

############################## Reading Data from Processing Folder for latest RSVs #################################################
try:
    logger.info(" Reading Folio Btch Hdr Data from JSON ")
    folio_s3_read_dyf = glueContext.create_dynamic_frame.from_options(connection_type="s3",
                                                                        connection_options={
                                                                            "paths":
                                                                                [file_path_gen],
                                                                            'recurse': True,
                                                                            'groupFiles': 'inPartition'},
                                                                        format="json",
                                                                        format_options={
                                                                            "jsonPath": f"$.{tablename}[*]"})

    folio_df = folio_s3_read_dyf.toDF()
    folio_df.show()
    folio_df_count = folio_df.count()
    logger.info('Total Cound DF: {}'.format(folio_df_count))
    # folio_df.printSchema()
    # folio_df.show(10, False)

except Exception as e:
    logger.error(
        "************ {} [ERROR] Exception while reading the file from S3 *************".format(
                str(datetime.now())))
    logger.error("*********** [ERROR] Failing with error:  {} **************".format(str(e)))
    f_msg = "  Error while reading Folio Btch Hdr data from S3 for the job {0} , failed with error: {1}  ".format(
            job_name, str(e))
    f_sub = "Folio Btch Hdr Glue job " + job_name + " failed"
    notifymsg(f_sub, f_msg)
    streaminfo(generateESLogs(job_name,"ERROR",str(e),create_timestamp_est(),create_timestamp_est(),create_timestamp_est(),0,0,0))
    raise SystemExit(e)

if folio_df_count == 0:
    logger.info(
        'No Data to process for Folio Btch Hdr for {} run'.format(str(datetime.now())))
    f_msg = "No Data to Process for Folio Btch Hdr Glue Job - {} for run {}".format(job_name,
                                                                                str(datetime.now()))
    f_sub = "No Data to Process for Folio Btch Hdr Glue Job - {}".format(job_name)
    notifymsg(f_sub, f_msg)
    # exit(0)
else:
    ################## Data Transformation Step #################################
    try:
        logger.info('Mapping Field Name with Redshift Column')

        # Filling in blank values with Null values
        for x in folio_df.columns:
            folio_df = folio_df.withColumn(x, when(col(x) != '', col(x)).otherwise(None))
        # creating temp view for the staging table
        folio_df.createTempView("stg_folio_temp")
        logger.info("stg_folio_temp tempView is created")

    except Exception as e:
        logger.error(
            "************ {} [ERROR] Exception while doing Data Transformtion on Folio Btch Hdr Data *************".format(
                str(datetime.now())))
        logger.error(
            "*********** [ERROR] Failing with error:  {} **************".format(str(e)))
        f_msg = "  Error while doing Data Transformtion on Folio Btch Hdr Data for Glue Job {0} , failed with error: {1}  ".format(
                    job_name, str(e))
        f_sub = "Folio Btch Hdr Glue job " + job_name + " failed"
        notifymsg(f_sub, f_msg)
        streaminfo(generateESLogs(job_name,"ERROR",str(e),create_timestamp_est(),create_timestamp_est(),create_timestamp_est(),int(folio_df_count),0,0))
        raise SystemExit(e)

############ Read the seqfile from s3, written by s3read job initially

    try:
        seqno_df = glueContext.read \
            .format("csv") \
            .option("inferSchema", "false") \
            .option("header", "true") \
            .load(seqno_path)
        # print(seqno_df.show())
        source_count = seqno_df.count()
        seqno_df.createTempView("id_temp")

    except Exception as e:
        logger.error(str(e))
        logger.error("**************** [ERROR] Error reading seqno file, failed with error: {} ***********".format(str(e)))
        f_msg = "**************** [ERROR] Error reading seqno file, failed with error: {} ***********".format(str(e))
        f_sub = "Folio Btch Hdr Job - {} Failed".format(job_name)
        notifymsg(f_sub, f_msg)
        streaminfo(generateESLogs(job_name,"ERROR",str(e),create_timestamp_est(),create_timestamp_est(),create_timestamp_est(),int(folio_df_count),0,0))
        raise SystemExit(e)

########################### Read STL_LOAD_ERRORS ###################################

    logger.info("{}: Getting Data from Load Error Table for Audit".format(str(datetime.now())))

    try:
        RSerror_df = glueContext.create_dynamic_frame.from_options(
            connection_type="redshift",
            connection_options={
                "url": rs_url_db_dest,
                "database": rsdb,
                "user": rs_user_dest,
                "password": rs_pwd_dest,
                "dbtable": schemaname + ".{}".format(glueerrortable),
                "redshiftTmpDir": REDSHIFT_PATH + "stl_load_errors/" + str(datetime.now()).replace(" ", "_") + "/"
            }
        )

        RSerror_df.toDF().createTempView("RSerror")
        logger.info("RSerror tempview is created")
    except Exception as e:
        logger.error(str(e))
        logger.error(
            "**************** [ERROR] Error reading STL_LOAD_ERRORS Table, failed with error: {} ***********".format(
                str(e)))
        f_msg = "**************** [ERROR] Error reading STL_LOAD_ERRORS Table, failed with error: {} ***********".format(
            str(e))
        f_sub = "Folio Btch Hdr Job - {} Failed".format(job_name)
        notifymsg(f_sub, f_msg)
        streaminfo(generateESLogs(job_name,"ERROR",str(e),create_timestamp_est(),create_timestamp_est(),create_timestamp_est(),int(folio_df_count),0,0))
        raise SystemExit(e)

    ########### setting start_time param to get fetch latest errors from stl_load_errors table #############

    starttime_df = spark.sql(""" select max(starttime) as starttime from id_temp """)
    starttime = starttime_df.first()['starttime']

    ########################### Write STL_LOAD_ERRORS to S3 path ###################################
    try:
        stl_load_errors_sql = \
            (f""" SELECT rs.starttime, rs.filename, rs.line_number, rs.col_length, rs.colname, rs.position,
                rs.raw_line, rs.raw_field_value, rs.err_reason 
                from RSerror rs, id_temp sq
                where SUBSTRING_INDEX(SUBSTRING_INDEX(trim(rs.raw_line),'/',-1),'.json',1) =
                SUBSTRING_INDEX(SUBSTRING_INDEX(sq.filepath,'/',-1),'.json',1)
                and rs.starttime > '{starttime}' """)

        logger.info("stl_load_errors_sql: %s", stl_load_errors_sql)
        stl_load_errors_df = spark.sql(stl_load_errors_sql)
        # stl_load_errors_df.show()

        if stl_load_errors_df.count() > 0:
            logger.info("Found errors while loading file. Hence, writing these errors from stl_load_errors table to s3 path")
            stl_load_errors_df.repartition(1).write.csv(stl_load_errors_file_path, mode='append', header='true')
        else:
            logger.info("No data errors found in stl_load_errors table")

    except Exception as e:
        logger.error(
                f"**************** [ERROR] Error writing STL_LOAD_ERRORS Table to S3 path, failed with error: "
                f"{str(e)} ***********")
        f_msg = f"**************** [ERROR] Error reading STL_LOAD_ERRORS Table, failed with error: {str(e)} " \
                    f"***********"
        f_sub = f"Stay Btch Hdr Job - {job_name} Failed"
        notifymsg(f_sub, f_msg)
        # systemexit is not needed as writing load errors to a file is independent task and shouldn't halt ongoing task

########################### SQL for Btch Hdr table ###################################

    logger.info("{}: Starting Audit Process".format(str(datetime.now())))
    try:
        starttime_df = spark.sql(""" select max(starttime) as starttime from id_temp """)
        starttime = starttime_df.first()['starttime']
        est_now = create_timestamp_est()

        try:
            obj = s3Client.get_object(Bucket=script_bucket, Key=stg_sql_file)
        except Exception:
            logger.error(
                "*********** NO SQL file present to fetch query for data load to Redshift "
                "***********")
            msg = f"NO SQL file present to fetch stg table '{job_title}' query for data load for Job '{job_name}' to run "
            sub = f"No SQL file present for Staging Job '{job_name}' to run"
            notifymsg(sub, msg)
            streaminfo(generateESLogs(job_name,"ERROR",str(e),create_timestamp_est(),create_timestamp_est(),create_timestamp_est(),int(folio_df_count),0,0))
            raise SystemExit("No SQL file present to fetch stg query. Can't proceed")

        logger.info(f"checking for stg table '{job_title}' query ")
        json_obj = json.loads(obj['Body'].read())
        # fetching respective SQL from json
        Audit_sql = json_obj[tablename]

        if len(Audit_sql) > 0:
            Audit_sql_updated = Audit_sql.format(est_now, starttime)
            logger.info("SQL for Audit table '%s' is: %s", tablename, Audit_sql)
            stg = spark.sql(Audit_sql_updated)
            stg.show()
            Audit_df = DynamicFrame.fromDF(stg, glueContext, "Audit_df")

            Audit_table_map = ResolveChoice.apply(
                frame=Audit_df,
                choice="make_cols",
                transformation_ctx="Audit_table_map"
                )
            stg.createTempView("btch_stats")
            stg.show()
            
            ##### Getting Success Records Count ########
            success_records = spark.sql(""" select count(stg_sts) as cnt from btch_stats where stg_sts = 'New' """)
            success_records_cnt = success_records.first()['cnt']
            
            ##### Getting Error Records Count ########
            error_records = spark.sql(""" select count(stg_sts) as cnt from btch_stats where stg_sts = 'Failed' """)
            error_records_cnt = error_records.first()['cnt']
            
        else:
            logger.error(f"*********** NO SQL present for '{job_name}' in json file ***********")
            streaminfo(generateESLogs(job_name,"ERROR",str(e),create_timestamp_est(),create_timestamp_est(),create_timestamp_est(),int(folio_df_count),0,0))
            raise SystemExit("No SQL present for the stg table in json file. Can't proceed")

    except Exception as e:
        logger.error(str(e))
        logger.error("**************** [ERROR] Error with Audit process, failed with error: {} ***********".format(str(e)))
        f_msg = "**************** [ERROR] Error with Audit process, failed with error: {} ***********".format(str(e))
        f_sub = "Folio Btch Hdr Glue Job - {} Failed".format(job_name)
        notifymsg(f_sub ,f_msg)
        streaminfo(generateESLogs(job_name,"ERROR",str(e),create_timestamp_est(),create_timestamp_est(),create_timestamp_est(),int(folio_df_count),0,0))
        raise SystemExit(e)

    try:
        ########################### Write to Btch Hdr table ###################################

        logger.info("{}: Updating Btch Hdr table with status ".format(str(datetime.now())))

        erroredTokensAudit = glueContext.write_dynamic_frame.from_jdbc_conf(
            frame = Audit_table_map,
            catalog_connection = redshiftconnection,
            connection_options = {
                "url": rs_url_db_dest,
                "database": rsdb,
                "user": rs_user_dest,
                "password": rs_pwd_dest,
                "dbtable": schemaname + f".{tablename}"
            },
            redshift_tmp_dir=REDSHIFT_PATH +"BtchHdr/" +str(datetime.now()).replace(" ","_") +"/"
        )
        
        if error_records_cnt != 0:
            streaminfo(generateESLogs(job_name,"SUCCESS","Check Redshift Load Error Table (dwstg.stl_load_errors_view) for more details",create_timestamp_est(),create_timestamp_est(),create_timestamp_est(),int(folio_df_count),int(success_records_cnt),int(error_records_cnt)))
        else:
            streaminfo(generateESLogs(job_name,"SUCCESS",None,create_timestamp_est(),create_timestamp_est(),create_timestamp_est(),int(folio_df_count),int(success_records_cnt),int(error_records_cnt)))

    except Exception as e:
        logger.error(str(e))
        logger.error("**************** [ERROR] Error with Audit process, failed with error: {} ***********".format(str(e)))
        f_msg = "**************** [ERROR] Error with Audit process, failed with error: {} ***********".format(str(e))
        f_sub = "Folio Btch Hdr Glue Job - {} Failed".format(job_name)
        notifymsg(f_sub, f_msg)
        streaminfo(generateESLogs(job_name,"ERROR",str(e),create_timestamp_est(),create_timestamp_est(),create_timestamp_est(),int(folio_df_count),0,0))
        raise SystemExit(e)


##############- Delete Marker files #################################
bucket = s3resource.Bucket(blue_bucket)

try:
    objects = bucket.objects.filter(Prefix='pms_folio/glue-workflow-marker-triggers/WHG-Glue-UW2-Folio')
    logger.info(" Deleting the marker files")
    objects.delete()
except Exception as e:
    logger.error(" Error while deleting the marker files, failed with error: {}".format(str(e)))
    f_msg = "Error while deleting the marker files, failed with error: {}".format(str(e))
    f_sub = "ERROR Deleting Marker Files for Folio Btch Hdr Job - ".format(job_name)
    notifymsg(f_sub, f_msg)
    raise SystemExit(e)

"""
####################### generating an ETL Trigger File ###########################
try:
    etl_trigger_key = 'trigger_files/Folio/rsrv_glue.trg'
    etl_trigger_body = json.dumps({"Folio": "/whgdata/Facts/TriggerFiles/Folio/rsrv_glue.trg",
                                   "timestamp": "{}".format(create_trigger_file_ts())})
    response = s3Client.put_object(Bucket=gold_bucket, Body=etl_trigger_body, Key=etl_trigger_key)
    print(response)
except Exception as e:
    logger.error(
        "************ {} [ERROR] Exception while writing the trigger file to S3 for Btch Hdr Glue Job************".format(
            str(datetime.now())))
    logger.error("*********** [ERROR] Failing with error: {} **************".format(str(e)))
    f_msg = "Error while writing the trigger file from Glue Job {}, failed with Error: {}".format(job_name, str(e))
    f_sub = "Error writing Trigger File for Glue Job - {}".format(job_name)
    notifymsg(f_sub, f_msg)
    raise SystemExit(e)
"""
logger.info(" End of Btch Hdr job run ")
logger.info("JOB COMPLETE!!")
