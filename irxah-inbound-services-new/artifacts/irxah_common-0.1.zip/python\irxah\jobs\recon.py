import logging
import sys
from ..redshift import (
    load_s3_file_into_table,
    get_connection,
    execute_query,
    cleanup_table,
    get_client_files_import_columns,
    load_s3_file_into_table_column_specific,
)
from ..glue import get_glue_logger
from ..model import Job
from awsglue.utils import getResolvedOptions
from typing import List, Optional
from ..file import get_timestamp
from ..database.job_log import (
    insert_job_detail_log,
    update_job_detail_log,
    _update_job_detail_log,
    _insert_job_detail_log,
)
from ..redshift import get_column_names
from ..s3 import delete_s3_files
from ..constants import (
    SCHEMA_DW,
    SCHEMA_STAGING,
    TABLE_RECON_DETAIL_STAGING,
    TABLE_RECON_DETAIL_DW,
    TABLE_CLIENT_FILES,
    JOB_S3_FILE_ARGUMENT_NAME,
)

logger = get_glue_logger(name=f"{__name__}", logging_level=logging.DEBUG)


def load_recon_to_database(job: Job, job_name: Optional[str] = "Load Recon") -> Job:
    """Loads detail file from temp folders into the staging recon table. Staging recon table will then be
    inserted with extra necessary columns into the permanent table. Cleans up the staging table afterwards.
    :param arguments: a list of variables that will be resolved to retrieve environment variables
    :param job: a Job object, from irxah/glue.py. Needs at least the following preconfigured: 
    *job_key
    :param job_name: User specified name for the job. 
    :returns Updated Job object ..
    """
    # create_redshift_connection(redshift_host, redshift_port, redshift_database, redshift_user, redshift_password)
    conn = get_connection(job.secret_name)
    # Earlier below variables were hard coded, now read from database
    s3_bucket_name = job.s3_bucket_name
    s3_inbound_dtl_temp_file_path = job.get_path(job.detail_file_name)
    iam_arn = job.client_file_info.redshift_glue_iam_role_arn
    s3_temp_file_path_job_key = f"{job.file_processing_location}/{str(job.job_key)}_"
    job.post_processing_file_location = ""

    error_occured = False

    # Create job log
    error_occured = _insert_job_detail_log(
        conn=conn,
        schema=SCHEMA_DW,
        job=job,
        sequence_number=3,
        job_name=job_name,
        input_file_name=job.output_file_name,
    )

    if not error_occured:
        logger.info(
            "recon load_recon_to_database :load_s3_file_into_table_column_specific : Started "
        )

        columns = get_client_files_import_columns(conn, SCHEMA_DW, TABLE_CLIENT_FILES, job)
        if columns is None or columns == "":
            error_occured = True
            job.error_message = (
                "Unable to retrieve import columns for Accumulator Reconciliation Detail table"
            )
            _update_job_detail_log(error_occured, job, conn, SCHEMA_DW)
            return job

        load_s3_file_into_table_column_specific(
            conn,
            SCHEMA_DW,
            TABLE_RECON_DETAIL_DW,
            columns,
            s3_bucket_name,
            s3_inbound_dtl_temp_file_path,
            iam_arn,
        )

        delete_s3_files(s3_bucket_name, s3_temp_file_path_job_key)

    # Update job log
    _update_job_detail_log(error_occured, job, conn, SCHEMA_DW)

    return job
