import logging
import sys
from typing import List, Optional
from awsglue.utils import getResolvedOptions
from .accumhist import process_cvs_acc_history_file
from .bci import process_bci_file_and_send_to_cvs, process_bci_error_file_and_load_in_database
from .inbound import load_incoming_file_in_database
from .cvs import process_cvs_file_load_in_database
from .job_logger import initialize
from ..database.file_schedule import get_file_schedule_info
from ..database.job_log import update, get_file_count
from .recon import load_recon_to_database
from .sla_processor import check_file_receipt_after_sla_end
from .split_incoming_file import split_file_handler
from .unload_cvs_to_bci import export_bci_file
from .validate_file_columns import notify_data_error
from .validate_file_structure import validate_file
from ..constants import (
    SUCCESS,
    RUNNING,
    INBOUND_BCI_ERROR_TO_DATABASE_CLIENT_FILE_ID,
    INBOUND_BCI_TO_CVS_CLIENT_FILE_ID,
    INBOUND_CVS_TO_DATABASE_CLIENT_FILE_ID,
    INBOUND_CVS_NON_INTEG_TO_DATABASE_CLIENT_FILE_ID,
    INBOUND_CVS_RECON_INTEG_TO_DATABASE_CLIENT_FILE_ID,
    INBOUND_CVS_RECON_NON_INTEG_TO_DATABASE_CLIENT_FILE_ID,
    INBOUND_CVS_ACCHIST_TO_CVS_CLIENT_FILE_ID,
    INBOUND_BCI_GP_TO_CVS_CLIENT_FILE_ID,
    FILE_TIMESTAMP_FORMAT,
    FAIL,
)
from ..database import get_client_file_info
from ..glue import get_glue_logger
from ..model import Job, FileScheduleProcessingTypeEnum
from ..notifications import send_file_structure_error_notification, notify_inbound_file
from ..redshift import get_connection
from ..s3 import delete_s3_files, split_file, move_file, create_s3_file, is_it_duplicate_file
import os
from .custom_to_standard import generate_standard_row
from ..common import tz_now, get_local_midnight_time_from_utc_time
from ..database import get_custom_to_standard_mappings_for_client
from ..file import get_timestamp
from datetime import datetime

logger = get_glue_logger(name=f"{__name__}", logging_level=logging.DEBUG)


def process_incoming_file_load_in_database(arguments: List[str]) -> None:
    """This function processes the incoming CVS files (both CVS Integrated, Recon and Acchist) depending upon the client_file_id
    obtained from triggered lambda.
    It will validate the file, split it, and load the file into database and sends the notification for any data errors.
    Jobs logs are tracked upon start and end of the function in the Redshift tables.
    """
    logger.info("Job initialisation started..")
    job = initialize(arguments)
    logger.info(log_job_status_begin(job))

    if job.job_status != RUNNING:
        update(job)
        logger.debug("Failure at initialize job_logger")
        logger.critical(log_job_status_end(job))
        return None

    # if validation for incoming file is required code enters into if block and the arguments are retrieved in 'validate_file' function
    # else the arguments are supplied in else block and will be moved to 'split_file_handler' process
    # 'CVS Accum history file' doesn't require any file validation and that is why its associated client_file_id is not included below.

    if job.validate_file_structure:
        logger.info("File validation started..")
        job = validate_file(job)

        if job.job_status != SUCCESS:
            update(job)
            logger.debug("Failure at validate_file")
            logger.critical(log_job_status_end(job))
            return None
    else:
        incoming_file = job.incoming_file_name
        file_name = incoming_file.split("/")[-1]
        job.input_file_name = file_name
        job.file_name_with_path = incoming_file

    logger.info("Split incoming file started..")
    job = split_file_handler(job)

    if not job.continue_processing:
        logger.info(
            "There is nothing to load , split_file_handler found only header and trailer in a file "
        )
        _complete_inbound_job(job)
        delete_s3_files(job.s3_bucket_name, f"{job.file_processing_location}/{str(job.job_key)}_")
        logger.info("inbound temp folder file clean up process is completed")

        conn = get_connection(job.secret_name)
        # send alert for receiving and processing the empty inbound file. For a full file it is taken care in inbound.py
        file_schedule = get_file_schedule_info(
            conn, job.client_file_id, FileScheduleProcessingTypeEnum.INBOUND_TO_AHUB
        )
        logger.info(" File Schedule Info is : %s", file_schedule)
        notify_inbound_file(file_schedule, job)

        logger.info(
            log_job_status_end(
                job,
                "There is nothing to load , split_file_handler found only header and trailer in a file",
            )
        )
        return None
    elif job.job_status != SUCCESS:
        update(job)
        logger.debug("Failure in split_file_handler")
        logger.critical(log_job_status_end(job))

        return None

    logger.info("Processing incoming Standard file started..")

    logger.info(
        "Incoming file is: %s and process name is: %s ",
        job.client_file_info.file_description,
        job.client_file_info.process_name,
    )

    job = load_incoming_file_in_database(job)

    if job.job_status != SUCCESS:
        update(job)
        logger.debug("Failure at process_cvs_file")
        logger.critical(log_job_status_end(job))
        return None

    _complete_inbound_job(job)
    logger.info(log_job_status_end(job))
    return None


# TODO: remove this unused below function
def process_bci_file(arguments: List[str]) -> None:
    """This function processes the incoming BCI file (Integrated, Error and GP) depending upon the client_file_id obtained from triggered lambda.
    It will validate the file, split it, and load, unload, and merge it and sends the notification for any data errors.
    Jobs logs are tracked upon start and end of the function in the Redshift tables.
    variables declared in lambda function are retrieved here and corresponding arguments are utilised for subsequent glue job runs.
    """
    logger.info("Job initialization started....")
    job = initialize(arguments)
    logger.info(log_job_status_begin(job))

    if job.job_status != RUNNING:
        update(job)
        logger.debug("Failure at initialize job_logger")
        logger.critical(log_job_status_end(job))
        return None

    if job.validate_file_structure:
        logger.info("File validation started..")
        job = validate_file(job)

    if job.job_status != SUCCESS:
        update(job)
        logger.debug("Failure at validate_file")
        logger.critical(log_job_status_end(job))
        return None

    logger.info("Split incoming file started..")
    job = split_file_handler(job)

    if (
            not job.continue_processing
            and job.client_file_id == INBOUND_BCI_ERROR_TO_DATABASE_CLIENT_FILE_ID
    ):
        logger.warning(
            "There is nothing to load , split_file_handler found only header and trailer in a file "
        )
        complete_bci_job(job)
        delete_s3_files(job.s3_bucket_name, f"{job.file_processing_location}/{str(job.job_key)}_")
        logger.info("inbound temp folder file clean up process is completed")
        logger.info(
            log_job_status_end(
                job,
            )
        )
        return None
    elif job.job_status != SUCCESS:
        update(job)
        logger.debug("Failure at split_file_handler")
        logger.critical(log_job_status_end(job))
        return None

    logger.info("Processing incoming BCI file started..")

    logger.info(
        "Incoming file is: %s and process name is: %s ",
        job.client_file_info.file_description,
        job.client_file_info.process_name,
    )

    if job.client_file_id in [
        INBOUND_BCI_TO_CVS_CLIENT_FILE_ID,
        INBOUND_BCI_GP_TO_CVS_CLIENT_FILE_ID,
    ]:
        job = process_bci_file_and_send_to_cvs(job)
    elif job.client_file_id == INBOUND_BCI_ERROR_TO_DATABASE_CLIENT_FILE_ID:
        job = process_bci_error_file_and_load_in_database(job)

    if job.job_status != SUCCESS:
        update(job)
        logger.debug("Failure at process_bci_file")
        logger.critical(log_job_status_end(job))
        return None

    complete_bci_job(job)
    logger.info(log_job_status_end(job))

    return None


def complete_bci_job(job: Job) -> None:
    """Completes the rest of the BCI Job
    Here BCI job_key is passed and process must be resulting in a Success.
    Args:
        job (Job): Job
    """
    logger.info(
        "job.job_key = %d, job.client_file_id = %d,  job.file_name =%s",
        job.job_key,
        job.client_file_id,
        job.file_name,
    )

    conn = get_connection(job.secret_name)
    client_file = get_client_file_info(conn, job.client_file_id)

    # sends notification upon data errors are found in outbound file if is_data_error_alert_active flag is TRUE
    if client_file.is_data_error_alert_active:
        logger.info("Alert is Active - Attempting to check error")
        notify_data_error(conn, job.job_key, job.file_name, client_file)

    logger.info("Job completed")
    update(
        job
    )  # updating Job table ends. Any failure in following steps will not be recorded in Job table.

    # sends notification upon receiving the missing file after sla
    logger.info(
        "Now checking whether the SLA Failure Email  need to be sent ( Client File ID =%d)  ",
        client_file.client_file_id,
    )
    check_file_receipt_after_sla_end(conn, job)

    # sends notification upon outbound file generation if outbound_successful_acknowledgement flag is TRUE
    if client_file.outbound_successful_acknowledgement:
        logger.info(
            "process_flow : process_bci_file : Alert is Active - Attempting to send outbound file generation alert"
        )
        client_file.client_abbreviated_name = "CVS"
        file_with_count = f"{job.output_file_name} ({job.record_count} records)"
        # notify_outbound_file_generation(client_file, file_with_count)

    else:
        logger.info(
            "Outbound_successful_acknowledgement is set to 'False' and any alert is not required"
        )


def process_cvs_file(arguments: List[str]) -> None:
    """This function processes the incoming CVS files (both CVS Integrated, Recon and Acchist) depending upon the client_file_id obtained from triggered lambda.
    It will validate the file, split it, and load the file into database and sends the notification for any data errors.
    Jobs logs are tracked upon start and end of the function in the Redshift tables.
    """
    logger.info("Job initialisation started..")
    job = initialize(arguments)
    logger.info(log_job_status_begin(job))

    if job.job_status != RUNNING:
        update(job)
        logger.debug("Failure at initialize job_logger")
        logger.critical(log_job_status_end(job))
        return None

    # if validation for incoming file is required code enters into if block and the arguments are retrieved in 'validate_file' function
    # else the arguments are supplied in else block and will be moved to 'split_file_handler' process
    # 'CVS Accum history file' doesn't require any file validation and that is why its associated client_file_id is not included below.

    if job.validate_file_structure:
        logger.info("File validation started..")
        job = validate_file(job)

        if job.job_status != SUCCESS:
            update(job)
            logger.debug("Failure at validate_file")
            logger.critical(log_job_status_end(job))
            return None
    else:
        incoming_file = job.incoming_file_name
        file_name = incoming_file.split("/")[-1]
        job.input_file_name = file_name
        job.file_name_with_path = incoming_file

    logger.info("Split incoming file started..")
    job = split_file_handler(job)

    if not job.continue_processing:
        logger.info(
            "There is nothing to load , split_file_handler found only header and trailer in a file "
        )
        complete_cvs_job(job)
        delete_s3_files(job.s3_bucket_name, f"{job.file_processing_location}/{str(job.job_key)}_")
        logger.info("inbound temp folder file clean up process is completed")

        conn = get_connection(job.secret_name)
        # send alert for receiving and processing the empty inbound file. For a full file it is taken care in cvs.py
        # TODO: remove redundancy of below alert code
        file_schedule = get_file_schedule_info(
            conn, job.client_file_id, FileScheduleProcessingTypeEnum.INBOUND_TO_AHUB
        )
        logger.info(" File Schedule Info is : %s", file_schedule)
        notify_inbound_file(file_schedule, job)

        logger.info(
            log_job_status_end(
                job,
                "There is nothing to load , split_file_handler found only header and trailer in a file",
            )
        )
        return None
    elif job.job_status != SUCCESS:
        update(job)
        logger.debug("Failure in split_file_handler")
        logger.critical(log_job_status_end(job))

        return None

    logger.info("Processing incoming CVS file started..")

    logger.info(
        "Incoming file is: %s and process name is: %s ",
        job.client_file_info.file_description,
        job.client_file_info.process_name,
    )

    if job.client_file_id in [
        INBOUND_CVS_TO_DATABASE_CLIENT_FILE_ID,
        INBOUND_CVS_NON_INTEG_TO_DATABASE_CLIENT_FILE_ID,
    ]:
        job = process_cvs_file_load_in_database(job)
    elif job.client_file_id in [
        INBOUND_CVS_RECON_INTEG_TO_DATABASE_CLIENT_FILE_ID,
        INBOUND_CVS_RECON_NON_INTEG_TO_DATABASE_CLIENT_FILE_ID,
    ]:
        job = load_recon_to_database(job)
    elif job.client_file_id == INBOUND_CVS_ACCHIST_TO_CVS_CLIENT_FILE_ID:
        job = process_cvs_acc_history_file(job)

    if job.job_status != SUCCESS:
        update(job)
        logger.debug("Failure at process_cvs_file")
        logger.critical(log_job_status_end(job))
        return None

    complete_cvs_job(job)
    logger.info(log_job_status_end(job))
    return None


def _complete_inbound_job(job: Job) -> None:
    """Completes the rest of the CVS Job
    Here CVS job_key is passed and process must be resulting in a Success.
    Args:
        job (Job): Job
    """
    conn = get_connection(job.secret_name)
    client_file = get_client_file_info(conn, job.client_file_id)

    # sends notification upon data errors are found in outbound file if is_data_error_alert_active flag is TRUE
    if client_file.is_data_error_alert_active:
        logger.info("Alert is Active - Attempting to check error")
        notify_data_error(conn, job.job_key, job.file_name, client_file)

    logger.info("Job completed - now updating job related information")
    update(
        job
    )  # updating Job table ends. Any failure in following steps will not be recorded in Job table.

    # sends notification upon receiving the missing file after sla
    logger.info(
        "Now checking whether the SLA Failure Email  need to be sent ( Client File ID =%d)  ",
        client_file.client_file_id,
    )
    check_file_receipt_after_sla_end(conn, job)


def complete_cvs_job(job: Job) -> None:
    """Completes the rest of the CVS Job
    Here CVS job_key is passed and process must be resulting in a Success.
    Args:
        job (Job): Job
    """
    conn = get_connection(job.secret_name)
    client_file = get_client_file_info(conn, job.client_file_id)

    # sends notification upon data errors are found in outbound file if is_data_error_alert_active flag is TRUE
    if client_file.is_data_error_alert_active:
        logger.info("Alert is Active - Attempting to check error")
        notify_data_error(conn, job.job_key, job.file_name, client_file)

    logger.info("Job completed - now updating job related information")
    update(
        job
    )  # updating Job table ends. Any failure in following steps will not be recorded in Job table.

    # sends notification upon receiving the missing file after sla
    logger.info(
        "Now checking whether the SLA Failure Email  need to be sent ( Client File ID =%d)  ",
        client_file.client_file_id,
    )
    check_file_receipt_after_sla_end(conn, job)


# TODO: remove this unused function
def from_database_export_cvs_to_bci(arguments: List[str]) -> None:
    """This function runs the whole CVS to database  process. It will validate the file, split it, and load,
    the file in to database. Jobs logs are tracked upon start and end of the function in the Redshift
    tables.
    """
    logger.info("Job initialisation started..")
    job = initialize(arguments)
    logger.info(log_job_status_begin(job))

    if job.job_status != RUNNING:
        update(job)
        logger.debug("Failure at initialize job_logger")
        logger.critical(log_job_status_end(job))
        return None

    job = export_bci_file(arguments, job)

    if job.job_status != SUCCESS:
        update(job)
        logger.debug("Failure at export_bci_file")
        logger.critical(log_job_status_end(job))
        return None

    logger.info("Job completed")
    update(job)

    conn = get_connection(job.secret_name)
    client_file = get_client_file_info(conn, job.client_file_id)

    # checks whether outbound file is generated as per sla and sends notification if found one
    if client_file.outbound_successful_acknowledgement:
        logger.info(
            "process_flow : from_database_export_cvs_to_bci : Alert is Active - Attempting to send outbound file generation alert"
        )
        file_with_count = " and ".join(
            [
                f"{file} ({count} records)"
                for file, count in zip(job.output_file_name, job.record_count)
            ]
        )
        # notify_outbound_file_generation(client_file, file_with_count)

    else:
        logger.info(
            "Outbound_successful_acknowledgement is set to 'False' and any alert is not required"
        )

    logger.info(log_job_status_end(job))

    return None


def log_job_status_begin(job: Job) -> str:
    """
    This function has no business impact but will make the life of a developer very easy. Earlier when you look at the job log
    in CloudWatch, it was very difficult to understand which is the start and end step after each run. But now log will clearly show the
    details like job_key, process_name, status and output_file_name etc..
    """
    log_result = f"{'*' * 100} "
    # if job.client_file_id in [
    #     INBOUND_BCI_TO_CVS_CLIENT_FILE_ID,
    #     INBOUND_CVS_TO_DATABASE_CLIENT_FILE_ID,
    #     INBOUND_CVS_RECON_INTEG_TO_DATABASE_CLIENT_FILE_ID,
    #     INBOUND_BCI_ERROR_TO_DATABASE_CLIENT_FILE_ID,
    # ]:
    return f"{log_result} {os.linesep}  Process : {job.job_name} [ Job Key : {job.job_key}] :  Started  : Incoming File Name is : {get_name(job.pre_processing_file_location)} {os.linesep}{log_result}"
    # else:
    #     return f"{log_result} {os.linesep} Process : {job.job_name} :  Started  {os.linesep}{log_result}"


def log_job_status_end(job: Job, custom_message: Optional = None) -> str:
    """
    This function has no business impact but will make the life of a developer very easy. Earlier when you look at the job log
    in CloudWatch, it was very difficult to understand which is the start and end step after each run. But now log will clearly show the
    details like job_key, process_name, status and output_file_name etc..
    """
    log_result = f"{'*' * 100} "
    if custom_message is None:
        if job.job_status != SUCCESS:
            return f"{log_result}{os.linesep} Process : {job.job_name} [ Job Key : {job.job_key}]:  Result :{job.job_status}  (No Outbound File Generated) Error Message (if any) : {job.error_message}{os.linesep} {log_result}"
        else:
            return f"{log_result}{os.linesep}Process : {job.job_name} [ Job Key : {job.job_key}]:  Result :  {job.job_status} Output File : {get_name(job.output_file_name)}  {os.linesep}{log_result}"
    else:
        return f"{log_result}{os.linesep} Process : {job.job_name} [ Job Key : {job.job_key}]: Result : {custom_message} {os.linesep}{log_result}"


def get_name(file_object) -> str:
    if isinstance(file_object, list):
        return file_object
    if not file_object or file_object.isspace():
        return "EMPTY (Not Required)"
    else:
        return file_object


def custom_to_standard(arguments: List[str]) -> None:
    """This function runs the whole custom to standard process.
    It gets the mapping table data for the given client id from custom_to_standard_mapping table
    Reads the custom file, generate standard file based on the mapping information
    """
    logger.info("Job initialization started....")
    job = initialize(arguments)
    logger.info(log_job_status_begin(job))

    if job.job_status != RUNNING:
        update(job)
        logger.debug("Failure at initialize job_logger")
        logger.critical(log_job_status_end(job))
        return None
    # To Validate whether the file is duplicate
    if is_it_duplicate_file(
            job.s3_bucket_name,
            job.client_file_info.archive_folder,
            job.pre_processing_file_location.split("/")[-1],
    ):
        logger.info(
            " %s file found in the %s folder ",
            job.pre_processing_file_location,
            job.client_file_info.archive_folder,
        )
        em = "%s incoming file found in the %s folder, can not process it" % (
            job.pre_processing_file_location,
            job.client_file_info.archive_folder,
        )
        complete_custom_to_standard_job(
            job,
            FAIL,
            file_record_count=0,
            error_message=em,
        )
        logger.critical(log_job_status_end(job))
        return None
    connection = get_connection(job.secret_name)
    mapping_data = get_custom_to_standard_mappings_for_client(
        connection, job.client_file_info.client_file_id
    )
    if not mapping_data:
        complete_custom_to_standard_job(
            job,
            FAIL,
            file_record_count=0,
            error_message=f"Mapping Information is not available for the client file id : {job.client_file_info.client_file_id}",
        )
        logger.critical(log_job_status_end(job))
        return None
    logger.info(
        "Retrieved %d Mapping Records for the cilent file id: %d ",
        len(mapping_data),
        job.client_file_info.client_file_id,
    )
    lines = split_file(job.s3_bucket_name, job.pre_processing_file_location)
    if not lines:
        complete_custom_to_standard_job(
            job,
            FAIL,
            file_record_count=0,
            error_message=f"There are no lines to process from the file: {job.pre_processing_file_location}",
        )
        logger.critical(log_job_status_end(job))
        return None
    logger.info("Number of Input File Lines: %s", len(lines))
    try:
        # To get the unique batch number for every run if we receive multiple files on the same day
        start_timestamp = get_local_midnight_time_from_utc_time(job.client_file_info.file_timezone)
        current_timestamp = datetime.utcnow()
        connection = get_connection(job.secret_name)
        file_count = get_file_count(
            connection, job.client_file_id, start_timestamp, current_timestamp
        )
        file_record_count = len(lines) - 2  # Excluding header and trailer
        standard_lines = generate_standard_lines(lines, mapping_data, (file_count + 1))
        now_et = tz_now()
        standard_file_name_with_path = os.path.join(
            job.client_file_info.extract_folder,
            f"{job.client_file_info.s3_output_file_name_prefix}{now_et.strftime(FILE_TIMESTAMP_FORMAT)}.TXT",
        )
        create_s3_file(
            job.s3_bucket_name,
            standard_file_name_with_path,
            "".join(standard_lines),
        )
        logger.info(
            "custom_to_standard process completed, File has been generated. File Name: %s",
            standard_file_name_with_path,
        )
        complete_custom_to_standard_job(
            job,
            SUCCESS,
            file_record_count=file_record_count,
            output_file_name=standard_file_name_with_path,
        )
        logger.info(log_job_status_end(job))
        # sends notification upon receiving the missing file after sla
        logger.info(
            "Now checking whether the SLA Failure Email  need to be sent ( Client File ID =%d)  ",
            job.client_file_id,
        )
        check_file_receipt_after_sla_end(connection, job)
    except Exception as ex:
        logger.error("custom_to_standard process failed.")
        logger.exception(ex)
        complete_custom_to_standard_job(
            job, FAIL, error_message=f"Failed to generate the standard File : {str(ex)}"
        )
        logger.critical(log_job_status_end(job))
    return None


def generate_standard_lines(lines: list, mapping_data: list, batch_number: int) -> list:
    """Function to generate the standard lines from custom lines
    :param lines: Custom file lines
    :param mapping_data: maping infrmation
    :param batch_number: Holds the retrieved batch number value
    returns the standard lines
    """
    standard_lines = []
    try:
        standard_header_row = generate_standard_row(
            "Header", "", lines[0], mapping_data, "0", batch_number
        )
    except Exception as e:
        raise Exception("Error While generating standard Header Row :" + str(e))
    standard_lines.append(standard_header_row + os.linesep)
    for linenumber, line in enumerate(lines[1:-1], start=1):
        try:
            standard_lines.append(
                generate_standard_row(
                    "Detail", standard_header_row, line, mapping_data, str(linenumber), batch_number
                )
                + os.linesep
            )
        except Exception as e:
            raise Exception(
                f"Error While generating standard Detail Row. Line number {linenumber} : {str(e)}"
            )
    try:
        standard_footer_row = generate_standard_row(
            "Footer",
            standard_header_row,
            lines[len(lines) - 1],
            mapping_data,
            str(len(lines)),
            batch_number,
        )
    except Exception as e:
        raise Exception("Error While generating standard Footer Row :" + str(e))
    standard_lines.append(standard_footer_row + os.linesep)
    return standard_lines


def complete_custom_to_standard_job(
        job: Job,
        job_status: str,
        file_record_count: Optional[int] = 0,
        output_file_name: Optional[str] = "",
        error_message: Optional[str] = "",
) -> None:
    """Function to update the Job table and move the files to either erro /archive folder
    :param job: a Job object.
    :param job_status: status of the job,
    :param file_record_count: Total number of detail lines from inut file (total lines -2)
    :param output_file_name: Standard  file name generated
    :param error_message: If job_status  FAIL, then the corresponding error message
    :return: None
    """
    job.job_end_timestamp = get_timestamp()
    job.job_status = job_status
    if file_record_count:
        job.file_record_count = file_record_count
    if output_file_name:
        job.output_file_name = output_file_name
        job.post_processing_file_location = job.client_file_info.archive_folder
        move_file(
            job.s3_bucket_name,
            job.pre_processing_file_location,
            job.s3_bucket_name,
            os.path.join(
                job.client_file_info.archive_folder,
                os.path.basename(job.pre_processing_file_location),
            ),
        )
        logger.info("Moved the file to archive folder.")
    if error_message:
        job.error_message = error_message
        job.post_processing_file_location = job.client_file_info.error_folder
        destination_file_name_with_path = os.path.join(
            job.client_file_info.error_folder,
            os.path.basename(job.pre_processing_file_location),
        )
        move_file(
            job.s3_bucket_name,
            job.pre_processing_file_location,
            job.s3_bucket_name,
            destination_file_name_with_path,
        )
        logger.info("Moved the file to error folder.")
        if job.validate_file_structure and job.client_file_info.is_data_error_alert_active:
            send_file_structure_error_notification(
                job.client_file_info, destination_file_name_with_path, error_message
            )
    job.input_sender_id = job.client_file_info.input_sender_id
    job.input_receiver_id = job.client_file_info.input_receiver_id
    update(job)
