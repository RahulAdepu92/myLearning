from ..redshift import execute_query
from ..glue import get_glue_logger
import logging
from typing import List


logger = get_glue_logger(name=f"{__name__}", logging_level=logging.DEBUG)


def is_active_maintenance(conn, client_file_id: int) -> bool:
    """This function retrieves whether for the given file is there any active mainteance window going on ? 
    :param conn: The redshift connection.
    :param client_file_id: The client file id  which denoes the file type
    :returns: True/False , True indicates active maintenance window, and False indicates no active mainteance window
    """
    # Pass a client file ID and returns the client file information in a Client_File Object
    sql = f"""SELECT COUNT(*) FROM AHUB_DW.FILE_MAINTENANCE_WINDOW A
            WHERE GETDATE() BETWEEN A.START_TIME AND A.END_TIME AND A.CLIENT_FILE_ID = $1 """

    sql_arg = (client_file_id,)

    logger.info("query: (%s) with arguments (%s)", sql, sql_arg)

    result = execute_query(conn, sql, sql_arg)
    row = result.getresult()
    count = row[0]
    if count > 0:
        return True
    return False
