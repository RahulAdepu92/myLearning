import logging
from typing import List, Tuple, Union
from datetime import datetime
from ..constants import SCHEMA_DW, TABLE_CLIENT_FILES, TABLE_CLIENT, TABLE_JOB
from ..notifications import account_id
from ..common import get_parameter, execute_query_module, tz_now
from ..model import ClientFile, FileSplitEnum
from ..glue import get_glue_logger
from ..s3 import delete_s3_files
from .dbi import AhubDb

db_module = ""

try:
    import pg
    from ..redshift import (
        get_connection,
        execute_query,
    )

    db_module = "pg"

except ImportError:
    import psycopg2
    from ..redshift_for_lambda import get_connection, execute_query

logger = get_glue_logger(name=f"{__name__}", logging_level=logging.DEBUG)

current_utc_time = datetime.utcnow()

common_sql = f"""select a.client_file_id, a.client_id, b.name, b.abbreviated_name as client_abbreviated_name, a.name_pattern, 
        a.file_type, a.created_by, a.data_error_notification_sns, a.data_error_threshold, a.is_data_error_alert_active , 
        a.processing_notification_sns, a.file_timezone, a.process_duration_threshold,
        a.file_description, a.outbound_file_generation_notification_sns, a.outbound_successful_acknowledgement, 
        a.environment_level, a.archive_folder, a.error_folder, a.structure_specification_file, a.expected_line_length, a.redshift_glue_iam_role_name, 
        a.s3_merge_output_path, a.outbound_file_type_column, a.outbound_transmission_type_column, a.input_sender_id, a.output_sender_id, 
        a.input_receiver_id, a.output_receiver_id, a.s3_output_file_name_prefix, a.file_processing_location, a.position_specification_file, 
        a.validate_file_structure, a.validate_file_detail_columns, a.process_name, a.process_description, a.reserved_variable, 
        a.file_category, a.is_active, a.glue_job_name, a.file_extraction_error_notification_sns,
        a.deliver_files_to_client, a.destination_bucket_cfx, a.destination_folder_cfx, a.zip_file, a.extract_folder, a.column_rule_id_for_transmission_id_validation ,
        a.error_file, a.inbound_successful_acknowledgement, a.inbound_file_arrival_notification_sns
        from {SCHEMA_DW}.{TABLE_CLIENT_FILES} a join {SCHEMA_DW}.{TABLE_CLIENT} b on a.client_id = b.client_id """


def get_client_file_info(conn, client_file_id: int) -> ClientFile:
    """This function retrieves the record from the client files table and creates a Client_File object to be used.
    :param conn: The redshift connection.
    :param client_file_id: The client file id that is used to get the unique record from the table.
    :returns: A Client_File object containing all the information from the query.
    """
    # Pass a client file ID and returns the client file information in a Client_File Object
    sql = f"{common_sql} where  a.client_file_id = {_param_format(1)} "

    sql_arg = (client_file_id,)

    logger.info("get_client_file_info: query: (%s) with arguments (%s)", sql, sql_arg)

    row = execute_query_module(conn, sql, sql_arg)
    # row = result.getresult()

    logger.info("sql results: %s", row)
    if row is not None:
        return get_client_file_from_record(row[0])
    return None


def get_client_files(conn, client_id: int) -> List[ClientFile]:
    """This function retrieves the record from the client files table and creates a collection of Client_File objects to be used.
    :param conn: The redshift connection.
    :param client_file_id: The client file id that is used to get the unique record from the table.
    :returns: A collection of Client_File objects containing all the information from the query.
    """
    # Pass a client ID and returns the client files information in a collection
    sql = f"{common_sql} where a.client_id = {_param_format(1)} "

    sql_arg = (client_id,)

    logger.info("query: (%s) with arguments (%s)", sql, sql_arg)

    rows = execute_query_module(conn, sql, sql_arg)
    # rows = result.getresult()

    client_files = []

    if rows is not None:
        for row in rows:
            client_files.append(get_client_file_from_record(row))

    return client_files


def get_all_client_files(conn) -> List[ClientFile]:
    """This function retrieves all records from the client files table and creates a Client_File object to be used.
    :param conn: The redshift connection.
    :returns: A Client_File object containing all the information from the query.
    """
    # Pass a client file ID and returns the client file information in a Client_File Object
    sql = f"{common_sql}"

    logger.info("query: (%s)", sql)

    rows = execute_query_module(
        conn,
        sql,
    )
    # rows = result.getresult()

    client_files = []

    if rows is not None:
        for row in rows:
            client_files.append(get_client_file_from_record(row))

    return client_files


def get_client_file_info_from_name_pattern(conn, file_name_pattern: str) -> ClientFile:
    """This function retrieves selective records from the client files table that are needed by a lambda
    to trigger a glue job and creates a Client_File object to be used.
    :param conn: The redshift connection.
    :param file_name_pattern: incoming s3 file prefix ( before 3rd '_' character)  which is retrieved from trigger event
    :returns: A Client_File object containing all the information from the query.

    """
    # Pass a client file ID and returns the client file information in a Client_File Object

    sql = f""" {common_sql} where a.name_pattern like {_param_format(1)} """

    # include 3rd underscore in the search criteria and add backslash character ('\\') that will escape metacharacters characters in the file name pattern.
    # two percentiles are included as psycopg2 module allows %% instead of % when like clause is used
    sql_arg = (file_name_pattern + "\\_%%",)
    logger.info(" query: (%s) with arguments (%s)", sql, sql_arg)

    row = execute_query_module(conn, sql, sql_arg)

    logger.info("sql results: %s", row)
    if row is not None:  # if list is non empty
        return get_client_file_from_record(row[0])
    return None


def get_client_file_from_record(row) -> ClientFile:
    """This function helps set the information from the pg query into a Client_File object.
    :param client_file: The client file object that we want to update values.
    :param row: The row/record of the result set from the pg query.
    """
    client_file = ClientFile()

    # unpack sql result output (a list) to variables
    # make sure that the order of columns specified in 'common_sql' above should be in sync while unpacking the indexes
    (
        client_file_id,
        client_id,
        name,
        abbreviated_name,
        name_pattern,
        file_type,
        created_by,
        data_error_notification_sns,
        data_error_threshold,
        is_data_error_alert_active,
        processing_notification_sns,
        file_timezone,
        process_duration_threshold,
        file_description,
        outbound_file_generation_notification_sns,
        outbound_successful_acknowledgement,
        environment_level,
        archive_folder,
        error_folder,
        structure_specification_file,
        expected_line_length,
        redshift_glue_iam_role_name,
        s3_merge_output_path,
        outbound_file_type_column,
        outbound_transmission_type_column,
        input_sender_id,
        output_sender_id,
        input_receiver_id,
        output_receiver_id,
        s3_output_file_name_prefix,
        file_processing_location,
        position_specification_file,
        validate_file_structure,
        validate_file_detail_columns,
        process_name,
        process_description,
        reserved_variable,
        file_category,
        is_active,
        glue_job_name,
        file_extraction_error_notification_sns,
        deliver_files_to_client,
        destination_bucket_cfx,
        destination_folder_cfx,
        zip_file,
        extract_folder,
        column_rule_id_for_transmission_id_validation,
        error_file,
        inbound_successful_acknowledgement,
        inbound_file_arrival_notification_sns,
    ) = row

    # random assigned value to each inbound or outbound file
    client_file.client_file_id = client_file_id or client_file.client_file_id
    # random assigned value to each client
    client_file.client_id = client_id or client_file.client_id
    # full name of client
    client_file.client_name = name or client_file.client_name
    # abbreviated name of client
    client_file.client_abbreviated_name = abbreviated_name or client_file.client_abbreviated_name
    # pattern of incoming file. This is very crucial and below all arguments are read depending on this value.
    client_file.name_pattern = name_pattern or client_file.name_pattern
    # tells whether file is inbound or outbound
    client_file.file_type = file_type or client_file.file_type
    client_file.created_by = created_by or client_file.created_by  # default value to AHUB
    # sns arn for sending data error alerts
    client_file.data_error_notification_sns = (
        data_error_notification_sns or client_file.data_error_notification_sns
    )
    # maximum allowed value for accepting data errors in incoming file
    client_file.data_error_threshold = data_error_threshold or client_file.data_error_threshold
    # acknowledges whether data error alert for incoming file is to be sent are not
    client_file.is_data_error_alert_active = (
        is_data_error_alert_active or client_file.is_data_error_alert_active
    )

    # sns arn for sending processing alerts
    client_file.processing_notification_sns = (
        processing_notification_sns or client_file.processing_notification_sns
    )
    # provides timezone info where incoming file arrives from
    client_file.file_timezone = file_timezone or client_file.file_timezone
    # maximum duration of time(in seconds) at which a process can run
    client_file.process_duration_threshold = (
        process_duration_threshold or client_file.process_duration_threshold
    )
    # Such as 06/02/2020 in mm/dd/yyyy format

    # sla start time of incoming/outgoing file, such as 05:00 AM

    # sla end time of incoming/outgoing file ,such as 05:30

    # describes incoming file
    client_file.file_description = file_description or client_file.file_description
    # sns arn for outbound file generation alert
    client_file.outbound_file_generation_notification_sns = (
        outbound_file_generation_notification_sns
        or client_file.outbound_file_generation_notification_sns
    )
    # acknowledges whether outbound file generation alert is to be sent or not
    client_file.outbound_successful_acknowledgement = (
        outbound_successful_acknowledgement or client_file.outbound_successful_acknowledgement
    )

    # AWS environment at which file is processing
    client_file.environment_level = environment_level or client_file.environment_level
    # path where incoming file will be moved to after inbound processing is successfully finished
    client_file.archive_folder = archive_folder or client_file.archive_folder
    # path where incoming file will be moved to when error is found in it
    client_file.error_folder = error_folder or client_file.error_folder
    # path of csv file which is used for validation of incoming file
    client_file.structure_specification_file = (
        structure_specification_file or client_file.structure_specification_file
    )
    # record length used to validate incoming file structure
    client_file.expected_line_length = expected_line_length or client_file.expected_line_length
    # IAM role name for accessing redshift through glue
    client_file.redshift_glue_iam_role_name = (
        redshift_glue_iam_role_name or client_file.redshift_glue_iam_role_name
    )
    # TODO: use get_redshift_glue_iam_role_arn instead
    client_file.redshift_glue_iam_role_arn = (
        f"arn:aws:iam::{account_id}:role/{client_file.redshift_glue_iam_role_name}"
    )
    # IAM role ARN for accessing redshift through glue
    # file path where outbound HDR, DTL and TLR files are merged
    client_file.s3_merge_output_path = s3_merge_output_path or client_file.s3_merge_output_path
    # file_type column in outgoing file
    client_file.outbound_file_type_column = (
        outbound_file_type_column or client_file.outbound_file_type_column
    )
    # outbound_transmission_type_column field in outgoing file
    client_file.outbound_transmission_type_column = (
        outbound_transmission_type_column or client_file.outbound_transmission_type_column
    )
    # sender_identifier field in incoming file
    client_file.input_sender_id = input_sender_id or client_file.input_sender_id
    # receiver_identifier field in outgoing file
    client_file.output_sender_id = output_sender_id or client_file.output_sender_id
    # receiver_identifier field in incoming file
    client_file.input_receiver_id = input_receiver_id or client_file.input_receiver_id
    # receiver_identifier field in outgoing file
    client_file.output_receiver_id = output_receiver_id or client_file.output_receiver_id
    # shows how outbound file name is to be fabricated
    client_file.s3_output_file_name_prefix = (
        s3_output_file_name_prefix or client_file.s3_output_file_name_prefix
    )
    # path where temp files are processed
    client_file.file_processing_location = (
        file_processing_location or client_file.file_processing_location
    )
    # provides path of range file used to split incoming file
    client_file.position_specification_file = (
        position_specification_file or client_file.position_specification_file
    )
    # decides whether file is to be validated structural wise
    client_file.validate_file_structure = (
        validate_file_structure or client_file.validate_file_structure
    )
    # decides whether detail records in incoming file are to be validated as per column rules
    client_file.validate_file_detail_columns = (
        validate_file_detail_columns or client_file.validate_file_detail_columns
    )
    # names on going process (like a title card)
    client_file.process_name = process_name or client_file.process_name
    # describes on going process in detail
    client_file.process_description = process_description or client_file.process_description
    # used as a reserve for any additional argument that has to be passed in favor of any incoming file apart from the above default arguments
    client_file.reserved_variable = reserved_variable or client_file.reserved_variable
    # specifies the category under which the incoming file falls (commercial/government programs)
    client_file.file_category = file_category or client_file.file_category
    # gets the expected file name that is useful while sending sla alerts
    client_file.expected_zip_file_name = get_file_name_from_pattern(client_file.name_pattern)
    # specifies if client is active or not
    client_file.is_active = is_active or client_file.is_active
    # specifies the glue job name that is to be executed for processing incoming file
    client_file.glue_job_name = glue_job_name or client_file.glue_job_name
    # sns topic name used upon encountering error while unzipping an incoming file
    client_file.file_extraction_error_notification_sns = (
        file_extraction_error_notification_sns or client_file.file_extraction_error_notification_sns
    )
    # flag used to decide whether zipped or unzipped file is to be sent to CFX or not.
    client_file.deliver_files_to_client = (
        deliver_files_to_client or client_file.deliver_files_to_client
    )
    # provides the CFX S3 bucket name where processed files from Ahub are dropped in
    client_file.destination_bucket_cfx = (
        destination_bucket_cfx or client_file.destination_bucket_cfx
    )
    # provides the CFX S3 bucket folder to which processed files from Ahub should be sent to
    client_file.destination_folder_cfx = (
        destination_folder_cfx or client_file.destination_folder_cfx
    )
    # flag used to decide whether the outgoing file is to be zipped or not while sending to CFX
    client_file.zip_file = zip_file or client_file.zip_file
    client_file.extract_folder = extract_folder or client_file.extract_folder
    client_file.column_rule_id_for_transmission_id_validation = (
        column_rule_id_for_transmission_id_validation
        or client_file.column_rule_id_for_transmission_id_validation
    )
    client_file.error_file = error_file or client_file.error_file
    client_file.inbound_successful_acknowledgement = inbound_successful_acknowledgement or client_file.inbound_successful_acknowledgement
    client_file.inbound_file_arrival_notification_sns = inbound_file_arrival_notification_sns or client_file.inbound_file_arrival_notification_sns
    return client_file


def get_client_file_ids(conn, file_type: str) -> List:
    """
    This function gets the list of client file ids given the file_type
    :param conn: The connection to redshift.
    :param file_type: The file type (INBOUND/OUTBOUND).
    """
    select_query = f"select client_file_id from {SCHEMA_DW}.{TABLE_CLIENT_FILES} where file_type={_param_format(1)} order by client_file_id"
    select_query_args = (file_type,)

    logger.info(
        "query: %s with args: %s",
        select_query,
        select_query_args,
    )

    rows = execute_query_module(conn, select_query, select_query_args)

    return rows


def get_file_name_from_pattern(pattern: str) -> str:
    """Based on the pattern specified returns the fully qualified ZIP file name

    Args:
        pattern (str): File name such as : ACCDLYINT_PRD_CVSINRX_MMDDYY.HHMMSS

    Returns:
        str: File name with month day and year specified.
    """
    file_suffix_full = {
        "YYMMDDHHMMSS": "%y%m%d",
        "MMDDYY.HHMMSS": "%m%d%y",
        "MMDDYYHHMMSS": "%m%d%y",
    }
    file_suffix_partial = {
        "YYMMDDHHMMSS": "HHMMSS",
        "MMDDYY.HHMMSS": ".HHMMSS",
        "MMDDYYHHMMSS": "HHMMSS",
    }
    utc_now = datetime.utcnow()
    # Splits the incoming pattern and pulls out the last part based on underscore
    # If pattern is : ACCDLYINT_PRD_CVSINRX_MMDDYY.HHMMSS, then MMDDYY.HHMMSS
    substring = pattern.split("_")[-1]
    # Identifies teh string based on the dictionary
    # If MMDDYY.HHMMSS needs to be translated in to python equilvalent of %m%d%y
    time_prefix = utc_now.strftime(file_suffix_full[substring])

    prefix = pattern[0 : pattern.find(substring)]
    # prefix would contain from the begin 0 to the last underscore
    # in case of ACCDLYINT_PRD_CVSINRX_MMDDYY.HHMMSS , it would return the ACCDLYINT_PRD_CVSINRX_
    return f"{prefix}{time_prefix}{file_suffix_partial[substring]}.ZIP"


def _param_format(param_number: int) -> str:
    """Formats a parameter based on the currently selected db_module."""
    return get_parameter(db_module, param_number)


class ClientFileRepo(AhubDb):
    _select_query = f"""
            select cf.client_file_id, cf.client_id, c.name, c.abbreviated_name as client_abbreviated_name, cf.name_pattern, 
            cf.file_type, cf.created_by, cf.data_error_notification_sns, cf.data_error_threshold, cf.is_data_error_alert_active , 
            cf.processing_notification_sns, cf.file_timezone, cf.process_duration_threshold,
            cf.file_description, cf.outbound_file_generation_notification_sns, cf.outbound_successful_acknowledgement, 
            cf.environment_level, cf.archive_folder, cf.error_folder, cf.structure_specification_file, cf.expected_line_length, cf.redshift_glue_iam_role_name, 
            cf.s3_merge_output_path, cf.outbound_file_type_column, cf.outbound_transmission_type_column, cf.input_sender_id, cf.output_sender_id, 
            cf.input_receiver_id, cf.output_receiver_id, cf.s3_output_file_name_prefix, cf.file_processing_location, cf.position_specification_file, 
            cf.validate_file_structure, cf.validate_file_detail_columns, cf.process_name, cf.process_description, cf.reserved_variable, 
            cf.file_category, cf.is_active, cf.glue_job_name, cf.file_extraction_error_notification_sns,
            cf.deliver_files_to_client, cf.destination_bucket_cfx, cf.destination_folder_cfx, cf.zip_file,
            es.export_setting_id,
            es.header_query, es.detail_query, es.trailer_query, es.update_query,
            es.create_empty_file, es.precondition, cf.extract_folder, cf.column_rule_id_for_transmission_id_validation , cf.error_file
            from {SCHEMA_DW}.{TABLE_CLIENT_FILES} cf inner join {SCHEMA_DW}.{TABLE_CLIENT} c on cf.client_id = c.client_id 
                left join {SCHEMA_DW}.export_setting es on es.client_file_id = cf.client_file_id"""

    def __init__(self, **kwargs):
        super().__init__(tables_to_lock=[f"{SCHEMA_DW}.{TABLE_JOB}"], **kwargs)

    def get_client_file(self, client_file_id: int) -> ClientFile:
        """Retrieves a ClientFile based on its id

        :param client_file_id: the id of the client file to get retrieved."""
        sql = f"{ClientFileRepo._select_query} where  cf.client_file_id = :id "
        row = self.get_one(sql, id=client_file_id)
        if row is None:
            return None
        cf = ClientFile.from_dict(**row)
        if row["export_setting_id"] is not None:
            cf._export_settings = ClientFile.ExportSettings(
                client_file_id=client_file_id,
                header_query=row["header_query"],
                detail_query=row["detail_query"],
                trailer_query=row["trailer_query"],
                update_query=row["update_query"],
                precondition=row["precondition"],
                create_empty_file=bool(row["create_empty_file"]),
            )

        return cf

    def get_export_settings(
        self, client_file: Union[int, str, ClientFile], for_date: datetime = None
    ) -> ClientFile.ExportSettings:
        """Gets the export settings for a client file id.
        If for_date is None, it assumes current date.
        :param client_file_it: int or string - the client file id
        :param for_date: effective date time for settings. A client file
        may have different settings for different date ranges.
        If None, assumes "today"
        :return: a tuple of header query, detail query, trailer query, update_query

        Note: the queries will need to be run through string.format
        and have the following parameters provided:
        * routing_id - a routing identifier for the file so that all the records have a
        consistent identifier;
        * s3_out_bucket - the bucket where we export the file
        * s3_file_path - the path to the file where we export the data
        * iam_role - the role used to export the file
        """
        sql = (
            "select header_query, detail_query, trailer_query, update_query, precondition, create_empty_file "
            "from ahub_dw.export_setting "
            "where client_file_id=:id and effective_from <= :date and :date <= effective_to"
        )
        for_date = datetime.now() if for_date is None else for_date
        if isinstance(client_file, ClientFile):
            if client_file._export_settings is not None:
                return client_file._export_settings

            client_file_id = client_file.client_file_id
        else:
            client_file_id = client_file

        row = self.get_one(sql, id=client_file_id, date=for_date)
        # TODO: guard against no records
        export_settings = ClientFile.ExportSettings(
            client_file_id=client_file_id,
            header_query=row["header_query"],
            detail_query=row["detail_query"],
            trailer_query=row["trailer_query"],
            update_query=row["update_query"],
            precondition=row["precondition"],
            create_empty_file=bool(row["create_empty_file"]),
        )

        if isinstance(client_file, ClientFile):
            client_file._export_settings = export_settings

        return export_settings

    def export_fragments(
        self, client_file: ClientFile, s3_out_bucket: str, job_key: str
    ) -> List[str]:
        """Exports the client file to a specified bucket into 3 files:
        a header file that identifies the parties (sender and receiver),
        a detail file containing all the records, and
        a trailer file that typically contains a checksum-like count.

        :param client_file: the client file to be exported
        :param s3_out_bucket: the bucket where to export the files
        :param job_key: the job that exports the records (used to mark
        the records as exported upon method completion)
        :return: a list of files, in order header, detail, trailer,
        that contains the full path of the exported files within the
        provided S3 bucket.

        If there no records to export and create_empty_file export setting was True,
        the function returns an empty array indicative of no files having been created."""
        export_settings: ClientFile.ExportSettings = self.get_export_settings(client_file)

        if not self.can_export(export_settings):
            logger.info(
                "Client file %s does not meet the precondition for export at this time.",
                client_file.client_file_id,
            )
            return []

        export_files_and_queries: List[Tuple[str, str]] = ClientFileRepo._build_exports(
            client_file=client_file,
            export_settings=export_settings,
            s3_out_bucket=s3_out_bucket,
            temp_file_prefix=job_key,
        )

        for (export_file, export_query) in export_files_and_queries:
            try:
                logger.info("FILE: %s export using query: %s", export_file, export_query)
                self.execute(export_query)
            except Exception as ex:
                logger.exception()
                raise FileExportException(
                    client_file.client_file_id, export_query, export_file
                ) from ex

        # HACK: even with PARALLEL OFF, Redshift will unload to a {f}000 file.
        # we probably should look up the actual files using the {f} prefix,
        # because Redshift splits them up across multiple files ({f}000, {f}001, etc)
        # at the 6.2 GB boundary
        # https://docs.aws.amazon.com/redshift/latest/dg/r_UNLOAD.html#unload-parallel
        actual_files = [f"{f}000" for (f, _) in export_files_and_queries]

        logger.debug("UPDATE with job_key=%s: %s", job_key, export_settings.update_query)
        # executing update query
        rows_updated = self.execute(export_settings.update_query, job_key=job_key)
        logger.info("UPDATE with job_key=%s: %s rows", job_key, rows_updated)

        if rows_updated == 0 and not export_settings.create_empty_file:
            # delete all the fragments since we don't export an empty file
            logger.info(
                "Zero records exported and create_empty_file is False. Deleting fragments: %r",
                actual_files,
            )
            delete_s3_files(s3_out_bucket, *actual_files)
            return []

        return actual_files

    def can_export(self, export_settings: ClientFile.ExportSettings) -> bool:
        """Determines whether the file meets the precondition set in export_settings.
        :param export_settings: a client file export settings instance.

        The requirement laid by AHUB-624 is that we don't create an empty file
        if we received no INBOUND files.
        For AHUB-to-Client export this precondition ensures we don't export
        empty files if we received no files from CVS; conversely, we don't
        create empty files to CVS if we received no client files for a given
        period.

        The purpose of this method is not to pass judgement or capture that requirement
        but merely to check if a pre-condition is met before exporting a file.
        As of the 2020-12-18 release, this precondition is captured in the form of
        query, but in the future we could very well expand this to more
        complex python code.
        """
        if not export_settings.precondition:
            logger.info(
                "No export precondition declared for client file id %s. Export assumed ok.",
                export_settings.client_file_id,
            )
            return True

        # TODO: assumes a URI scheme.
        # If the precondition starts with "python:", then execute a python function,
        # otherwise assume a SQL string.
        # For a SQL string, the precondition should:
        #  1) return 1 row (no rows assumes the precondition failed)
        #  2) the first column should be a truthy value that indicates whether
        #     the export can be performed.
        rows = self.iquery(export_settings.precondition)
        if not rows:
            logger.warning(
                "Precondition for client file %s returned no rows thus implying it should not run. Query: %s",
                export_settings.client_file_id,
                export_settings.precondition,
            )
            return False

        row = rows[0]
        # the precondition should be the first column of the precondition
        # and should be a truthy value
        return bool(row[0])

    def _build_exports(
        client_file: ClientFile,
        export_settings: ClientFile.ExportSettings,
        s3_out_bucket: str,
        temp_file_prefix: Union[str, int],
    ) -> List[Tuple[str, str]]:
        """
        Builds the partial files and the queries to execute to export data
        into those files.
        :param client_file: the client file for which to build the exports
        :param export_settings: the export settings for the client file
        :param s3_out_bucket: where to export the files
        :param temp_file_prefix: a string or an int to prefix the exported
        parts (typicall the job key).
        :return: a list of (file_path, query_to_execute) in the right order
        """
        # determine now in a predefined time-frame (Eastern time) so that we have a consistent timestamps throughout
        about_damn_time = tz_now()

        # Builds identifier fields that are used in the export
        # For example, we use a combination of client file sender id + date time, eg. 00489INGENIORX112722020171819
        # 1. Exporting header
        routing_number = client_file.build_process_routing_id(about_damn_time)

        order = [
            (export_settings.header_query, FileSplitEnum.HEADER),
            (export_settings.detail_query, FileSplitEnum.DETAIL),
            (export_settings.trailer_query, FileSplitEnum.TRAILER),
        ]

        return [
            ClientFileRepo.__build_query(
                query=q,
                query_kind=qkind,
                client_file=client_file,
                routing_id=routing_number,
                s3_out_bucket=s3_out_bucket,
                file_prefix=temp_file_prefix,
            )
            for (q, qkind) in order
        ]

    def __build_query(
        query: str,
        query_kind: FileSplitEnum,
        client_file: ClientFile,
        routing_id: str,
        s3_out_bucket: str,
        file_prefix: str,
    ) -> Tuple[str, str]:
        """Builds the queries to export the files.
        The parametess of this method are all format strings
        found within the query.
        :return: a tuple where the first element is the file path and
          the second is the query, formatted according to the parameters."""
        s3_outbound_temp_path = client_file.file_processing_location
        s3_outbound_temp_file_prefix = f"{file_prefix}_{client_file.s3_output_file_name_prefix}"
        s3_file_path = ClientFileRepo.__make_temp_merge_file_path(
            query_kind, s3_outbound_temp_path, s3_outbound_temp_file_prefix
        )
        iam_role = client_file.get_redshift_glue_iam_role_arn(account_id)

        # These are known strings that show up in the queries a "{name}"
        # Please do not unnecessarily expand this list
        format_args = {
            "routing_id": routing_id,
            "s3_out_bucket": s3_out_bucket,
            "s3_file_path": s3_file_path,
            "iam_role": iam_role,
        }
        try:
            formatted_query = query.format(**format_args)
        except KeyError as e:
            logger.error(
                "Missing key %s when formatting %s using dictionary: %r", e.args, query, format_args
            )
            raise ExportConfigurationException(
                client_file_id=client_file.client_file_id,
                item_in_error=query_kind,
                error_description=f"Cannot find key {e.args}  for string.format",
            )

        return (s3_file_path, formatted_query)

    def __make_temp_merge_file_path(file_type: FileSplitEnum, *path_fragments) -> str:
        """Creates a temporary merge file out of path fragments.
        :param file_type: FileSplitEnum - one of the header, detail, trailer components.
        :param *path_fragments: a list of at least 1 path fragment to turn into a merge file.
        :return: A string representing a full file path

        Examples:
        make_temp_merge_file(FileSplitEnum.HEADER, "foo", "bar") # => "foo/bar_HDR.txt"
        make_temp_merge_file(FileSplitEnum.HEADER, "foo/bar/baz") # => "foo/bar/baz_HDR.txt"
        """
        # the last fragment is the file. take it, append HDR.txt to it
        path = "/".join(path_fragments)
        return f"{path}_{file_type}.txt"


class ExportConfigurationException(Exception):
    """Raised when a configuration exception ocurred.
    The error exposes:
    * client_file_id - the id of the client file having the configuration error
    """

    def __init__(self, client_file_id: Union[str, int], item_in_error: str, error_description: str):
        self.client_file_id = client_file_id
        self.item_in_error = item_in_error
        self.error_description = error_description
        self.message = f"Incorrectly configured {item_in_error} for client file {client_file_id}: {error_description}"
        super().__init__(self.message)


class FileExportException(Exception):
    """Raised when an unload query fails.
    Provides info about the query and the file_path."""

    def __init__(self, client_file_id: Union[str, int], query: str, file_path: str):
        self.client_file_id = client_file_id
        self.query = query
        self.file = file_path
        self.message = f"Failed to export a fragment of client file {client_file_id} to {file_path} using {query}."
        super().__init__(self.message)
