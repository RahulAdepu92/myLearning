"""
Description : Author - Anthony Nguyen (AG40625)

Job Logging

This script is used in the glue job irx_process_inbound_file. It's purpose is to create a record for tracking in the Redshift
table ahub_dw.job, or parent job table. If an error occurs as processes finished, it will update the record early and exit out of the glue job.
If no error occurs, it will update the record with job_status 'Success'. Each process inside the glue job will be connected
to this record through the 'job_key'.
"""

import logging
import sys
from awsglue.utils import getResolvedOptions
from ..glue import get_glue_logger
from ..model import Job
from ..redshift import (
    get_connection,
    insert_id,
    execute_query,
)
from datetime import datetime
from typing import List, Optional
from ..file import get_timestamp, get_process_description
from ..constants import (
    TABLE_JOB,
    TABLE_JOB_DETAIL,
    SCHEMA_DW,
    DEFAULT_DELIMITER,
    NULL,
    RUNNING,
    FAIL,
)
from ..notifications import send_email_notification_for_process_duration
from ..database.client_files import get_client_file_info

logger = get_glue_logger(name=f"{__name__}", logging_level=logging.DEBUG)


def initialize(arguments: List[str], file: Optional[str] = None) -> Job:
    """Sets environment variables and calls insert_job()
    :param arguments: a list of variables that will be resolved to retrieve environment variables
    :param job_name: the name of the job to be displayed in the table
    :param file_type: transmission type, should be either Inbound or Outbound
    :param file: file that will go into the job log. 
    :return: a Job object
    """
    args = getResolvedOptions(
        arguments,
        [
            "SECRET_NAME",
            "S3_FILE_BUCKET",
            "S3_FILE_NAME",
            "CLIENT_FILE_ID",
            "PROCESS_NAME",
            "FILE_TYPE",
        ],
    )
    logger.debug("Printing sys.argv: %r", sys.argv)

    # below variables are retrieved upon starting a glue job that will be invoked by Lambda
    result_file = args["S3_FILE_NAME"]
    if file is not None:
        result_file = file
    secret_name = args["SECRET_NAME"]
    s3_bucket_name = args["S3_FILE_BUCKET"]
    client_file_id = int(args["CLIENT_FILE_ID"])
    job_name = args["PROCESS_NAME"]
    file_type = args["FILE_TYPE"]

    conn = get_connection(secret_name)
    client_id = get_client_id_using_client_file_id(
        conn, schema=SCHEMA_DW, client_file_id=client_file_id
    )
    logger.info("Client ID is  %d , client file id is : %d", client_id, client_file_id)

    job = insert_job(
        result_file,
        s3_bucket_name,
        SCHEMA_DW,
        secret_name,
        client_id,
        job_name,
        file_type,
        client_file_id,
    )
    job.set_file_name(job.job_key)

    return job


def insert_job(
    file: str,
    s3_bucket_name: str,
    schema: str,
    secret_name: str,
    client_id: int,
    job_name: str,
    file_type: str,
    client_file_id: int,
) -> Job:
    """Executes a redshift query to insert a record into ahub_dw.job table. Record will contain the parent job information.
    :param file: the inbound/outbound file
    :param schema: the db schema
    :param secret_name: the secret name for Redshift connection
    :param client_id: the client id
    :param job_name: the name of the job to be displayed in the table
    :param file_type: transmission type, should be either Inbound or Outbound
    :return: a Job object
    """
    # create_redshift_connection(redshift_host, redshift_port, redshift_database, redshift_user, redshift_password)
    conn = get_connection(secret_name)

    file_name = file.split("/")[-1]

    job = Job()
    job.job_name = job_name
    job.pre_processing_file_location = file
    job.file_type = file_type
    job.client_id = client_id
    job.job_status = RUNNING
    job.job_start_timestamp = job.job_initial_start_timestamp = get_timestamp()
    job.file_name = file_name
    job.client_file_id = client_file_id
    job.secret_name = secret_name
    job.incoming_file_name = file
    job.s3_bucket_name = s3_bucket_name
    # 'get_client_file_info(conn, job.client_file_id)' will get ClientFile object
    # it pulls all information from client_files table using job.client_file_id
    job.client_file_info = get_client_file_info(conn, job.client_file_id)
    job.process_description = get_process_description(
        job.client_file_info.process_name, job.client_file_info.process_description
    )
    job.validate_file_structure = job.client_file_info.validate_file_structure
    job.validate_file_detail_columns = job.client_file_info.validate_file_detail_columns

    # This is where actual entry of record with unique 'job_key' is made into ahub_dw.job table
    job = insert_job_log(conn=conn, schema=schema, job=job)

    if job.job_key == 0:
        logger.warning("Database Error occured when trying to insert record into ahub_dw.job table")
        job.job_status = FAIL
        job.error_message = "Database Error occured"
    else:
        job.job_key = job.job_key

    return job


def insert_job_log(conn, schema: str, job: Job) -> Job:
    """This function will log the job in the specified Redshift table.
    :param conn: The Redshift connection object, from irxah/redshift.py
    :param schema_name: The Redshift schema name
    :param job: The Job object, from irxah/glue.py. Needs at least the following preconfigured:
    *job_key
    :return: The job key
    """

    # Grabbing client key
    # client_id = get_client_id(
    #     conn, schema="ahub_dw", table="client_reference", source_client=job.source_code
    # )

    insert_sql = (
        f"insert into {schema}.{TABLE_JOB} (name, start_timestamp, file_name, pre_processing_file_location, file_type, status, client_id, "
        f"client_file_id,error_message, file_status) values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)"
    )
    insert_sql_args = [
        job.job_name,
        job.job_start_timestamp,
        job.file_name,
        job.pre_processing_file_location,
        job.file_type,
        job.job_status,
        job.client_id,
        job.client_file_id,
        job.error_message,
        job.file_status,
    ]
    select_sql = f"select job_key from {schema}.{TABLE_JOB} where start_timestamp=$1"
    select_sql_args = (job.job_start_timestamp,)

    logger.info(
        " Executing Insert in Job Table : %s with arguments %s", insert_sql, insert_sql_args,
    )

    job_key = insert_id(conn, insert_sql, insert_sql_args, select_sql, select_sql_args)
    # Job Key is the parent Key here..
    job.job_key = job_key
    logger.info(
        "Generated Job Key is: %s for Job Name: %s", job_key, job.job_name,
    )

    return job


def update(job: Job) -> None:
    """Sets environment variables and calls update_job()
    :param arguments: a list of variables that will be resolved to retrieve environment variables
    :param job: a Job object. Needs at least the following preconfigured: 
    *job_key
    """
    # create_redshift_connection(redshift_host, redshift_port, redshift_database, redshift_user, redshift_password)
    conn = get_connection(job.secret_name)

    rows_affected = update_job(job, SCHEMA_DW)
    logger.info(" Job key, %d, updated.", rows_affected.job_key)

    # Attempt to send notification if threshold is exceeded job total duration
    notify_process_duration(
        conn,
        job.job_initial_start_timestamp,
        job.job_end_timestamp,
        job.job_key,
        job.client_file_id,
        job.client_file_info.environment_level,
    )


def update_job(job: Job, schema: str) -> Job:
    """Update record in ahub_dw.job before the glue job processes have been completed. The status of the record will
    depend on what the processes' 'Job.job_status' is. If failed, need to update the processes' job object..
    :param job: a Job object. Needs at least the following preconfigured: 
    *job_key
    :param schema: the db schema
    :param secret_name: The secret name for Redshift connection
    :return: a Job object
    """
    # create_redshift_connection(redshift_host, redshift_port, redshift_database, redshift_user, redshift_password)
    conn = get_connection(job.secret_name)

    job.job_end_timestamp = get_timestamp()

    # Update job log
    logger.info("Job Object %s", job)
    rows_affected = update_job_log(conn, schema=schema, job=job)
    logger.info(
        "Update :: %s for Job Key, %d :: Status = %s :: Rows Affected %s",
        job.job_name,
        job.job_detail_key,
        job.job_status,
        rows_affected,
    )

    return job


def update_job_log(conn, schema: str, job: Job) -> int:
    """This function will update the job log in the specified Redshift table.
    :param conn: The Redshift connection object, from irxah/redshift.py
    :param schema: The Redshift schema name
    :param job: The Job object, from irxah/glue.py. Needs at least the following preconfigured:
    *job_key
    :return: the result set of the query
    """
    ## TO DO : Anthony

    logger.info("job object is %s", job)
    if job.updated_by == "":
        job.updated_by = "AHUB ETL"
    if job.updated_timestamp == "":
        job.updated_timestamp = get_timestamp()

    update_sql = (
        f"update {schema}.{TABLE_JOB} "
        f" set end_timestamp=$1, status=$2, error_message=$3, file_record_count=$4, input_sender_id=$5, "
        f" input_receiver_id=$6, post_processing_file_location=$7, updated_by=$8, updated_timestamp=$9, "
        f" outbound_file_name=$10, outbound_file_generation_complete=$11 where job_key=$12"
    )
    update_sql_args = (
        job.job_end_timestamp,
        job.job_status,
        job.error_message,
        job.file_record_count,
        job.input_sender_id,
        job.input_receiver_id,
        job.post_processing_file_location,
        job.updated_by,
        job.updated_timestamp,
        job.output_file_name,
        job.outbound_file_generation_complete,
        job.job_key,
    )

    logger.info(
        "Executing Update: %s with arguments %s", update_sql, update_sql_args,
    )

    # rows_affected = execute_update(conn, update_sql)
    rows_affected = execute_query(conn, update_sql, update_sql_args)

    logger.info(
        " %s :: Status = %s :: Rows Affected %s", job.job_name, job.job_status, rows_affected,
    )

    return rows_affected


def insert_job_detail_log(conn, schema: str, job: Job, sequence_number: int) -> int:
    """This function will log the job detail in the specified Redshift ahub_dw.job_detail table.
    :param conn: The Redshift connection object, from irxah/redshift.py
    :param schema: The Redshift schema name
    :param job: The Job object, from irxah/glue.py. Needs at least the following preconfigured: 
    *job_key
    :return: The job key
    """

    insert_sql = (
        f"insert into {schema}.{TABLE_JOB_DETAIL} (job_key,sequence_number,name,start_timestamp,input_file_name,output_file_name,status) "
        f"values ($1,$2,$3,$4,$5,$6,$7)"
    )
    insert_sql_args = [
        job.job_key,
        sequence_number,
        job.job_name,
        job.job_start_timestamp,
        job.input_file_name,
        job.output_file_name,
        job.job_status,
    ]
    select_sql = f"select job_detail_key from {schema}.{TABLE_JOB_DETAIL} where start_timestamp=$1"
    select_sql_args = (job.job_start_timestamp,)

    logger.info(" Executing Insert: %s", insert_sql)
    logger.info(
        "arguments are job.job_key=%d, sequence_number=%d, "
        "job.job_name=%s, job.job_start_timestamp=%s,job.input_file_name=%s, "
        " job.output_file_name=%s, job.job_status=%s",
        job.job_key,
        sequence_number,
        job.job_name,
        job.job_start_timestamp,
        job.input_file_name,
        job.output_file_name,
        job.job_status,
    )

    # Returns job detail key

    job_detail_key = insert_id(conn, insert_sql, insert_sql_args, select_sql, select_sql_args)
    logger.info(
        " Generated Job Detail Key, %s, for Job Name: %s", job_detail_key, job.job_name,
    )

    return job_detail_key


def update_job_detail_log(conn, schema: str, job: Job):
    """This function will update the job detail log in the specified Redshift table.
    :param conn: The Redshift connection object, from irxah/redshift.py
    :param schema_name: The Redshift schema name
    :param job: The Job object, from irxah/glue.py. Needs at least the following preconfigured: 
    *job_key
    :return: the result set of the query
    """

    if job.updated_by == "":
        job.updated_by = "AHUB ETL"
    job.updated_timestamp = get_timestamp()

    update_sql = (
        f"update {schema}.{TABLE_JOB_DETAIL} "
        f" set end_timestamp=$1, status=$2, error_message=$3, updated_by=$4, updated_timestamp=$5 "
        f" where job_detail_key=$6"
    )
    update_sql_args = (
        job.job_end_timestamp,
        job.job_status,
        job.error_message,
        job.updated_by,
        job.updated_timestamp,
        job.job_detail_key,
    )
    logger.info(
        "Executing Update: %s with arguments %s", update_sql, update_sql_args,
    )
    # rows_affected = execute_update(conn, update_sql)
    rows_affected = execute_query(conn, update_sql, update_sql_args)

    logger.info(
        "Update :: %s for Job Detail Key, %d :: Status = %s :: Rows Affected %s",
        job.job_name,
        job.job_detail_key,
        job.job_status,
        rows_affected,
    )

    return rows_affected


def get_client_id(conn, schema: str, source_client: str):
    """This function will retrieve the client key from the client table on Redshift.
    :param conn: The connection to Redshift
    :param schema: The schema name
    :param source_client: The source client, i.e. BCI, CVS...
    :return: The client key
    """
    select_sql = f"select client_id from {schema}.client_reference where abbreviated_name=$1"
    select_sql_args = (source_client,)
    logger.info(
        "elect query :: %s with arguments %s", select_sql, select_sql_args,
    )
    result = execute_query(conn, select_sql, select_sql_args)
    first_row = result.getresult()
    if first_row is not None:
        return int(first_row[0][0])
    logging.exception("error executing get_client_id() with query :: %s", select_sql)
    raise Exception(
        f"get_client_id(conn,schema,table,source_client) :: No client key found with query : {select_sql}"
    )


def get_client_id_using_client_file_id(conn, schema: str, client_file_id: int):
    """This function  retrieves the client id  based on a given file
    :param conn: The connection to Redshift
    :param schema: The schema name
    :return: The client key
    """
    select_sql = f"select client_id from {schema}.client_files where client_file_id=$1"
    select_sql_args = (client_file_id,)
    logger.info(
        "select query :: %s using %s ", select_sql, select_sql_args,
    )
    result = execute_query(conn, select_sql, select_sql_args)
    first_row = result.getresult()
    if first_row is not None:
        return int(first_row[0][0])

    logging.exception(
        "job_logger :error executing get_client_id_using_client_file_id() with query :: %s",
        select_sql,
    )
    raise Exception(
        "job_logger :get_client_id_using_client_file_id(conn, schema: str, client_file_id: int) :: No client id found with query : %s"
        % select_sql
    )


def _update_job_detail_log(error_occured: bool, job: Job, conn, schema_job):
    """This function  updates the Job detail log table. 
    :param error_occured: If set to Yes, job status will be successful, othrewise it will be set to Fail
    :param Job: The job object which contains the characteristics of a job.
    :param conn : The redshift connection ( it must be active)
    :schema_job : The underlying schema
    :return: None
    """
    if error_occured:
        job.job_status = FAIL
    else:
        job.job_status = "Success"
        job.error_message = None

    job.job_end_timestamp = get_timestamp()

    update_job_detail_log(conn, schema=schema_job, job=job)


def get_job_keys_outbound_generation(conn, client_id: int, flag: Optional[bool] = False) -> str:
    """This function retrieves the job keys which have not been flagged true for outbound_file_generation_complete.
    in a comma delimited list. If It can't find any job keys, it will return "NULL"
    :param conn: The Redshift connection.
    :param sender_id: The sender identifier.
    :returns: The comma delimited list, or "NULL"
    """
    query = (
        f"select job_key from {SCHEMA_DW}.{TABLE_JOB} where outbound_file_generation_complete=$1 and client_id=$2"
        f" and status = 'Success' and file_status='Available' "
    )
    query_args = (
        flag,
        client_id,
    )
    logger.info(
        "get_job_keys_cvs_ungenerated_file :: query: %s, args: %s", query, query_args,
    )
    result = execute_query(conn, query, query_args)
    array = result.getresult()

    keys = create_delimited_list(array, default_value=NULL)

    logger.info("get_job_keys_cvs_ungenerated_file has found the following keys: %s", keys)
    return keys


def set_outbound_generation(conn, job_keys, completion_flag):
    """This function updates the outbound_file_generation_complete flag to true for the job keys given in the parameter. This is so the same
    records do not get re-used.
    :param conn: The Redshift connection.
    :param job_keys: The list of job keys delimited by a comma, i.e. "3,4,5". If there are no job keys, it would be "NULL".
    :param completion_flag: The completion flag to set the outbound_file_generation field to.
    """
    query = f"update {SCHEMA_DW}.{TABLE_JOB} set outbound_file_generation_complete={completion_flag} , file_status='Sent' ,  UPDATED_TIMESTAMP=GETDATE() where job_key in ({job_keys})"
    logger.info("update_cvs_ungenerated_file :: query: %s", query)
    rows_affected = execute_query(conn, query)
    logger.info(
        "set_outbound_generation: %s :: Rows Affected %s", job_keys, rows_affected,
    )


def create_delimited_list(
    array, separator: Optional[str] = DEFAULT_DELIMITER, default_value: Optional[str] = None
) -> str:
    """ This function creates a delimited list from a PG array (the result of the query).
    :param array: The pg array. This is created from a sql query.
    :param separator: Optional. The delimiting character. Defaulted to what is set in constants.py.
    :param default_value: Optional. Defaults to None.
    :return: A delimited list of values from the pg array.
    """
    delimited_list = ""
    for item in array:
        delimited_list = f"{delimited_list}{separator}{item[0]}"
    if delimited_list == "":
        return default_value
    return delimited_list.lstrip(",")


def _insert_job_detail_log(
    conn,
    schema,
    job,
    sequence_number,
    job_name,
    input_file_name: Optional[str] = "",
    output_file_name: Optional[str] = "",
):
    """This function creates a record in the job detail table.
    :param conn: The Redshift connection object, from irxah/redshift.py
    :param schema_name: The Redshift schema name
    :param job: The Job object, from irxah/glue.py. Needs at least the following preconfigured: 
    *job_key
    :param sequence_number: The sequence number.
    :param job_name: The job name.
    :param input_file_name: Optional. The input file name. Defaults to "".
    :param output_file_name: Optional. The output file name. Defaults to "".
    :return: Boolean if error occured.
    """
    job.job_name = job_name
    job.job_status = RUNNING
    job.job_start_timestamp = get_timestamp()
    job.input_file_name = input_file_name
    job.output_file_name = output_file_name
    error_occured = False

    # create job log
    job_detail_key = insert_job_detail_log(
        conn=conn, schema=schema, job=job, sequence_number=sequence_number
    )

    if job_detail_key == 0:
        logger.info(
            "%s: Database Error occured when trying to insert record into ahub_dw.job_detail table",
            job.job_name,
        )
        error_occured = True
        job.error_message = "Database error occured"
    else:
        logger.info("Generated ID is %s", job_detail_key)
        job.job_detail_key = job_detail_key

    return error_occured


def mark_unavailable_file_status_to_available(
    conn,
    client_file_id: int,
    start_time: Optional[datetime] = None,
    end_time: Optional[datetime] = None,
    list_of_files: Optional[str] = "",
    num_of_files: Optional[int] = 0,
):
    """
    This function marks the unavailable file status to available as well as update the updated_timestamp column in the job table.
    :param conn: The connection to redshift.
    :param start_time: The bounded datetime.
    :param end_time: The bounded datetime.
    :list_of_files: Comma separated file names, no surrounding quotes.
    """
    em = ""

    # Search if all files are valid
    num_of_records = 0
    if list_of_files:
        select_query = (
            f"select count(distinct file_name) from {SCHEMA_DW}.{TABLE_JOB} where file_status='Not Available' and client_file_id=$1 and "
            f" outbound_file_generation_complete=false and status='Success' and file_name in ({list_of_files})"
        )
        select_query_args = (client_file_id,)

        logger.info(
            " :: Provided list of cvs files :: query: %s, args: %s",
            select_query,
            select_query_args,
        )

        rows_affected = execute_query(conn, select_query, select_query_args)
        first_row = rows_affected.getresult()
        if first_row is not None:
            num_of_records = int(first_row[0][0])
            if num_of_records != num_of_files or num_of_records == 0:
                em = "ERROR: One of the provided files in the list cannot be found."
                return em

    # Update Not Available to Available
    query = ""
    query_args = ""
    if not list_of_files:
        query = (
            f"update {SCHEMA_DW}.{TABLE_JOB} set file_status='Available', updated_timestamp=GETDATE() where file_status='Not Available' and client_file_id=$1"
            f" and outbound_file_generation_complete=false and status='Success'"
            f" and start_timestamp between $2 and $3"
        )
        query_args = (
            client_file_id,
            start_time,
            end_time,
        )
        em = "ERROR: No records were updated in the table with the provided timeframe"
    elif not start_time and not end_time:
        query = (
            f"update {SCHEMA_DW}.{TABLE_JOB} set file_status='Available', updated_timestamp=GETDATE() where file_status='Not Available' and client_file_id=$1"
            f" and outbound_file_generation_complete=false and status='Success'"
            f" and file_name in ({list_of_files})"
        )
        query_args = (client_file_id,)
        em = "ERROR: No records were updated in the table with the list of file names"
    else:
        logger.info(" Not enough arguments were given!")
        em = "ERROR: Not enough arguments were given for the query"
        return em

    logger.info(
        " query: %s, args: %s", query, query_args,
    )

    rows_affected = execute_query(conn, query, query_args)

    logger.info(
        "Rows Affected %s", rows_affected,
    )

    if rows_affected is not None and int(rows_affected) > 0:
        em = ""

    return em


def notify_process_duration(
    conn, job_start_timestamp, job_end_timestamp, job_key, client_file_id, environment_level: str,
):
    """
    This function determines if a job has reached the threshold before sending an email alert notifying users
    that the process exceeded the set amount.
    :param conn: The connection to Redshift
    :param job_start_timestamp: The initial start time of the job
    :param job_end_timestamp: The end time of the job
    :param job_name: The general job name
    :param job_key: The job key
    :param client_file_id: The client file id
    :param environment_level: The environment level, i.e. dev,sit
    """

    # Formating timestamp into Datetime object and grabbing the difference as elapsed time
    start_time = datetime.strptime(job_start_timestamp, "%Y-%m-%d %H:%M:%S.%f")
    end_time = datetime.strptime(job_end_timestamp, "%Y-%m-%d %H:%M:%S.%f")
    elapsed_time = (end_time - start_time).total_seconds()
    client_file = get_client_file_info(conn, client_file_id)
    # Send notification when client_file_id exists in db
    if client_file.client_file_id > 0:
        logger.info(
            "Elapsed time of process: %d, Theshold value is %d",
            elapsed_time,
            client_file.process_duration_threshold,
        )
        if elapsed_time >= client_file.process_duration_threshold:
            logger.info(
                "Job exceeded process duration threshold of %d seconds",
                client_file.process_duration_threshold,
            )
            send_email_notification_for_process_duration(client_file, job_key, elapsed_time)


def update_job_file_status(
    conn, client_file_id: int, start_timestamp: datetime, end_timestamp: datetime
) -> None:
    update_sql = (
        f"UPDATE AHUB_DW.JOB  SET FILE_STATUS='Available' ,   UPDATED_TIMESTAMP=GETDATE() "
        f" WHERE CLIENT_FILE_ID= $1 AND OUTBOUND_FILE_GENERATION_COMPLETE = FALSE "
        f" AND STATUS='Success' "
        f" AND FILE_STATUS='Not Available' "
        f" AND START_TIMESTAMP BETWEEN $2 AND $3"
    )

    update_sql_args = (
        client_file_id,
        start_timestamp,
        end_timestamp,
    )

    logger.info(
        "Executing Update: %s  with arguments %s", update_sql, update_sql_args,
    )

    # rows_affected = execute_update(conn, update_sql)
    rows_affected = execute_query(conn, update_sql, update_sql_args)
    logger.info(" Execution Complete")
    logger.info(
        "Rows Affected %d", rows_affected,
    )
    logger.info(" Complete ")
