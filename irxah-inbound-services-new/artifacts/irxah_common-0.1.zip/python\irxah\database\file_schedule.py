from ..model import FileSchedule, ClientFile, FileScheduleProcessingTypeEnum, CronExpressionError
from ..common import (
    get_parameter,
    convert_utc_to_local,
    execute_query_module,
    get_next_iteration,
    format_string_time_to_timestamp,
    get_traceback,
)
import traceback
from ..glue import get_glue_logger
from ..constants import SECRET_NAME_KEY
import logging
from typing import Callable, List, Optional, Tuple
from datetime import datetime, timedelta

from ..notifications import send_email_notification_when_failure_executing_sla

db_module = ""

try:
    import pg
    from ..redshift import (
        get_connection,
        execute_query,
    )

    db_module = "pg"

except ImportError:
    import psycopg2
    from ..redshift_for_lambda import get_connection, execute_query

    parameter = ""
# from ..redshift import execute_query


# from ..jobs.validate_file_columns import get_pos


logger = get_glue_logger(name=f"{__name__}", logging_level=logging.DEBUG)


common_sql = f"""SELECT f.client_file_id, c.client_id, c.name, c.abbreviated_name, f.file_schedule_id, 
        f.frequency_type, f.frequency_count, f.total_files_per_day,  f.grace_period, f.notification_sns, 
       f.notification_timezone,  f.file_category,     f.file_description,  f.is_active,  f.is_running, 
       f.aws_resource_name,     f.last_poll_time, 
        f.next_poll_time,
         f.updated_by,  f.updated_timestamp, upper(f.processing_type), 
       f.environment_level, f.cron_expression, f.cron_description
       FROM AHUB_DW.file_schedule f 
        LEFT OUTER JOIN ahub_dw.client_files cf ON f.client_file_id = cf.client_file_id 
        LEFT OUTER JOIN ahub_dw.client c ON cf.client_id = c.client_id 
        """


def get_file_schedule_info(
    conn,
    client_file_id: int,
    processing_type: Optional[FileScheduleProcessingTypeEnum] = FileScheduleProcessingTypeEnum.GLUE,
) -> FileSchedule:
    """Returns a file schedule specific information.

    Args:
        conn ([type]): Redshift connection
        client_file_id (int): Client File ID
        processing_type (FileScheduleProcessingTypeEnum):  Procesing Type

    Returns:
        FileSchedule: [description]
    """
    # Pass a client file ID and returns the client file information in a Client_File Object
    sql = f"{common_sql} where  f.client_file_id = {_param_format(1)} and f.processing_type = {_param_format(2)}  "
    # Please note that if you pass the process_type as enum, the query fails !!
    sql_arg = (client_file_id, processing_type)
    logger.info("get_file_schedule_info: query: (%s) with arguments (%s)", sql, sql_arg)

    rows = execute_query_module(conn, sql, sql_arg)

    # row = result.getresult()

    if rows is None:
        logger.info("Above Query Returns None")
        return None

    logger.info(" Above Query output is non empty")
    for row in rows:
        return _get_file_schedule_from_record(row)


def get_file_schedules_requiring_sla_check(conn) -> List[FileSchedule]:
    """Gets all the file schedule requiring SLA check.
        A simple check is performed and that is is the current time ( UTC) is greater than the next poll time.
        For example, current time is 11/15/2020 05:00 AM UTC then this function would return all those
        file schedule's information which had a poll time in past. Poll time in past means it expires.
        If expired then SLA check needs to be made.

    Args:
        conn ([type]): Redshift Connection Object

    Returns:
        List[FileSchedule]: Collection of file schedules where next poll time <= current utc time
    """
    # Pass a client ID and returns the client files information in a collection
    sql = f"{common_sql} where f.is_active=True and f.is_running=False and f.next_poll_time <= {_param_format(1)} order by f.file_schedule_id "
    now = datetime.utcnow()

    sql_arg = (now,)

    logger.info("query: (%s) with arguments (%s)", sql, sql_arg)

    rows = execute_query_module(conn, sql, sql_arg)
    # rows = result.getresult()

    return _get_file_schedules(rows)


def get_all_file_schedules(conn) -> List[FileSchedule]:
    """This function retrieves all records from the client files table and creates a Client_File object to be used.
    :param conn: The redshift connection.
    :returns: A Client_File object containing all the information from the query.
    """
    # Pass a client file ID and returns the client file information in a Client_File Object
    sql = f"{common_sql} order by f.file_schedule_id "

    logger.info("query: (%s) without arguments ", sql)

    rows = execute_query_module(
        conn,
        sql,
    )
    return _get_file_schedules(rows)


def get_file_schedule_info_by_file_schedule_id(
    conn,
    file_schedule_id: int,
) -> FileSchedule:
    """Returns a file schedule specific information.

    Args:
        conn ([type]): Redshift connection
        file_schedule_id (int): File Schedule ID


    Returns:
        FileSchedule: [description]
    """
    # Pass a client file ID and returns the client file information in a Client_File Object
    sql = f"{common_sql} where  f.file_schedule_id = {_param_format(1)} "
    # Please note that if you pass the process_type as enum, the query fails !!
    sql_arg = (file_schedule_id,)
    logger.info(
        "get_file_schedule_info_by_file_schedule_id: query: (%s) with arguments (%s)", sql, sql_arg
    )

    rows = execute_query_module(conn, sql, sql_arg)

    # row = result.getresult()

    if rows is None:
        logger.info("Above Query Returns None")
        return None

    logger.info(" Above Query output is non empty")
    for row in rows:
        return _get_file_schedule_from_record(row)


def _get_file_schedule_from_record(row) -> FileSchedule:
    """This function helps set the information from the pg query into a Client_File object.
    :param client_file: The client file object that we want to update values.
    :param row: The row/record of the result set from the pg query.
    """

    (
        client_file_id,
        client_id,
        client_name,
        client_abbreviated_name,
        file_schedule_id,
        frequency_type,
        frequency_count,
        total_files_per_day,
        grace_period,
        notification_sns,
        notification_timezone,
        file_category,
        file_description,
        is_active,
        is_running,
        aws_resource_name,
        last_poll_time,
        next_poll_time,
        updated_by,
        updated_timestamp,
        processing_type,
        environment_level,
        cron_expression,
        cron_description,
    ) = row

    # unpack sql result output (a list) to variables
    # make sure that the order of columns specified in 'common_sql' above should be in sync while unpacking the indexes

    file_schedule = FileSchedule()
    file_schedule.client_file_id = (
        client_file_id or file_schedule.client_file_id
    )  # random assigned value to each inbound or outbound file
    file_schedule.client_id = (
        client_id or file_schedule.client_id
    )  # random assigned value to each client
    file_schedule.client_name = client_name or file_schedule.client_name  # full name of client
    file_schedule.client_abbreviated_name = (
        client_abbreviated_name or file_schedule.client_abbreviated_name
    )
    file_schedule.file_schedule_id = file_schedule_id or file_schedule.file_schedule_id

    file_schedule.frequency_type = frequency_type or file_schedule.frequency_type
    file_schedule.frequency_count = frequency_count or file_schedule.frequency_count
    file_schedule.total_files_per_day = total_files_per_day or file_schedule.total_files_per_day
    file_schedule.grace_period = grace_period or file_schedule.grace_period
    file_schedule.notification_sns = notification_sns or file_schedule.notification_sns
    file_schedule.notification_timezone = (
        notification_timezone or file_schedule.notification_timezone
    )
    file_schedule.file_category = file_category or file_schedule.file_category

    file_schedule.file_description = file_description or file_schedule.file_description
    file_schedule.is_active = is_active or file_schedule.is_active
    file_schedule.is_running = is_running or file_schedule.is_running
    file_schedule.aws_resource_name = aws_resource_name or file_schedule.aws_resource_name

    if db_module == "pg":
        file_schedule.last_poll_time = (
            format_string_time_to_timestamp(last_poll_time) or file_schedule.last_poll_time
        )
        file_schedule.next_poll_time = (
            format_string_time_to_timestamp(next_poll_time) or file_schedule.next_poll_time
        )
    else:
        file_schedule.last_poll_time = last_poll_time or file_schedule.last_poll_time
        file_schedule.next_poll_time = next_poll_time or file_schedule.next_poll_time

    file_schedule.end_timestamp = file_schedule.next_poll_time

    file_schedule.start_timestamp = file_schedule.end_timestamp + timedelta(
        minutes=file_schedule.grace_period * -1
    )

    file_schedule.current_sla_start_time = convert_utc_to_local(
        file_schedule.start_timestamp, file_schedule.notification_timezone, "%m/%d/%Y %I:%M %p"
    )
    # In the conversion to a string the timezone information is also included via %Z
    file_schedule.current_sla_end_time = convert_utc_to_local(
        file_schedule.end_timestamp, file_schedule.notification_timezone, "%m/%d/%Y %I:%M %p %Z"
    )

    file_schedule.updated_by = updated_by or file_schedule.updated_by
    file_schedule.updated_timestamp = updated_timestamp or file_schedule.updated_timestamp
    file_schedule.processing_type = processing_type or file_schedule.processing_type
    file_schedule.environment_level = environment_level or file_schedule.environment_level
    file_schedule.cron_expression = cron_expression or file_schedule.cron_expression
    file_schedule.cron_description = cron_description or file_schedule.cron_description
    return file_schedule


def update_file_schedule_to_running(connection, file_schedule_id: int) -> None:
    """For a given schedule ID ( aka file schedule ID) , it sets to running.
    The reason we set it to running is that if one job is already running then
    the other job should not be running with a same file schedule ID

    Args:
        connection ([type]): Redshift Connection
        file_schedule_id (int): File Schedule ID

    Returns:
        [type]: None
    """
    select_sql = (
        f"update ahub_dw.FILE_SCHEDULE  SET IS_RUNNING = True,  "
        f" updated_timestamp = GETDATE(), "
        f" updated_by ='AHUB ETL (update_file_schedule_to_running)' "
        f"  WHERE FILE_SCHEDULE_ID = {_param_format(1)}"
    )

    update_sql_args = (file_schedule_id,)

    logger.info(
        "Executing Update: %s with arguments %s",
        select_sql,
        update_sql_args,
    )

    _ = execute_query_module(connection, select_sql, update_sql_args, True)


def update_file_schedule_to_next_execution_glue_curry(**kwargs) -> Callable:
    """Creates a curried instance of update_file_schedule_to_next_execution_glue
    based on whether appropriate parameters are passed.
    There parameters are typically passed to scheduled glue functions.
    These method exists so that glue code doesn't have to specifically unpack
    variables it does not need to function.

    :param SECRET_NAME: the name of the secret file
    :param CLIENT_FILE_ID: the id of the client file whose execution is being updated
    :param UPDATE_FILE_SCHEDULE_STATUS: whether to update the schedule
    :param FILE_SCHEDULE_ID: Optional the specific schedule id that triggered the job

    Example usage:
        args = getResolvedOptions(
            sys.argv,
            [
                "CLIENT_FILE_ID",
                "SECRET_NAME",
                "S3_FILE_BUCKET",
                "FILE_SCHEDULE_ID",
                "UPDATE_FILE_SCHEDULE_STATUS",
            ],
        )
        update_file_schedule_to_next_execution_glue_curry(**args)()
    """
    update_status = kwargs.get("UPDATE_FILE_SCHEDULE_STATUS", "FALSE")

    if update_status.upper() != "TRUE":
        logger.debug(
            "UPDATE_FILE_SCHEDULE_STATUS is not TRUE (%s) so no updating file schedule",
            update_status,
        )
        return lambda: None

    secret_name = kwargs.get(SECRET_NAME_KEY, "")
    client_file_id = kwargs.get("CLIENT_FILE_ID", 0)
    return lambda: update_file_schedule_to_next_execution_glue(secret_name, client_file_id)


def update_file_schedule_to_next_execution_glue(
    secret_name: str,
    client_file_id: int,
    processing_type: Optional[FileScheduleProcessingTypeEnum] = FileScheduleProcessingTypeEnum.GLUE,
) -> None:
    """[summary]

    Args:
        secret_name (str): AWS Secret Name ( when used in a Glue Job , the underlying code will establish PG connection)
        client_file_id (int): Client File ID
        processing_type (Optional[FileScheduleProcessingTypeEnum], optional): Defaults to FileScheduleProcessingTypeEnum.GLUE.
    """
    # Since it is passed from Glue ( could be a pg8000 connection - but the code below deals with pg connection)
    logger.debug("Updating file scheduled for client file: %s", client_file_id)
    connection = get_connection(secret_name)
    file_schedule = get_file_schedule_info(connection, client_file_id)
    if not file_schedule:
        logger.warning("Cannot retrieve file schedule for client_file_id=%s", client_file_id)
        return

    update_file_schedule_to_next_execution(
        connection,
        file_schedule.file_schedule_id,
        file_schedule.cron_expression,
        file_schedule.notification_timezone,
    )


def update_file_schedule_to_next_execution(
    connection, file_schedule_id: int, cron_expression: str, notification_timezone: str
) -> None:
    """Using the cron expression decides the next execution time ( also known as next poll time).
        If cron_expressioin is specified in local then notification_timezone is also used.


    Args:
        connection ([type]): Redshift Connection
        file_schedule_id (int): File Schedule ID ( used in the update)
        cron_expression (str): Cron Expression , it must begin with either utc or local
                                For example -> local : 30 10 * * * means Everyday 10:30 in the notification_timezone
                                                utc  : 30 15 * * * means Everdya 15:30 in the UTC
        notification_timezone (str): pytz compliant timezone string such as 'America/New_York'

    Returns:
        None
    """
    select_sql = (
        f"update ahub_dw.FILE_SCHEDULE  SET IS_RUNNING = False, last_poll_time=next_poll_time, "
        f" next_poll_time= {_param_format(1)}, "
        f" updated_timestamp = GETDATE(), updated_by ='AHUB ETL (update_file_schedule_to_next_execution)' "
        f" WHERE FILE_SCHEDULE_ID = {_param_format(2)}"
    )
    try:
        next_schedule_time = get_next_iteration(cron_expression, notification_timezone)
        if next_schedule_time is None:
            logger.info(
                "Unable to assign the Next Schedule Time for file schedule id %d , process is aborting with is_running True",
                file_schedule_id,
            )
            return
        logger.info(
            " Next Scheduled Poll Time for cron_expression : %s  is : %s",
            cron_expression,
            next_schedule_time,
        )
        update_sql_args = (next_schedule_time, file_schedule_id)

        logger.info(
            "Executing Update: %s with arguments %s",
            select_sql,
            update_sql_args,
        )
        _ = execute_query_module(connection, select_sql, update_sql_args, True)
    except CronExpressionError as e:
        logger.exception(" Error occured while processing SLA, Error is : %s", e)
        logger.exception(get_traceback(e.__traceback__))
        file_schedule = get_file_schedule_info_by_file_schedule_id(connection, file_schedule_id)
        # Send alert
        send_email_notification_when_failure_executing_sla(file_schedule, e)


def _param_format(param_number: int) -> str:
    """Formats a parameter based on the currently selected db_module."""
    return get_parameter(db_module, param_number)


def _get_file_schedules(rows) -> List[FileSchedule]:
    """Reads an incoming row and return a list of file schedule

    Args:
        rows ([type]): Incoming rows

    Returns:
        List[FileSchedule]: File Schedule
    """

    "TODO : Find out how to write it shorter the following expression"
    if rows is None or len(rows) == 0:
        return None

    return [_get_file_schedule_from_record(row) for row in rows]
