import boto3
import json
import logging
import os
import psycopg2
from typing import Optional, Iterable
from botocore.exceptions import ClientError
from .constants import (
    SCHEMA_DW,
    TABLE_CLIENT,
    TABLE_CLIENT_FILES,
)
from .glue import get_glue_logger
from .redshift import get_redshift_credentials_as_json

session = boto3.session.Session()
region_name = session.region_name

logger = get_glue_logger(name=f"{__name__}", logging_level=logging.DEBUG)


def get_connection(secret_name: Optional[str] = None):
    """Returns a redshift connection
    Keyword Arguments:
        secret_name {str} -- [description] (default: {None})
    Returns:
        [type] -- [description]
    """
    # secret_name = secret_name if secret_name is not None else os.environ.get("SECRET_NAME", "dv")
    secret_json = get_redshift_credentials_as_json(secret_name, region_name)
    secret = json.loads(secret_json)
    redshift_user = secret.get("username")
    redshift_password = secret.get("password")
    redshift_host = secret.get("host")
    redshift_port = secret.get("port")
    redshift_database = secret.get("dbname")
    conn = create_redshift_connection(
        redshift_host, redshift_port, redshift_database, redshift_user, redshift_password
    )
    return conn


def create_redshift_connection(host: str, port: str, db_name: str, user: str, password: str):
    """
    Function to establish a connection with Redshift using psycopg2
    The function connect() creates a new database session and returns a new connection instance
    :param host: Host (IP) of the Redshift cluster
    :param port: Port of the Redshift database
    :param db_name: Name of the Redshift database
    :param user: Name of the Redshift master user
    :param password: Password for the Redshift master password
    :return: Returns a Redshift connection object
    """

    """conn_string = "host={} port={} dbname={} user={} password={}".format(
        host, port, db_name, user, password,
    )"""

    conn = psycopg2.connect(dbname=db_name, host=host, port=port, user=user, password=password)
    return conn


def execute_query(
    conn,
    query: str,
    query_args: Optional[Iterable] = None,
    is_insert_or_update: Optional[bool] = False,
):
    """Executes a query against a connection.
    Here class 'cursor' allows interaction with the database.
    It send commands to the database using methods such as execute() and executemany().
    It retrieves data from the database by iteration or using methods such as fetchone(), fetchmany(), fetchall()
    :param conn: a conn opened with get_connection
    :param  query: a sql query. can be parametrized using old-style pg ($1, $2)
    :param query_args: a positional iterable (list, tuple) matching the parameters in query
    :return: a query object if select, or the number of affected rows if insert/update/delete
    """
    cur = conn.cursor()
    if query_args is not None:
        try:
            cur.execute(query, query_args)
            if is_insert_or_update:
                return cur.rowcount
            else:
                return cur.fetchall()
            # print(result)

        except psycopg2.ProgrammingError:
            logging.exception("Error executing query: %s with parameters: %r", query, query_args)
            return None
    else:
        try:
            cur.execute(query)
            if is_insert_or_update:
                return cur.rowcount
            else:
                return cur.fetchall()
            # print(result)

        except psycopg2.ProgrammingError:
            logging.exception("Error executing query: %s", query)
            return None


def insert_id(
    redshift_connection,
    insert_sql: str,
    insert_sql_args,
    select_sql: Optional[str] = None,
    select_sql_args=None,
):
    """
    Executes an insert statement and an optional select statement if the insert was successful.
    :param redshift_connection: an opened conn (see create_redshift_connection)
    :param insert_sql: the insert sql statement on a table
    :param insert_sql_args: arguments passed to the insert sql statement
    :param select_sql: optional parameter. runs the select sql statement
    :param select_sql_args: takes the select sql statement arguments
    :returns: the first column if select_sql was present, or the number of inserted records otherwise"""
    logger.info(" insert_sql = (%s) with arguments %s", insert_sql, insert_sql_args)
    rows_affected = execute_query(redshift_connection, insert_sql, insert_sql_args)
    logger.info(
        " rows_affected = %s",
        rows_affected,
    )
    if int(rows_affected) == 1 and select_sql is not None:
        logger.info(" select_sql = %s", insert_sql)
        result_query = execute_query(redshift_connection, select_sql, select_sql_args)
        first_row = result_query.getresult()
        if first_row is not None:
            logger.info(
                " my_job_key = %s",
                first_row,
            )
            return int(first_row[0][0])

        return rows_affected
    return rows_affected
