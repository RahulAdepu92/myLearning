try:
    import pg
    from .accumhist import process_cvs_acc_history_file
    from .bci import process_bci_file_and_send_to_cvs, process_bci_error_file_and_load_in_database
    from .cvs import process_cvs_file_load_in_database
    from .unload_cvs_to_bci import export_bci_file
    from .job_logger import initialize
    from ..database.job_log import update, get_file_count
    from .process_flow import (
        process_bci_file,
        process_cvs_file,
        from_database_export_cvs_to_bci,
        custom_to_standard,
    )
    from .log_job_status import log_status
    from .cvs_manual_marking import manual_mark

    from .sla_processor import process_sla
    from .custom_to_standard import generate_standard_row

    db_module = "pg"

except ImportError:
    import psycopg2
    from .sla_processor import process_sla
    from .custom_to_standard import generate_standard_row