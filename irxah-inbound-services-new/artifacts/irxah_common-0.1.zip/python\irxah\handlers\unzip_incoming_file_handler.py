import io
import logging
import logging.config
import os
import zipfile
import boto3

from datetime import datetime

from ..common import convert_utc_to_local
from ..database.client_files import get_client_file_info_from_name_pattern
from ..constants import FAIL, DEFAULT_TIMEZONE
from ..database.file_schedule import get_file_schedule_info
from ..glue import get_glue_logger
from ..model import FileScheduleProcessingTypeEnum, ClientFileFileTypeEnum
from ..notifications import notify_unknown_inbound_file_arrival, notify_inactive_inbound_file, notify_inbound_file_extraction_error
from ..redshift_for_lambda import get_connection
from ..s3 import get_file_from_s3_trigger, move_file

logger = get_glue_logger(name=f"{__name__}", logging_level=logging.DEBUG)

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# file path types - literals
TXT_FILES = "txtfiles"
ARC_FILES = "archive"
ERR_FILES = "error"
UNKNOWN_FILES = "unknown"

s3_client = boto3.client("s3")
s3_resource = boto3.resource("s3")


def unzip_handler(event, context) -> None:
    """In a nutshell, this lambda function is a common watcher for the inbound source files of all the clients
    which process them by unzipping the zip files and move the extracted files to the corresponding staging folder based
    on client and archive the inbound file. In an even of unsuccesful processing, the file moves to error folder
    and sends an email notification to the receipents for the error encountered.
    :param event: lambda event
    :param context: lambda context
    :return: None
    """
    try:
        logger.info("Process started. finding the file path of trigger event: %r", event)
        # incoming_file = inbound/srcfiles/filename.txt
        s3_bucket_name, incoming_file = get_file_from_s3_trigger(event)
        # incoming file is  such as  inbound/srcfiles/ACCDLYINT_TST_BCIINRX_200406190343430.zip
        logger.info("incoming_file : %s", incoming_file)

        # retrieve existing environment variables for lambda function
        # 'secret_name' is useful to connect redshfift using "psycopg2 external library" to get client file related variables through ClientFile object
        secret_name = os.environ["SECRET_NAME"]
        environment = os.environ["ENVIRONMENT"]
        sns_name = os.environ["FILE_EXTRACTION_ERROR_NOTIFICATION_SNS_ARN"]

        conn = get_connection(secret_name)

        #initialising the local time here becasue as soon as the inbound file arrives s3 event will be triggered
        current_utc_time = datetime.utcnow()
        current_local_time = convert_utc_to_local(current_utc_time, DEFAULT_TIMEZONE)

        # Pulls the name out of the incoming file for example the incoming file is : inbound/srcfiles/ACCDLYINT_TST_BCIINRX_200406190343430.zip

        # the incoming file name below would reteurn just the  ACCDLYINT_TST_BCIINRX_200406190343430.zip
        incoming_file_name = incoming_file.split(os.sep)[-1]
        incoming_file_path = os.path.dirname(incoming_file)  # inbound/srcfiles
        logger.info("incoming_file_name : %s", incoming_file_name)
        # get full string before 3rd '_' character in incoming file and checks if any name_pattern exists in db. For ex 'ACCHIST_TST_BCIINRX'
        incoming_file_name_pattern = incoming_file_name[
            : incoming_file_name.replace("_", "X", 2).find("_")
        ]
        logger.info("incoming_file_name_pattern : %s", incoming_file_name_pattern)

        client_file = get_client_file_info_from_name_pattern(
            conn, incoming_file_name_pattern
        )
        logger.info("client_file : %s", client_file)

        if client_file is not None and client_file.file_type == ClientFileFileTypeEnum.INBOUND: # restricting the entry of files that match outbound file name patterns
            file_schedule = get_file_schedule_info(
                conn, client_file.client_file_id, FileScheduleProcessingTypeEnum.INBOUND_TO_AHUB
            )
            logger.info(" File Schedule Info is : %s", file_schedule)
            # if 'is_active' is FALSE, do nothing. Otherwise it will move forward to check for zip file, send to cfx etc.,
            if client_file.is_active:
                logger.info(
                    "Incoming file name '%s' matches with file name pattern '%s' in client files table and 'is_active' alert is set to '%s'. "
                    "Hence, it will move forward to check for file extension and is moved to %s folder.",
                    client_file.is_active,
                    incoming_file_name,
                    client_file.name_pattern,
                    client_file.extract_folder,
                )
                client_name = client_file.client_abbreviated_name
                logger.info("incoming file client name : %s", client_name)

                # Now where the file needs to be extracted is determined as <s3 bucket>\<extract folder>\incoming_file_name
                # <extract folder>\incoming_file_name frees up the hard coding the client or folder name.
                customTuple = (
                    client_file.extract_folder,
                    incoming_file_name,
                )

                incoming_file_with_client = os.sep.join(customTuple)

                logger.info(
                    "From Try Block : s3_bucket_name = %s, incoming_file = %s, incoming_file_with_client = %s",
                    s3_bucket_name,
                    incoming_file,
                    incoming_file_with_client,
                )

                status_message = ""
                error_message = ""
                try:
                    if unzip_file(
                        s3_bucket_name,
                        incoming_file,
                        incoming_file_with_client,
                        client_file.extract_folder,
                        client_file.error_folder,
                        client_file.archive_folder,
                    ):
                        logger.info("File Unzipped Successfully")
                        status_message = "Success"
                        error_message = "No Error"
                        return
                    logger.info(
                        "File %s / %s was not unzipped successfully, no need to process any files",
                        s3_bucket_name,
                        incoming_file_with_client,
                    )
                    return
                except Exception as e:
                    logging.exception(e)
                    # Notification
                    logger.info("sending email notification for file extraction error")
                    incoming_file = f"{s3_bucket_name}/{incoming_file}"
                    res = notify_inbound_file_extraction_error(client_file, file_schedule, incoming_file, current_local_time, str(e))
                    logger.info(res)
                    status_message = FAIL
                    # error_message = f"Error : {str(e)}.    File : {incoming_file}."
                    error_message = f"{str(e)}."

                finally:
                    # logging to job and job_details table
                    glue_job = boto3.client("glue")
                    glue_job_name = os.environ["GLUE_JOB_NAME"]
                    secret_name = os.environ["SECRET_NAME"]
                    logger.info("Calling Glue Job:: %s ", glue_job_name)
                    # after following line, if system comes out of it immediately, it means that unzip has not been done by the time you reach line 120
                    # if thers a huge file that needs to be unzipped, and code below just initiates the process and comes out of it, then we need to
                    # put this (unzip activity as part of one glue job activity i.e, from unzip to end of the process- Ahub_455)
                    response = glue_job.start_job_run(
                        JobName=glue_job_name,
                        Arguments={
                            # preparing arguments for glue job 'irxah_log_job_status'
                            "--INCOMING_FILE": incoming_file,
                            "--STATUS_MESSAGE": status_message,
                            "--ERROR_MESSAGE": error_message,
                            "--SECRET_NAME": secret_name,
                            "--JOB_NAME": "Unzip Inbound File",
                            "--FILE_TYPE": "INBOUND",
                            "--CLIENT_NAME": client_name,
                        },
                    )

                    if "JobRunId" in response:
                        jobId = response["JobRunId"]
                        logger.info("%s job run with id %s", glue_job_name, response["JobRunId"])
                        _ = glue_job.get_job_run(JobName=glue_job_name, RunId=jobId)

            else:
                logger.info(
                    "Incoming file name '%s' matches with file name pattern '%s' in client files table. But 'is_active' flag is set to '%s'. "
                    "Hence, file processing will be on hold and it remains as is in '%s' until you push it manually after setting 'is_active' flag to TRUE. ",
                    incoming_file_name,
                    client_file.name_pattern,
                    client_file.is_active,
                    incoming_file_path
                )
                notify_inactive_inbound_file(client_file, file_schedule, incoming_file_name, incoming_file_path, current_local_time)

        # any file that doesnt qualify the above criteria will remain in 'inbound/srcfiles'.
        # So, this unprocessed file has to be moved as is to 'inbound/unknown' folder with help of below if condition.
        if client_file is None:
            # path_folders => ['inbound', 'srcfiles']
            path_folders = (os.path.dirname(incoming_file)).split(os.sep)
            src_folder = path_folders[1]  # srcfiles (or) history
            # sets archive_file_name_with_path to inbound/unknown/abc.txt
            archive_path = (os.sep.join(path_folders).replace(src_folder, UNKNOWN_FILES))
            archive_file_name_with_path = (
                    os.sep.join(path_folders).replace(src_folder, UNKNOWN_FILES)
                    + os.sep
                    + os.path.basename(incoming_file)
            )

            logger.info(
                "Incoming file '%s' name doesn't match with any of the expected Inbound file name pattern in db. "
                "Hence, file processing will be skipped and moved directly to 'inbound/unknown' folder.",
                incoming_file_name,
            )
            move_file(s3_bucket_name, incoming_file, s3_bucket_name, archive_file_name_with_path)
            notify_unknown_inbound_file_arrival(environment, sns_name, incoming_file_name, current_local_time, archive_path)

    except Exception as e:
        logging.exception(e)
        logging.exception("File path could not be retrieved from the S3 trigger event: %r", event)
        return


def unzip_file(
    bucket_name: str,
    incoming_file: str,
    incoming_file_with_client: str,
    extract_folder: str,
    error_folder: str,
    archive_folder: str,
) -> bool:
    """
    This function does the following tasks

    1. This processes the incoming file from inbound path by unzipping and loads the content
    in the 'txtfiles' folder upon successful unzipping.
    Ex: For example, "incoming/bci/srcfiles/GOOD.ZIP" would be have its GOOD.TXT extracted to "incoming/bci/txtfiles/GOOD.TXT"

    2. Upon successful unzipping of the flle, It removes the source file after moving it from srcfiles to archive
       Ex: For example, "incoming/bci/srcfiles/GOOD.ZIP" would be have its GOOD.TXT extracted to "incoming/bci/archive/GOOD.TXT"

    3. In unsuccessful attempt of unzipping due to any reason , It moves the file to 'error' folder
    Ex: an invalid "incoming/cvs/srcfiles/BAD.ZIP" would be moved to "incoming/cvs/error/BAD.ZIP"

    4. If the souce file is .txt(.TXT) file , it skips the unzipping and moves it to txtfiles
    Ex: For example, "incoming/bci/srcfiles/good.txt"  to "incoming/bci/txtfiles/good.txt"

    :param bucket_name: s3 bucket name.
    :param incoming_file: inbound file path  like inbond/srcfiles
    :param incoming_file_with_client: inbound file path with client name like inbond/bci/srcfiles
    :return: The boolean to indicate unzip successful or not
    """
    unzip_file_successful = True

    # derivation of various file paths
    incoming_zip_file_name = inbound_src_file_path = ""
    txt_file_path = archive_file_path = error_file_path = ""

    incoming_zip_file_name = os.path.basename(incoming_file)

    inbound_src_file_path = os.path.dirname(incoming_file) + os.sep  # inbound/srcfiles/

    # path_folder => ['inbound','<client_name>','srcfiles']
    path_folders = (os.path.dirname(incoming_file_with_client)).split(os.sep)
    logger.info(
        "incoming_file=%s, incoming zip file name =%s, inbound_src_file_path=%s, path_folders=%s ",
        incoming_file,
        incoming_zip_file_name,
        inbound_src_file_path,
        path_folders,
    )

    # src_folder = path_folders[2]  # srcfiles (or) history

    # Ensure that the path ends with os.sep ( the front-slash) at the end
    txt_file_path = os.path.join(extract_folder, "")
    archive_file_path = os.path.join(archive_folder, "")
    error_file_path = os.path.join(error_folder, "")

    logging.info(
        "incoming_zip_file_name is : %s \n inbound_src_file_path is : %s"
        "\n txt_file_path is : %s \n archive_file_path is : %s \n error_file_path is : %s",
        incoming_zip_file_name,
        inbound_src_file_path,
        txt_file_path,
        archive_file_path,
        error_file_path,
    )

    try:
        logger.info(
            "Incoming source file for processing  %s%s",
            inbound_src_file_path,
            incoming_zip_file_name,
        )
        # handling .txt(.TXT) files
        if incoming_zip_file_name.lower().endswith(".txt"):
            logger.info(
                " Copying from s3://%s/%s%s to s3://%s/%s%s",
                bucket_name,
                inbound_src_file_path,
                incoming_zip_file_name,
                bucket_name,
                txt_file_path,
                incoming_zip_file_name,
            )
            s3_resource.Object(bucket_name, txt_file_path + incoming_zip_file_name).copy_from(
                CopySource={
                    "Bucket": bucket_name,
                    "Key": inbound_src_file_path + incoming_zip_file_name,
                }
            )

            logger.info(" Copy SUCCESSFUL")

        else:
            put_object = None
            # throw error if not .zip(ZIP)
            if not incoming_zip_file_name.lower().endswith(".zip"):
                raise AccumHubArchiveException(
                    "The inbound source file must be either .ZIP(.zip) or .TXT(.txt)"
                )

            # unzip the zip file
            obj = s3_client.get_object(
                Bucket=bucket_name, Key=inbound_src_file_path + incoming_zip_file_name
            )

            with io.BytesIO(obj["Body"].read()) as tf:
                # rewind the file
                tf.seek(0)

                # Read the file as a zipfile and process the members
                with zipfile.ZipFile(tf, mode="r") as zipf:
                    zip_content_list = zipf.namelist()
                    # validate the txt file in the zip before extraction
                    txt_file_count = 0
                    zipped_text_file = None
                    for zipped_file in zip_content_list:
                        logger.info("zip content ..%s ", str(zipped_file))
                        if str(zipped_file).lower().endswith(".txt"):
                            txt_file_count += 1
                            zipped_text_file = zipped_file

                    if txt_file_count > 1:
                        raise AccumHubArchiveException(
                            "More than one text file present in archive. Expected only one"
                        )
                    if txt_file_count < 1:
                        raise AccumHubArchiveException("No text file present in archive")

                    # reading the zip content which is of .txt and writing to folder 'txtfiles'
                    if zipped_text_file is not None:
                        unzipped_text_file = txt_file_path + str(zipped_text_file)
                        logging.info(" fileName: %s", unzipped_text_file)
                        logging.info(
                            "%s is being extracted and its content is copying to %s ",
                            zipped_text_file,
                            unzipped_text_file,
                        )
                        put_object = s3_client.put_object(
                            Bucket=bucket_name,
                            Key=unzipped_text_file,
                            Body=zipf.read(zipped_text_file),
                        )
                        logging.info(
                            "The zip content  %s has been extracted successfully",
                            unzipped_text_file,
                        )

            # Move zip file after unzip to archive
            if put_object is not None:
                logging.info(
                    "The inbound source file %s%s is moving to archive folder",
                    inbound_src_file_path,
                    incoming_zip_file_name,
                )
                s3_resource.Object(
                    bucket_name, archive_file_path + incoming_zip_file_name
                ).copy_from(
                    CopySource={
                        "Bucket": bucket_name,
                        "Key": inbound_src_file_path + incoming_zip_file_name,
                    }
                )
                logging.info(
                    "The inbound source file %s%s has been moved to archive folder successfully",
                    inbound_src_file_path,
                    incoming_zip_file_name,
                )

    except AccumHubArchiveException as archive_error:
        unzip_file_successful = False
        logging.exception("AccumHubArchiveException.. %s ", archive_error)
        raise

    except Exception as unknown_error:
        unzip_file_successful = False
        logging.exception("Unknown error encountered unzipping file: %s", unknown_error)
        raise

    finally:
        if not unzip_file_successful:
            # moving the file to error folder
            logging.info(
                "The inbound source file %s%s is moving  to error folder",
                inbound_src_file_path,
                incoming_zip_file_name,
            )
            # copy to archive folder
            s3_resource.Object(
                bucket_name, error_file_path + incoming_zip_file_name.upper()
            ).copy_from(
                CopySource={
                    "Bucket": bucket_name,
                    "Key": inbound_src_file_path + incoming_zip_file_name,
                }
            )
            logging.info(
                "The inbound source file %s%s has been moved to error folder successfully",
                inbound_src_file_path,
                incoming_zip_file_name,
            )

        # deleting the incoming zip upon moving to Archive or Error folder
        logging.info(
            "The inbound source file %s%s is being deleted",
            inbound_src_file_path,
            incoming_zip_file_name,
        )
        _ = s3_client.delete_object(
            Bucket=bucket_name, Key=inbound_src_file_path + incoming_zip_file_name
        )
        logging.info(
            "The inbound source file %s%s has been deleted successfully",
            inbound_src_file_path,
            incoming_zip_file_name,
        )

    return unzip_file_successful


class AccumHubArchiveException(Exception):
    """ custom exception for zipping validations"""

    pass
