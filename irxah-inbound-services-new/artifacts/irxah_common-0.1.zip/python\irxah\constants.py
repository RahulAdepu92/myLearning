# Indicates what is the delimiter string for columns in the split file
COLUMN_DELIMITER = "|"
BLANK = ""

# Schemas available in redshift db which are utilised in executing sqls
SCHEMA_DW = "ahub_dw"
SCHEMA_STAGING = "ahub_stg"

# Tables and Views available in redshift db which are utilised in executing sqls
TABLE_JOB = "job"
TABLE_JOB_DETAIL = "job_detail"
TABLE_ACCUM_DETAIL_STAGING = "stg_accum_dtl"
TABLE_RECON_DETAIL_STAGING = "stg_accumulator_reconciliation_detail"
TABLE_ACCUM_HISTORY_DETAIL_STAGING = "stg_accum_hist_dtl"
VIEW_ACCUM_HISTORY_DETAIL_STAGING = "vw_accum_hist_dtl"
TABLE_ACCUM_HISTORY_CROSSWALK_STAGING = "stg_accum_hist_crosswalk"
TABLE_ACCUM_DETAIL_DW = "accumulator_detail"
TABLE_RECON_DETAIL_DW = "accumulator_reconciliation_detail"
TABLE_CLIENT = "client"
TABLE_CLIENT_FILES = "client_files"
TABLE_COLUMN_RULES = "column_rules"
TABLE_FILE_COLUMNS = "file_columns"
TABLE_COLUMN_ERROR_CODES = "column_error_codes"
TABLE_FILE_VALIDATION_RESULT = "file_validation_result"
TABLE_CUSTOM_TO_STANDARD_MAPPING = "custom_to_standard_mapping"

# S3_bukcet name and file_names used in various functions
JOB_S3_BUCKET_ARGUMENT_NAME = "S3_FILE_BUCKET"
JOB_S3_FILE_ARGUMENT_NAME = "S3_FILE_NAME"

# values used in 'validate_file_columns.py' to check if Accumulator_Balance_Qualifier fields have expected values or not
LIST_OF_ACCUM_QUALIFIERS = [
    "989:991",
    "1025:1027",
    "1061:1063",
    "1097:1099",
    "1133:1135",
    "1169:1171",
    "1229:1231",
    "1265:1267",
    "1301:1303",
    "1337:1339",
    "1373:1375",
    "1409:1411",
]

# position of column 'record_count' in trailer line of outbound file
COMMON_TRAILER_RECORD_COUNT_POSITION = "210:219"

# 'TRANSMISSION_ID' column position value and its respective error_code, error_level to check the record duplication in incoming client files
BCI_TRANSMISSION_ID_COLUMN_RULE_ID = 225
CVS_TRANSMISSION_ID_COLUMN_RULE_ID = 1225
TRANSMISSION_ID_COLUMN_POSITION = "358:407"
TRANSMISSION_ID_ERROR_CODE = 103
TRANSMISSION_ID_ERROR_LEVEL = 1

# SNS related values used to publish sns topic alerts
SNS_SUBJECT = "Alert notification, Error occurred"
SNS_ARN_PREFIX = "arn:aws:sns:"

# Delimiter for getting job keys
DEFAULT_DELIMITER = ","
NULL = "NULL"

# client_file_id values used in 'unload_cvs_to_bci.py' for glue job
CLIENT_ID_BCI = 1
CLIENT_ID_CVS = 2

# client_file_id values used in several functions for processing glue jobs
INBOUND_BCI_TO_CVS_CLIENT_FILE_ID = 1
OUTBOUND_BCI_TO_CVS_CLIENT_FILE_ID = 2
INBOUND_CVS_TO_DATABASE_CLIENT_FILE_ID = 3
OUTBOUND_DATABASE_TO_BCI_CLIENT_FILE_ID = 4
OUTBOUND_DATABASE_TO_BCI_CLIENT_FILE_ID_ERR = 5
INBOUND_CVS_RECON_INTEG_TO_DATABASE_CLIENT_FILE_ID = 6
INBOUND_BCI_ERROR_TO_DATABASE_CLIENT_FILE_ID = 7
INBOUND_CVS_ACCHIST_TO_CVS_CLIENT_FILE_ID = 8
INBOUND_BCI_GP_TO_CVS_CLIENT_FILE_ID = 9
INBOUND_CVS_RECON_NON_INTEG_TO_DATABASE_CLIENT_FILE_ID = 10
INBOUND_CVS_NON_INTEG_TO_DATABASE_CLIENT_FILE_ID = 11

# 'NA' value is used in 'cvs_manual_marking.py' to declare few glue parmaters and set them to default 'NA'
NA = "NA"


# String literals used for getting glue jobs status while processing them in 'processflow.py'
SUCCESS = "Success"
RUNNING = "Running"
FAIL = "Fail"

# timezone in which glue jobs run. This will be used in 'irxah_check_dst_and_update_sla_triggers.py' to decide EDT/EST timings
DEFAULT_TIMEZONE = "America/New_York"

# Secret name key in arguments
SECRET_NAME_KEY = "SECRET_NAME"
FILE_TIMESTAMP_FORMAT = "%y%m%d%H%M%S"


# file types
OUTBOUND = "OUTBOUND"
INBOUND = "INBOUND"
