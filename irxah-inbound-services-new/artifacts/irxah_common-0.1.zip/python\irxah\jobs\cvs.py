import logging.config
from typing import List, Optional

from awsglue.utils import getResolvedOptions

from ..common import convert_utc_to_local
from ..database.client_files import current_utc_time
from ..database.file_schedule import get_file_schedule_info
from ..database.job_log import _update_job_detail_log, _insert_job_detail_log
from ..constants import (
    SCHEMA_DW,
    TABLE_ACCUM_DETAIL_DW,
    TABLE_CLIENT_FILES,
    TABLE_FILE_VALIDATION_RESULT,
    CVS_TRANSMISSION_ID_COLUMN_RULE_ID,
    TRANSMISSION_ID_COLUMN_POSITION,
    TRANSMISSION_ID_ERROR_CODE,
    TRANSMISSION_ID_ERROR_LEVEL,
    DEFAULT_TIMEZONE)
from ..glue import get_glue_logger
from ..model import Job, FileScheduleProcessingTypeEnum
from ..notifications import notify_inbound_file
from ..redshift import (
    get_connection,
    load_s3_file_into_table_column_specific,
    get_client_files_import_columns,
    record_duplicate_transmission_identifier,
)
from ..s3 import delete_s3_files

logger = get_glue_logger(name=f"{__name__}", logging_level=logging.DEBUG)


def process_cvs_file_load_in_database(
    job: Job, job_name: Optional[str] = "Load CVS File in to Database"
) -> Job:
    """
    Copies S3 detail inbound split file to Redshift "stg_accum_dtl" table.
    This code resides in a glue job "irx_accumhub_load_cvs_to_bci" and is called
    by lambda "irx_accumhub_SubmitGlueJobLambda_cvs_to_bci".


    Args:
        arguments (List[str]): Passed from the Lambda  
        job (Job): object containing critical information about the job
        job_name (Optional[str], optional): [description]. Defaults to "Load CVS File in to Database".

    Returns:
        Job: [description]
    """
    # create_redshift_connection(redshift_host, redshift_port, redshift_database, redshift_user, redshift_password)
    conn = get_connection(job.secret_name)
    # Earlier below variables were hard coded, now read from database
    s3_accumhub_bucket = job.s3_bucket_name
    iam_arn = job.client_file_info.redshift_glue_iam_role_arn
    s3_inbound_detail_file = job.get_path(job.detail_file_name)

    error_occured = False

    job.post_processing_file_location = ""

    # Create job detail log
    error_occured = _insert_job_detail_log(
        conn=conn,
        schema=SCHEMA_DW,
        job=job,
        sequence_number=3,
        job_name=job_name,
        input_file_name=s3_inbound_detail_file,
    )

    logger.info(" Job Object Information is : %s", job)

    if error_occured:
        _update_job_detail_log(error_occured, job, conn, SCHEMA_DW)
        return job

    logger.info("Calling load_s3_file_into_table")

    columns = get_client_files_import_columns(conn, SCHEMA_DW, TABLE_CLIENT_FILES, job)
    if columns is None or columns == "":
        error_occured = True
        job.error_message = (
            "Unable to retrieve import columns for Accumulator Reconciliation Detail table"
        )
        _update_job_detail_log(error_occured, job, conn, SCHEMA_DW)
        return job

    if not job.outbound_file_generation_complete:
        load_s3_file_into_table_column_specific(
            conn,
            SCHEMA_DW,
            TABLE_ACCUM_DETAIL_DW,
            columns,
            s3_accumhub_bucket,
            s3_inbound_detail_file,
            iam_arn,
        )

    logger.info("load_s3_file_into_table completed")

    if job.validate_file_structure:
        validation_file = job.get_path(job.validation_file_name)
        logger.info(
            "load_s3_file_into_table_column_specific  started with file name : %s", validation_file,
        )
        load_s3_file_into_table_column_specific(
            conn,
            SCHEMA_DW,
            TABLE_FILE_VALIDATION_RESULT,
            "job_key,line_number,column_rules_id,validation_result,error_message",
            s3_accumhub_bucket,
            validation_file,
            iam_arn,
        )

        record_duplicate_transmission_identifier(
            conn,
            CVS_TRANSMISSION_ID_COLUMN_RULE_ID,
            TRANSMISSION_ID_COLUMN_POSITION,
            TRANSMISSION_ID_ERROR_CODE,
            TRANSMISSION_ID_ERROR_LEVEL,
            job.job_key,
        )

        logger.info(" load_s3_file_into_table_column_specific - Completed")

    delete_s3_files(s3_accumhub_bucket, f"{job.file_processing_location}/{str(job.job_key)}_")
    logger.info("inbound temp folder file clean up process is completed")
    _update_job_detail_log(error_occured, job, conn, SCHEMA_DW)

    # send alert for receiving and processing the inbound file
    file_schedule = get_file_schedule_info(
        conn, job.client_file_id, FileScheduleProcessingTypeEnum.INBOUND_TO_AHUB
    )
    logger.info(" File Schedule Info is : %s", file_schedule)
    notify_inbound_file(file_schedule, job)

    return job
