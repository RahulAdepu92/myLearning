import datetime
from datetime import timedelta
from typing import List, Optional
import pytz
import boto3
import logging
import sys
from ..glue import get_glue_logger
from ..constants import SLA_TRIGGER, DEFAULT_TIMEZONE, NA
from botocore.exceptions import ParamValidationError
from ..redshift import get_connection
from awsglue.utils import getResolvedOptions

logger = get_glue_logger(name=f"{__name__}", logging_level=logging.DEBUG)

client = boto3.client("glue")

current_utc_time = datetime.datetime.utcnow()



def update_trigger_schedule(trigger_name: str, trigger_schedule: str, glue_job_name: str) -> dict:
    """
    a boto3 api for updating glue triggers
        Args:
        trigger_name (str): name of the trigger to be updated
        trigger_schedule (str): schedule to which the trigger has to be set
        glue_job_name (str): name of the glue job associated with the trigger
    """
    response = client.update_trigger(
        Name=trigger_name,
        TriggerUpdate={"Schedule": trigger_schedule, "Actions": [{"JobName": glue_job_name},]},
    )


def update_sla_triggers(
    input_datetime: datetime, yesterday_datetime: datetime, current_timezone: str
) -> None:
    """"This function updates BCI sla triggers alone as the client observes the daylight savings time.
    CVS sla triggers are untouched as the client fall under Arizona Time and does not get interrupted by Eastern time
    :param input_datetime: current utc datetime
    

    Args:
        input_datetime (datetime):  Typically a current utc date time is passed here, however a manual input_datetime can be supplied from the
                                    corresponding glue job and system will behave as if the current time is the one that was supplied from the 
                                    Glue job env variable.
    """
    current_timezone_string = (
        input_datetime.replace(tzinfo=pytz.UTC)
        .astimezone(pytz.timezone(current_timezone))
        .strftime("%Z")
    )
    logger.info(
        "current timezone is : %s", current_timezone_string,
    )
    yesterday_timezone_string = (
        yesterday_datetime.replace(tzinfo=pytz.UTC)
        .astimezone(pytz.timezone(current_timezone))
        .strftime("%Z")
    )
    logger.info(
        "yesterday timezone was : %s", yesterday_timezone_string,
    )
    # Why we do half here ?? refer to comments on SLA_TRIGGER to know more
    half = int(len(SLA_TRIGGER) / 2)
    # compare current time zone with previous day time zone and update the sla triggers accordingly
    if current_timezone_string == yesterday_timezone_string:
        logger.info(
            "There is no change in timezone from yesterday. Hence, sla triggers update is NOT REQUIRED today"
        )
    else:
        logger.info("Timezone has changed from yesterday. Hence, UPDATING sla triggers now..")
        if current_timezone_string == "EDT":
            try:
                # Reads the DST triggers from SLA_TRIGGER
                for i in SLA_TRIGGER[:half]:
                    update_trigger_schedule(i[0], i[1], i[2])
                    logger.info(f"sla trigger '%s' schedule is updated to %s", i[0], i[1])

            except ParamValidationError as e:
                logger.exception("Param Validation error: %s", e)

            except ValueError as e:
                logger.exception("Value error: %s", e)

        elif current_timezone_string == "EST":
            try:
                # Reads  the  NON DST from SLA_TRIGGER
                for i in SLA_TRIGGER[half:]:
                    update_trigger_schedule(i[0], i[1], i[2])
                    logger.info(f"sla trigger '%s' schedule is updated to %s", i[0], i[1])

            except ParamValidationError as e:
                logger.exception("Param Validation error: %s", e)

            except ValueError as e:
                logger.exception("Value error: %s", e)