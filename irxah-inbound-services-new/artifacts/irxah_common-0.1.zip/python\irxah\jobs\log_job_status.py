import boto3
import logging
import sys
import os
from ..glue import get_glue_logger
from ..model import Job
from ..redshift import get_connection, get_client_id
from ..database.job_log import (
    insert_job_detail_log,
    update_job_detail_log,
    insert_job_log,
    update_job_log,
)
from ..file import get_timestamp
from awsglue.utils import getResolvedOptions
from typing import List, Optional
from ..constants import SCHEMA_DW

logger = get_glue_logger(name=f"{__name__}", logging_level=logging.DEBUG)
s3client = boto3.client("s3")
s3resource = boto3.resource("s3")


def log_status(arguments: List[str],) -> Job:
    """ This logs the status of the job. It records the error in case of failure, into the table job_detail
    with file and its error message.
    """
    args = getResolvedOptions(
        arguments,
        [
            "INCOMING_FILE",
            "STATUS_MESSAGE",
            "ERROR_MESSAGE",
            "SECRET_NAME",
            "JOB_NAME",
            "FILE_TYPE",
            "CLIENT_NAME",
        ],
    )

    logger.debug(" Printing sys.argv: %r", arguments)

    incoming_file = args["INCOMING_FILE"]
    status_message = args["STATUS_MESSAGE"]
    error_message = args["ERROR_MESSAGE"]
    secret_name = args["SECRET_NAME"]
    job_name = args["JOB_NAME"]
    file_type = args["FILE_TYPE"]
    client_name = args["CLIENT_NAME"]

    file_name = os.path.basename(incoming_file)

    logger.info(
        " incoming_file = %s, status_message =%s, error_message =%s, secret_name =%s, job_name =%s,file_type=%s,client_name=%s, file_name=%s,",
        incoming_file,
        status_message,
        error_message,
        secret_name,
        job_name,
        file_type,
        client_name,
        file_name,
    )

    # create redshift connection
    conn = get_connection(secret_name)

    # get client id from client abbreviated name
    client_id = get_client_id(connection=conn, schema=SCHEMA_DW, client_name=client_name)
    logger.info("Client Name : %s , Client id : %s", client_name, client_id)
    logger.info(" Insert into Redshift Table ")

    if error_message == "No Error":
        error_message = ""

    job = Job()
    job.job_name = job_name
    job.file_type = file_type
    job.file_name = file_name
    job.job_status = status_message
    job.job_start_timestamp = get_timestamp()
    job.input_file_name = incoming_file
    job.file_name_with_path = incoming_file
    job.error_message = error_message
    job.job_end_timestamp = get_timestamp()

    # client id
    job.client_id = client_id
    logger.info("%s status : job Object is  %s", job_name, job)

    # This is where actual entry of record with unique 'job_key' is made into ahub_dw.job table for "Unzip Inbound File"
    # insert into job table and retrieve the job key
    job_table = insert_job_log(conn=conn, schema=SCHEMA_DW, job=job)

    if job_table.job_key == 0:
        logger.warning(
            " Database Error occured when trying to insert record into ahub_dw.job table"
        )
    else:
        logger.info("job_logger: log_job_status :Generated Job Key is %s.", job.job_key)
        job.job_key = job_table.job_key

        # This is where actual entry of record with unique 'job_detail_key' is made into ahub_dw.job_detail table for "Unzip Inbound File"
        job_detail_key = insert_job_detail_log(
            conn=conn, schema=SCHEMA_DW, job=job, sequence_number=1
        )
        if job_detail_key == 0:
            logger.info(
                "Database Error occured when trying to insert record into ahub_dw.job_detail table"
            )
        else:
            logger.info("Generated ID is %s", job_detail_key)
            job.job_detail_key = job_detail_key
            # update status and message
            update_job_detail_log(conn, schema=SCHEMA_DW, job=job)
        # update job log
        update_job_log(conn=conn, schema=SCHEMA_DW, job=job)

    return job

