import croniter
import logging.config

from datetime import datetime, timedelta
from typing import List, Optional, Tuple
from ..glue import get_glue_logger
from ..model import ClientFile, Job

from ..redshift import (
    get_connection,
    execute_query,
)

logger = get_glue_logger(name=f"{__name__}", logging_level=logging.DEBUG)


def run_scheduler(file_type: str):
    """Retrives schedules for all files of type file_type
    from the client_files table and executes those that are scheduled.
    """
    logger.info("Retrieving jobs of type: %s", file_type)
