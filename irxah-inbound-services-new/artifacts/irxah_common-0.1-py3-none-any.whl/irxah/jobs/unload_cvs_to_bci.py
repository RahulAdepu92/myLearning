import datetime
import dateutil.tz
import logging
import logging.config
import os
from typing import List, Optional
from ..glue import get_glue_logger
from ..model import Job, FileSplitEnums
from awsglue.utils import getResolvedOptions
from ..redshift import (
    get_connection,
    cleanup_table,
    execute_query,
)
from ..s3 import delete_s3_files, merge_file_parts, get_outbound_file_record_count
from ..database.job_log import (
    _update_job_detail_log,
    _insert_job_detail_log,
    get_job_keys_outbound_generation,
    set_outbound_generation,
    update_job_outbound_file_name,
)
from ..constants import (
    TABLE_JOB_DETAIL,
    SCHEMA_DW,
    TABLE_ACCUM_DETAIL_DW,
    TABLE_COLUMN_RULES,
    TABLE_FILE_VALIDATION_RESULT,
    TABLE_JOB,
    CLIENT_ID_BCI,
    CLIENT_ID_CVS,
    NULL,
    COMMON_TRAILER_RECORD_COUNT_POSITION,
    FAIL,
    INBOUND_BCI_TO_CVS_CLIENT_FILE_ID,
)
from ..file import get_timestamp

logger = get_glue_logger(name=f"{__name__}", logging_level=logging.DEBUG)


def export_bci_file(
    arguments: List[str],
    job: Job,
    job_name: Optional[str] = "Prepare CVS Export File from database for BCI",
) -> Job:
    """
    Exports Redshift "stg_accum_dtl" table to header, detail
    and trailer output files followed by merging all of them and produce approved and rejected records files.
    This code resides in a glue job "irx_accumhub_unload_merge_cvs_to_bci"
    and is executed by scheduled trigger "irx-accumhub-unload-merge-cvs-to-bci-scheduled-trigger".
    """
    job.record_count = 0
    args = getResolvedOptions(
        arguments,
        [
            "S3_OUTBOUND_DQ_FILE_PREFIX",
            "S3_OUTBOUND_DR_FILE_PREFIX",
        ],
    )
    # Earlier below variables were hard coded, now read from database
    s3_accumhub_bucket = job.s3_bucket_name
    s3_outbound_temp_path = (
        job.client_file_info.file_processing_location
    )  ##  Used to be outbound/bci/temp
    iam_arn = (
        job.client_file_info.redshift_glue_iam_role_arn
    )  ##  Used to be  arn:aws:iam::474156701944:role/IRX-IDW-Redshift
    s3_outbound_path = job.client_file_info.s3_merge_output_path  ##  ", "outbound/bci")
    s3_outbound_dq_file_prefix = args["S3_OUTBOUND_DQ_FILE_PREFIX"]  ##  "ACCDLYINT_TST_BCI_")
    s3_outbound_dr_file_prefix = args["S3_OUTBOUND_DR_FILE_PREFIX"]  ##"ACCDLYERR_TST_BCI_")
    outbound_file_list = []

    error_occured = False

    # create_redshift_connection(redshift_host, redshift_port, redshift_database, redshift_user, redshift_password)
    conn = get_connection(job.secret_name)
    # Create job detail log
    error_occured = _insert_job_detail_log(
        conn=conn,
        schema=SCHEMA_DW,
        job=job,
        sequence_number=3,
        job_name=job_name,
    )

    logger.info("cvs export_bci_file : Job Object Information is : %s", job)

    if error_occured:
        logger.info(" Error Occured, updating the job detal log now..")
        _update_job_detail_log(error_occured, job, conn, SCHEMA_DW)
        return job

    """BEGIN :  Below variables are CSV export specific, assigned to variable so that it can have some meaning.
    earlier it used to be obtained through os.getenv. However, it remains AS IS for the life of export
    hence not being ingested from the environment variables """
    generate_dq_records = True

    transmission_file_typ_dq = "DQ"  # 'transmission_file_type' column from inbound detail records used for filtering DQ records in unload_detail query
    transmission_file_typ_dr = "DR"  # 'transmission_file_type' column from inbound detail records used for filtering DR records in unload_detail query
    transmission_type_dq = (
        "T"  # 'transmission_type' column for outbound INT file in unload_header query
    )
    transmission_type_dr = (
        "R"  # 'transmission_type' column for outbound ERR file in unload_header query
    )
    transaction_response_status_dq = ""  # 'transaction_response_status' column from inbound detail records used for filtering DQ records in unload_detail query
    transaction_response_status_dr = "R"  # 'transaction_response_status' column from inbound detail records used for filtering DR records in unload_detail query

    # Earlier below values were hard coded, now read from database.
    input_sender_id = job.client_file_info.input_sender_id
    output_sender_id = job.client_file_info.output_sender_id
    output_receiver_id = job.client_file_info.output_receiver_id
    file_type = job.client_file_info.outbound_file_type_column

    # get bci job keys which have not been flagged to TRUE for 'level1_error_reporting_complete'
    # job_key_bci = get_job_keys_level1_reporting_for_client(conn, CLIENT_ID_BCI)
    job_key_bci = 0 # passing some dummy value inorder to avoid unload query error. However this entire code will be decommissioned.
    # logger.info(" job_key_bci value is : %s", job_key_bci)

    # get cvs job keys which have not been flagged to TRUE for 'outbound_file_generation_complete'
    job_key_cvs = get_job_keys_outbound_generation(conn, CLIENT_ID_CVS)
    logger.info(" job_key_cvs value is : %s", job_key_cvs)

    if job_key_cvs is None or job_key_cvs == NULL:
        logger.info(" setting generate_dq_records to False")
        generate_dq_records = False
    else:
        logger.info(
            " Non NULL job_key_cvs= %s found, DQ and DR file will be generated ", job_key_cvs
        )

    if generate_dq_records:
        job.record_count = "0"
        error_records_from_bci_dq = ""
        error_records_from_bci_dr = f""" union (SELECT a.accumulator_detail_key,a.processor_routing_identification,a.record_type, ''{transmission_file_typ_dr}'' as transmission_file_type,
                   a.version_release_number,a.sender_identifier,a.receiver_identifier,a.submission_number,''{transaction_response_status_dr}''
                   as transaction_response_status,CAST(b.error_code as varchar) as reject_code,a.record_length,a.reserved_1,a.transmission_date,a.transmission_time,
                   a.date_of_service,a.service_provider_identifier_qualifier,a.service_provider_identifier,a.document_reference_identifier_qualifier,
                   a.document_reference_identifier,a.transmission_identifier,a.benefit_type,a.in_network_indicator,a.formulary_status,
                   a.accumulator_action_code,a.sender_reference_number,a.insurance_code,a.accumulator_balance_benefit_type,a.benefit_effective_date,
                   a.benefit_termination_date,a.accumulator_change_source_code,a.transaction_identifier,a.transaction_identifier_cross_reference,
                   a.adjustment_reason_code,a.accumulator_reference_time_stamp,a.reserved_2,a.cardholder_identifier,a.group_identifier,
                   a.patient_first_name,a.middle_initial,a.patient_last_name,a.patient_relationship_code,a.date_of_birth,a.patient_gender_code,
                   a.patient_state_province_address,a.cardholder_last_name,a.carrier_number,a.contract_number,a.client_pass_through,
                   a.family_identifier_number,a.cardholder_identifier_alternate,a.group_identifier_alternate,a.patient_identifier,a.person_code,
                   a.reserved_3,a.accumulator_balance_count,a.accumulator_specific_category_type,a.reserved_4,a.accumulator_1_balance_qualifier,
                   a.accumulator_1_network_indicator,a.accumulator_1_applied_amount,a.accumulator_1_applied_amount_action_code,
                   a.accumulator_1_benefit_period_amount,a.accumulator_1_benefit_period_amount_action_code,a.accumulator_1_remaining_balance,
                   a.accumulator_1_remaining_balance_action_code,a.accumulator_2_balance_qualifier,a.accumulator_2_network_indicator,
                   a.accumulator_2_applied_amount,a.accumulator_2_applied_amount_action_code,a.accumulator_2_benefit_period_amount,
                   a.accumulator_2_benefit_period_amount_action_code,a.accumulator_2_remaining_balance,a.accumulator_2_remaining_balance_action_code,
                   a.accumulator_3_balance_qualifier,a.accumulator_3_network_indicator,a.accumulator_3_applied_amount,a.accumulator_3_applied_amount_action_code,
                   a.accumulator_3_benefit_period_amount,a.accumulator_3_benefit_period_amount_action_code,a.accumulator_3_remaining_balance,
                   a.accumulator_3_remaining_balance_action_code,a.accumulator_4_balance_qualifier,a.accumulator_4_network_indicator,
                   a.accumulator_4_applied_amount,a.accumulator_4_applied_amount_action_code,a.accumulator_4_benefit_period_amount,
                   a.accumulator_4_benefit_period_amount_action_code,a.accumulator_4_remaining_balance,a.accumulator_4_remaining_balance_action_code,
                   a.accumulator_5_balance_qualifier,a.accumulator_5_network_indicator,a.accumulator_5_applied_amount,a.accumulator_5_applied_amount_action_code,
                   a.accumulator_5_benefit_period_amount,a.accumulator_5_benefit_period_amount_action_code,a.accumulator_5_remaining_balance,
                   a.accumulator_5_remaining_balance_action_code,a.accumulator_6_balance_qualifier,a.accumulator_6_network_indicator,a.accumulator_6_applied_amount,
                   a.accumulator_6_applied_amount_action_code,a.accumulator_6_benefit_period_amount,a.accumulator_6_benefit_period_amount_action_code,
                   a.accumulator_6_remaining_balance,a.accumulator_6_remaining_balance_action_code,a.reserved_5,a.accumulator_7_balance_qualifier,
                   a.accumulator_7_network_indicator,a.accumulator_7_applied_amount,a.accumulator_7_applied_amount_action_code,a.accumulator_7_benefit_period_amount,
                   a.accumulator_7_benefit_period_amount_action_code,a.accumulator_7_remaining_balance,a.accumulator_7_remaining_balance_action_code,
                   a.accumulator_8_balance_qualifier,a.accumulator_8_network_indicator,a.accumulator_8_applied_amount,a.accumulator_8_applied_amount_action_code,
                   a.accumulator_8_benefit_period_amount,a.accumulator_8_benefit_period_amount_action_code,a.accumulator_8_remaining_balance,
                   a.accumulator_8_remaining_balance_action_code,a.accumulator_9_balance_qualifier,a.accumulator_9_network_indicator,a.accumulator_9_applied_amount,
                   a.accumulator_9_applied_amount_action_code,a.accumulator_9_benefit_period_amount,a.accumulator_9_benefit_period_amount_action_code,
                   a.accumulator_9_remaining_balance,a.accumulator_9_remaining_balance_action_code,a.accumulator_10_balance_qualifier,a.accumulator_10_network_indicator,
                   a.accumulator_10_applied_amount,a.accumulator_10_applied_amount_action_code,a.accumulator_10_benefit_period_amount,
                   a.accumulator_10_benefit_period_amount_action_code,a.accumulator_10_remaining_balance,a.accumulator_10_remaining_balance_action_code,
                   a.accumulator_11_balance_qualifier,a.accumulator_11_network_indicator,a.accumulator_11_applied_amount,a.accumulator_11_applied_amount_action_code,
                   a.accumulator_11_benefit_period_amount,a.accumulator_11_benefit_period_amount_action_code,a.accumulator_11_remaining_balance,
                   a.accumulator_11_remaining_balance_action_code,a.accumulator_12_balance_qualifier,a.accumulator_12_network_indicator,
                   a.accumulator_12_applied_amount,a.accumulator_12_applied_amount_action_code,a.accumulator_12_benefit_period_amount,
                   a.accumulator_12_benefit_period_amount_action_code,a.accumulator_12_remaining_balance,a.accumulator_12_remaining_balance_action_code,
                   a.optional_data_indicator,a.total_amount_paid,a.total_amount_paid_action_code,a.amount_of_copay,a.amount_of_copay_action_code,
                   a.patient_pay_amount,a.patient_pay_amount_action_code,a.amount_attributed_to_product_selection_brand,
                   a.amount_attributed_to_product_selection_brand_action_code,a.amount_attributed_to_sales_tax,a.amount_attributed_to_sales_tax_action_code,
                   a.amount_attributed_to_processor_fee,a.amount_attributed_to_processor_fee_action_code,a.gross_amount_due,a.gross_amount_due_action_code,
                   a.invoiced_amount,a.invoiced_amount_action_code,a.penalty_amount,a.penalty_amount_action_code,a.reserved_6,a.product_service_identifier_qualifier,
                   a.product_service_identifier,a.days_supply,a.quantity_dispensed,a.product_service_name,a.brand_generic_indicator,a.therapeutic_class_code_qualifier,
                   a.therapeutic_class_code,a.dispensed_as_written,a.reserved_7,a.line_number,a.job_key,a.created_by,a.updated_by,a.updated_timestamp,a.created_timestamp
                   FROM ( select * from {SCHEMA_DW}.{TABLE_ACCUM_DETAIL_DW} where job_key in ({job_key_bci}))a join 
                   (select * from (select *,row_number() over (partition by job_key, line_number order by error_level asc,file_column_id asc ) rnk 
                   from (SELECT d.validation_result, d.job_key , d.line_number, c.file_column_id, c.error_level , c.error_code,  
                   c.column_rules_id FROM {SCHEMA_DW}.{TABLE_COLUMN_RULES} c JOIN {SCHEMA_DW}.{TABLE_FILE_VALIDATION_RESULT} as d   
                   ON c.column_rules_id = d.column_rules_id where d.validation_result=''N'' and d.job_key in ({job_key_bci}) )A)Z where rnk=1 and error_level=1)b  
                   ON a.job_key = b.job_key and a.line_number=b.line_number WHERE a.job_key in ({job_key_bci}))"""

        # END :  Above  are CSV export specific variable used in unload..

        job.post_processing_file_location = s3_outbound_path

        logger.info("Calling load_s3_file_into_table")

        # Gets the file array
        """Instead of getting the 4 X 3  = 12 variables , array is declared and the individual elements is acccessed
        using the enum """

        """ dq_files and dr_files array is used as a path while unloading , the real file does not exist as such"""

        eastern = dateutil.tz.gettz("US/Eastern")
        timestamp_file = datetime.datetime.now(tz=eastern).strftime("%y%m%d%H%M%S")
        timestamp_process_routing = datetime.datetime.now(tz=eastern).strftime("%m%d%Y%H%M%S")
        process_routing_timestamp = output_sender_id + f"{timestamp_process_routing}"
        # print(process_routing_timestamp)
        timestamp_src_creation = datetime.datetime.now(tz=eastern).strftime("%H%M")

        # one file for each HDR, DTL, TLR
        # {s3_outbound_temp_path}/{job_key}_{s3_outbound_file_prefix}[HRD,DTL,TLR]_DQ.txt
        dq_files = get_files(
            s3_outbound_temp_path, job.job_key, s3_outbound_dq_file_prefix, "DQ", "txt"
        )

        merge_dq_files = get_files(
            s3_outbound_temp_path, job.job_key, s3_outbound_dq_file_prefix, "DQ", "txt000"
        )

        logger.info(" unload_detail DQ Headers records Started")
        unload_header(
            conn,
            process_routing_timestamp,
            transmission_type_dq,
            timestamp_src_creation,
            output_sender_id,
            output_receiver_id,
            file_type,
            s3_accumhub_bucket,
            dq_files[FileSplitEnums.HEADER],
            iam_arn,
        )
        logger.info("unload_detail DQ Headers records Completed")

        logger.info("unload_detail DQ Detail records Started")
        unload_detail(
            conn,
            process_routing_timestamp,
            output_sender_id,
            output_receiver_id,
            input_sender_id,
            transmission_file_typ_dq,
            transaction_response_status_dq,
            error_records_from_bci_dq,
            s3_accumhub_bucket,
            dq_files[FileSplitEnums.DETAIL],
            iam_arn,
            job_key_cvs,
        )
        logger.info(" unload_detail DQ Detail records Completed")

        logger.info("unload_detail DQ Trailer records Started")
        unload_trailer(
            conn,
            process_routing_timestamp,
            input_sender_id,
            transmission_file_typ_dq,
            transaction_response_status_dq,
            error_records_from_bci_dq,
            s3_accumhub_bucket,
            dq_files[FileSplitEnums.TRAILER],
            iam_arn,
            job_key_cvs,
        )
        logger.info("unload_detail DQ Trailer records Completed")

        record_count_dq = get_outbound_file_record_count(
            s3_accumhub_bucket,
            merge_dq_files[FileSplitEnums.TRAILER],
            COMMON_TRAILER_RECORD_COUNT_POSITION,
        )
        logger.info("DQ file has total record count of : %s", record_count_dq)

        # Before merging and creating the file in s3 bucket, insert a false update into the job table so we are
        # guaranteed to have an output file name populated for other functions such as retrieving client_file or job_key
        # based off of the output file name.
        false_outbound_file_list = []
        false_outbound_file_list.append(f"{s3_outbound_dq_file_prefix}{timestamp_file}.TXT")
        false_outbound_file_list.append(f"{s3_outbound_dr_file_prefix}{timestamp_file}.TXT")
        update_job_outbound_file_name(conn, job.job_key, false_outbound_file_list)

        logger.info("export_bci_file : MERGE DQ Files Started")
        merge_file_parts(
            s3_accumhub_bucket,
            merge_dq_files[FileSplitEnums.DETAIL],
            merge_dq_files[FileSplitEnums.HEADER],
            merge_dq_files[FileSplitEnums.TRAILER],
            os.path.join(s3_outbound_path, f"{s3_outbound_dq_file_prefix}{timestamp_file}.TXT"),
        )
        outbound_file_list.append(f"{s3_outbound_dq_file_prefix}{timestamp_file}.TXT")

        logger.info("MERGE DQ Files Completed")

        dr_files = get_files(
            s3_outbound_temp_path, job.job_key, s3_outbound_dr_file_prefix, "DR", "txt"
        )

        """The arguments passed in the generation of the file is like this outbound/bci/temp/123_ACCDLYINT_TST_BCI_HDR_DQ.txt and the resultant
        file is outbound/bci/temp/123_ACCDLYINT_TST_BCI_HDR_DQ.txt000 the array below captures these type of file names """

        merge_dr_files = get_files(
            s3_outbound_temp_path, job.job_key, s3_outbound_dr_file_prefix, "DR", "txt000"
        )

        logger.info("unload_detail DR Header records Started")
        unload_header(
            conn,
            process_routing_timestamp,
            transmission_type_dr,
            timestamp_src_creation,
            output_sender_id,
            output_receiver_id,
            file_type,
            s3_accumhub_bucket,
            dr_files[FileSplitEnums.HEADER],
            iam_arn,
        )
        logger.info("unload_detail DR Headers records Completed")

        logger.info(" unload_detail DR Detail records Started")
        unload_detail(
            conn,
            process_routing_timestamp,
            output_sender_id,
            output_receiver_id,
            input_sender_id,
            transmission_file_typ_dr,
            transaction_response_status_dr,
            error_records_from_bci_dr,
            s3_accumhub_bucket,
            dr_files[FileSplitEnums.DETAIL],
            iam_arn,
            job_key_cvs,
        )
        logger.info("unload_detail DR Detail records Completed")

        logger.info(" unload_detail DR Trailer records Started")
        unload_trailer(
            conn,
            process_routing_timestamp,
            input_sender_id,
            transmission_file_typ_dr,
            transaction_response_status_dr,
            error_records_from_bci_dr,
            s3_accumhub_bucket,
            dr_files[FileSplitEnums.TRAILER],
            iam_arn,
            job_key_cvs,
        )
        logger.info("unload_detail DR Trailer records Completed")

        logger.info(" MERGE DR Files Started")
        fully_temp = os.path.join(
            s3_outbound_path, f"{s3_outbound_dr_file_prefix}{timestamp_file}.txt"
        )
        logger.info(
            " Calling merge_file_parts s3_accumhub_bucket= %s, s3_temp_dr_records_file_path= %s, s3_temp_dr_header_file_path = %s, s3_temp_dr_trailer_file_path = %s, outbound_path = %s",
            s3_accumhub_bucket,
            merge_dr_files[FileSplitEnums.DETAIL],
            merge_dr_files[FileSplitEnums.HEADER],
            merge_dr_files[FileSplitEnums.TRAILER],
            fully_temp,
        )

        record_count_dr = get_outbound_file_record_count(
            s3_accumhub_bucket,
            merge_dr_files[FileSplitEnums.TRAILER],
            COMMON_TRAILER_RECORD_COUNT_POSITION,
        )
        logger.info(" DR file has total record count of : %s", record_count_dr)

        logger.info("MERGE DR Files Started")
        merge_file_parts(
            s3_accumhub_bucket,
            merge_dr_files[FileSplitEnums.DETAIL],
            merge_dr_files[FileSplitEnums.HEADER],
            merge_dr_files[FileSplitEnums.TRAILER],
            os.path.join(s3_outbound_path, f"{s3_outbound_dr_file_prefix}{timestamp_file}.TXT"),
        )
        logger.info("MERGE DR Files Completed")
        outbound_file_list.append(f"{s3_outbound_dr_file_prefix}{timestamp_file}.TXT")

        job.record_count = [str(record_count_dq), str(record_count_dr)]
        logger.info("Outbound file(s) record count is : %s ", job.record_count)

        logger.info(
            "Deleting files which starts with %d in the %s",
            job.job_key,
            s3_outbound_temp_path,
        )

        delete_s3_files(s3_accumhub_bucket, f"{s3_outbound_temp_path}/{job.job_key}_")
        logging.info("outbound temp folder file clean up process is completed")
        job.status = "Success"
        job.output_file_name = outbound_file_list
        job.outbound_file_generation_complete = True

        # Update level1_error flag for the bci error job keys
        # set_level1_reporting(conn, job_key_bci, completion_flag="true")  # code not in usage
        # update_bci_and_cvs_errors(conn, job_key_cvs)
        # Update outbound_file_generation flag for the cvs job keys
        set_outbound_generation(conn, job_key_cvs, completion_flag="true")
    else:
        job.status = FAIL
        job.output_file_name = "No File Generated"
        job.error_message = "No DQ Records ( CVS transactions to report to ) found"
        error_occured = True  # So that job will be marked as fail

    _update_job_detail_log(error_occured, job, conn, SCHEMA_DW)
    return job


def unload_detail(
    conn,
    timestamp,
    output_sender,
    output_receiver,
    input_sender,
    transmission_file_type,
    transaction_response_status,
    error_records_from_bci,
    s3_out_bucket,
    s3_file_path,
    iam_role,
    job_key_cvs,
):
    """Unloads records from redshift detail table to outbound folder detail file in fixedwidth format"""
    unload_detail_query = f"""unload ('SELECT ''{timestamp}'' AS processor_routing_identification,record_type,transmission_file_type,version_release_number,
            ''{output_sender}'' AS sender_identifier,''{output_receiver}'' AS receiver_identifier,submission_number,transaction_response_status,reject_code,record_length,reserved_1,transmission_date,transmission_time,
            date_of_service,service_provider_identifier_qualifier,service_provider_identifier,document_reference_identifier_qualifier,document_reference_identifier,transmission_identifier,
            benefit_type,in_network_indicator,formulary_status,accumulator_action_code,sender_reference_number,insurance_code,
            accumulator_balance_benefit_type,benefit_effective_date,benefit_termination_date,accumulator_change_source_code,transaction_identifier,transaction_identifier_cross_reference,
            adjustment_reason_code,accumulator_reference_time_stamp,reserved_2,cardholder_identifier,group_identifier,patient_first_name,
            middle_initial,patient_last_name,patient_relationship_code,date_of_birth,patient_gender_code,
            patient_state_province_address,cardholder_last_name,carrier_number,contract_number,client_pass_through,family_identifier_number,
            cardholder_identifier_alternate,group_identifier_alternate,patient_identifier,person_code,reserved_3,accumulator_balance_count,accumulator_specific_category_type,
            reserved_4,accumulator_1_balance_qualifier,accumulator_1_network_indicator,accumulator_1_applied_amount,accumulator_1_applied_amount_action_code,
            accumulator_1_benefit_period_amount,accumulator_1_benefit_period_amount_action_code,accumulator_1_remaining_balance, 
            accumulator_1_remaining_balance_action_code,accumulator_2_balance_qualifier,accumulator_2_network_indicator,accumulator_2_applied_amount,accumulator_2_applied_amount_action_code,
            accumulator_2_benefit_period_amount,accumulator_2_benefit_period_amount_action_code,accumulator_2_remaining_balance,accumulator_2_remaining_balance_action_code,accumulator_3_balance_qualifier,
            accumulator_3_network_indicator,accumulator_3_applied_amount,accumulator_3_applied_amount_action_code,accumulator_3_benefit_period_amount,accumulator_3_benefit_period_amount_action_code,
            accumulator_3_remaining_balance,accumulator_3_remaining_balance_action_code,accumulator_4_balance_qualifier,accumulator_4_network_indicator,accumulator_4_applied_amount,
            accumulator_4_applied_amount_action_code,accumulator_4_benefit_period_amount,accumulator_4_benefit_period_amount_action_code,accumulator_4_remaining_balance,accumulator_4_remaining_balance_action_code, 
            '' '' as reserved_5 from 
            (select *,ROW_NUMBER() over (partition by transmission_identifier, patient_identifier, date_of_birth, 
            transaction_identifier, accumulator_specific_category_type, accumulator_1_balance_qualifier, 
            accumulator_2_balance_qualifier, accumulator_3_balance_qualifier, accumulator_4_balance_qualifier,
            accumulator_1_applied_amount_action_code,accumulator_2_applied_amount_action_code,accumulator_3_applied_amount_action_code,
            accumulator_4_applied_amount_action_code,accumulator_1_applied_amount, accumulator_2_applied_amount, accumulator_3_applied_amount,
            accumulator_4_applied_amount order by transmission_date) as RowNumber from 
            (select j.* from  {SCHEMA_DW}.{TABLE_ACCUM_DETAIL_DW} j join {SCHEMA_DW}.{TABLE_JOB} k on j.job_key = k.job_key and j.job_key in ({job_key_cvs}) 
            where j.sender_identifier = ''{input_sender}'' and transmission_file_type =''{transmission_file_type}''
            and transaction_response_status = ''{transaction_response_status}'' {error_records_from_bci} )z) where RowNumber = 1 order by to_timestamp(transmission_date || transmission_time, ''YYYYMMDDHH24MISSMS'') ') 
            TO 's3://{s3_out_bucket}/{s3_file_path}' iam_role '{iam_role}' 
            FIXEDWIDTH 
            '0:200,1:2,2:2,3:2,4:30,5:30,6:4,7:1,8:3,9:5,10:20,11:8,12:8,13:8,14:2,15:15,16:2,17:15,18:50,19:1,20:1,
            21:1,22:2,23:30,24:20,25:1,26:8,27:8,28:1,29:30,30:30,31:1,32:26,33:13,34:20,35:15,36:25,37:1,38:35,39:1,40:8,
            41:1,42:2,43:35,44:9,45:15,46:50,47:20,48:20,49:15,50:20,51:3,52:90,53:2,54:2,55:20,56:2,57:1,58:10,59:1,60:10,
            61:1,62:10,63:1,64:2,65:1,66:10,67:1,68:10,69:1,70:10,71:1,72:2,73:1,74:10,75:1,76:10,77:1,78:10,79:1,80:2,
            81:1,82:10,83:1,84:10,85:1,86:10,87:1,88:567' 
            ALLOWOVERWRITE 
            parallel off;"""
    logger.info("unload_detail_query: %s", unload_detail_query)
    execute_query(conn, unload_detail_query)


def unload_header(
    conn,
    timestamp,
    transmission_type,
    timestamp_src,
    output_sender,
    output_receiver,
    file_type,
    s3_out_bucket,
    s3_file_path,
    iam_role,
):
    """Exports DQ records in outbound folder header file in fixedwidth format"""
    unload_header = f"""UNLOAD ('select ''{timestamp}'' AS PRCS_ROUT_ID,''HD'' AS RECD_TYPE,''{transmission_type}'' AS TRANSMISSION_FILE_TYP,
            to_char(sysdate, ''YYYYMMDD'') AS SRC_CREATE_DT,''{timestamp_src}'' AS SRC_CREATE_TS,
            ''{output_sender}'' AS SENDER_IDENTIFIER,''{output_receiver}'' AS RECEIVER_IDENTIFIER,''0000001'' AS BATCH_NBR,
            ''{file_type}'' AS FILE_TYP,
            ''10'' AS VER_RELEASE_NBR,'' '' AS RESERVED_SP') 
            TO 's3://{s3_out_bucket}/{s3_file_path}' iam_role '{iam_role}' 
            FIXEDWIDTH 
            '0:200,1:2,2:1,3:8,4:4,5:30,6:30,7:7,8:1,9:2,10:1415' 
            ALLOWOVERWRITE 
            parallel off;"""
    execute_query(conn, unload_header)


def unload_trailer(
    conn,
    timestamp,
    input_sender,
    transmission_file_type,
    transaction_response_status,
    error_records_from_bci,
    s3_out_bucket,
    s3_file_path,
    iam_role,
    job_key_cvs,
):
    """Unloads records in outbound folder trailer file in fixedwidth format"""
    unload_trailer_query = f"""UNLOAD ('select ''{timestamp}'' AS PRCS_ROUT_ID,''TR'' AS RECD_TYPE,''0000001'' AS BATCH_NBR,lpad(b.cnt,10,''0'') AS REC_CNT,'' '' AS MSG_TXT,'' ''AS RESERVED_SP from 
            (SELECT cast(count(1) as varchar)cnt from (select *,ROW_NUMBER() over (partition by transmission_identifier, patient_identifier, date_of_birth, 
            transaction_identifier, accumulator_specific_category_type, accumulator_1_balance_qualifier, accumulator_2_balance_qualifier,
             accumulator_3_balance_qualifier, accumulator_4_balance_qualifier,accumulator_1_applied_amount_action_code,accumulator_2_applied_amount_action_code,
            accumulator_3_applied_amount_action_code,accumulator_4_applied_amount_action_code,accumulator_1_applied_amount, accumulator_2_applied_amount,
             accumulator_3_applied_amount,accumulator_4_applied_amount order by transmission_date) RowNumber from 
            (select j.* from  {SCHEMA_DW}.{TABLE_ACCUM_DETAIL_DW} j join {SCHEMA_DW}.{TABLE_JOB} k on j.job_key = k.job_key and j.job_key in ({job_key_cvs}) 
            where j.sender_identifier = ''{input_sender}'' and transmission_file_type =''{transmission_file_type}''and 
            transaction_response_status = ''{transaction_response_status}'' {error_records_from_bci} )z) 
            where RowNumber = 1)b') 
            TO 's3://{s3_out_bucket}/{s3_file_path}' iam_role '{iam_role}' 
            FIXEDWIDTH 
            '0:200,1:2,2:7,3:10,4:80,5:1401' 
            ALLOWOVERWRITE 
            parallel off;"""
    logger.info("unload_trailer_query: %s", unload_trailer_query)
    execute_query(conn, unload_trailer_query)


def get_files(
    prefix_path: str, job_key: int, prefix: str, suffix: str, extension: str
) -> List[str]:
    """
    Return the array of unique files with first element as HDR, second element as DTL and third element as TLR.
    It is used in the unload process.
    :param prefix_path: This is the path of the file where it will be generated such outbound/bci/temp
    :param job_key: Each file will be prefixed with the job_key
    :param prefix: Usually ACCDLYINT_TST_BCI_ is passed
    :param suffix: What should be the last characters in the file such as DQ or DR
    :param extension : The extension of the file
    :return : string array
    Example : get_files("outbound/bci/temp", 123, "ACCDLYINT_TST_BCI_", "DQ", txt) will give  array consisting of the following values :
    outbound/bci/temp/123_ACCDLYINT_TST_BCI_HDR_DQ.txt
    outbound/bci/temp/123_ACCDLYINT_TST_BCI_DTL_DQ.txt
    outbound/bci/temp/123_ACCDLYINT_TST_BCI_TLR_DQ.txt


    """
    info = ["HDR", "DTL", "TLR"]
    return [f"{prefix_path}/{job_key}_{prefix}{item}_{suffix}.{extension}" for item in info]
