"""
Description : This Python script will copy s3 detail inbound split file to Redshift "stg_accum_dtl" table
  and unload it to header, detail and trailer output files followed by merging all of them.
  This code resides in a glue job "irx_accumhub_load_unload_merge_bci_to_cvs"
  and is called by lambda "irx_accumhub_SubmitGlueJobLambda_bci_to_cvs".
"""

import datetime
import logging.config
import os
import random
from typing import List, Optional, Tuple
import dateutil.tz
from awsglue.utils import getResolvedOptions
from ..database.job_log import (
    insert_job_detail_log,
    _update_job_detail_log,
    _insert_job_detail_log,
    update_job_outbound_file_name,
)
from ..constants import (
    BCI_TRANSMISSION_ID_COLUMN_RULE_ID,
    TRANSMISSION_ID_COLUMN_POSITION,
    TRANSMISSION_ID_ERROR_CODE,
    TRANSMISSION_ID_ERROR_LEVEL,
    SCHEMA_DW,
    TABLE_ACCUM_DETAIL_DW,
    TABLE_CLIENT_FILES,
    TABLE_COLUMN_RULES,
    TABLE_FILE_VALIDATION_RESULT,
    COMMON_TRAILER_RECORD_COUNT_POSITION,
    RUNNING,
)
from ..file import get_timestamp
from ..glue import get_glue_logger
from ..model import Job
from ..redshift import (
    get_connection,
    record_duplicate_transmission_identifier,
    load_s3_file_into_table_column_specific,
    execute_query,
    get_client_files_import_columns,
)
from ..s3 import merge_file_parts, delete_s3_files, get_outbound_file_record_count

logger = get_glue_logger(name=f"{__name__}", logging_level=logging.DEBUG)


def process_bci_file_and_send_to_cvs(
    job: Job, job_name: Optional[str] = "Load, Unload, and Merge BCI to CVS"
) -> Job:
    """This function executes the load, unload, and merge functionality for the BCI inbound. It is executed
    in a glue job. For each execution, a record will be inserted into Redshift ahub_dw.job_detail before the
    process to keep track of the job (success or failure). After the load, unload, and merge process is done,
    the record that was inserted will be updated with the status. The parameter Job is passed in to keep track
    of the existing details that will be used to populate the record.
    Takes in the job as an argument to grab pre-existing values for job logging in Redshift.
    :param arguments: a list of variables that will be resolved to retrieve environment variables
    :param job: a Job object, from irxah/glue.py. Needs at least the following preconfigured:
    *parent_key
    :param job_name: User specified name for the job.
    : returns the Tuple ( Job and record count)
    """
    # create_redshift_connection(redshift_host, redshift_port, redshift_database, redshift_user, redshift_password)
    conn = get_connection(job.secret_name)
    # Earlier below variables were hard coded, now read from database
    s3_accumhub_bucket = job.s3_bucket_name
    iam_arn = job.client_file_info.redshift_glue_iam_role_arn
    file_type = job.client_file_info.outbound_file_type_column
    transmission_type = job.client_file_info.outbound_transmission_type_column
    input_sender_id = job.client_file_info.input_sender_id
    output_sender_id = job.client_file_info.output_sender_id
    output_receiver_id = job.client_file_info.output_receiver_id
    s3_merge_output_path = job.client_file_info.s3_merge_output_path
    # As the name suggests below that it is inbound detail file but in reality it is NOT
    # It is just a location to the file which starts with the S3_INBOUND_DETAIL_FILE_PREFIX
    # The code below should be re-written.

    # s3_inbound_detail_file = os.path.join(
    #     args["S3_INBOUND_DETAIL_PATH"], args["S3_INBOUND_DETAIL_FILE_PREFIX"]
    # )
    s3_inbound_detail_file = job.get_path(job.detail_file_name)
    s3_outbound_detail_file = job.get_path(job.outbound_detail_file_name)
    s3_outbound_header_file = job.get_path(job.outbound_header_file_name)
    s3_outbound_trailer_file = job.get_path(job.outbound_trailer_file_name)
    s3_merge_detail_file = job.get_path(job.merge_detail_file_name)
    s3_merge_header_file = job.get_path(job.merge_header_file_name)
    s3_merge_trailer_file = job.get_path(job.merge_trailer_file_name)
    s3_outbound_temp_file_path = (
        f"{job.file_processing_location}/"  ##   args["S3_OUTBOUND_TEMP_FILE_PATH"]
    )
    s3_temp_file_path_job_key = f"{job.file_processing_location}/{str(job.job_key)}_"  ##   args["S3_OUTBOUND_TEMP_FILE_PATH"]

    eastern = dateutil.tz.gettz("US/Eastern")
    timestamp_file = datetime.datetime.now(tz=eastern).strftime("%y%m%d%H%M") + str(
        random.randint(0, 59)
    ).zfill(2)
    # print(timestamp_file)
    timestamp_process_routing = datetime.datetime.now(tz=eastern).strftime("%m%d%Y%H%M%S")
    # AHUB_318 initiated the change from output_sender_id ( full) to first 5 character [0:5]
    process_routing_timestamp = output_sender_id[0:5] + f"{timestamp_process_routing}"
    # print(process_routing_timestamp)
    timestamp_src_creation = datetime.datetime.now(tz=eastern).strftime("%H%M")
    s3_merge_file_name = job.client_file_info.s3_output_file_name_prefix + f"{timestamp_file}.TXT"

    error_occured = False

    job.post_processing_file_location = s3_merge_output_path

    # Create job detail log
    error_occured = _insert_job_detail_log(
        conn=conn,
        schema=SCHEMA_DW,
        job=job,
        sequence_number=3,
        job_name=job_name,
        input_file_name=job.output_file_name,
        output_file_name=s3_merge_file_name,
    )

    logger.info(" Job Object Information is : %s", job)

    job.record_count = 0
    if error_occured:
        _update_job_detail_log(error_occured, job, conn, SCHEMA_DW)
        return job

    # logger.info("bci process_bci_file :cleanup_table : Started ")

    # logger.info("bci process_bci_file :cleanup_table : Completed ")
    logger.info("load_s3_file_into_table_column_specific : Started ")

    columns = get_client_files_import_columns(conn, SCHEMA_DW, TABLE_CLIENT_FILES, job)
    if columns is None or columns == "":
        error_occured = True
        job.error_message = (
            "Unable to retrieve import columns for Accumulator Reconciliation Detail table"
        )
        _update_job_detail_log(error_occured, job, conn, SCHEMA_DW)
        return job

    # the code below takes the detail records of incoming BCI file ( pipe delimited through earlier process)
    # and loads in to the table.
    # FYI : Job key is included in the pipe delimited.

    if not job.outbound_file_generation_complete and job.continue_processing:
        load_s3_file_into_table_column_specific(
            conn,
            SCHEMA_DW,
            TABLE_ACCUM_DETAIL_DW,
            columns,
            s3_accumhub_bucket,
            s3_inbound_detail_file,
            iam_arn,
        )

    logger.info("load_s3_file_into_table : Completed ")

    # If incoming file is configured for the validations then validations performed are also loaded
    # in the table.

    if job.validate_file_structure and job.continue_processing:
        validation_file = job.get_path(job.validation_file_name)
        logger.info(
            " load_s3_file_into_table_column_specific [ Validations]  started with file name : %s",
            validation_file,
        )
        load_s3_file_into_table_column_specific(
            conn,
            SCHEMA_DW,
            TABLE_FILE_VALIDATION_RESULT,
            "job_key,line_number,column_rules_id,validation_result,error_message",
            s3_accumhub_bucket,
            validation_file,
            iam_arn,
        )

        # One of the validations is to perform the duplicate check across the entire file
        # This duplication check is performed at the end
        record_duplicate_transmission_identifier(
            conn,
            BCI_TRANSMISSION_ID_COLUMN_RULE_ID,
            TRANSMISSION_ID_COLUMN_POSITION,
            TRANSMISSION_ID_ERROR_CODE,
            TRANSMISSION_ID_ERROR_LEVEL,
            job.job_key,
        )

        logger.info(" load_s3_file_into_table_column_specific [Validartions- Completed")
    logger.info("nload_detail_table to generate CVS file : Started ")
    unload_detail_table(
        conn,
        process_routing_timestamp,
        output_sender_id,
        output_receiver_id,
        input_sender_id,
        s3_accumhub_bucket,
        s3_outbound_detail_file,
        iam_arn,
        job,
    )
    job.outbound_file_generation_complete = True
    logger.info("unloading completed for detail table to generate CVS file")
    # delete_files_in_bucket_paths(
    #     s3_accumhub_bucket,
    #     s3_inbound_trailer_temp_file_path,
    #     s3_inbound_detail_temp_file_path,
    #     s3_inbound_header_temp_file_path,
    # )
    # logger.info("bci process_bci_file :temp folder file clean up process is completed")
    logger.info("unload_header_table for CVS file: Started ")
    unload_header_table(
        conn,
        process_routing_timestamp,
        transmission_type,
        timestamp_src_creation,
        output_sender_id,
        output_receiver_id,
        file_type,
        s3_accumhub_bucket,
        s3_outbound_header_file,
        iam_arn,
    )
    logger.info(" unload_header_table for CVS file: Completed ")
    logger.info("unload_trailer_table for CVS File: Started ")
    unload_trailer_table(
        conn,
        process_routing_timestamp,
        s3_accumhub_bucket,
        s3_outbound_trailer_file,
        iam_arn,
        job,
    )
    logger.info("unload_trailer_table for CVS File: Completed ")
    logger.info("process_bci_file merge_file_parts (CVS) : Started ")
    logger.info(
        " s3_accumhub_bucket=%s, "
        "s3_merge_detail_file=%s, s3_merge_header_file=%s, s3_merge_trailer_file=%s, "
        "s3_merge_output_path=%s, s3_merge_file_name=%s",
        s3_accumhub_bucket,
        s3_merge_detail_file,
        s3_merge_header_file,
        s3_merge_trailer_file,
        s3_merge_output_path,
        s3_merge_file_name,
    )

    # Before merging and creating the file in s3 bucket, insert a false update into the job table so we are
    # guaranteed to have an output file name populated for other functions such as retrieving client_file or job_key
    # based off of the output file name.

    update_job_outbound_file_name(conn, job.job_key, s3_merge_file_name)

    merge_file_parts(
        s3_accumhub_bucket,
        s3_merge_detail_file,
        s3_merge_header_file,
        s3_merge_trailer_file,
        os.path.join(s3_merge_output_path, s3_merge_file_name),
    )
    logger.info("process_bci_file merge_file_parts (CVS): Completed ")

    job.record_count = get_outbound_file_record_count(
        s3_accumhub_bucket, s3_merge_trailer_file, COMMON_TRAILER_RECORD_COUNT_POSITION
    )
    logger.info("Outbound file record count is : %s ", job.record_count)

    logger.info(
        "delete_files_in_bucket_paths : Started for %s , path is : %s, file getting deleted starts with : %s",
        s3_accumhub_bucket,
        s3_outbound_temp_file_path,
        s3_temp_file_path_job_key,
    )
    delete_s3_files(s3_accumhub_bucket, s3_temp_file_path_job_key)
    # delete_files_in_bucket_paths(s3_accumhub_bucket, s3_outbound_temp_file_path)
    logger.info(" (CVS):clean up process is completed")

    _update_job_detail_log(error_occured, job, conn, SCHEMA_DW)
    return job


def unload_detail_table(
    conn,
    process_routing_timestamp: str,
    output_sender_id: str,
    output_receiver_id: str,
    input_sender_id: str,
    s3_accumhub_bucket: str,
    s3_outbound_detail_file: str,
    iam_arn: str,
    job: Job,
) -> None:
    """Unloads the output to the s3://s3_out_bucket/s3_out_detail_file

    Args:
        conn ([type]): Redshift Connection
        process_routing_timestamp (str): It is made of the output_sender_id + current eastern time stamp in the format of %m%d%Y%H%M%S
        output_sender_id (str): output_sender_id read from the Lambda environment variable
        output_receiver_id (str): output_receiver_id read from the Lambda envirionment variable
        input_sender_id (str): input_sender_id read from the Lambda environment variable
        s3_accumhub_bucket (str): output bucket where the S3 file will be written to
        s3_outbound_detail_file (str): output file name
        iam_arn (str): IAM Role
        job (Job): Job containing the  critical information about the job getting executed.
    """
    unload_detail_query = f"""UNLOAD ('SELECT ''{process_routing_timestamp}'' AS processor_routing_identification,record_type,transmission_file_type,version_release_number,''{output_sender_id}'' AS sender_identifier,
        ''{output_receiver_id}'' AS receiver_identifier,submission_number,transaction_response_status,reject_code,record_length,reserved_1,transmission_date,transmission_time,
         CASE 
         WHEN to_date(date_of_service,''YYYYMMDD'') <  to_date(''20200701'', ''YYYYMMDD'') 
         AND CURRENT_DATE  < to_date(''20200701'', ''YYYYMMDD'') 
         THEN ''20200701'' 
         ELSE date_of_service 
         END, 
        service_provider_identifier_qualifier,service_provider_identifier,document_reference_identifier_qualifier,document_reference_identifier,transmission_identifier, 
        benefit_type,in_network_indicator,formulary_status,accumulator_action_code,sender_reference_number,insurance_code,
        accumulator_balance_benefit_type,benefit_effective_date,benefit_termination_date,accumulator_change_source_code,transaction_identifier,transaction_identifier_cross_reference,
        adjustment_reason_code,accumulator_reference_time_stamp,reserved_2,cardholder_identifier,group_identifier,patient_first_name,
        middle_initial,patient_last_name,patient_relationship_code,date_of_birth,patient_gender_code,
        patient_state_province_address,cardholder_last_name,carrier_number,contract_number,client_pass_through,family_identifier_number,
        cardholder_identifier_alternate,group_identifier_alternate,patient_identifier,person_code,reserved_3,accumulator_balance_count,accumulator_specific_category_type,
        reserved_4,accumulator_1_balance_qualifier,accumulator_1_network_indicator,accumulator_1_applied_amount,accumulator_1_applied_amount_action_code,
        accumulator_1_benefit_period_amount,accumulator_1_benefit_period_amount_action_code,accumulator_1_remaining_balance,accumulator_1_remaining_balance_action_code,accumulator_2_balance_qualifier,
        accumulator_2_network_indicator,accumulator_2_applied_amount,accumulator_2_applied_amount_action_code,accumulator_2_benefit_period_amount,accumulator_2_benefit_period_amount_action_code,
        accumulator_2_remaining_balance,accumulator_2_remaining_balance_action_code,accumulator_3_balance_qualifier,accumulator_3_network_indicator,accumulator_3_applied_amount,
        accumulator_3_applied_amount_action_code,accumulator_3_benefit_period_amount,accumulator_3_benefit_period_amount_action_code,accumulator_3_remaining_balance,accumulator_3_remaining_balance_action_code,
        accumulator_4_balance_qualifier,accumulator_4_network_indicator,accumulator_4_applied_amount,accumulator_4_applied_amount_action_code,accumulator_4_benefit_period_amount,
        accumulator_4_benefit_period_amount_action_code,accumulator_4_remaining_balance,accumulator_4_remaining_balance_action_code,'' '' as accumulator_5_balance_qualifier,'' '' as 
        accumulator_5_network_indicator,''0000000000'' as accumulator_5_applied_amount,'' '' as accumulator_5_applied_amount_action_code,''0000000000'' as 
        accumulator_5_benefit_period_amount,'' '' as accumulator_5_benefit_period_amount_action_code,''0000000000'' as accumulator_5_remaining_balance,
        '' '' as accumulator_5_remaining_balance_action_code,'' '' as accumulator_6_balance_qualifier,'' '' as accumulator_6_network_indicator,
        ''0000000000'' as accumulator_6_applied_amount,'' '' as accumulator_6_applied_amount_action_code,''0000000000'' as accumulator_6_benefit_period_amount,
        '' '' as accumulator_6_benefit_period_amount_action_code,''0000000000'' as accumulator_6_remaining_balance,'' '' as accumulator_6_remaining_balance_action_code,'' '' as reserved_5, 
        '' '' as accumulator_7_balance_qualifier,'' '' as accumulator_7_network_indicator,''0000000000'' as accumulator_7_applied_amount,
        '' '' as accumulator_7_applied_amount_action_code,''0000000000'' as accumulator_7_benefit_period_amount,'' '' as accumulator_7_benefit_period_amount_action_code,
        ''0000000000'' as accumulator_7_remaining_balance,'' '' as accumulator_7_remaining_balance_action_code,'' '' as accumulator_8_balance_qualifier,
        '' '' as accumulator_8_network_indicator,''0000000000'' as accumulator_8_applied_amount,'' '' as accumulator_8_applied_amount_action_code,
        ''0000000000'' as accumulator_8_benefit_period_amount,'' '' as accumulator_8_benefit_period_amount_action_code,''0000000000'' as accumulator_8_remaining_balance,
        '' '' as accumulator_8_remaining_balance_action_code,'' '' as accumulator_9_balance_qualifier,'' '' as accumulator_9_network_indicator,
        ''0000000000'' as accumulator_9_applied_amount,'' '' as accumulator_9_applied_amount_action_code,''0000000000'' as accumulator_9_benefit_period_amount,
        '' '' as accumulator_9_benefit_period_amount_action_code,''0000000000'' as accumulator_9_remaining_balance,'' '' as accumulator_9_remaining_balance_action_code,
        '' '' as accumulator_10_balance_qualifier,'' '' as accumulator_10_network_indicator,''0000000000'' as accumulator_10_applied_amount,
        '' '' as accumulator_10_applied_amount_action_code,''0000000000'' as accumulator_10_benefit_period_amount,'' '' as accumulator_10_benefit_period_amount_action_code,
        ''0000000000'' as accumulator_10_remaining_balance,'' '' as accumulator_10_remaining_balance_action_code,'' '' as accumulator_11_balance_qualifier,
        '' '' as accumulator_11_network_indicator,''0000000000'' as accumulator_11_applied_amount,'' '' as accumulator_11_applied_amount_action_code,
        ''0000000000'' as accumulator_11_benefit_period_amount,'' '' as accumulator_11_benefit_period_amount_action_code,''0000000000'' as accumulator_11_remaining_balance,
        '' '' as accumulator_11_remaining_balance_action_code,'' '' as accumulator_12_balance_qualifier,'' '' as accumulator_12_network_indicator,
        ''0000000000'' as accumulator_12_applied_amount,'' '' as accumulator_12_applied_amount_action_code,''0000000000'' as accumulator_12_benefit_period_amount,
        '' '' as accumulator_12_benefit_period_amount_action_code,''0000000000'' as accumulator_12_remaining_balance,'' '' as accumulator_12_remaining_balance_action_code,
        '' '' as optional_data_indicator,''0000000000'' as total_amount_paid,
        '' '' as total_amount_paid_action_code,''0000000000'' as amount_of_copay,'' '' as amount_of_copay_action_code,''0000000000'' as 
        patient_pay_amount,'' '' as patient_pay_amount_action_code,''0000000000'' as amount_attributed_to_product_selection_brand,
        '' '' as amount_attributed_to_product_selection_brand_action_code,''0000000000'' as amount_attributed_to_sales_tax,'' '' as amount_attributed_to_sales_tax_action_code,''0000000000'' as 
        amount_attributed_to_processor_fee,'' '' as amount_attributed_to_processor_fee_action_code,''0000000000'' as gross_amount_due,
        '' '' as gross_amount_due_action_code,''0000000000'' as invoiced_amount,'' '' as invoiced_amount_action_code,''0000000000'' as 
        penalty_amount,'' '' as penalty_amount_action_code,'' '' as reserved_6,'' '' as product_service_identifier_qualifier,
        '' '' as product_service_identifier,''000'' as days_supply,''0000000000'' as quantity_dispensed,
        '' '' as product_service_name,'' '' as brand_generic_indicator,'' '' as therapeutic_class_code_qualifier,
        '' '' as therapeutic_class_code,'' '' as dispensed_as_written,'' '' as reserved_7 
        FROM (select * from {SCHEMA_DW}.{TABLE_ACCUM_DETAIL_DW} where job_key =''{job.job_key}'') a left join 
        (select * from (select *,rank () over (partition by job_key, line_number order by error_level asc, file_column_id asc ) rnk 
        from (SELECT d.validation_result, d.job_key , d.line_number, c.file_column_id,c.error_level , 
        c.column_rules_id FROM {SCHEMA_DW}.{TABLE_COLUMN_RULES} c JOIN {SCHEMA_DW}.{TABLE_FILE_VALIDATION_RESULT} as d 
        ON c.column_rules_id = d.column_rules_id where d.validation_result=''N'' )A)Z where rnk=1 and error_level=1) b 
        ON a.job_key = b.job_key and a.line_number=b.line_number 
        WHERE a.sender_identifier=''{input_sender_id}'' and a.job_key=''{job.job_key}'' and b.error_level is null order by a.accumulator_detail_key') 
        TO 's3://{s3_accumhub_bucket}/{s3_outbound_detail_file}' iam_role '{iam_arn}' 
        FIXEDWIDTH 
        '0:200,1:2,2:2,3:2,4:30,5:30,6:4,7:1,8:3,9:5,10:20,11:8,12:8,13:8,14:2,15:15,16:2,17:15,18:50,19:1,20:1,21:1,
        22:2,23:30,24:20,25:1,26:8,27:8,28:1,29:30,30:30,31:1,32:26,33:13,34:20,35:15,36:25,37:1,38:35,39:1,40:8,41:1,
        42:2,43:35,44:9,45:15,46:50,47:20,48:20,49:15,50:20,51:3,52:90,53:2,54:2,55:20,56:2,57:1,58:10,59:1,60:10,61:1,
        62:10,63:1,64:2,65:1,66:10,67:1,68:10,69:1,70:10,71:1,72:2,73:1,74:10,75:1,76:10,77:1,78:10,79:1,80:2,81:1,
        82:10,83:1,84:10,85:1,86:10,87:1,88:2,89:1,90:10,91:1,92:10,93:1,94:10,95:1,96:2,97:1,98:10,99:1,100:10,101:1,
        102:10,103:1,104:24,105:2,106:1,107:10,108:1,109:10,110:1,111:10,112:1,113:2,114:1,115:10,116:1,117:10,118:1,
        119:10,120:1,121:2,122:1,123:10,124:1,125:10,126:1,127:10,128:1,129:2,130:1,131:10,132:1,133:10,134:1,135:10,
        136:1,137:2,138:1,139:10,140:1,141:10,142:1,143:10,144:1,145:2,146:1,147:10,148:1,149:10,150:1,151:10,152:1,
        153:1,154:10,155:1,156:10,157:1,158:10,159:1,160:10,161:1,162:10,163:1,164:10,165:1,166:10,167:1,168:10,169:1,
        170:10,171:1,172:23,173:2,174:19,175:3,176:10,177:30,178:1,179:1,180:17,181:1,182:48' 
        ALLOWOVERWRITE 
        parallel off;"""

    logger.info("( CVS DETAIL): %s", unload_detail_query)
    execute_query(conn, unload_detail_query)
    return None


def unload_header_table(
    conn,
    process_routing_timestamp: str,
    transmission_type: str,
    timestamp_src_creation: str,
    output_sender_id: str,
    output_receiver_id: str,
    file_type: str,
    s3_accumhub_bucket: str,
    s3_outbound_header_file: str,
    iam_arn: str,
) -> None:
    """Exports records to outbound folder s3://s3_out_bucket/s3_out_header_file  file in fixed-width format

    Args:
        conn ([type]):  Redshift Connection
        process_routing_timestamp (str): It is made of the output_sender_id + current eastern time stamp in the format of %m%d%Y%H%M%S
        transmission_type (str): transmission_type read from db
        timestamp_src_creation (str): timestamp in form of eastern HHMM
        output_sender_id (str): output_sender_id read from the Lambda environment variable
        output_receiver_id (str): output_receiver_id read from the Lambda envirionment variable
        file_type (str):  file type read from the Lambda envirionment variable
        s3_accumhub_bucket (str): output bucket where the S3 file will be written to
        s3_outbound_header_file (str): output file name
        iam_arn (str): IAM Role
    """
    unload_header_query = f"""UNLOAD ('select ''{process_routing_timestamp}'' AS PRCS_ROUT_ID,''HD'' AS RECD_TYPE,
        ''{transmission_type}'' AS TRANSMISSION_FILE_TYP, 
        to_char(sysdate, ''YYYYMMDD'') AS SRC_CREATE_DT,''{timestamp_src_creation}'' AS SRC_CREATE_TS, 
        ''{output_sender_id}'' AS SENDER_ID, ''{output_receiver_id}'' AS RECEIVER_ID,''0000001'' AS BATCH_NBR,
        ''{file_type}'' AS FILE_TYP,''10'' AS VER_RELEASE_NBR, 
        '' '' AS RESERVED_SP') 
        TO 's3://{s3_accumhub_bucket}/{s3_outbound_header_file}' iam_role '{iam_arn}' 
        FIXEDWIDTH 
        '0:200,1:2,2:1,3:8,4:4,5:30,6:30,7:7,8:1,9:2,10:1415' 
        ALLOWOVERWRITE 
        parallel off;"""

    logger.info("unload_header_query  = %s", unload_header_query)
    execute_query(conn, unload_header_query)
    return None
    # logging.debug(unl_hdr)


# This query needs to be optimized...
def unload_trailer_table(
    conn,
    process_routing_timestamp: str,
    s3_accumhub_bucket: str,
    s3_outbound_trailer_file: str,
    iam_arn: str,
    job: Job,
) -> None:
    """Exports records to s3_out_bucket\s3_out_trailer_file  as a trailer file in fixed-width format

    Args:
        conn ([type]): Redshift Connection
        process_routing_timestamp (str): It is made of the output_sender_id + current eastern time stamp in the format of %m%d%Y%H%M%S
        s3_accumhub_bucket (str): output bucket where the S3 file will be written to
        s3_outbound_trailer_file (str): output file name
        iam_arn (str): IAM Role
        job (Job): Job containing the  critical information about the job getting executed.
    """
    unload_trailer_query = f"""UNLOAD ('select ''{process_routing_timestamp}'' AS PRCS_ROUT_ID,''TR'' AS RECD_TYPE,''0000001'' AS BATCH_NBR,
        lpad(c.cnt,10,''0'') AS REC_CNT,'' '' AS MSG_TXT,'' ''AS RESERVED_SP from 
        (select cast(count(1) as varchar)cnt from 
        {SCHEMA_DW}.{TABLE_ACCUM_DETAIL_DW} a 
        left join (select * from (select line_number,job_key,validation_result,error_level,rank() over (partition by job_key, line_number 
        order by error_level asc, file_column_id asc) rnk from (select d.validation_result, d.job_key, d.line_number, 
        c.file_column_id,c.error_level,c.column_rules_id from {SCHEMA_DW}.{TABLE_COLUMN_RULES} c 
        join {SCHEMA_DW}.{TABLE_FILE_VALIDATION_RESULT} d on c.column_rules_id = d.column_rules_id 
        where validation_result=''N'' and job_key = {job.job_key})A)Z  where rnk=1 and error_level = 1) b  
        on a.line_number=b.line_number and a.job_key = b.job_key 
        where a.job_key = {job.job_key} and b.validation_result is null) c ') 
        TO 's3://{s3_accumhub_bucket}/{s3_outbound_trailer_file}' iam_role '{iam_arn}' 
        FIXEDWIDTH 
        '0:200,1:2,2:7,3:10,4:80,5:1401' 
        ALLOWOVERWRITE 
        parallel off;"""

    execute_query(conn, unload_trailer_query)
    return None


def process_bci_error_file_and_load_in_database(
    job: Job, job_name: Optional[str] = "Load BCI Error File in to Database"
) -> Job:
    """Incoming bci error file storage function. Please note that the incoming error file
    is stored in ahub_dw.accuulator detail table

    Arguments:
        arguments {List[str]} -- Arguments inherited from Lambda
        job {Job} -- Job Object

    Keyword Arguments:
        job_name {Optional[str]} -- Optional with default as  {"Load BCI Error File in to Database"}

    Returns:
        Job -- Returns a Job object
    """
    # create_redshift_connection(redshift_host, redshift_port, redshift_database, redshift_user, redshift_password)
    conn = get_connection(job.secret_name)
    s3_accumhub_bucket = job.s3_bucket_name
    iam_arn = job.client_file_info.redshift_glue_iam_role_arn
    s3_inbound_detail_file = job.get_path(job.detail_file_name)

    error_occured = False

    # Code below needs to be refactored , but it has been used in several places, it would be better if we
    # all put one-time effort and get ti cleaned everywhere

    job.job_name = job_name
    job.job_status = RUNNING
    job.job_start_timestamp = get_timestamp()
    job.input_file_name = s3_inbound_detail_file
    job.output_file_name = ""
    job.post_processing_file_location = ""

    # Create job detail log
    job_detail_key = insert_job_detail_log(
        conn=conn,
        schema=SCHEMA_DW,
        job=job,
        sequence_number=3,
    )

    if job_detail_key == 0:
        logger.debug(
            " Database Error occured when trying to insert record into ahub_dw.job_detail table"
        )
        error_occured = True
        job.error_message = "Database Error occured"
    else:
        logger.info("Generated ID is %s", job_detail_key)
        job.job_detail_key = job_detail_key

    logger.info("Job Object Information is : %s", job)

    if error_occured:
        _update_job_detail_log(error_occured, job, conn, SCHEMA_DW)
        return job

    logger.info("Calling load_s3_file_into_table")

    columns = get_client_files_import_columns(conn, SCHEMA_DW, TABLE_CLIENT_FILES, job)
    if columns is None or columns == "":
        error_occured = True
        job.error_message = (
            "Unable to retrieve import columns for Accumulator Reconciliation Detail table"
        )
        _update_job_detail_log(error_occured, job, conn, SCHEMA_DW)
        return job

    if not job.outbound_file_generation_complete:
        load_s3_file_into_table_column_specific(
            conn,
            SCHEMA_DW,
            TABLE_ACCUM_DETAIL_DW,
            columns,
            s3_accumhub_bucket,
            s3_inbound_detail_file,
            iam_arn,
        )

    logger.info("load_s3_file_into_table completed")
    delete_s3_files(s3_accumhub_bucket, f"{job.file_processing_location}/{str(job.job_key)}_")
    logger.info("inbound temp folder file clean up process is completed")
    _update_job_detail_log(error_occured, job, conn, SCHEMA_DW)
    return job
