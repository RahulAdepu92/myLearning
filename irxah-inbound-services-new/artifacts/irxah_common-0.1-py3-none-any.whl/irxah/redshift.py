import boto3
import json
import logging
import os


from typing import Optional, Iterable, Tuple
from botocore.exceptions import ClientError
from .constants import (
    SCHEMA_DW,
    TABLE_FILE_VALIDATION_RESULT,
    TABLE_ACCUM_DETAIL_DW,
    TABLE_CLIENT,
    TABLE_CLIENT_FILES,
)
from .glue import get_glue_logger
from .model import Job

logger = get_glue_logger(name=f"{__name__}", logging_level=logging.DEBUG)

try:
    import pg

    db_module = "pg"

except ImportError:
    logger.exception(" Error occured while importing pg module in redshift.py")

session = boto3.session.Session()
region_name = session.region_name


def get_connection(secret_name: str = None):
    """Returns a redshift connection
    Keyword Arguments:
        secret_name {str} -- [description] (default: {None})
    Returns:
        [type] -- [description]
    """
    secret_name = secret_name if secret_name is not None else os.environ.get("SECRET_NAME", "dv")
    secret_json = get_redshift_credentials_as_json(secret_name, region_name)
    secret = json.loads(secret_json)
    redshift_user = secret.get("username")
    redshift_password = secret.get("password")
    redshift_host = secret.get("host")
    redshift_port = secret.get("port")
    redshift_database = secret.get("dbname")
    conn = create_redshift_connection(
        redshift_host, redshift_port, redshift_database, redshift_user, redshift_password
    )
    return conn


def create_redshift_connection(host: str, port: str, db_name: str, user: str, password: str):
    """
    Function to establish a connection with Redshift using psycopg2
    :param host: Host (IP) of the Redshift cluster
    :param port: Port of the Redshift database
    :param db_name: Name of the Redshift database
    :param user: Name of the Redshift master user
    :param password: Password for the Redshift master password
    :return: Returns a Redshift connection object
    """

    conn_string = "host={} port={} dbname={} user={} password={}".format(
        host,
        port,
        db_name,
        user,
        password,
    )
    conn = pg.connect(dbname=conn_string)
    return conn


def get_redshift_credentials_as_json(secret_name: str, region_name: str) -> str:
    """Returns the redshift credentials as a JSON string.
    :param secret_name: Optional parameter. Specify the secret_name to establish Redshift connection.
    :param region_name: the region in which the credentials are stored (default us-east-1)
    :return: The JSON will contain the following keys:
    username, password, host, port, dbname
    """

    secret = ""
    # secret_name = f"irx-ahub-{environment}-redshift-cluster"

    # Create a Secrets Manager client
    logging.debug("Getting Secret %s", secret_name)
    client = session.client(service_name="secretsmanager", region_name=region_name)
    try:
        get_secret_value_response = client.get_secret_value(SecretId=secret_name)
    except ClientError as error:
        if error.response["Error"]["Code"] == "DecryptionFailureException":
            raise error
        if error.response["Error"]["Code"] == "InternalServiceErrorException":
            raise error
        if error.response["Error"]["Code"] == "InvalidParameterException":
            raise error
        if error.response["Error"]["Code"] == "InvalidRequestException":
            raise error
        if error.response["Error"]["Code"] == "ResourceNotFoundException":
            raise error
    else:
        if "SecretString" in get_secret_value_response:
            secret = get_secret_value_response["SecretString"]

    return secret


def get_redshift_credentials_as_tuple(secret_name: str) -> Tuple[str, str, str, str, str]:
    """Returns the redshift credentials as tuple.
    :param secret_name: Optional parameter. Specify the secret_name to establish Redshift connection.
    :return: The tuple will contain the following keys:
    username, password, host, port, dbname
    """
    secret_name = secret_name if secret_name is not None else os.environ.get("SECRET_NAME", "dv")
    secret_json = get_redshift_credentials_as_json(secret_name, region_name)
    secret = json.loads(secret_json)
    return (
        secret.get("username"),
        secret.get("password"),
        secret.get("host"),
        secret.get("port"),
        secret.get("dbname"),
    )


def execute_query(conn, query: str, query_args: Optional[Iterable] = None):
    """Executes a query against a connection.
    :param conn: a conn opened with get_connection
    :param  query: a sql query. can be parametrized using old-style pg ($1, $2)
    :param query_args: a positional iterable (list, tuple) matching the parameters in query
    :return: a query object if select, or the number of affected rows if insert/update/delete

    :Example:
    >>> result = execute_query(conn, "select top 5 from schema.table")
    >>> result.getresult() # rows as list of tuples
    >>> result = execute_query(conn, "select * from schema.table where key=$1", (5, ))
    >>> result.dictresult() # rows as list of dictionaries
    >>> execute_query(conn, "insert into schema.table (col1, col2) values ($1, $2)", ['a', 2])
    1
    """
    if query_args is not None:
        try:
            return conn.query(query, query_args)
        except pg.ProgrammingError:
            logging.exception("Error executing query: %s with parameters: %r", query, query_args)
            return None
    else:
        try:
            return conn.query(query)
        except pg.ProgrammingError:
            logging.exception("Error executing query: %s", query)
            return None


def load_s3_file_into_table(
    conn, db_schema: str, redshift_table: str, s3_in_bucket: str, s3_in_file: str, iam_role
) -> None:
    """
    Loads file from S3 bucket and into specified redshift tables
    :param conn: an opened conn (see create_redshift_connection)
    :param db_schema: The schema for the database
    :param redshift_table: The table for client files. This table should have the import_columns information.
    :param s3_in_bucket: s3 bucket name of incoming file
    :param s3_in_file: s3 file name with path of incoming file
    :param iam_role: IAM role which allows file copy operation from s3 to redshift database
    """
    copy_query = f"COPY {db_schema}.{redshift_table} FROM 's3://{s3_in_bucket}/{s3_in_file}' iam_role '{iam_role}' delimiter '|';"
    logger.info(" Query is : %s", copy_query)
    conn.query(copy_query)
    logging.info(
        "Loaded %s into %s", os.path.join(s3_in_bucket, s3_in_file), f"{db_schema}.{redshift_table}"
    )


def load_s3_file_into_table_column_specific(
    connection,
    db_schema: str,
    redshift_table: str,
    columns: str,
    s3_in_bucket: str,
    s3_in_file: str,
    iam_role,
) -> None:
    """Loads file from S3 bucket and into specified redshift tables, column specific
    :param connection: The connection to Redshift
    :param db_schema: The schema for the database
    :param redshift_table: The table for client files. This table should have the import_columns information.
    :param columns: specific columns into which the data is copied from s3 file
    :param s3_in_bucket: s3 bucket name of incoming file
    :param s3_in_file: s3 file name with path of incoming file
    :param iam_role: IAM role which allows file copy operation from s3 to redshift database

    Constructs the SQL dialect as follows :

            copy ahub_dw.FILE_VALIDATION_RESULT (job_key,line_number,column_number,validation_result,error_message)
        FROM 's3://irx-accumhub-dv-data2/log/data.txt'
        iam_role 'arn:aws:iam::474156701944:role/IRX-IDW-Redshift'
        region 'us-east-1'
        delimiter '|';"""
    copy_query = f"COPY {db_schema}.{redshift_table} ({columns}) FROM 's3://{s3_in_bucket}/{s3_in_file}' iam_role '{iam_role}' delimiter '|';"
    logger.info(" Query is : %s", copy_query)
    connection.query(copy_query)
    logging.info(
        "Loaded %s into %s", os.path.join(s3_in_bucket, s3_in_file), f"{db_schema}.{redshift_table}"
    )


def insert_id(
    redshift_connection,
    insert_sql: str,
    insert_sql_args,
    select_sql: Optional[str] = None,
    select_sql_args=None,
):
    """
    Executes an insert statement and an optional select statement if the insert was successful.
    :param redshift_connection: an opened conn (see create_redshift_connection)
    :param insert_sql: the insert sql statement on a table
    :param insert_sql_args: arguments passed to the insert sql statement
    :param select_sql: optional parameter. runs the select sql statement
    :param select_sql_args: takes the select sql statement arguments
    :returns: the first column if select_sql was present, or the number of inserted records otherwise"""
    logger.info(
        " insert_sql = %s",
        insert_sql,
    )
    rows_affected = execute_query(redshift_connection, insert_sql, insert_sql_args)
    logger.info(
        " rows_affected = %s",
        rows_affected,
    )
    if int(rows_affected) == 1 and select_sql is not None:
        logger.info(" select_sql = %s", insert_sql)
        result_query = execute_query(redshift_connection, select_sql, select_sql_args)
        first_row = result_query.getresult()
        if first_row is not None:
            logger.info(
                " my_job_key = %s",
                first_row,
            )
            return int(first_row[0][0])

        return rows_affected
    return rows_affected


def remove_columns(
    comma_seperated_list_of_all_columns: str, comma_seperated_list_of_columns_to_be_ignored: str
) -> str:
    """Takes the list of columns as a first argument, and the list of columns ( which would be the subset of the first argument) and removes it from the list
    :param comma_seperated_list_of_all_columns:  comma seperated list of columns
    :param comma_seperated_list_of_columns_to_be_ignored : comma seperated list of columns to be ignored from the first argument.
    EXAMPLE
    the comma_seperated_list_of_all_columns = “A, B,C, D, E, G, M, H , I, J,K”
    comma_seperated_list_of_columns_to_be_ignored=“A,J,K”
    the functtion will return the string : "B,C,D,E,G,M,H,I"
    """
    list_of_columns_to_be_ignored = comma_seperated_list_of_columns_to_be_ignored.split(",")

    for column_to_be_ignored in list_of_columns_to_be_ignored:
        columns_to_be_ignored_with_comma_at_end = column_to_be_ignored + ","
        columns_to_be_ignored_with_comma_at_begin = "," + column_to_be_ignored
        if comma_seperated_list_of_all_columns.count(columns_to_be_ignored_with_comma_at_end) > 0:
            comma_seperated_list_of_all_columns = comma_seperated_list_of_all_columns.replace(
                columns_to_be_ignored_with_comma_at_end, ""
            )
        else:
            if (
                comma_seperated_list_of_all_columns.count(columns_to_be_ignored_with_comma_at_begin)
                > 0
            ):
                comma_seperated_list_of_all_columns = comma_seperated_list_of_all_columns.replace(
                    columns_to_be_ignored_with_comma_at_begin, ""
                )
    return comma_seperated_list_of_all_columns


def get_column_names(
    schema_name,
    table_name,
    connection=None,
    secret_name: Optional[str] = None,
    ignore_columns: Optional[str] = None,
) -> str:
    """Returns the string as a list of comma seperated list for  a given schema_name and table_name.
    :param schema_name: the name of the schema such as ahub_dw or ahubg_stg
    :param table_name : the name of the table for which you need to know column names
    :param connection :  If it( Redshift connection)  is specified it uses that one to query,
      if None is passed then it uses the secret_name to establish the connection.
    :param secret_name:  Function establishes the connection in case if no connection is specified
    :param ignore_columns : The list of columns that will be automatically removed from the resultant column list.
    :return: The string of column names
    NOTE : If both connection and secret_name are non-empty , the function uses the connection. If both are empty then None is returned
    If the function usually returns the list “A, B,C, D, E, G, M, H , I, J,K” and if the function is called with the following argument
    get_column_names( schema_name, table_name, connection, None, “A,J,K”) then it returns the B,C, D, E, G, M, H , I only.
    """

    select_sql = "select column_name  from information_schema.columns where  table_schema=$1 and table_name=$2 order by ordinal_position"
    if connection is None:
        if secret_name is not None:
            connection = get_connection(secret_name)
        else:
            return None

    return_value = ""

    select_sql_args = (
        schema_name,
        table_name,
    )
    result = execute_query(connection, select_sql, select_sql_args)
    records = result.getresult()
    list_of_columns = []
    for row in records:
        list_of_columns.append(row[0])  # Column Name

    if list_of_columns is not None:
        seperator = ","
        return_value = seperator.join(list_of_columns)

    if ignore_columns is not None:
        return_value = remove_columns(return_value, ignore_columns)

    return return_value


def get_client_files_import_columns(
    connection,
    db_schema: str,
    redshift_table: str,
    job: Job,
    secret_name: Optional[str] = None,
) -> str:
    """This function allows you to read the client_files table and retrieve the column names for a specific job"
    :param connection: The connection to Redshift
    :param db_schema: The schema for the database
    :param redshift_table: The table for client files. This table should have the import_columns information.
    :param job: The job object to search for import columns. It should contain the client_file_id, client_id, sender_id, and receiver_id.
    :param secret_name: Optional param. Specify the secret_name for the Redshift connection.
    """
    select_sql = f"select import_columns from {db_schema}.{redshift_table} where client_file_id=$1 and client_id=$2 and input_sender_id=$3 and input_receiver_id=$4"
    if connection is None:
        if secret_name is not None:
            connection = get_connection(secret_name)
        else:
            return None
    return_value = ""

    select_sql_args = (
        job.client_file_id,
        job.client_id,
        job.input_sender_id,
        job.input_receiver_id,
    )
    logger.info(
        " sql = %s :: args = %s",
        select_sql,
        select_sql_args,
    )
    result = execute_query(connection, select_sql, select_sql_args)
    records = result.getresult()
    if records is not None and records != []:
        logger.info(
            " record = %s",
            records,
        )
        return_value = str(records[0][0])

    return return_value


def record_duplicate_transmission_identifier(
    connection,
    column_rule_id: int,
    column_position: str,
    error_code: int,
    error_level: int,
    job_key: int,
) -> None:
    """This method takes the job key, identifies duplicate in the permanent table and reports it in to the validation result
    :param connection: The connection to Redshift
    :param column_rule_id: The column rule id , the rule which is failing
    :param column_position: position value of column TRANSMISSION_ID
    :param error_code : Error code to report for duplicate transmission
    :param error_level : Error Level to report for duplicate transmission
    :param job_key: job_key
    """
    select_sql = (
        f"INSERT INTO {SCHEMA_DW}.{TABLE_FILE_VALIDATION_RESULT} (job_key,line_number,column_rules_id, validation_result,error_message) "
        f"SELECT {job_key}, CR.line_number, {column_rule_id}, 'N', 'Column : Transmission ID  at position {column_position} is duplicate. "
        f" Duplicate Value is ' || CR.TRANSMISSION_IDENTIFIER || ' Error Code : {error_code}, Error Level : {error_level} ' "
        f"FROM "
        f" (SELECT a.line_number,"
        f"  ROW_NUMBER() OVER(PARTITION BY a.TRANSMISSION_IDENTIFIER ORDER BY A.LINE_NUMBER )"
        f"AS ROW_NUM , count(a.TRANSMISSION_IDENTIFIER) over ( partition by a.TRANSMISSION_IDENTIFIER ) AS V_COUNT ,  a.TRANSMISSION_IDENTIFIER "
        f"from {SCHEMA_DW}.{TABLE_ACCUM_DETAIL_DW} a WHERE a.job_key=$1 ) CR "
        f"WHERE CR.V_COUNT > 1"
        f"AND CR.ROW_NUM > 1 "
        f"ORDER BY   CR.V_COUNT DESC,CR.ROW_NUM ASC"
    )

    select_sql_args = (job_key,)
    logger.info(
        "sql = %s :: args = %s",
        select_sql,
        select_sql_args,
    )
    result = execute_query(connection, select_sql, select_sql_args)
    ## There should be some kind of validations upon execution of the above should be done
    ## For example how many records affected etc. How we code it right with pg module ?


def get_client_id(
    connection: str,
    schema: str,
    client_name: str,
) -> str:
    """Returns the client id from the Client Abbreviated Name
    :param connection: The connection to Redshift
    :param schema: the database schema
    :param client_name : the client name from incoiming file path
    :return client_id : the client id for a given client
    """
    client_id = ""
    select_sql = (
        f"select client_id  from {schema}.{TABLE_CLIENT} where  upper(abbreviated_name)=upper($1)"
    )

    select_sql_args = (client_name,)
    result = execute_query(connection, select_sql, select_sql_args)
    records = result.getresult()
    if records is not None and records != []:
        logger.info(
            " record = %s",
            records,
        )
        client_id = str(records[0][0])
    logging.debug("client_id for client name %s : %s", client_name, client_id)

    return client_id


def cleanup_table(
    conn,
    db_schema: str,
    table_name: str,
    conditional_column: Optional[str] = None,
    conditional_value: Optional[str] = None,
):
    """
    Cleans up the specified table.
    :param conn: an opened conn (see create_redshift_connection)
    :param db_schema: name of database scheme
    :param table_name: name of table within db_schema
    :param conditional_column: Optional parameter. Takes the name of specific column on which delete operation is to be performed
    :param conditional_value: Optional parameter. Specifies if any special condition is required before performing deletion operation
    """
    # TODO: beware of Little Bobby Tables injection: https://xkcd.com/327/
    if conditional_column is not None and conditional_value is not None:
        delete_query = "DELETE FROM {schema}.{table} WHERE {column}=$1".format(
            schema=db_schema, table=table_name, column=conditional_column
        )
        logger.info("Delete Query is : %s", delete_query)
        conn.query(delete_query, (conditional_value,))
    else:
        truncate = "truncate table {}.{} ".format(db_schema, table_name)
        logger.info("Truncate Query is : %s", truncate)
        conn.query(truncate)


def get_error_records_count(conn, job_key: int):
    """
    This function gets the total number of error records in the incoming file that got recorded in 'ahub_dw.file_validation_result' table:
    :param conn: connection establishment to redshift table via pg module
    :param job_key: job object which should be populated from model.py
    """
    error_records_query = f"""select cnt from (
                select job_key,count(job_key)cnt from( 
                    select job_key from( 
                        select job_key,line_number,row_number() over (partition by job_key,line_number) rnum FROM  {SCHEMA_DW}.{TABLE_FILE_VALIDATION_RESULT} 
                        where job_key ={job_key} and validation_result='N' )x 
                    where rnum =1 )y 
                group by job_key )z"""
    logger.info("process_flow.py : notify_data_error :  Execucting SQL %s", error_records_query)
    result = execute_query(conn, error_records_query)
    count = result.getresult()

    if count is not None:
        if len(count) != 0:
            return count

    logger.info("error_records_count_query: Result is None")
    return None


def get_detail_records_count(conn, job_key: int):
    """
    This function gets the total number of detail records in the incoming file that got recorded in 'ahub_dw.accumulator_detail' table:
    :param conn: connection establishment to redshift table via pg module
    :param job_key: job object which should be populated from model.py
    """
    detail_records_query = (
        f"select count(1)cnt from  {SCHEMA_DW}.{TABLE_ACCUM_DETAIL_DW} where job_key={job_key}"
    )
    logger.info(
        "( data_error_threshold <1 ) Executing the Query : %s ",
        detail_records_query,
    )
    result = execute_query(conn, detail_records_query)
    count = result.getresult()

    return count
