import os
import logging.config

from ..glue import get_glue_logger
from ..s3 import get_file_from_s3_trigger, move_file

logger = get_glue_logger(name=f"{__name__}", logging_level=logging.DEBUG)


def move_file_to_folder_handler(event, context) -> None:
    """ Prior Information:
    At present CFX send files to client specific folders <s3 bucket>\inbound\*bci* or *cvs*\srcfiles  folder.
    But AHub_489 aims at streamlining inound process where it eliminates sending files to client specific folders.
    CFX needs to be engaged if the existing files needs to be landed in the <s3 bucket>\inbound\srcfiles folder.
    Hence the existing inbound\bci\srcfiles and ability to process the file from there ( via trigger etc..) will stay as is.
    However, if CFX agrees to send the files to the <s3 bucket>\inbound\srcfiles , system will automatically pick it up from there.
    #TODO: After agreement is made with CFX, get rid of this whole py script and lambda function 'irxah_move_incoming_file_to_folder' and its associated s3 triggers.
    :param event: lambda event
    :param context: lambda context
    :return: None
    """
    try:
        logger.info(
            "Move to 'srcfiles' folder started. finding the file path of trigger event: %r", event
        )
        s3_bucket_name, incoming_file = get_file_from_s3_trigger(event)
        # incoming_file = inbound/<client_name>/srcfiles/filename.txt

        # path_folders => ['inbound', '<client_name>', 'srcfiles', 'filename.txt']
        path_folders = incoming_file.split(os.sep)
        # excludes the element from list and returns bci or cvs here
        client_name = path_folders.pop(1)
        # src_file_name_with_path -> inbound/srcfiles/filename.txt
        src_file_name_with_path = os.sep.join(path_folders)
        move_file(s3_bucket_name, incoming_file, s3_bucket_name, src_file_name_with_path)
    except:
        logging.exception("File path could not be retrieved from the S3 trigger event: %r", event)
        return
